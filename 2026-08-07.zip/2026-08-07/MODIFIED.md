﻿# Modified files — 2026-08-07

Copied from `web-08-09` (Auth/EApp split, no userId, callback fix).

| File | Change |
|------|--------|
| kofc_authclient.js | Shared MSAL only (KOFC.Auth) |
| kofc_eappClient.js | **New** — KOFC.Eapp Boomi client |
| kofc_authcallback.html | Fixed callApi; Blob pending restored |
| kofc_EappLeftSite | Uses KOFC.Eapp; no userId |
| kofc_Opportunity | Uses KOFC.Eapp; scope access_as_user |
| kofc_policyClient.js | Header/docs cleanup (no userId) |
| kofc_blobClient.js | SPA-forward comments |
| README.md | Package notes |

**Not copied** (unchanged in web-08-09): kofc_Eapp, kofc_Policy, kofc_policy_details, kofc_policy_details.html, kofc_blob_open.html, kofc_blobLinkBuilder.js, kofc_ContactService
