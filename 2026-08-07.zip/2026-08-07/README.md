# web-08-09 — D365 web resources (cleaned)

SPA-token forward model. Auth split from EApp. No `userId` on Boomi/Function hops.

## Naming (this package)

| File | Web resource Name | Role |
|------|-------------------|------|
| `kofc_authclient.js` | `kofc_authclient.js` | Shared `KOFC.Auth` (MSAL only) |
| `kofc_eappClient.js` | `kofc_eappClient.js` | **New** `KOFC.Eapp` (Boomi + open EApp) |
| `kofc_authcallback.html` | `kofc_authcallback.html` | Shared redirect (EApp / Policy / Blob) |
| `kofc_EappLeftSite` | `kofc_EappLeftSite` | Left-nav JS |
| `kofc_Eapp` | `kofc_Eapp` | Left-nav HTML shell |
| `kofc_Opportunity` | `kofc_Opportunity` | Opportunity form script |
| `kofc_policyClient.js` | `kofc_policyClient.js` | `KOFC.Policy` |
| `kofc_policy_details` | `kofc_policy_details` | Policy details page JS |
| `kofc_policy_details.html` | `kofc_policy_details.html` | Policy details HTML |
| `kofc_Policy` | `kofc_Policy` | Policy form script |
| `kofc_blobClient.js` | `kofc_blobClient.js` | `KOFC.Blob` |
| `kofc_blob_open.html` | `kofc_blob_open.html` | Blob opener page |
| `kofc_blobLinkBuilder.js` | `kofc_blobLinkBuilder.js` | Blob link builder |
| `kofc_ContactService` | `kofc_ContactService` | Contact form (unchanged Boomi path) |

Also required: `kofc_msalbrowsermin`.

## API

```javascript
KOFC.Eapp.configure(config);
KOFC.Eapp.openEapp(oppId, eappUrl);   // no userId
```

Ribbon: `KOFC.Eapp.callBoomi` (not `KOFC.Auth.callBoomi`).

## Env vars used here

- Shared SPA: `kofc_TenantId`, `kofc_SPAClientId`
- EApp: `kofc_EappApiAppId`, `kofc_EappApiKey`, `kofc_BoomieAppUrl`, `kofc_EappURL`
- Blob: `kofc_BlobApiAppId`, `kofc_BlobBoomiUrl` (+ shared key/tenant/client as configured)

## Fixes applied in this pass

1. Split `KOFC.Auth` / `KOFC.Eapp`
2. Removed `userId` from EApp/Policy Boomi payloads
3. Fixed broken `callApi` in callback (`qs` undefined)
4. Restored Blob pending handling in callback
5. Opportunity scope `.default` → `access_as_user`
6. Left-nav + Opportunity load `kofc_eappClient.js`
