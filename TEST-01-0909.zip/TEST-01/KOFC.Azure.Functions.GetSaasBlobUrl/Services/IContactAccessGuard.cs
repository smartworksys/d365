namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public interface IContactAccessGuard
{
    ContactAccessResult CheckContactAccess(Guid userId, Guid contactId);

    ContactAccessResult CheckContactAccessByEntraOid(Guid entraOid, Guid contactId);

    /// <summary>Resolves Entra oid to Dataverse systemuserid (no impersonation).</summary>
    Guid? ResolveSystemUserIdByEntraOid(Guid entraOid);
}
