namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public interface IBlobService
{
    /// <summary>
    /// Generates a read-only SAS URL for the specified blob with 15-minute expiration
    /// </summary>
    /// <param name="containerName">The name of the blob container</param>
    /// <param name="blobPath">The path to the blob within the container</param>
    /// <returns>The SAS URL for the blob</returns>
    Task<string> GenerateSasUrlAsync(string containerName, string blobPath);

    /// <summary>
    /// Normalizes a Windows file path to a blob-safe path
    /// </summary>
    /// <param name="rawPath">The raw Windows file path (e.g., D:\KOFCExt Extractions\09272024\file.xlsx)</param>
    /// <returns>Blob path within the container (e.g., KOFCExt Extractions/09272024/file.xlsx)</returns>
    string NormalizePathToBlob(string rawPath);
}

