using Xunit;

namespace KOFC_FA_PolicyNonHeader_TierOne.Tests.Support;

[CollectionDefinition("EnvironmentVariables", DisableParallelization = true)]
public sealed class EnvironmentVariablesCollection
{
}
