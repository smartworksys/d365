using KOFC_FA_PolicyNonHeader_TierOne.Models;
using KOFC_FA_PolicyNonHeader_TierOne.Services;

namespace KOFC_FA_PolicyNonHeader_TierOne.Tests.Support;

internal sealed class FakePolicyNonHeaderData : IPolicyNonHeaderData
{
    public PolicyNonHeaderResponse Response { get; set; } = new()
    {
        PolicyNumber = "123456"
    };

    public Task<PolicyNonHeaderResponse> GetPolicyNonHeaderDataAsyn(
        string source,
        string companyCode,
        string policyNo,
        string userName) =>
        Task.FromResult(Response);
}

internal sealed class FakePolicyTierOneIngeniumData : IPolicyTierOneIngeniumData
{
    public TierOneResponseJson Response { get; set; } = new()
    {
        DEATH_BENEFIT = "100000"
    };

    public Task<TierOneResponseJson> GetPolicyTierOneIngeniumDataAsync(string policyNo, string companyCode) =>
        Task.FromResult(Response);
}

internal sealed class FakePolicyTierOneLife70Data : IPolicyTierOneLife70Data
{
    public TierOneResponseJson Response { get; set; } = new()
    {
        DEATH_BENEFIT = "200000"
    };

    public Task<TierOneResponseJson> GetPolicyTierOneLife70Data(string policyNo, string companyCode) =>
        Task.FromResult(Response);
}
