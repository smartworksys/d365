namespace KOFC_FA_PolicyNonHeader_TierOne.Tests.Support;

/// <summary>
/// Sets process environment variables for one test and restores them on dispose.
/// A reentrant lock prevents parallel tests from clearing DataverseEntity
/// while a deny test is running (that race grants instead of AccessDenied).
/// </summary>
internal sealed class EnvironmentVariableScope : IDisposable
{
    private static readonly object Gate = new();
    private readonly Dictionary<string, string?> _originalValues = new(StringComparer.Ordinal);
    private bool _disposed;

    public EnvironmentVariableScope(params (string Name, string? Value)[] variables)
    {
        Monitor.Enter(Gate);
        try
        {
            foreach (var (name, value) in variables)
            {
                _originalValues[name] = Environment.GetEnvironmentVariable(name);
                Environment.SetEnvironmentVariable(name, value, EnvironmentVariableTarget.Process);
            }
        }
        catch
        {
            Monitor.Exit(Gate);
            throw;
        }
    }

    public void Dispose()
    {
        if (_disposed)
        {
            return;
        }

        _disposed = true;
        try
        {
            foreach (var (name, originalValue) in _originalValues)
            {
                Environment.SetEnvironmentVariable(name, originalValue, EnvironmentVariableTarget.Process);
            }
        }
        finally
        {
            Monitor.Exit(Gate);
        }
    }
}
