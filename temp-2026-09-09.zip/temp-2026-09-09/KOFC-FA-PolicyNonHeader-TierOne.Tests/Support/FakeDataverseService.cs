using KOFC_FA_PolicyNonHeader_TierOne.Services;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace KOFC_FA_PolicyNonHeader_TierOne.Tests.Support;

internal sealed class FakeDataverseService : IDataverseService
{
    public Guid CallerId { get; set; }

    public EntityCollection? UserEntities { get; set; }

    public EntityCollection? PolicyEntities { get; set; }

    public Entity? PolicyRetrieveEntity { get; set; }

    public Exception? RetrieveException { get; set; }

    public Entity Retrieve(string entityName, Guid id, ColumnSet columnSet)
    {
        if (RetrieveException != null)
        {
            throw RetrieveException;
        }

        if (PolicyRetrieveEntity != null && PolicyRetrieveEntity.Id == id)
        {
            return PolicyRetrieveEntity;
        }

        throw new InvalidOperationException($"Policy record '{id}' was not found.");
    }

    public EntityCollection RetrieveMultiple(QueryBase query)
    {
        if (query is not QueryExpression queryExpression)
        {
            return new EntityCollection();
        }

        if (string.Equals(queryExpression.EntityName, "systemuser", StringComparison.OrdinalIgnoreCase))
        {
            return UserEntities ?? new EntityCollection();
        }

        return PolicyEntities ?? new EntityCollection();
    }
}
