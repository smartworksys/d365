using KOFC_FA_PolicyNonHeader_TierOne.Helpers;

namespace KOFC_FA_PolicyNonHeader_TierOne.Tests;

public class LogSanitizerTests
{
    [Fact]
    public void Neutralize_RemovesCarriageReturnAndLineFeed()
    {
        var forged = "ok\r\nINFO Fake log entry";

        var sanitized = LogSanitizer.Neutralize(forged);

        Assert.Equal("okINFO Fake log entry", sanitized);
        Assert.DoesNotContain("\r", sanitized);
        Assert.DoesNotContain("\n", sanitized);
    }

    [Theory]
    [InlineData(null, "")]
    [InlineData("", "")]
    public void Neutralize_ReturnsEmptyForNullOrEmpty(string? value, string expected)
    {
        Assert.Equal(expected, LogSanitizer.Neutralize(value));
    }
}
