using KOFC_FA_PolicyNonHeader_TierOne.Helpers;

namespace KOFC_FA_PolicyNonHeader_TierOne.Tests;

public class NonHeaderUrlGuardTests
{
    private const string Template = "https://nonheader.example.com/api/{source}/{policyNo}/{userName}";

    [Fact]
    public void BuildAllowedUri_KeepsConfiguredHost()
    {
        var uri = NonHeaderUrlGuard.BuildAllowedUri(
            Template,
            "ing",
            "01",
            "1234567",
            "agent.user@kofc.org");

        Assert.Equal("https", uri.Scheme);
        Assert.Equal("nonheader.example.com", uri.Host);
        Assert.Equal("/api/ing/011234567/agent.user@kofc.org", uri.AbsolutePath);
    }

    [Fact]
    public void BuildAllowedUri_RejectsHostInjectionInSource()
    {
        var ex = Assert.Throws<InvalidOperationException>(() =>
            NonHeaderUrlGuard.BuildAllowedUri(
                Template,
                "ing@evil.example",
                "01",
                "1234567",
                "agent"));

        Assert.Contains("source", ex.Message, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void BuildAllowedUri_RejectsMissingTemplate()
    {
        var ex = Assert.Throws<InvalidOperationException>(() =>
            NonHeaderUrlGuard.BuildAllowedUri(string.Empty, "ing", "01", "123", "agent"));

        Assert.Contains("not configured", ex.Message, StringComparison.OrdinalIgnoreCase);
    }
}
