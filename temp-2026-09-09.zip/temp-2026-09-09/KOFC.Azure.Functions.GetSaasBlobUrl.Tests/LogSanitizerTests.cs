using KOFC.Azure.Functions.GetSaasBlobUrl.Helpers;
using Xunit;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests;

public class LogSanitizerTests
{
    [Fact]
    public void Neutralize_RemovesCarriageReturnAndLineFeed()
    {
        var forged = "ok\r\nINFO Fake log entry";

        var sanitized = LogSanitizer.Neutralize(forged);

        Assert.Equal("okINFO Fake log entry", sanitized);
        Assert.DoesNotContain("\r", sanitized);
        Assert.DoesNotContain("\n", sanitized);
    }

    [Fact]
    public void Neutralize_HtmlEncodesMarkup()
    {
        var sanitized = LogSanitizer.Neutralize("<script>alert(1)</script>");

        Assert.Equal("&lt;script&gt;alert(1)&lt;/script&gt;", sanitized);
    }

    [Theory]
    [InlineData(null, "")]
    [InlineData("", "")]
    public void Neutralize_ReturnsEmptyForNullOrEmpty(string? value, string expected)
    {
        Assert.Equal(expected, LogSanitizer.Neutralize(value));
    }
}
