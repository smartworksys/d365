using Azure.Core;
using Azure.Identity;
using KOFC_FA_PolicyNonHeader_TierOne.Helpers;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;
using System.Net;

namespace KOFC_FA_PolicyNonHeader_TierOne;

public static class DataverseServiceClientFactory
{
    public static ServiceClient Create(ILogger logger)
    {
        var crmUrl = Environment.GetEnvironmentVariable("CRM_URL")
            ?? throw new InvalidOperationException("CRM_URL is not configured.");

        var dataverseUri = new Uri(crmUrl);
        var credential = new DefaultAzureCredential();
        var scope = $"{dataverseUri.GetLeftPart(UriPartial.Authority)}/.default";

        var serviceClient = new ServiceClient(
            dataverseUri,
            async _ =>
            {
                var token = await credential.GetTokenAsync(
                    new TokenRequestContext(new[] { scope }),
                    CancellationToken.None);
                return token.Token;
            },
            useUniqueInstance: true);

        if (!serviceClient.IsReady)
        {
            logger.LogError("Failed to connect to CRM: {Error}", WebUtility.HtmlEncode(LogSanitizer.Strip(serviceClient.LastError)));
            throw new InvalidOperationException($"Failed to connect to CRM: {serviceClient.LastError}");
        }

        return serviceClient;
    }
}
