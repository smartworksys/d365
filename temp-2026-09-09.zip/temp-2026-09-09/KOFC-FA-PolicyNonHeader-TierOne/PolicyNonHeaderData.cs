using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Net.Http;
using Azure;
using Newtonsoft.Json;
using JsonSerializer = Newtonsoft.Json.JsonSerializer;
using KOFC_FA_PolicyNonHeader_TierOne.Models;
using KOFC_FA_PolicyNonHeader_TierOne.Services;
using KOFC_FA_PolicyNonHeader_TierOne.Helpers;
using System.Net.Http.Json;
using JsonException = Newtonsoft.Json.JsonException;
using Microsoft.Xrm.Sdk.PluginTelemetry;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace KOFC_FA_PolicyNonHeader_TierOne
{
    public class PolicyNonHeaderData : IPolicyNonHeaderData
    {
        private readonly ILogger<PolicyNonHeaderData> _logger;
        private readonly HttpClient _httpClient;

        public PolicyNonHeaderData(ILogger<PolicyNonHeaderData> logger, IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
             _httpClient = httpClientFactory.CreateClient();
        }
      
        public async Task<PolicyNonHeaderResponse> GetPolicyNonHeaderDataAsyn(string source, string companyCode, string policyNo, string userName)
        {

            try
            {

                var nonHeaderAPIURL = Environment.GetEnvironmentVariable("POLICY_NON_HEADER_API_URL");

                var allowedUri = NonHeaderUrlGuard.BuildAllowedUri(
                    nonHeaderAPIURL ?? string.Empty,
                    source,
                    companyCode,
                    policyNo,
                    userName);

                _logger.LogInformation("Calling NonHeader API.");

                var nonHeaderAPIResponse = await _httpClient.GetAsync(allowedUri);
                _logger.LogInformation(
                    "NonHeader API response. StatusCode={StatusCode}, Reason={ReasonPhrase}",
                    (int)nonHeaderAPIResponse.StatusCode,
                    WebUtility.HtmlEncode(LogSanitizer.Strip(nonHeaderAPIResponse.ReasonPhrase)));

                if (!nonHeaderAPIResponse.IsSuccessStatusCode)
                {
                    var json = await nonHeaderAPIResponse.Content.ReadAsStringAsync();
                    PolicyNonHeaderAPIError? error = null;
                    try
                    {
                        error = JsonConvert.DeserializeObject<PolicyNonHeaderAPIError>(json);
                    }
                    catch (JsonException jex)
                    {
                        _logger.LogWarning(jex, "Failed to parse NonHeader error JSON.");
                    }

                    if (error != null)
                    {
                        _logger.LogInformation(
                            "NonHeader API error. Status: {Status}. Message: {Message}. Details: {Details}",
                            error.Status, WebUtility.HtmlEncode(LogSanitizer.Strip(error.Message)), WebUtility.HtmlEncode(LogSanitizer.Strip(error.Details)));

                        throw new Exception(
                            $"NonHeader API returned error status {error.Status}.");
                    }
                    else
                    {
                        // Fallback when we cannot parse the known error shape
                        _logger.LogInformation(
                            "NonHeader API error (HTTP {StatusCode}).",
                            (int)nonHeaderAPIResponse.StatusCode);

                        throw new Exception(
                            $"NonHeader API error {(int)nonHeaderAPIResponse.StatusCode}.");
                    }

                }

                var nonHeaderAPIResponseData = await nonHeaderAPIResponse.Content.ReadAsStringAsync();
                //nonHeaderAPIResponseData = nonHeaderAPIResponseData.Replace("[]", "\"\"");

                var root = JsonConvert.DeserializeObject<PolicyNonHeaderAPIModel.Root>(nonHeaderAPIResponseData);

                if (root?.Data?.NonHeader is null)
                {

                    throw new InvalidOperationException("NonHeader is null. Check JSON shape and property names.");
                }


                var nonHeaderCRMResponse = PolicyNonHeaderResponseMapper.Map(root.Data.NonHeader);

                return nonHeaderCRMResponse;

            }
            catch (TaskCanceledException tex)
            {
                 _logger.LogError(tex, "Request to NonHeader API timed out.");
                throw new TimeoutException("Request to NonHeader API timed out.", tex);
            }
            catch (HttpRequestException hex)
            {
                _logger.LogError(hex, "HTTP request error when calling NonHeader API.");
                throw new Exception($"HTTP error when calling NonHeader API: {hex.Message}", hex);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error when calling NonHeader API.");
                throw;
            }
        }
    }
}