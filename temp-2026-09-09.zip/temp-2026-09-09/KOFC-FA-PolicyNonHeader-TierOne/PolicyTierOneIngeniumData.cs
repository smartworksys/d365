using System.Text;
using System.Xml.Linq;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Xml;
using KOFC_FA_PolicyNonHeader_TierOne.Helpers;
using KOFC_FA_PolicyNonHeader_TierOne.Models;
using KOFC_FA_PolicyNonHeader_TierOne.Services;
using Microsoft.Crm.Sdk.Messages;
using System.Security.Authentication;

namespace KOFC_FA_PolicyNonHeader_TierOne
{
    public class PolicyTierOneIngeniumData : IPolicyTierOneIngeniumData
    {
        private readonly ILogger _log;
        private readonly HttpClient _httpClient;

        public PolicyTierOneIngeniumData(
            ILogger<PolicyTierOneIngeniumData> logger,
            IHttpClientFactory httpClientFactory)
        {
            _log = logger;
            _httpClient = httpClientFactory.CreateClient();
        }

        public async Task<TierOneResponseJson> GetPolicyTierOneIngeniumDataAsync(string policyNo, string companyCode)
        {
            _log.LogInformation(
                "Calling Ingenium PING API for policy {PolicyNo}, company {CompanyCode}.",
                LogSanitizer.Neutralize(policyNo),
                LogSanitizer.Neutralize(companyCode));

            try
            {
                var ingPingUrl = Environment.GetEnvironmentVariable("INGENIUM_URL");
                var ingClonePingUrl = Environment.GetEnvironmentVariable("INGENIUM_CLONE_URL");
                var headlessflowUrl = Environment.GetEnvironmentVariable("INGENIUM_URL");

                if (string.IsNullOrWhiteSpace(ingPingUrl) || string.IsNullOrWhiteSpace(ingClonePingUrl))
                    throw new InvalidOperationException("Ingenium API Url is not configured.");

                var ingPingRequest = BuildINGPingPayload(policyNo, "ProductionServer");
                var ingClonePingRequest = BuildINGPingPayload(policyNo, "CloneServer");

                var pingResponse = await GetIngPingResponse(ingPingRequest, ingPingUrl, _log, "ProductionServer");

                if (pingResponse == "00")
                {
                    _log.LogInformation("Ingenium is live. Proceeding with Headlessflow API call.");
                    var headlessflowResponse = await CallHeadlessFlowAsync(policyNo, companyCode,_log, "ProductionServer");
                    var returnPolciyDetails = ExtractPolicyDetails(headlessflowResponse, _log);

                    var policyJson = JsonConvert.DeserializeObject<TierOneINGRootXml>(returnPolciyDetails);
                    var TierOneCRMResponse = TierOneINGResponseMapper.Map(policyJson.DATA);
                    _log.LogInformation(
                        "Ingenium Headlessflow response mapped successfully for policy {PolicyNo}.",
                        LogSanitizer.Neutralize(policyNo));
                    return TierOneCRMResponse;
                }else if (pingResponse != "00")
                {
                   var ingClonePingResponse = await GetIngPingResponse(ingClonePingRequest, ingClonePingUrl, _log, "CloneServer");
                    if(ingClonePingResponse != "00")
                    {
                        _log.LogError("Ing Clone server is down");
                        throw new Exception("Ingenium Clone server is down");
                    }

                    _log.LogInformation("Ingenium is Clone live. Proceeding with Headlessflow API call.");
                    var headlessflowResponse = await CallHeadlessFlowAsync(policyNo, companyCode, _log, "CloneServer");
                    var returnPolciyDetails = ExtractPolicyDetails(headlessflowResponse, _log);

                    var policyJson = JsonConvert.DeserializeObject<TierOneINGRootXml>(returnPolciyDetails);
                    var TierOneCRMResponse = TierOneINGResponseMapper.Map(policyJson.DATA);
                    _log.LogInformation(
                        "Ingenium Headlessflow response mapped successfully for policy {PolicyNo}.",
                        LogSanitizer.Neutralize(policyNo));
                    return TierOneCRMResponse;

                }

                _log.LogWarning("Ingenium returned non-success code: {ReturnCode}", LogSanitizer.Neutralize(pingResponse));
                throw new Exception("Ingenium is down");
            }
            catch (Exception ex)
            {
                _log.LogError(ex, "Unhandled exception while calling Ingenium for policy {PolicyNo}.", LogSanitizer.Neutralize(policyNo));
                throw new Exception("Failed to fetch Ping response!", ex);
            }
        }

        private async Task<string> GetIngPingResponse(string requestPayload,string pingUrl, ILogger _log, string serverName)
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, pingUrl)
                {
                    Content = new StringContent(requestPayload, Encoding.UTF8, "text/xml")
                };

                _log.LogDebug("Ingenium PING request payload for {ServerName}: {Payload}", LogSanitizer.Neutralize(serverName), LogSanitizer.Neutralize(requestPayload));

                _log.LogInformation("Sending Ingenium SOAP request to {Url}", LogSanitizer.Neutralize(pingUrl));
                // ---- SOAP headers----
                request.Headers.Add("Accept", "*/*");
                request.Headers.Add("Accept-Encoding", "gzip, deflate, br");
                request.Headers.Add("Cache-Control", "no-cache");
                request.Headers.Add("Connection", "keep-alive");

            try
            {

                var response = await _httpClient.SendAsync(request);
                var responseXml = await response.Content.ReadAsStringAsync();
                if (!response.IsSuccessStatusCode)
                {
                    // _log.LogError("Ingenium SOAP call failed. Status: ", response, response.StatusCode);
                    //return $"Failed to fetch Ping response from - {serverName}";
                    _log.LogError(
            "Ingenium SOAP call failed. StatusCode={StatusCode}, Reason={ReasonPhrase}, Response={Response}",
            (int)response.StatusCode,
            LogSanitizer.Neutralize(response.ReasonPhrase),
            LogSanitizer.Neutralize(responseXml));

                    return $"Failed to fetch Ping response from - {serverName}. StatusCode={(int)response.StatusCode}";
                }

                var returnCode = ExtractPingReturnCode(responseXml, _log);
                _log.LogInformation(
                    "LSIR-RETURN-CD received from {ServerName}: {ReturnCode}",
                    LogSanitizer.Neutralize(serverName),
                    LogSanitizer.Neutralize(returnCode));
                return returnCode;
            }
            catch (HttpRequestException ex) when (ex.InnerException is AuthenticationException)
            {
                // ✅ THIS WILL CATCH YOUR CERTIFICATE ISSUE
                _log.LogError(ex,
                    "SSL certificate validation failed when calling Ingenium at {Url}",
                    LogSanitizer.Neutralize(pingUrl));

                return $"SSL certificate validation failed when calling {serverName}";
            }
            catch (HttpRequestException ex)
            {
                _log.LogError(ex,
                    "HTTP request failed when calling Ingenium at {Url}. Message={Message}",
                    LogSanitizer.Neutralize(pingUrl),
                    LogSanitizer.Neutralize(ex.Message));

                return $"HTTP error occurred while calling {serverName}";
            }
            catch (TaskCanceledException ex)
            {
                _log.LogError(ex,
                    "Ingenium SOAP call timed out. Url={Url}",
                    LogSanitizer.Neutralize(pingUrl));

                return $"Timeout occurred while calling {serverName}";
            }
            catch (Exception ex)
            {
                _log.LogError(ex,
                    "Unexpected error during Ingenium SOAP call. Url={Url}",
                    LogSanitizer.Neutralize(pingUrl));

                throw; // Let Azure Functions mark it as failed
            }
        }

        private static string BuildINGPingPayload(string policyNo,string serverName)
        {
            var prodClientId = Environment.GetEnvironmentVariable("INGENIUM_CLIENT_ID");
            var prodClientSecret = Environment.GetEnvironmentVariable("INGENIUM_CLIENT_SECRET");
            var ingCloneClientId = Environment.GetEnvironmentVariable("INGENIUM_CLONE_CLIENT_ID");
            var ingCloneClientSecret = Environment.GetEnvironmentVariable("INGENIUM_CLONE_CLIENT_SECRET");
            var isProd = serverName == "ProductionServer";

            var selectedServerClientID = isProd ? prodClientId : ingCloneClientId;
            var selectedServerClientSecret = isProd ? prodClientSecret : ingCloneClientSecret;

            return $@"<?xml version='1.0' encoding='UTF-8'?>
                        <soapenv:Envelope xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/'
                        xmlns:web='http://schema/webservices.elink.solcorp.com'>
                        <soapenv:Header />
                        <soapenv:Body>
                        <web:callFlowRequest>
                        <ProcessClassID>IngStatusCheck</ProcessClassID>
                        <!--Optional:-->
                        <StatisticLogging>?</StatisticLogging>
                        <!--Optional:-->
                        <BAMID>?</BAMID>
                        <MIR-USER-ID>{selectedServerClientID}</MIR-USER-ID>
                        <MIR-USER-PSWD-TXT>{selectedServerClientSecret}</MIR-USER-PSWD-TXT>
                        <MIR-CO-ID>01</MIR-CO-ID>
                        <LocaleID>E</LocaleID>
                        </web:callFlowRequest>
                        </soapenv:Body>
                        </soapenv:Envelope>";
        }

        private static string ExtractPingReturnCode(string xml, ILogger _log)
        {
            var document = XDocument.Parse(xml);
            var returnCodeElement = document
                .Descendants("LSIR-RETURN-CD")
                .FirstOrDefault();

            var Severity = document
                .Descendants("Severity")
                .FirstOrDefault();

            /*if(Severity.HasElements) {
                _log.LogError($"Server responded with Severity:{Severity}");
                return String.Empty;
            }*/

            if (returnCodeElement == null)
            {
                _log.LogError("Response element not found. XML tag 'LSIR-RETURN-CD' is missing: {Xml}", LogSanitizer.Neutralize(xml));
                return String.Empty;
            }
            return returnCodeElement?.Value;
        }

        private static string ExtractPolicyDetails(string xml, ILogger _log)
        {
            var document = XDocument.Parse(xml);
            var body = document
                .Descendants()
                .FirstOrDefault(e => e.Name.LocalName== "Body");
            if (body == null)
            {
                _log.LogError("Response element not found. XML Body is missing");
                throw new Exception("Xml Body is missing");
            }
            var actualResponse = body.Elements().FirstOrDefault();
            if (actualResponse == null)
            {
                _log.LogError("Policy Details not found. Policy Xml is empty");
                throw new Exception("Policy Xml is empty");
            }
            var responseXml = actualResponse.ToString();

            var xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(responseXml);
            var json = JsonConvert.SerializeXmlNode(xmlDoc);

            return json;
        }

        private async Task<string> CallHeadlessFlowAsync(string policyNo, string companyCode,ILogger _log, string serverName)
        {
            try
            {
                var headlessProdFlowUrl = Environment.GetEnvironmentVariable("INGENIUM_URL");
                var headlessFlowCloneUrl = Environment.GetEnvironmentVariable("INGENIUM_CLONE_URL");
                var isProd = serverName == "ProductionServer";

                var headlessFlowUrl = isProd ? headlessProdFlowUrl : headlessFlowCloneUrl;
                var headlessFlowServerName = isProd ? "ProductionServer" : "CloneServer";

                if (string.IsNullOrWhiteSpace(headlessFlowUrl))
                    throw new InvalidOperationException("INGENIUM_PING_URL is not configured.");

                var headlessflowRequest = BuildHeadlessFlowPayload(policyNo, companyCode, _log, headlessFlowServerName);

                using var request = new HttpRequestMessage(HttpMethod.Post, headlessFlowUrl)
                {
                    Content = new StringContent(headlessflowRequest, Encoding.UTF8, "text/xml")
                };

                // ---- SOAP headers----
                request.Headers.Add("Accept", "*/*");
                request.Headers.Add("Accept-Encoding", "gzip, deflate, br");
                request.Headers.Add("Cache-Control", "no-cache");
                request.Headers.Add("Connection", "keep-alive");

                var response = await _httpClient.SendAsync(request);

                _log.LogInformation(
                    "Headlessflow API call completed for policy {PolicyNo} on {ServerName}. StatusCode={StatusCode}",
                    LogSanitizer.Neutralize(policyNo),
                    LogSanitizer.Neutralize(serverName),
                    (int)response.StatusCode);
                return await response.Content.ReadAsStringAsync();
            }
            catch (Exception ex) {
                _log.LogError(ex, "Error while fetching response from Headlessflow for policy {PolicyNo}.", LogSanitizer.Neutralize(policyNo));
                throw new Exception("Error while fetching response from Headlessflow", ex);
            }
            
        }

        private static string BuildHeadlessFlowPayload(string policyNo, string companyCode,ILogger _log,string serverName)
        {
            var headlessflowProdClientId = Environment.GetEnvironmentVariable("INGENIUM_CLIENT_ID");
            var headlessflowProdClientSecret = Environment.GetEnvironmentVariable("INGENIUM_CLIENT_SECRET");
            var headlessflowCloneClientId = Environment.GetEnvironmentVariable("INGENIUM_CLONE_CLIENT_ID");
            var headlessflowCloneClientSecret = Environment.GetEnvironmentVariable("INGENIUM_CLONE_CLIENT_SECRET");
            var isProd = serverName == "ProductionServer";

            var headlessflowClientId = isProd? headlessflowProdClientId : headlessflowCloneClientId;
            var headlessflowClientSecret = isProd? headlessflowCloneClientSecret : headlessflowCloneClientSecret;

            var systemRequestDetails = SystemRequestGenerator.GenerateSystemRequestNumber();
            _log.LogInformation(
                "Generated Ingenium system request {SystemRequestId} at {DateAndTimeStamp}.",
                LogSanitizer.Neutralize(systemRequestDetails.SystemRequestId),
                LogSanitizer.Neutralize(systemRequestDetails.DateAndTimeStamp));
            string systemReqId = systemRequestDetails.SystemRequestId;
            string currentDate = systemRequestDetails.CurrentDate;
            string dateTimeStamp = systemRequestDetails.DateAndTimeStamp;

            return $@"<?xml version='1.0' encoding='UTF-8'?>
                    <soapenv:Envelope
                        xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/'
                        xmlns:web='http://schema/webservices.elink.solcorp.com'>
                        <soapenv:Header/>
                        <soapenv:Body>
                            <web:callFlowRequest>
                                <ProcessClassID>CRMPolValues</ProcessClassID>
                                <LocaleID>E</LocaleID>
                                <StatisticLogging>?</StatisticLogging>
	                            <BAMID>?</BAMID>   
                                <MIR-CO-ID>{companyCode}</MIR-CO-ID>
                                <MIR-USER-ID>{headlessflowClientId}</MIR-USER-ID>
                                <MIR-USER-PSWD-TXT>{headlessflowClientSecret}</MIR-USER-PSWD-TXT>
                                <MIR-REL-SYS-ID>CRM</MIR-REL-SYS-ID>
                                <MIR-REL-SYS-RQST-NUM>{systemReqId}</MIR-REL-SYS-RQST-NUM>
                                <MIR-MBR-TYP-CD></MIR-MBR-TYP-CD>
                                <MIR-RQST-TS>{dateTimeStamp}</MIR-RQST-TS>
                                <MIR-BPF-ID>CRMPolValues</MIR-BPF-ID>
                                <MIR-RQST-DT>{currentDate}</MIR-RQST-DT>
                                <MIR-POL-ID-BASE>{policyNo}</MIR-POL-ID-BASE>
                                <MIR-POL-ID-SFX></MIR-POL-ID-SFX>            
                                <MIR-DV-EFF-DT>{currentDate}</MIR-DV-EFF-DT>        
                                </web:callFlowRequest>
                        </soapenv:Body>
                    </soapenv:Envelope";
        }
    }
}
