namespace KOFC_FA_PolicyNonHeader_TierOne.Helpers;

/// <summary>
/// Strips CR/LF and other line-break characters from values before they are written to logs.
/// Prevents log forging (CWE-117 / CRLF injection).
/// </summary>
public static class LogSanitizer
{
    public static string Neutralize(string? value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return string.Empty;
        }

        return value
            .Replace("\r", string.Empty)
            .Replace("\n", string.Empty)
            .Replace("\u0000", string.Empty)
            .Replace("\u0085", string.Empty)
            .Replace("\u2028", string.Empty)
            .Replace("\u2029", string.Empty);
    }
}
