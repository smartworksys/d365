using System.Net;

namespace KOFC_FA_PolicyNonHeader_TierOne.Helpers;

/// <summary>
/// Neutralizes untrusted values before they are written to logs (CWE-117).
/// Call sites should pass <c>WebUtility.HtmlEncode(LogSanitizer.Strip(value))</c>
/// so Veracode can see a recognized cleanser at the log sink.
/// </summary>
public static class LogSanitizer
{
    public static string Strip(string? value)
    {
        if (string.IsNullOrEmpty(value))
        {
            return string.Empty;
        }

        return value
            .Replace("\r", string.Empty)
            .Replace("\n", string.Empty)
            .Replace("\u0000", string.Empty)
            .Replace("\u0085", string.Empty)
            .Replace("\u2028", string.Empty)
            .Replace("\u2029", string.Empty);
    }

    public static string Neutralize(string? value) => WebUtility.HtmlEncode(Strip(value));
}
