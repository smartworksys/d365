using System.Text.RegularExpressions;

namespace KOFC_FA_PolicyNonHeader_TierOne.Helpers;

/// <summary>
/// Builds the NonHeader API URL from a configured template and user tokens,
/// then verifies the resolved URL stays on the same host (CWE-918).
/// </summary>
public static class NonHeaderUrlGuard
{
    private static readonly Regex SafeToken = new(@"^[A-Za-z0-9._-]+$", RegexOptions.Compiled);
    private static readonly Regex SafeUserName = new(@"^[A-Za-z0-9._@+-]+$", RegexOptions.Compiled);

    public static Uri BuildAllowedUri(string template, string source, string companyCode, string policyNo, string userName)
    {
        if (string.IsNullOrWhiteSpace(template))
        {
            throw new InvalidOperationException("NON_HEADER_API_URL is not configured.");
        }

        EnsureSafeToken(source, nameof(source));
        EnsureSafeToken(companyCode, nameof(companyCode));
        EnsureSafeToken(policyNo, nameof(policyNo));
        EnsureSafeUserName(userName);

        var compPolicyNo = string.Concat(companyCode, policyNo);
        var updatedUrl = template
            .Replace("{source}", source, StringComparison.Ordinal)
            .Replace("{policyNo}", compPolicyNo, StringComparison.Ordinal)
            .Replace("{userName}", userName, StringComparison.Ordinal);

        if (!Uri.TryCreate(updatedUrl, UriKind.Absolute, out var resolved)
            || (resolved.Scheme != Uri.UriSchemeHttps && resolved.Scheme != Uri.UriSchemeHttp))
        {
            throw new InvalidOperationException("NonHeader API URL is invalid.");
        }

        var allowedOrigin = ExtractOrigin(template);
        if (!string.Equals(resolved.Scheme, allowedOrigin.Scheme, StringComparison.OrdinalIgnoreCase)
            || !string.Equals(resolved.Host, allowedOrigin.Host, StringComparison.OrdinalIgnoreCase)
            || resolved.Port != allowedOrigin.Port)
        {
            throw new InvalidOperationException("NonHeader API URL host is not allowed.");
        }

        return resolved;
    }

    internal static Uri ExtractOrigin(string template)
    {
        var match = Regex.Match(template, @"^(https?://[^/\s{]+)", RegexOptions.IgnoreCase);
        if (!match.Success || !Uri.TryCreate(match.Groups[1].Value, UriKind.Absolute, out var origin))
        {
            throw new InvalidOperationException("POLICY_NON_HEADER_API_URL must be an absolute HTTP(S) URL.");
        }

        return origin;
    }

    private static void EnsureSafeToken(string value, string name)
    {
        if (string.IsNullOrWhiteSpace(value) || !SafeToken.IsMatch(value))
        {
            throw new InvalidOperationException($"{name} contains invalid characters.");
        }
    }

    private static void EnsureSafeUserName(string value)
    {
        if (string.IsNullOrWhiteSpace(value) || !SafeUserName.IsMatch(value))
        {
            throw new InvalidOperationException("userName contains invalid characters.");
        }
    }
}
