using System.Diagnostics;
using System.Text.Json;
using Azure;
using KOFC.Azure.Functions.GetSaasBlobUrl.Helpers;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace KOFC.Azure.Functions.GetSaasBlobUrl;

public class GetSaasBlobUrl
{
    private readonly IContactAccessGuard _contactAccessGuard;
    private readonly IBlobLinkAssociationGuard _blobLinkAssociationGuard;
    private readonly IBlobService _blobService;
    private readonly IConfiguration _configuration;

    public GetSaasBlobUrl(
        IContactAccessGuard contactAccessGuard,
        IBlobLinkAssociationGuard blobLinkAssociationGuard,
        IBlobService blobService,
        IConfiguration configuration)
    {
        _contactAccessGuard = contactAccessGuard;
        _blobLinkAssociationGuard = blobLinkAssociationGuard;
        _blobService = blobService;
        _configuration = configuration;
    }

    [Function("GetSaasBlobUrl")]
    public Task<IActionResult> RunAsync(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")] HttpRequest req,
        FunctionContext context)
    {
        // Category must match the function name so logs correlate with the Invocations blade.
        var log = context.GetLogger("GetSaasBlobUrl");
        return RunCoreAsync(req, log);
    }

    public async Task<IActionResult> RunCoreAsync(HttpRequest req, ILogger log)
    {
        var callerScopes = FunctionAppRoleAuth.GetCallerScopes(req);
        var callerOid = FunctionAppRoleAuth.GetCallerObjectId(req);
        var isDelegatedCaller = FunctionAppRoleAuth.IsDelegatedCaller(req);
        var tokenEmail = FunctionAppRoleAuth.GetCallerEmail(req);
        var tokenName = FunctionAppRoleAuth.GetCallerDisplayName(req);
        var principalName = req.Headers.ContainsKey("X-MS-CLIENT-PRINCIPAL-NAME")
            ? req.Headers["X-MS-CLIENT-PRINCIPAL-NAME"].ToString()
            : null;
        var forwardedFor = req.Headers.ContainsKey("X-Forwarded-For")
            ? req.Headers["X-Forwarded-For"].ToString()
            : req.HttpContext.Connection.RemoteIpAddress?.ToString();

        var audit = new RequestAudit
        {
            Method = req.Method,
            EntraOid = callerOid,
            UserEmail = FirstNonEmpty(tokenEmail, principalName),
            UserName = FirstNonEmpty(tokenName, principalName),
            AuthMode = isDelegatedCaller ? "delegated" : "app",
            ClientIp = forwardedFor,
            Scopes = string.Join(", ", callerScopes)
        };

        var tokenLifetime = FunctionAppRoleAuth.GetAccessTokenLifetime(req);
        audit.TokenIssuedAt = tokenLifetime.IssuedAt;
        audit.TokenExpiresAt = tokenLifetime.ExpiresAt;
        audit.TokenLifetimeMinutes = tokenLifetime.LifetimeMinutes;
        audit.TokenRemainingMinutes = tokenLifetime.RemainingMinutes;
        log.LogInformation(
            "Caller token lifetime. IssuedAt={TokenIssuedAt} ExpiresAt={TokenExpiresAt} " +
            "LifetimeMinutes={TokenLifetimeMinutes} RemainingMinutes={TokenRemainingMinutes} EntraOid={EntraOid}",
            tokenLifetime.IssuedAt,
            tokenLifetime.ExpiresAt,
            tokenLifetime.LifetimeMinutes,
            tokenLifetime.RemainingMinutes,
            callerOid);

        using var scope = log.BeginScope(new Dictionary<string, object?>
        {
            ["oid"] = callerOid?.ToString() ?? "",
            ["authMode"] = audit.AuthMode ?? ""
        });
        Activity.Current?.SetTag("oid", callerOid?.ToString() ?? "");
        Activity.Current?.SetTag("authMode", audit.AuthMode ?? "");

        if (!FunctionAppRoleAuth.IsAuthenticated(req))
        {
            return Fail(
                log,
                audit,
                StatusCodes.Status401Unauthorized,
                "Authentication required.",
                "Unauthenticated",
                "Request is not authenticated.");
        }

        if (!isDelegatedCaller)
        {
            return Fail(
                log,
                audit,
                StatusCodes.Status403Forbidden,
                $"Missing required delegated scope: {FunctionAppRoleAuth.BlobReadRole} or {FunctionAppRoleAuth.AccessAsUserScope}.",
                "DelegatedScopeMissing",
                "Caller is not a delegated SPA user with Blob.Read or access_as_user.");
        }

        if (!callerOid.HasValue)
        {
            return Fail(
                log,
                audit,
                StatusCodes.Status401Unauthorized,
                "The delegated token does not contain a valid oid claim.",
                "MissingOid",
                "Delegated token has no oid claim.");
        }

        try
        {
            var queryParams = ParseQuery(req);
            await MergePostBodyAsync(req, queryParams);

            var rawPath = GetParam(queryParams, "path");
            var contactId = GetParam(queryParams, "contactId");
            var responseFormat = (GetParam(queryParams, "format") ?? "redirect").ToLowerInvariant();
            audit.RawPath = rawPath;
            audit.ContactId = contactId;
            audit.Format = responseFormat;

            if (string.IsNullOrWhiteSpace(rawPath))
            {
                return Fail(
                    log,
                    audit,
                    StatusCodes.Status400BadRequest,
                    "Bad Request: Missing 'path' parameter",
                    "MissingPath",
                    "path is missing.");
            }

            if (string.IsNullOrWhiteSpace(contactId) || !Guid.TryParse(contactId, out var contactGuid))
            {
                return Fail(
                    log,
                    audit,
                    StatusCodes.Status400BadRequest,
                    "Bad Request: Missing or invalid 'contactId' parameter",
                    "InvalidContactId",
                    "contactId is missing or not a GUID.");
            }

            var accessResult = _contactAccessGuard.CheckContactAccessByEntraOid(
                callerOid.Value,
                contactGuid);
            audit.DataverseUserId = accessResult.UserId;
            audit.UserName = FirstNonEmpty(accessResult.UserName, audit.UserName);
            audit.UserEmail = FirstNonEmpty(accessResult.UserName, audit.UserEmail);

            if (!accessResult.IsGranted)
            {
                var status = accessResult.Status == ContactAccessStatus.UserNotFound
                    ? StatusCodes.Status404NotFound
                    : StatusCodes.Status403Forbidden;
                var clientMessage = accessResult.Status == ContactAccessStatus.UserNotFound
                    ? "User not found."
                    : "Access denied.";
                return Fail(
                    log,
                    audit,
                    status,
                    clientMessage,
                    accessResult.Status.ToString(),
                    accessResult.Message);
            }

            var blobPath = _blobService.NormalizePathToBlob(rawPath);
            audit.BlobPath = blobPath;
            if (string.IsNullOrWhiteSpace(blobPath))
            {
                return Fail(
                    log,
                    audit,
                    StatusCodes.Status400BadRequest,
                    "Bad Request: Invalid file path",
                    "InvalidPath",
                    "Normalized blob path is empty.");
            }

            var linkCheck = _blobLinkAssociationGuard.CheckPathLinkedToContact(
                accessResult.UserId ?? Guid.Empty,
                contactGuid,
                rawPath,
                blobPath);
            if (!linkCheck.IsLinked)
            {
                return Fail(
                    log,
                    audit,
                    StatusCodes.Status403Forbidden,
                    "Access denied.",
                    "PathNotLinkedToContact",
                    linkCheck.Message);
            }

            var containerName = _configuration["BlobContainerName"] ?? "kofcext-extractions";
            audit.Container = containerName;
            try
            {
                if (responseFormat is "file" or "proxy")
                {
                    var file = await _blobService.DownloadAsync(containerName, blobPath);
                    audit.FileName = file.FileName;
                    audit.ContentType = file.ContentType;
                    audit.ByteLength = file.Content.Length;
                    return Succeed(
                        log,
                        audit,
                        new OkObjectResult(new
                        {
                            fileName = file.FileName,
                            contentType = file.ContentType,
                            contentBase64 = Convert.ToBase64String(file.Content)
                        }),
                        "FileDownload");
                }

                var sasUrl = await _blobService.GenerateSasUrlAsync(containerName, blobPath);
                audit.FileName = Path.GetFileName(blobPath.Replace('\\', '/'));
                if (responseFormat == "json")
                {
                    return Succeed(log, audit, new OkObjectResult(new { sasUrl }), "SasJson");
                }

                return Succeed(log, audit, new RedirectResult(sasUrl), "SasRedirect", StatusCodes.Status302Found);
            }
            catch (InvalidOperationException ex)
            {
                return Fail(
                    log,
                    audit,
                    StatusCodes.Status404NotFound,
                    "Not Found: The requested file does not exist",
                    "BlobNotFound",
                    ex.Message,
                    ex);
            }
            catch (RequestFailedException ex)
            {
                return Fail(
                    log,
                    audit,
                    StatusCodes.Status500InternalServerError,
                    "Internal Server Error: Unable to access blob storage.",
                    "StorageError",
                    $"Azure Storage status {ex.Status}: {ex.ErrorCode}",
                    ex);
            }
        }
        catch (JsonException ex)
        {
            return Fail(
                log,
                audit,
                StatusCodes.Status400BadRequest,
                "Request body is not valid JSON.",
                "InvalidJson",
                ex.Message,
                ex);
        }
        catch (Exception ex)
        {
            return Fail(
                log,
                audit,
                StatusCodes.Status500InternalServerError,
                "Internal Server Error: An unexpected error occurred.",
                "UnhandledException",
                ex.Message,
                ex);
        }
    }

    private static Dictionary<string, string> ParseQuery(HttpRequest req)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var pair in req.Query)
        {
            if (!string.IsNullOrWhiteSpace(pair.Key))
            {
                result[pair.Key] = pair.Value.ToString();
            }
        }

        return result;
    }

    private static async Task MergePostBodyAsync(HttpRequest req, Dictionary<string, string> queryParams)
    {
        if (!HttpMethods.IsPost(req.Method))
        {
            return;
        }

        req.EnableBuffering();
        using var reader = new StreamReader(req.Body, leaveOpen: true);
        var body = await reader.ReadToEndAsync();
        req.Body.Position = 0;

        if (string.IsNullOrWhiteSpace(body))
        {
            return;
        }

        using var document = JsonDocument.Parse(body);
        foreach (var property in document.RootElement.EnumerateObject())
        {
            if (!queryParams.ContainsKey(property.Name))
            {
                queryParams[property.Name] = property.Value.ToString();
            }
        }
    }

    private static string? GetParam(Dictionary<string, string> queryParams, string name) =>
        queryParams.TryGetValue(name, out var value) && !string.IsNullOrWhiteSpace(value)
            ? value
            : null;

    private static string? FirstNonEmpty(params string?[] values) =>
        values.FirstOrDefault(value => !string.IsNullOrWhiteSpace(value));

    private static IActionResult Succeed(
        ILogger log,
        RequestAudit audit,
        IActionResult result,
        string outcome,
        int statusCode = StatusCodes.Status200OK)
    {
        audit.Outcome = outcome;
        audit.StatusCode = statusCode;
        LogOutcome(log, success: true, audit);
        return result;
    }

    private static IActionResult Fail(
        ILogger log,
        RequestAudit audit,
        int statusCode,
        string clientMessage,
        string outcome,
        string reason,
        Exception? exception = null)
    {
        audit.Outcome = outcome;
        audit.StatusCode = statusCode;
        audit.Reason = reason;
        audit.ExceptionType = exception?.GetType().Name ?? outcome;
        LogOutcome(log, success: false, audit, exception);
        return statusCode switch
        {
            StatusCodes.Status400BadRequest => new BadRequestObjectResult(clientMessage),
            StatusCodes.Status401Unauthorized => new UnauthorizedObjectResult(clientMessage),
            StatusCodes.Status404NotFound => new NotFoundObjectResult(clientMessage),
            _ => new ObjectResult(clientMessage) { StatusCode = statusCode }
        };
    }

    private static void LogOutcome(ILogger log, bool success, RequestAudit audit, Exception? exception = null)
    {
        if (success)
        {
            log.LogInformation(
                "Blob request succeeded. Status={StatusCode} Bytes={Bytes} UserId={UserId} EntraOid={EntraOid}",
                audit.StatusCode,
                audit.ByteLength,
                audit.DataverseUserId,
                audit.EntraOid);
            return;
        }

        if (audit.StatusCode >= 500)
        {
            log.LogError(
                exception,
                "Blob request failed. Status={StatusCode} Bytes={Bytes} UserId={UserId} EntraOid={EntraOid}",
                audit.StatusCode,
                audit.ByteLength,
                audit.DataverseUserId,
                audit.EntraOid);
            return;
        }

        log.LogWarning(
            exception,
            "Blob request failed. Status={StatusCode} Bytes={Bytes} UserId={UserId} EntraOid={EntraOid}",
            audit.StatusCode,
            audit.ByteLength,
            audit.DataverseUserId,
            audit.EntraOid);
    }

    private sealed class RequestAudit
    {
        public string? Outcome { get; set; }
        public int StatusCode { get; set; }
        public string? Reason { get; set; }
        public string? Method { get; set; }
        public string? Format { get; set; }
        public string? ContactId { get; set; }
        public string? RawPath { get; set; }
        public string? BlobPath { get; set; }
        public string? Container { get; set; }
        public string? FileName { get; set; }
        public string? ContentType { get; set; }
        public int? ByteLength { get; set; }
        public Guid? EntraOid { get; set; }
        public Guid? DataverseUserId { get; set; }
        public string? UserEmail { get; set; }
        public string? UserName { get; set; }
        public string? AuthMode { get; set; }
        public string? ClientIp { get; set; }
        public string? Scopes { get; set; }
        public DateTimeOffset? TokenIssuedAt { get; set; }
        public DateTimeOffset? TokenExpiresAt { get; set; }
        public int? TokenLifetimeMinutes { get; set; }
        public int? TokenRemainingMinutes { get; set; }
        public string? ExceptionType { get; set; }
    }
}
