using System.ServiceModel;
using System.Text.RegularExpressions;
using KOFC.Azure.Functions.GetSaasBlobUrl.Helpers;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Net;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

/// <summary>
/// InfoSec control: a caller who can read a Contact cannot request an arbitrary blob path.
/// The path must exist on a Blob Link Activity Regarding that Contact.
/// </summary>
public class BlobLinkAssociationGuard : IBlobLinkAssociationGuard
{
    public const string DefaultEntityLogicalName = "kofc_bloblinkactivity";

    private readonly ILogger<BlobLinkAssociationGuard> _log;
    private readonly IDataverseClient _dataverse;
    private readonly IBlobService _blobService;
    private readonly string _entityLogicalName;

    public BlobLinkAssociationGuard(
        ILogger<BlobLinkAssociationGuard> log,
        IDataverseClient dataverse,
        IBlobService blobService,
        IConfiguration configuration)
    {
        _log = log;
        _dataverse = dataverse;
        _blobService = blobService;
        _entityLogicalName = configuration["BlobLinkActivityEntity"] ?? DefaultEntityLogicalName;
    }

    public BlobLinkAssociationResult CheckPathLinkedToContact(
        Guid systemUserId,
        Guid contactId,
        string requestedPath,
        string normalizedBlobPath)
    {
        try
        {
            _dataverse.CallerId = systemUserId;
            var activities = RetrieveRegardingActivities(contactId);
            var match = FindMatchingActivity(activities, normalizedBlobPath);

            var result = match is null
                ? new BlobLinkAssociationResult
                {
                    IsLinked = false,
                    ActivitiesReviewed = activities.Count,
                    EntityLogicalName = _entityLogicalName,
                    Message =
                        "No Blob Link Activity regarding this contact has a Description that matches the requested path."
                }
                : new BlobLinkAssociationResult
                {
                    IsLinked = true,
                    ActivityId = match.Id,
                    Subject = match.GetAttributeValue<string>("subject"),
                    MatchedDescription = match.GetAttributeValue<string>("description"),
                    ActivitiesReviewed = activities.Count,
                    EntityLogicalName = _entityLogicalName,
                    Message = "Requested path is associated with a Blob Link Activity for this contact."
                };

            LogCheck(result, systemUserId, contactId, requestedPath, normalizedBlobPath);
            return result;
        }
        catch (FaultException<OrganizationServiceFault> ex)
        {
            var result = new BlobLinkAssociationResult
            {
                IsLinked = false,
                EntityLogicalName = _entityLogicalName,
                Message =
                    $"Unable to query Blob Link Activity '{_entityLogicalName}'. ErrorCode={ex.Detail.ErrorCode}."
            };
            LogCheck(result, systemUserId, contactId, requestedPath, normalizedBlobPath, ex);
            return result;
        }
        finally
        {
            _dataverse.CallerId = Guid.Empty;
        }
    }

    private IReadOnlyList<Entity> RetrieveRegardingActivities(Guid contactId)
    {
        var collected = new List<Entity>();
        var query = new QueryExpression(_entityLogicalName)
        {
            ColumnSet = new ColumnSet("activityid", "subject", "description", "regardingobjectid"),
            PageInfo = new PagingInfo { Count = 50, PageNumber = 1 },
            Criteria = new FilterExpression(LogicalOperator.And)
        };
        query.Criteria.AddCondition("regardingobjectid", ConditionOperator.Equal, contactId);
        query.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);

        while (true)
        {
            var page = _dataverse.RetrieveMultiple(query);
            if (page.Entities is { Count: > 0 })
            {
                collected.AddRange(page.Entities);
            }

            if (!page.MoreRecords || string.IsNullOrWhiteSpace(page.PagingCookie))
            {
                break;
            }

            query.PageInfo.PageNumber++;
            query.PageInfo.PagingCookie = page.PagingCookie;
        }

        return collected;
    }

    private Entity? FindMatchingActivity(IReadOnlyList<Entity> activities, string normalizedBlobPath)
    {
        foreach (var activity in activities)
        {
            var description = activity.GetAttributeValue<string>("description");
            if (string.IsNullOrWhiteSpace(description))
            {
                continue;
            }

            var activityPath = _blobService.NormalizePathToBlob(StripDescriptionNoise(description));
            if (string.Equals(normalizedBlobPath, activityPath, StringComparison.OrdinalIgnoreCase))
            {
                return activity;
            }
        }

        return null;
    }

    private void LogCheck(
        BlobLinkAssociationResult result,
        Guid systemUserId,
        Guid contactId,
        string requestedPath,
        string normalizedBlobPath,
        Exception? exception = null)
    {
        const string template =
            "BlobLinkActivity association check completed. Linked={Linked} " +
            "ContactId={ContactId} RequestedPath={RequestedPath} NormalizedPath={NormalizedPath} " +
            "ActivityId={ActivityId} Subject={Subject} ActivitiesReviewed={ActivitiesReviewed} " +
            "Entity={Entity} UserId={UserId} Reason={Reason}";

        object?[] args =
        [
            result.IsLinked,
            contactId,
            WebUtility.HtmlEncode(LogSanitizer.Strip(requestedPath)),
            WebUtility.HtmlEncode(LogSanitizer.Strip(normalizedBlobPath)),
            result.ActivityId,
            WebUtility.HtmlEncode(LogSanitizer.Strip(result.Subject)),
            result.ActivitiesReviewed,
            WebUtility.HtmlEncode(LogSanitizer.Strip(result.EntityLogicalName)),
            systemUserId,
            WebUtility.HtmlEncode(LogSanitizer.Strip(result.Message))
        ];

        if (result.IsLinked)
        {
            _log.LogInformation(template, args);
            return;
        }

        _log.LogWarning(exception, template, args);
    }

    private static string StripDescriptionNoise(string value)
    {
        var cleaned = value
            .Replace("&nbsp;", " ", StringComparison.OrdinalIgnoreCase)
            .Replace("&#160;", " ", StringComparison.Ordinal);
        cleaned = Regex.Replace(cleaned, @"<br\s*/?>", "", RegexOptions.IgnoreCase);
        cleaned = Regex.Replace(cleaned, @"<[^>]+>", "");
        return cleaned.Trim();
    }
}
