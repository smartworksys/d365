using System.Diagnostics;
using System.ServiceModel;
using System.Text;
using KOFC_FA_AgentPortal_UserProfile.Helpers;
using KOFC_FA_AgentPortal_UserProfile.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using Formatting = Newtonsoft.Json.Formatting;
using System.Net;

namespace KOFC_FA_AgentPortal_UserProfile;

public class EappSSO
{
    private readonly ILogger<EappSSO> _log;
    private readonly IDataverseService _dataverseService;

    public EappSSO(ILogger<EappSSO> log, IDataverseService dataverseService)
    {
        _log = log;
        _dataverseService = dataverseService;
    }

    [Function("getSOReqForEappSSO")]
    public IActionResult Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")] HttpRequest req)
    {
        _log.LogInformation("C# HTTP trigger function processed a request.");

        if (!EappFunctionAuth.IsAuthenticated(req))
        {
            return new UnauthorizedObjectResult("Authentication required.");
        }

        var callerRoles = EappFunctionAuth.GetCallerRoles(req);
        var callerScopes = EappFunctionAuth.GetCallerScopes(req);
        var callerOid = EappFunctionAuth.GetCallerObjectId(req);
        var isDelegatedCaller = EappFunctionAuth.IsDelegatedCaller(req);

        using var scope = _log.BeginScope(new Dictionary<string, object?>
        {
            ["oid"] = callerOid?.ToString() ?? "",
            ["authMode"] = isDelegatedCaller ? "delegated" : "app"
        });
        Activity.Current?.SetTag("oid", callerOid?.ToString() ?? "");
        Activity.Current?.SetTag("authMode", isDelegatedCaller ? "delegated" : "app");

        _log.LogInformation(
            "Auth context: roleCount={RoleCount}, scopeCount={ScopeCount}, oid={Oid}, delegated={IsDelegated}",
            callerRoles.Count,
            callerScopes.Count,
            callerOid,
            isDelegatedCaller);

        var hasContactPermission =
            EappFunctionAuth.HasAppRole(callerRoles, EappFunctionAuth.ContactReadRole)
            || (isDelegatedCaller
                && EappFunctionAuth.HasScope(req, EappFunctionAuth.ContactReadRole));

        if (!hasContactPermission)
        {
            return new ObjectResult(
                $"Missing required app role or delegated scope: {EappFunctionAuth.ContactReadRole}.")
            {
                StatusCode = StatusCodes.Status403Forbidden
            };
        }

        var queryParams = req.Query;
        string? userId = queryParams["userId"];
        string? opportunityId = queryParams["oppID"];

        Guid dataverseUserId;
        if (isDelegatedCaller)
        {
            var resolvedUserId = callerOid.HasValue
                ? ResolveSystemUserIdByEntraOid(callerOid.Value)
                : null;

            if (!resolvedUserId.HasValue)
            {
                return new ObjectResult("The signed-in user was not found in Dataverse.")
                {
                    StatusCode = StatusCodes.Status403Forbidden
                };
            }

            dataverseUserId = resolvedUserId.Value;
            if (!string.IsNullOrWhiteSpace(userId))
            {
                _log.LogInformation(
                    "Ignoring legacy userId parameter for delegated caller. Using user {UserId} resolved from token oid {Oid}.",
                    dataverseUserId,
                    callerOid);
            }
        }
        else if (string.IsNullOrWhiteSpace(userId)
            || !Guid.TryParse(userId, out dataverseUserId))
        {
            return new BadRequestObjectResult("A valid userId query parameter is required.");
        }

        if (!string.IsNullOrWhiteSpace(opportunityId) && !Guid.TryParse(opportunityId, out _))
        {
            return new BadRequestObjectResult("oppID must be a valid GUID when provided.");
        }

        if (!string.IsNullOrWhiteSpace(opportunityId)
            && !EappFunctionAuth.HasAppRole(callerRoles, EappFunctionAuth.OpportunityReadRole)
            && !(isDelegatedCaller
                && EappFunctionAuth.HasScope(req, EappFunctionAuth.OpportunityReadRole)))
        {
            return new ObjectResult(
                $"Missing required app role or delegated scope: {EappFunctionAuth.OpportunityReadRole}.")
            {
                StatusCode = StatusCodes.Status403Forbidden
            };
        }

        _log.LogInformation("CRM connection ready.");
        _log.LogInformation(
            "Processing request for user {UserId}, opportunity {OpportunityId}",
            dataverseUserId,
            WebUtility.HtmlEncode(LogSanitizer.Strip(string.IsNullOrWhiteSpace(opportunityId) ? "(none)" : opportunityId)));
        _log.LogInformation("Impersonating Dataverse user: {UserId}", dataverseUserId);

        try
        {
            _dataverseService.CallerId = dataverseUserId;
            return BuildSoReqResponse(dataverseUserId.ToString(), opportunityId);
        }
        catch (FaultException<OrganizationServiceFault> ex) when (IsInsufficientPrivilege(ex))
        {
            _log.LogWarning(ex, "Dataverse access denied for user {UserId}", dataverseUserId);
            return new ObjectResult("Access denied for the requested Dataverse records.")
            {
                StatusCode = StatusCodes.Status403Forbidden
            };
        }
        catch (FaultException<OrganizationServiceFault> ex)
        {
            _log.LogError(ex,
                "Dataverse error for user {UserId}. ErrorCode={ErrorCode}, Message={ErrorMessage}",
                dataverseUserId, ex.Detail.ErrorCode, WebUtility.HtmlEncode(LogSanitizer.Strip(ex.Detail.Message)));
            return new ObjectResult("A Dataverse error occurred. Please try again or contact support.")
            {
                StatusCode = StatusCodes.Status500InternalServerError
            };
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Unexpected error processing request for user {UserId}", dataverseUserId);
            return new ObjectResult("An unexpected error occurred. Please try again or contact support.")
            {
                StatusCode = StatusCodes.Status500InternalServerError
            };
        }
        finally
        {
            _dataverseService.CallerId = Guid.Empty;
        }
    }

    private Guid? ResolveSystemUserIdByEntraOid(Guid entraOid)
    {
        var query = new QueryExpression("systemuser")
        {
            TopCount = 1,
            ColumnSet = new ColumnSet("systemuserid"),
            Criteria = new FilterExpression(LogicalOperator.And)
        };
        query.Criteria.AddCondition(
            "azureactivedirectoryobjectid",
            ConditionOperator.Equal,
            entraOid);
        query.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, false);

        var result = _dataverseService.RetrieveMultiple(query);
        return result.Entities is { Count: > 0 } ? result.Entities[0].Id : null;
    }

    private IActionResult BuildSoReqResponse(string userId, string? opportunityId)
    {
        string userFetchXml = $@"
                                    <fetch top='50'>
                                      <entity name='systemuser'>
                                         <attribute name='kofc_agentid' />
                                         <attribute name='kofc_user_ldap_id' />
                                         <attribute name='windowsliveid' />
                                         <attribute name='kofc_insurancerole' />
                                        <filter>
                                          <condition attribute='systemuserid' operator='eq' value='{userId}' />
                                        </filter>
                                      </entity>
                                    </fetch>";

        var userFetchExpression = new FetchExpression(userFetchXml);
        EntityCollection userResult = _dataverseService.RetrieveMultiple(userFetchExpression);
        var soReq = new SoReqData();

        if (userResult.Entities == null || userResult.Entities.Count == 0)
        {
            return new NotFoundObjectResult("User not found.");
        }

        Entity userEntity = userResult.Entities[0];
        string? roleLabel;

        if (userEntity.Contains("kofc_insurancerole"))
        {
            OptionSetValue roleCodeId = userEntity.GetAttributeValue<OptionSetValue>("kofc_insurancerole");
            roleLabel = GetOptionSetValueLabel("systemuser", "kofc_insurancerole", roleCodeId.Value);
        }
        else
        {
            _log.LogWarning(
                "kofc_insurancerole not present for user {UserId}. Attributes returned: {Attributes}. "
                + "Likely causes: field is empty, field-level security hides it under impersonation, or wrong userId.",
                WebUtility.HtmlEncode(LogSanitizer.Strip(userId)),
                WebUtility.HtmlEncode(LogSanitizer.Strip(string.Join(", ", userEntity.Attributes.Keys))));
            return new BadRequestObjectResult("Role not found for the user.");
        }

        string roletype = EappRoleMapper.ResolveRoleType(roleLabel);

        soReq.reqAction = "EAPP";
        string dateTime = DateTime.Now.ToString("yyyy-MM-dd.HH:mm:ss");
        soReq.gmtStamp = dateTime;
        soReq.agentId = userEntity.GetAttributeValue<string>("kofc_agentid") ?? " ";
        soReq.loginUserID = userEntity.GetAttributeValue<string>("kofc_user_ldap_id") ?? " ";

        _log.LogInformation("Resolved user role type: {RoleType}", WebUtility.HtmlEncode(LogSanitizer.Strip(roletype)));

        EappRoleMapper.ApplyRoleFlags(soReq, roletype);

        if (!string.IsNullOrEmpty(opportunityId))
        {
            string clientFetchXml = $@"<fetch>
                                        <entity name = 'opportunity'>
                                            <attribute name = 'opportunityid'/>
                                             <filter type = 'and' >
                                                 <condition attribute = 'parentcontactid' operator= 'not-null'/>
                                                 <condition attribute='opportunityid' operator='eq' value='{opportunityId}'/>
                                            </filter>
                                                <link-entity name = 'contact' from = 'contactid' to = 'parentcontactid' visible = 'false' link-type = 'outer' alias = 'c' >
                                                    <attribute name = 'kofc_clientid'/>
                                                    <attribute name = 'kofc_contacttype'/>
                                                    <attribute name = 'kofc_birthdate'/>
                                                </link-entity>
                                             </entity>
                                        </fetch>";

            var clientFetchExpression = new FetchExpression(clientFetchXml);
            EntityCollection clientResult = _dataverseService.RetrieveMultiple(clientFetchExpression);

            if (clientResult.Entities != null && clientResult.Entities.Count > 0)
            {
                Entity client = clientResult.Entities[0];
                var clientId = client.GetAttributeValue<AliasedValue>("c.kofc_clientid");
                soReq.clientId = clientId?.Value.ToString() ?? string.Empty;

                var clientDob = client.GetAttributeValue<AliasedValue>("c.kofc_birthdate");
                if (clientDob != null && DateTime.TryParse(clientDob.Value.ToString(), out DateTime dob))
                {
                    soReq.clientDob = dob.ToString("yyyy-MM-dd");
                }
            }
        }

        string jsonResult = JsonConvert.SerializeObject(soReq, Formatting.Indented);
        string base64encodedStr = Base64Encode(jsonResult);
        _log.LogInformation("EApp SSO success: base64 payload generated ({ByteLength} bytes).", base64encodedStr.Length);

        return new ContentResult
        {
            Content = base64encodedStr,
            ContentType = "text/plain",
            StatusCode = StatusCodes.Status200OK
        };
    }

    private static bool IsInsufficientPrivilege(FaultException<OrganizationServiceFault> ex)
    {
        const int PrivilegeDeniedErrorCode = unchecked((int)0x80048303);
        return ex.Detail.ErrorCode == PrivilegeDeniedErrorCode;
    }

    private static string Base64Encode(string jsonStr)
    {
        return Convert.ToBase64String(Encoding.UTF8.GetBytes(jsonStr));
    }

    private string? GetOptionSetValueLabel(string entityName, string fieldName, int optionSetValue)
    {
        var attReq = new RetrieveAttributeRequest
        {
            EntityLogicalName = entityName,
            LogicalName = fieldName,
            RetrieveAsIfPublished = true
        };

        var attResponse = (RetrieveAttributeResponse)_dataverseService.Execute(attReq);
        if (attResponse.AttributeMetadata is not EnumAttributeMetadata attMetadata
            || attMetadata.OptionSet?.Options == null)
        {
            return null;
        }

        return attMetadata.OptionSet.Options
            .FirstOrDefault(x => x.Value == optionSetValue)
            ?.Label?.UserLocalizedLabel?.Label;
    }
}
