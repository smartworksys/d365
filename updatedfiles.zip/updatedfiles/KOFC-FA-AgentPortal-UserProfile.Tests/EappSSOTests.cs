using System.Text;
using KOFC_FA_AgentPortal_UserProfile.Tests.Support;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Newtonsoft.Json;

namespace KOFC_FA_AgentPortal_UserProfile.Tests;

public class EappSSOTests
{
    [Fact]
    public void Run_ReturnsBadRequestWhenUserIdMissing()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var function = CreateFunction(new FakeDataverseService());
        var request = HttpRequestTestHelper.CreateRequest();

        var result = function.Run(request);

        var badRequest = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal("A valid userId query parameter is required.", badRequest.Value);
    }

    [Fact]
    public void Run_ReturnsBadRequestWhenOppIdInvalid()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var function = CreateFunction(new FakeDataverseService());
        var userId = Guid.NewGuid();
        var request = HttpRequestTestHelper.CreateRequest($"?userId={userId}&oppID=not-a-guid");

        var result = function.Run(request);

        var badRequest = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal("oppID must be a valid GUID when provided.", badRequest.Value);
    }

    [Fact]
    public void Run_ReturnsForbiddenWhenOpportunityRoleMissingInAzure()
    {
        using var azure = new AzureEnvironmentScope(simulateAzureHost: true);
        var function = CreateFunction(new FakeDataverseService());
        var userId = Guid.NewGuid();
        var oppId = Guid.NewGuid();
        var request = HttpRequestTestHelper.CreateRequest(
            queryString: $"?userId={userId}&oppID={oppId}",
            claims: new[] { new System.Security.Claims.Claim("roles", "Contact.Read") });

        var result = function.Run(request);

        var forbidden = Assert.IsType<ObjectResult>(result);
        Assert.Equal(403, forbidden.StatusCode);
    }

    [Fact]
    public void Run_DelegatedSpaToken_ResolvesUserFromOidWithoutUserId()
    {
        using var azure = new AzureEnvironmentScope(simulateAzureHost: true);
        var oid = Guid.NewGuid();
        var userId = Guid.NewGuid();
        var userEntity = new Entity("systemuser") { Id = userId };
        userEntity["kofc_agentid"] = "AGENT-SPA";
        userEntity["kofc_user_ldap_id"] = "spa-user";
        userEntity["kofc_insurancerole"] = new OptionSetValue(1);
        var fake = new FakeDataverseService
        {
            UserEntities = new EntityCollection(new List<Entity> { userEntity }),
            OptionSetLabel = "Insurance-General Agent"
        };
        var function = CreateFunction(fake);
        var request = HttpRequestTestHelper.CreateRequest(
            principalRoleClaims: new[]
            {
                ("scp", "Contact.Read"),
                ("oid", oid.ToString())
            });

        var result = function.Run(request);

        var content = Assert.IsType<ContentResult>(result);
        Assert.Equal(200, content.StatusCode);
        Assert.Equal(Guid.Empty, fake.CallerId);
    }

    [Fact]
    public void Run_ReturnsNotFoundWhenUserDoesNotExist()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var fake = new FakeDataverseService
        {
            UserEntities = new EntityCollection()
        };
        var function = CreateFunction(fake);
        var userId = Guid.NewGuid();
        var request = HttpRequestTestHelper.CreateRequest($"?userId={userId}");

        var result = function.Run(request);

        Assert.IsType<NotFoundObjectResult>(result);
        Assert.Equal(Guid.Empty, fake.CallerId);
    }

    [Fact]
    public void Run_ReturnsBase64EncodedSoReqForValidUser()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var userId = Guid.NewGuid();
        var userEntity = new Entity("systemuser")
        {
            Id = userId
        };
        userEntity["kofc_agentid"] = "AGENT-001";
        userEntity["kofc_user_ldap_id"] = "ldap-user";
        userEntity["kofc_insurancerole"] = new OptionSetValue(1);

        var fake = new FakeDataverseService
        {
            UserEntities = new EntityCollection(new List<Entity> { userEntity }),
            OptionSetLabel = "Insurance-General Agent"
        };

        var function = CreateFunction(fake);
        var request = HttpRequestTestHelper.CreateRequest($"?userId={userId}");

        var result = function.Run(request);

        var content = Assert.IsType<ContentResult>(result);
        Assert.Equal(200, content.StatusCode);
        Assert.Equal("text/plain", content.ContentType);

        var json = Encoding.UTF8.GetString(Convert.FromBase64String(content.Content!));
        var soReq = JsonConvert.DeserializeObject<SoReqData>(json);

        Assert.NotNull(soReq);
        Assert.Equal("EAPP", soReq!.reqAction);
        Assert.Equal("AGENT-001", soReq.agentId);
        Assert.True(soReq.isGeneralAgent);
        Assert.Equal(Guid.Empty, fake.CallerId);
    }

    [Fact]
    public void Run_SetsAdminFlagForAgencyAdminRole()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var userId = Guid.NewGuid();
        var userEntity = new Entity("systemuser") { Id = userId };
        userEntity["kofc_agentid"] = "AGENT-ADMIN";
        userEntity["kofc_user_ldap_id"] = "ldap-admin";
        userEntity["kofc_insurancerole"] = new OptionSetValue(6);

        var fake = new FakeDataverseService
        {
            UserEntities = new EntityCollection(new List<Entity> { userEntity }),
            OptionSetLabel = "Insurance-AgencyAdmin",
            OptionSetValue = 6
        };

        var function = CreateFunction(fake);
        var request = HttpRequestTestHelper.CreateRequest($"?userId={userId}");

        var result = function.Run(request);
        var content = Assert.IsType<ContentResult>(result);
        var json = Encoding.UTF8.GetString(Convert.FromBase64String(content.Content!));
        var soReq = JsonConvert.DeserializeObject<SoReqData>(json);

        Assert.NotNull(soReq);
        Assert.True(soReq!.isAdmin);
    }

    private static EappSSO CreateFunction(FakeDataverseService fake) =>
        new(NullLogger<EappSSO>.Instance, fake);
}
