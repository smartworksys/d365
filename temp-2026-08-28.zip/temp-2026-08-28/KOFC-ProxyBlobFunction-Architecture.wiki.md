# KOFC Proxy Blob Function — Architecture

> **Solution:** `proxyBlobFunction` (`KOFC.Azure.Functions.GetSaasBlobUrl`)
> **Function:** `GetSaasBlobUrl`
> **Runtime:** .NET 8 (Isolated), Azure Functions v4
> **Last updated:** 2026-08-28 (full end-to-end flow)

[[_TOC_]]

---

## 1. Overview

The Proxy Blob Function App exposes a secure HTTP API that returns a **Contact-authorized file** from Azure Blob Storage. Users click a **Blob Link Activity** on the Contact timeline in Dynamics 365. The browser never calls the Function or storage account directly.

The path is:

```text
Contact timeline Subject
  → Blob Link Activity form OnLoad
  → kofc_blob_open.html
  → MSAL SPA token (api://{kofc_BlobApiAppId}/.default)
  → POST Boomi (Bearer JWT only; no x-api-key)
  → GetSaasBlobUrl
  → Function Managed Identity downloads the blob
  → JSON { fileName, contentType, contentBase64 }
  → browser saves the file
```

**Key characteristics**

- **D365 client path:** MSAL delegated SPA token → **Boomi** (validates JWT) → Function (**same SPA token forwarded**).
- **Function inbound auth:** **Easy Auth** + delegated **`scp`** (`Blob.Read` or `access_as_user`). No function key from the browser. No Boomi client-credentials.
- **User identity:** token **`oid`** → Dataverse `systemuser`. **`userId` is not required**; legacy `userId` / `oid` body fields are ignored for delegated callers.
- **Per-user security:** `ContactAccessGuard` sets `ServiceClient.CallerId` and **Retrieves** the requested Contact. If the user cannot read that Contact, the Function returns **403** (generic body; details in logs only).
- **Storage:** Function App **Managed Identity** reads the blob (`DownloadAsync`). Production default is **`format=file`** so the browser never hits `*.blob.core.windows.net` (storage firewall / private endpoint — SAS fails off VPN).
- **SAS (`format=json` / redirect)** remains available for validator / VPN testing. The Function still does not put SAS URLs or file bytes in logs.
- **Blob Boomi calls send no `x-api-key`.** EApp and Policy still send theirs.

> **SPA-token forward model (same as EApp / Policy).** The browser's delegated token authenticates the *user* to Boomi. Boomi forwards that token to the Function. Easy Auth validates it; the Function authorizes on **`scp`** and binds Dataverse impersonation to token **`oid`**.

---

## 2. Identities & App Registrations

There are **two Entra ID app registrations** plus the **Function App Managed Identity**. Boomi does **not** need a confidential client for calling the Function.

| # | Identity | Type | Secret? | Purpose |
|---|----------|------|---------|---------|
| 1 | **SPA (D365 opener)** | App registration (public client / SPA) | No | Browser sign-in via MSAL.js; acquires the **delegated user token** |
| 2 | **Function App API** | App registration (resource) | No | Defines delegated scopes (`Blob.Read` / `access_as_user`); Easy Auth validates tokens issued **for** this API |
| 3 | **Function App Managed Identity** | System-assigned MI | No | Function App acquires tokens **to call Dataverse** and **Azure Blob Storage** |

> Easy Auth is **not** a separate app registration — it is middleware on the Function App configured to trust app registration **#2**.

### 2.1 Delegated scopes (on the Function API registration)

| Scope (`scp` claim) | Required when | Present in which token |
|---------------------|---------------|------------------------|
| `Blob.Read` (or `access_as_user`) | Every call | SPA delegated token |

> Production uses the **SPA delegated token** end-to-end (browser → Boomi → Function). Authorization is on **`scp`**, not app-role **`roles`**. Empty `roles` in Function logs is expected for SPA tokens.

### 2.2 SPA redirect URIs

Register under the **SPA** app (`kofc_SPAClientId`), case-sensitive:

```text
https://<org>.crm.dynamics.com/WebResources/kofc_authcallback.html
```

Same callback page as EApp and Policy — no extra redirect URI if that page is already registered.

---

## 3. High-Level Architecture

::: mermaid
flowchart LR
    subgraph D365["Dynamics 365"]
        TL["Contact timeline<br/>Blob Link Activity"]
        FORM["kofc_blobLinkActivity.js<br/>OnLoad"]
        OPEN["kofc_blob_open.html"]
        AUTH["kofc_authclient.js<br/>KOFC.Auth / MSAL"]
        CB["kofc_authcallback.html"]
    end

    subgraph BOOMI["Boomi"]
        BP["Blob Proxy / GetSmartOffice<br/>Validate SPA JWT<br/>Forward SPA token"]
    end

    subgraph AZURE["Azure Function App"]
        EA["Easy Auth<br/>(validates SPA token)"]
        FA["GetSaasBlobUrl"]
        GUARD["ContactAccessGuard"]
        BLOB["BlobService"]
        MI["Managed Identity"]
    end

    ST[("Azure Blob Storage")]
    DV[("Dataverse")]
    AAD["Microsoft Entra ID"]

    TL --> FORM
    FORM -->|path + contactId in localStorage| OPEN
    OPEN --> AUTH
    AUTH -->|MSAL: Blob.Read / .default| AAD
    AAD -->|delegated SPA token| CB
    CB -.->|token| OPEN
    OPEN -->|Bearer SPA token<br/>path + contactId + format=file| BP
    BP -->|same Bearer SPA token + params| EA
    EA --> FA
    FA -->|scp + oid| FA
    FA --> GUARD
    GUARD --> MI
    MI --> DV
    FA --> BLOB
    BLOB --> MI
    MI --> ST
    FA -.->|file JSON or sasUrl| BP
    BP -.->|JSON| OPEN
:::

> **One SPA token, two hops.** Dashed arrows are responses. The browser downloads the file from the Function JSON — it does not open blob storage unless `format=json` (VPN).

---

## 4. Authentication Layers

The solution uses **independent auth layers**. They are **not** linked by token exchange.

| Layer | Direction | Mechanism | Identity | Purpose |
|-------|-----------|-----------|----------|---------|
| Gateway | Browser → Boomi | SPA JWT (no `x-api-key`) | Signed-in D365 user | Validate caller before proxying |
| Inbound | Boomi → Function | Easy Auth + SPA token | Same SPA user token | Authorize API access (`scp`) |
| Outbound | Function → Dataverse | `DefaultAzureCredential` | Function App Managed Identity | Acquire Dataverse token |
| Impersonation | Function → Dataverse | `ServiceClient.CallerId` | Dataverse `systemuser` from token `oid` | Enforce Contact read |
| Storage | Function → Blob | Managed Identity | Function App MI | Download / user-delegation SAS |

::: mermaid
flowchart TB
    T1["SPA delegated token<br/>forwarded by Boomi<br/><i>audience = Blob Function API</i>"] --> Q1{"Is caller<br/>allowed to hit<br/>the API?"}
    Q1 -->|Easy Auth + scp Blob.Read| OK1["Authenticated delegated user"]

    T2["Managed Identity token<br/><i>audience = Dataverse</i>"] --> Q2{"Can the app<br/>reach Dataverse?"}
    Q2 -->|DefaultAzureCredential| OK2["ServiceClient connected"]

    OK2 --> IMP["CallerId = systemuserid from oid"]
    IMP --> Q3{"Can THIS user<br/>read the Contact?"}
    Q3 -->|Retrieve contact| OK3["Access granted or 403/404"]

    T3["Managed Identity token<br/><i>audience = storage</i>"] --> Q4{"Can the app<br/>read the blob?"}
    Q4 -->|Storage Blob Data Contributor| OK4["Download or SAS"]
:::

---

## 5. End-to-End Sequence

::: mermaid
sequenceDiagram
    autonumber
    participant U as D365 User
    participant TL as Timeline / Form
    participant JS as kofc_blob_open.html
    participant B as Boomi
    participant EA as Easy Auth
    participant FA as GetSaasBlobUrl
    participant AAD as Entra ID
    participant DV as Dataverse
    participant ST as Blob Storage

    U->>TL: Click activity Subject
    TL->>TL: OnLoad reads Description + Regarding
    TL->>JS: Open opener with activity GUID
    JS->>AAD: MSAL acquire token (Blob.Read / .default)
    AAD-->>JS: Delegated SPA token (scp)
    JS->>B: POST Bearer SPA token<br/>path + contactId + format=file
    B->>B: Validate SPA JWT
    B->>EA: Same Bearer token + params
    EA->>EA: Validate token (sig, exp, aud, iss)
    EA->>FA: Principal + access-token headers
    FA->>FA: Require Blob.Read or access_as_user
    FA->>FA: Resolve systemuserid from token oid
    FA->>DV: CallerId Retrieve contact
    DV-->>FA: Granted / denied
    alt format=file or proxy
        FA->>ST: MI DownloadAsync
        ST-->>FA: File bytes
        FA-->>B: fileName, contentType, contentBase64
    else format=json
        FA->>ST: MI user-delegation SAS
        ST-->>FA: sasUrl
        FA-->>B: { sasUrl }
    end
    B-->>JS: JSON
    JS-->>U: Browser download (file) or SAS navigate (VPN)
:::

### 5.0 Flow diagram (all hops)

::: mermaid
flowchart TB
    subgraph D365["1. Dynamics 365"]
        A[User clicks Subject on Contact timeline] --> B[Blob Link Activity form OnLoad]
        B --> C[Save Description + Regarding to localStorage]
        C --> D[Open kofc_blob_open.html with activity GUID]
        D --> E[navigateBack to Contact]
        D --> F[Opener reads path + contactId]
        F --> G[Load env vars and KOFC.Blob.configure]
    end

    subgraph ENTRA["2. Microsoft Entra"]
        G --> H{MSAL cache?}
        H -->|No / expired| I[Redirect to kofc_authcallback.html]
        I --> J[User signs in]
        J --> K[Delegated SPA token oid + scp]
        H -->|Yes| L[acquireTokenSilent]
        L --> K
    end

    subgraph BOOMI["3. Boomi Blob Proxy"]
        K --> M[POST Bearer JWT]
        M --> N["Body: encodeURI path, contactId, format=file"]
        N --> O[Validate JWT — no x-api-key, no userId]
        O --> P[Forward same Bearer token to Function]
    end

    subgraph FN["4. GetSaasBlobUrl"]
        P --> Q[Easy Auth validates SPA token]
        Q --> R{scp Blob.Read or access_as_user?}
        R -->|No| X1[403]
        R -->|Yes| S[Resolve systemuser from oid]
        S -->|Not found| X2[404 User not found]
        S -->|OK| T[CallerId Retrieve Contact]
        T -->|Denied| X3[403 Access denied]
        T -->|Granted| U[Normalize D:\\ path to blob path]
        U --> V[MI DownloadAsync]
        V -->|Missing| X4[404 file does not exist]
        V -->|OK| W["200 fileName, contentType, contentBase64"]
    end

    subgraph USER["5. Browser"]
        W --> Y[Boomi returns JSON unchanged]
        Y --> Z[atob → Blob → download]
        Z --> AA[Hide spinner / show File downloaded]
    end
:::

> Production stays on the **file** path. `format=json` branches after **U** to a user-delegation SAS and the browser opens `*.blob.core.windows.net` (VPN required).

### 5.1 Happy path — first click (no MSAL cache)

This is what a user sees the first time that day (or after cache clear).

1. **Contact timeline.** User clicks the Blob Link Activity **Subject** (file name). Dynamics opens the Blob Link Activity main form.
2. **Form OnLoad** (`kofc_blobLinkActivity.js` → `KOFC.BlobLinkActivity.onLoad`):
   - Form type **1 (Create)** → exit. ADF / makers can still save a new record.
   - Reads `description` (Windows path), `regardingobjectid` (Contact GUID), entity logical name, and activity GUID.
   - Writes `localStorage.kofc_blob_open_ctx`: `{ activityId, path, contactId, entityName, ts }`.
   - Opens a new tab:  
     `{org}/main.aspx?pagetype=webresource&webresourceName=kofc_blob_open.html&data={activityGuid}&forceUCI=1`
   - Calls `Xrm.Navigation.navigateBack()` so the user returns to the Contact. If the pop-up is blocked, the current tab navigates to the opener instead.
3. **Opener starts** (`kofc_blob_open.html`):
   - Title/status: *Opening file* / *Reading link parameters…*
   - Parses `data=` as the activity GUID (also supports legacy `path|contactId` and `path=&contactId=`).
   - Checks `kofc_blob_result` (empty on first click).
   - Waits for `Xrm.WebApi` (must be `main.aspx`, not raw `/WebResources/`).
   - Reads `kofc_blob_open_ctx` if `activityId` matches → uses Description + Regarding. **Does not** call `retrieveRecord`.
   - If context is missing or Description/Regarding empty → `Xrm.WebApi.retrieveRecord(kofc_bloblinkactivity, id, ?$select=subject,description,_regardingobjectid_value)`. Failure shows table + activity id + Dynamics privilege text (`{0}`…`{6}` filled).
   - Empty Description or Regarding after load → *Blob Link Activity is missing Description (path) or Regarding (Contact).*
   - Loads env vars: `kofc_TenantId`, `kofc_SPAClientId`, `kofc_BlobApiAppId`, `kofc_BlobBoomiUrl`.
   - `KOFC.Blob.configure({ scope: ".default", httpMethod: "POST", redirectWebResource: "kofc_authcallback.html", … })`.
4. **Token** (`KOFC.Auth.getAccessToken` / `openSaasBlob`):
   - Writes `kofc_blob_pending` (`action: blob`, raw path, contactId, boomiUrl, apiScopes, returnUrl).
   - Tries `acquireTokenSilent`, then `ssoSilent`, then **`acquireTokenRedirect`** to Microsoft.
   - Opener status: *Redirecting to Microsoft sign-in…* and the tab leaves Dynamics.
5. **Callback** (`kofc_authcallback.html`):
   - `handleRedirectPromise()` exchanges the auth code; token is cached in `localStorage`.
   - Sees `kofc_blob_pending` → `callBlobApi()` **POST** Boomi:
     - Header: `Authorization: Bearer {SPA token}` only (no `x-api-key`).
     - Body: `{ path: encodeURI(path), contactId, format: "file" }`.
   - Stores `kofc_blob_result` (`ok`, status, parsed JSON).
   - If `contentBase64` + `fileName` → builds a Blob, triggers download, hides spinner, shows green check: *File downloaded. You can close this tab.*
   - If only `sasUrl` → `window.location.href = sasUrl` (needs VPN).
6. **If the user returns to the opener tab** (returnUrl / still open): `consumePendingResult()` reads `kofc_blob_result`, downloads again if needed, `showSuccess(fileName)`, spinner off, **Close tab**.

### 5.2 Happy path — later click (silent token)

Same as 5.1 through opener configure. MSAL has a cached account:

1. `acquireTokenSilent` succeeds — **no redirect**, no callback page.
2. `kofc_blobClient.js` POSTs Boomi immediately (`format: "file"`).
3. Boomi → Function (same as 5.4–5.5).
4. Opener `downloadFromPayload`: `atob` → `Blob` → `<a download>` → **File downloaded** + Close tab.

Typical UI: *Signing in and requesting file access…* → file in Downloads → *File downloaded*.

### 5.3 Browser → Boomi (exact contract)

| Item | Value |
|------|-------|
| Method | **POST** only (GET leftover in code is unused) |
| URL | `kofc_BlobBoomiUrl` with **no** query string |
| `Authorization` | `Bearer <delegated SPA JWT>` |
| `Accept` | `application/json` |
| `Content-Type` | `application/json` |
| `x-api-key` | **Not sent** |
| Body `path` | `encodeURI(normalized Description)` e.g. `D:%5CKOFCEXT%20Extractions%5C09272024\...` |
| Body `contactId` | Regarding GUID, braces stripped |
| Body `format` | `"file"` |

Identity is **only** the token `oid`. Do not send `userId`.

### 5.4 Boomi → Function

1. Validate JWT (signature, issuer, audience = Blob API app, expiry, `scp`).
2. **Do not** swap to client-credentials. **Do not** add `userId`.
3. POST/GET Function `/api/GetSaasBlobUrl` with the **same** `Authorization: Bearer` and the same `path` / `contactId` / `format`.
4. Return the Function JSON **unchanged** (`contentBase64` or `sasUrl`). Do not unwrap or drop fields.

### 5.5 Function processing (every request)

1. **Easy Auth** — unauthenticated → **401** `Authentication required.` Log: `Unauthenticated`.
2. **Delegated `scp`** — must include `Blob.Read` or `access_as_user`. Else **403**. Log: `DelegatedScopeMissing`. Empty `roles` is normal.
3. **`oid`** — missing → **401**. Log: `MissingOid`.
4. Merge query + POST JSON. Missing `path` → **400**. Bad `contactId` → **400**.
5. Ignore legacy `userId` / body `oid`.
6. **`ContactAccessGuard.CheckContactAccessByEntraOid(oid, contactId)`**
   - Resolve enabled `systemuser` where `azureactivedirectoryobjectid` = token oid.
   - Not found → **404** `User not found.` Log: `UserNotFound`, UserId/email if known.
   - `CallerId` = that systemuserid → **Retrieve** `contact(contactId)`.
   - Privilege / not visible → **403** `Access denied.` Log: `AccessDenied`, ContactId, Path, UserId, UserEmail, UserName, EntraOid.
   - Reset `CallerId`.
7. **`NormalizePathToBlob`** — decode `+` / `%20` / `%5C` / `&nbsp;`, strip `D:\`, `\` → `/`. Empty → **400**.
8. **`format`**
   - `file` or `proxy` → MI `DownloadAsync` → **200** `{ fileName, contentType, contentBase64 }`. Log success (bytes, names — **not** base64).
   - `json` → user-delegation SAS (`AbsoluteUri` keeps `%20`) → **200** `{ sasUrl }`. Log success (**not** the SAS URL).
   - else → **302** to SAS.
9. Missing blob → **404** `The requested file does not exist`. Storage fault → **500** generic. Log `ExceptionType` (`InvalidOperationException` / `RequestFailedException`).

HTTP bodies stay generic. Logs have ContactId, Path, BlobPath, Container, UserId, UserEmail, UserName, EntraOid, Outcome, Status, Reason, Scopes, and ExceptionType **on failures only**.

### 5.6 File reaches the user

```text
Function JSON
  → Boomi passthrough
  → kofc_blobClient.downloadFromPayload / callback
  → atob(contentBase64) → Uint8Array → Blob(contentType)
  → object URL + <a download=fileName> click
  → browser Downloads folder
```

The page does **not** navigate to `*.blob.core.windows.net`. Spinner stops; checkmark / *File downloaded* / Close tab.

`format=json` only: `window.location.href = sasUrl`. That host is firewalled — **AuthorizationFailure** off VPN. Same for account-key SAS.

### 5.7 Alternate and error flows

| Step | What happens | User sees |
|------|----------------|-----------|
| Empty Description / no Regarding | OnLoad still opens opener; context or retrieve finds empty fields | *Unable to open file* — missing Description (path) or Regarding |
| No Read on Blob Link Activity + no form context | `retrieveRecord` fails | *Could not load Blob Link Activity* + table `kofc_bloblinkactivity` + GUID + privilege `{2}=Read` |
| Form OnLoad published | Context in `localStorage` | Retrieve skipped; path/contact from the form |
| User cannot read Contact | Function 403 | *File request failed (HTTP 403): Access denied.* + path/contactId sent |
| oid not a Dataverse user | Function 404 | *HTTP 404: User not found.* |
| Wrong/missing blob path | Function 404 | *The requested file does not exist* |
| Missing env vars | Opener throws before Boomi | *Missing configuration: kofc_…* |
| Raw `/WebResources/kofc_blob_open.html` | No Xrm | *Dynamics Xrm.WebApi is not available* — use `main.aspx` |
| Pop-up blocked | OnLoad `location.replace` | Opener in the same tab |
| First-time sign-in | Full Microsoft redirect | Callback spinner then check + download |
| Silent token later | No redirect | Download on the opener tab |
| Validator `format=file` | Same Function path | JSON with `contentBase64` |
| Validator `format=json` | SAS | `{ sasUrl }` — open only on VPN |
| Large file | Base64 through Boomi | Timeout / size limit — stream would be a later change |

### 5.8 Identity and data on each hop

```text
User clicks Subject
  → D365 already authenticated (Dataverse cookie)
  → OnLoad: path + contactId from the form (not from the Function)
  → MSAL: new token for api://{BlobApiAppId}/.default  (oid, scp, preferred_username)
  → Boomi: proves JWT; does not become the user
  → Easy Auth: same JWT
  → Function: oid → systemuserid → CallerId → Contact Read
  → Function MI: storage download
  → Browser: file bytes only (no storage URL)
```

| Hop | Knows | Does not need |
|-----|--------|----------------|
| Timeline / form | Activity, Description, Regarding | Token, Boomi, storage |
| Opener | path, contactId, env vars | `userId` |
| Boomi | JWT + path + contactId + format | Function key, client secret, `userId` |
| Function | oid, scp, path, contactId | Browser IP on storage |
| Storage | MI of the Function | End-user identity |

### 5.9 Timeouts (opener)

| Step | Timeout |
|------|---------|
| Wait for Xrm | 8s |
| Load activity (retrieve fallback) | 15s |
| Load env vars | 20s |
| Sign-in + Boomi | 60s |

---

## 6. Request Processing Logic

::: mermaid
flowchart TD
    START([Request received]) --> AUTH{IsAuthenticated?}
    AUTH -->|No| E401[401 Unauthorized]
    AUTH -->|Yes| DEL{Delegated caller<br/>Blob.Read or access_as_user?}
    DEL -->|No| E403a[403 Forbidden]
    DEL -->|Yes| OID{Token has oid?}
    OID -->|No| E401b[401 Unauthorized]
    OID -->|Yes| PARSE[Merge query + POST JSON]
    PARSE --> PATH{path present?}
    PATH -->|No| E400a[400 Missing path]
    PATH -->|Yes| CID{contactId valid GUID?}
    CID -->|No| E400b[400 Invalid contactId]
    CID -->|Yes| GUARD[CheckContactAccessByEntraOid]
    GUARD -->|UserNotFound| E404a[404 User not found]
    GUARD -->|AccessDenied| E403b[403 Access denied]
    GUARD -->|Granted| NORM[NormalizePathToBlob]
    NORM -->|Empty| E400c[400 Invalid file path]
    NORM -->|OK| FMT{format}
    FMT -->|file / proxy| DL[DownloadAsync]
    FMT -->|json| SAS[GenerateSasUrlAsync]
    FMT -->|other| REDIR[Redirect SAS]
    DL -->|OK| OK200[200 file JSON]
    SAS -->|OK| OK200j[200 sasUrl]
    DL -->|Missing blob| E404b[404 File does not exist]
    SAS -->|Missing blob| E404b
    DL -->|Storage error| E500[500 Storage error]
:::

HTTP bodies stay **generic**. Contact, path, user, and exception details are written to **Application Insights / Function logs** only.

---

## 7. Component Model

| Source file | Responsibility |
|-------------|----------------|
| `Program.cs` | DI host; MI `BlobServiceClient`; **scoped** Dataverse `ServiceClient`; App Insights log filter |
| `GetSaasBlobUrl.cs` | HTTP trigger; Easy Auth + `scp`; oid resolve; access guard; `format` routing; structured success/failure logs |
| `Helpers/FunctionAppRoleAuth.cs` | Easy Auth + delegated **`scp`**; `oid`, email, display name from token |
| `Services/ContactAccessGuard.cs` | oid → `systemuser` + impersonated Contact **Retrieve** |
| `Services/DataverseClientFactory.cs` | MI + `DefaultAzureCredential` Dataverse connection (`DataverseUrl` / `CRM_URL`) |
| `Services/BlobService.cs` | Path decode/normalize; `DownloadAsync`; user-delegation SAS (`AbsoluteUri`) |
| `Services/BlobFileContent.cs` | Download payload (`Content`, `ContentType`, `FileName`) |

### 7.1 Client web resources (Dynamics 365)

| Web resource | Folder | Responsibility |
|--------------|--------|----------------|
| `kofc_authclient.js` | `webresources/eapp-boomi-button/` | Shared MSAL (`KOFC.Auth`) — **do not change EApp/Policy API-key behavior** |
| `kofc_authcallback.html` | `webresources/eapp-boomi-button/` | Shared redirect URI; blob pending uses `callBlobApi()` (`format: file`, no `x-api-key`) |
| `kofc_msalbrowsermin` | `webresources/` | MSAL.js (org-hosted) |
| `kofc_blobClient.js` | `webresources/blob-link-activity/` | `KOFC.Blob` — POST Boomi `path` + `contactId` + `format=file`; download base64 |
| `kofc_blob_open.html` | `webresources/blob-link-activity/` | Timeline landing page; env vars; success/error UI |
| `kofc_blobLinkActivity.js` | `webresources/blob-link-activity/` | Form OnLoad: stash Description + Regarding, open opener, `navigateBack` |
| `kofc_blobLinkBuilder.js` | `webresources/blob-link-activity/` | Optional URL / timeline HTML builder |

---

## 8. API Specification

### 8.1 Endpoint

| Property | Value |
|----------|-------|
| Function name | `GetSaasBlobUrl` |
| Methods | `GET`, `POST` |
| Authorization | **Easy Auth** + **`Blob.Read`** / **`access_as_user`** (SPA token forwarded by Boomi) |
| Response content type | `application/json` (`format=file` or `json`) |

**Example (called by Boomi, not the browser):**

```text
POST https://<function-app>.azurewebsites.net/api/GetSaasBlobUrl
Authorization: Bearer <same SPA token>
Content-Type: application/json

{
  "path": "D:%5CKOFCEXT%20Extractions%5C09272024\\000554\\file.xlsx",
  "contactId": "653df982-6a82-4bbc-8299-0000238ec972",
  "format": "file"
}
```

### 8.2 Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `path` | Yes | Windows path from activity Description (raw or `encodeURI`) |
| `contactId` | Yes | Contact GUID (Regarding), no braces |
| `format` | No | `file` / `proxy` (default production), `json` (SAS), or omit for SAS redirect |
| `userId` | **No** | Ignored for delegated callers |
| `oid` | **No** | Ignored; identity from token `oid` |

POST JSON is merged with the query string. Path encoding matches the Boomi validator: **`encodeURI`** (not `encodeURIComponent`). The Function decodes `+`, `%20`, `%5C`, and `&nbsp;` before stripping `D:\`.

**Normalized blob example**

| Input Description | Blob path in container |
|-------------------|------------------------|
| `D:\KOFCEXT Extractions\09272024\000554\file.xlsx` | `KOFCEXT Extractions/09272024/000554/file.xlsx` |

### 8.3 Format routing

| `format` | Function action | Client result | VPN? |
|----------|-----------------|---------------|------|
| `file` or `proxy` | MI `DownloadAsync` | `{ fileName, contentType, contentBase64 }` | No |
| `json` | User-delegation SAS | `{ sasUrl }` | Yes (storage firewall) |
| omitted / other | SAS redirect | `302` to SAS URL | Yes |

> **Why `file` is the production default.** Storage is firewalled / private-endpoint. The Function MI can read the blob; the user's browser cannot. Account-key SAS fails the same way off VPN.

### 8.4 Request headers

| Header | Set by | Purpose |
|--------|--------|---------|
| `Authorization: Bearer <SPA token>` | Browser → Boomi; Boomi → Function | Same delegated SPA token end-to-end |
| `Accept: application/json` | Browser | JSON response |
| `x-api-key` | **Not sent** for Blob | EApp / Policy only |

### 8.5 Success response (`format=file`)

```json
{
  "fileName": "380_11_exceltemplate1333211.xlsx",
  "contentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "contentBase64": "UEsDBB..."
}
```

Boomi must pass this JSON through (`contentBase64`, not only `sasUrl`). Large files may hit Boomi / Function size limits; typical extraction xlsx files are fine.

### 8.6 HTTP status codes (client-visible)

| Status | Client body | Typical cause |
|--------|-------------|---------------|
| `200 OK` | File JSON or `{ sasUrl }` | Access granted and blob found |
| `400 Bad Request` | Missing/invalid `path` or `contactId`; invalid JSON; empty normalized path | Bad payload |
| `401 Unauthorized` | Authentication required / missing `oid` | Token not forwarded or not delegated |
| `403 Forbidden` | `Access denied.` or missing delegated scope | No Contact Read, or missing `Blob.Read` |
| `404 Not Found` | `User not found.` or file does not exist | oid not in Dataverse, or blob missing |
| `500` | Unable to access blob storage / unexpected error | Storage or unhandled exception |

---

## 9. Contact Access Guard

Mirrors the EApp / Policy impersonation pattern (`DataverseClientFactory` + `CallerId`).

### 9.1 Steps

1. Resolve token **`oid`** → enabled `systemuser` (`azureactivedirectoryobjectid`).
2. Set `ServiceClient.CallerId` to that `systemuserid`.
3. **Retrieve** `contact` by `contactId` (`contactid` only).
4. Return `Granted`, `UserNotFound`, or `AccessDenied`.
5. Reset `CallerId = Guid.Empty` in `finally`.

Privilege / retrieve faults (including “does not exist” under the impersonated user) are treated as **AccessDenied**.

### 9.2 What the user sees vs logs

| Case | HTTP body | Log `Outcome` / `ExceptionType` |
|------|-----------|----------------------------------|
| User cannot read Contact | `Access denied.` | `AccessDenied` |
| No Dataverse user for oid | `User not found.` | `UserNotFound` |
| Blob missing | `Not Found: The requested file does not exist` | `BlobNotFound` / `InvalidOperationException` |
| Storage fault | Generic 500 | `StorageError` / `RequestFailedException` |

---

## 10. Request logging

Every success and failure writes **one** structured line. Details are **not** added to the HTTP body. SAS URLs and file bytes are **not** logged.

**Always logged**

`Outcome`, `StatusCode`, `Reason`, `ContactId`, `Path`, `BlobPath`, `Container`, `FileName`, `ContentType`, `Bytes`, `Format`, `Method`, `UserId`, `UserEmail`, `UserName`, `EntraOid`, `AuthMode`, `ClientIP`, `Scopes`

**Unsuccessful only**

`ExceptionType` — real .NET type when something threw (`RequestFailedException`, `JsonException`, …); otherwise the outcome name (`AccessDenied`, `MissingPath`, `UserNotFound`).

`Roles` is not logged (SPA tokens do not carry app roles).

---

## 11. Client Web Resources (Dynamics 365)

Same **MSAL → Boomi → Function** pattern as EApp / Policy. Reuses `kofc_authclient.js` and `kofc_authcallback.html` (blob pending keys `kofc_blob_pending` / `kofc_blob_result`).

### 11.1 Blob Link Activity (preferred timeline design)

| Field | Logical name | Value |
|-------|----------------|-------|
| Subject | `subject` | File name (what the user clicks) |
| Regarding | `regardingobjectid` | Contact |
| Description | `description` | Full Windows blob path (raw, not encoded) |
| Table | `kofc_bloblinkactivity` | Confirm publisher prefix |

Form OnLoad: library `kofc_blobLinkActivity.js`, function **`KOFC.BlobLinkActivity.onLoad`**, pass execution context. Create form type 1 is skipped.

OnLoad writes Description + Regarding + entity name to `localStorage` (`kofc_blob_open_ctx`) so the opener **does not** call `Xrm.WebApi.retrieveRecord` again (that second retrieve is a common privilege failure). Then opens:

```text
{OrgUrl}/main.aspx?pagetype=webresource&webresourceName=kofc_blob_open.html&data=<ACTIVITY_GUID>&forceUCI=1
```

Users who open files need **Read** on Blob Link Activity **and** the Regarding Contact. Contact access is enforced again in the Function.

### 11.2 Public API (`KOFC.Blob`)

```javascript
KOFC.Blob.configure({
    tenantId: "...",
    clientId: "...",
    apiAppId: "...",
    boomiUrl: "https://.../ws/rest/BlobProxy",
    scope: ".default",
    httpMethod: "POST",
    redirectWebResource: "kofc_authcallback.html",
    allowRedirect: true
});

await KOFC.Blob.openSaasBlob({
    path: "D:\\KOFCEXT Extractions\\09272024\\000554\\file.xlsx",
    contactId: "653df982-6a82-4bbc-8299-0000238ec972"
});
```

First visit may redirect to Microsoft; `kofc_authcallback.html` finishes the Boomi call, downloads the file, and shows a green check (spinner hidden).

### 11.3 Boomi request (from browser)

| Header / param | Value |
|----------------|-------|
| `Authorization` | `Bearer <SPA token>` |
| `x-api-key` | **Do not send** |
| Body | `path` (`encodeURI`), `contactId`, `format: "file"` |

Boomi forwards to `GetSaasBlobUrl` with the **same SPA Bearer token**. **Do not send `userId`.** Pass through `contentBase64` on success.

### 11.4 Environment variables (D365)

Read by `kofc_blob_open.html`:

| Schema name | Purpose |
|-------------|---------|
| `kofc_TenantId` | Entra tenant ID |
| `kofc_SPAClientId` | SPA client ID |
| `kofc_BlobApiAppId` | Function API app ID (scope `api://<id>/.default`) |
| `kofc_BlobBoomiUrl` | Boomi REST URL (no query string) |

> Separate Blob API app / Boomi URL keeps this deployment independent of EApp and Policy. The SPA client and callback page can be shared.

### 11.5 Legacy / test opener URLs

Activity GUID is preferred. Manual test (pipe):

```text
{OrgUrl}/main.aspx?pagetype=webresource&webresourceName=kofc_blob_open.html
  &data={encodeURIComponent(filePath + "|" + contactGuid)}&forceUCI=1
```

Do **not** open `/WebResources/kofc_blob_open.html` directly (no `Xrm` / env vars).

### 11.6 ADF / Dataverse create (no opener URL on the record)

```http
POST /api/data/v9.2/kofc_bloblinkactivities
```

```json
{
  "subject": "380_11_exceltemplate1333211.xlsx",
  "description": "D:\\KOFCEXT Extractions\\09272024\\000554\\KOFCEXT\\000554(380)\\file.xlsx",
  "regardingobjectid_contact@odata.bind": "/contacts(653df982-6a82-4bbc-8299-0000238ec972)"
}
```

---

## 12. Security Design

### 12.1 Inbound (Boomi → Function)

- Easy Auth on the Function App (Entra ID provider); audience = Blob Function API app.
- Boomi **forwards the SPA delegated token** after JWT validation — no client-credentials swap.
- Function enforces **`Blob.Read`** or **`access_as_user`** on **`scp`**.
- Runtime auth level is `Anonymous`; platform enforces authentication.
- Locally (no `WEBSITE_SITE_NAME`), auth checks are relaxed for unit tests / local host.

### 12.2 Boomi gateway (browser → Boomi)

| Layer | What Boomi checks | What it proves |
|-------|-------------------|----------------|
| **`Authorization: Bearer`** | Entra JWT signature, issuer, audience, expiry, **`scp`** | Signed-in user obtained a delegated token for the Blob API app |

Blob does **not** use `x-api-key`. After validation, Boomi calls the Function with the same Bearer token and `path` / `contactId` / `format`.

### 12.3 Outbound (Function → Dataverse / Storage)

- System-assigned Managed Identity on the Function App.
- MI as **Application User** in Dataverse with **Act on Behalf of Another User** + Contact Read (intersection with the impersonated user).
- MI **Storage Blob Data Contributor** (or equivalent) on the storage account / container.
- User-delegation SAS (when used) is signed with MI (`skoid` / `sktid`). Browser still cannot open SAS if the account firewall blocks the client IP.

### 12.4 What is NOT used

| Mechanism | Reason |
|-----------|--------|
| Browser → Function URL | Always Boomi |
| Browser → `*.blob.core.windows.net` | Storage firewall; production uses file proxy |
| Boomi client-credentials | Replaced by SPA-token forward |
| Required `userId` | Identity from token `oid` |
| Blob `x-api-key` | Bearer JWT only (EApp/Policy still use keys) |
| Public container / account-key SAS | MI download; SAS still firewalled off VPN |

### 12.5 Recommended hardening

| # | Control | Priority |
|---|---------|----------|
| 1 | Network-restrict the Function to Boomi (IP allow-list or private endpoint) | High |
| 2 | Keep storage private; do not open blob public access to “fix” SAS | High |
| 3 | Easy Auth audience = Blob API app; require authentication | High |
| 4 | Grant timeline users Read on Blob Link Activity + Contact | High |

---

## 13. Infrastructure & app settings

| Resource | Value (dev example) |
|----------|---------------------|
| Function App | Deploy from `proxyBlobFunction/` (or `TEST-01/` if that is the pipeline source) |
| Runtime | `dotnet-isolated`, Functions v4, .NET 8 |
| Identity | System-assigned Managed Identity |
| Storage account | e.g. `koccrmudsbdev` (`BlobStorageAccountName`) |
| Container | `BlobContainerName` (code default `kofcext-extractions`; env may be `homeoffice`) |
| Application Insights | Function App Insights (Invocations + traces) |

| App setting | Purpose |
|-------------|---------|
| `DataverseUrl` or `CRM_URL` | Dataverse organization URL |
| `BlobStorageAccountName` | Storage account for MI `BlobServiceClient` + user-delegation SAS |
| `BlobContainerName` | Container that holds extraction blobs |
| `BLOB_CONNECTION_STRING` | Local fallback if account name is unset |
| `APPLICATIONINSIGHTS_CONNECTION_STRING` | Request logs |
| `FUNCTIONS_WORKER_RUNTIME` | `dotnet-isolated` |

---

## 14. Deployment Checklist

### 14.1 Azure Function App

1. Deploy `KOFC.Azure.Functions.GetSaasBlobUrl` (Zip Deploy or pipeline).
2. Enable **system-assigned Managed Identity**.
3. Create **Application User** in Dataverse linked to the MI; **Act on Behalf Of** + Contact Read.
4. Grant MI **Storage Blob Data Contributor** on the storage account / container.
5. Enable **Easy Auth** (audience = Blob Function API app).
6. Expose delegated scope **`Blob.Read`** (and/or `access_as_user`); admin-consent the SPA.
7. Set `DataverseUrl`, `BlobStorageAccountName`, `BlobContainerName`.

### 14.2 Dynamics 365 web resources

1. Publish shared: `kofc_authclient.js`, `kofc_authcallback.html`, `kofc_msalbrowsermin`.
2. Publish blob: `kofc_blobClient.js`, `kofc_blob_open.html`, `kofc_blobLinkActivity.js`.
3. Register OnLoad on the Blob Link Activity form (`KOFC.BlobLinkActivity.onLoad`).
4. Create env vars: `kofc_TenantId`, `kofc_SPAClientId`, `kofc_BlobApiAppId`, `kofc_BlobBoomiUrl`.
5. Confirm Entra SPA redirect URI is `kofc_authcallback.html`.

### 14.3 Boomi process

1. Expose REST endpoint matching `kofc_BlobBoomiUrl` (POST).
2. Accept `Authorization: Bearer` + JSON `path`, `contactId`, `format`.
3. Validate SPA JWT; **do not** obtain client-credentials; **do not** require `x-api-key` or `userId`.
4. Forward the **same SPA Bearer token** to `GetSaasBlobUrl`.
5. Return Function JSON unchanged (`contentBase64` / `sasUrl`).

### 14.4 Smoke test

1. Open a Contact with a Blob Link Activity → click Subject.
2. First time: redirect → callback checkmark → file in Downloads (no VPN).
3. Second click: silent token → same download; opener shows **File downloaded**.
4. User without Contact Read → opener **Unable to open file** / HTTP 403 `Access denied.`
5. Validator: `main.aspx?pagetype=webresource&webresourceName=kofc_BoomiIntegrationValidator` with `format: "file"`.

---

## 15. Error Handling

| Scenario | Behavior | Status |
|----------|----------|--------|
| Unauthenticated caller | Generic unauthorized | 401 |
| App-only / missing `Blob.Read` | Generic forbidden | 403 |
| Missing / invalid `path` or `contactId` | Generic bad request | 400 |
| Token `oid` not in Dataverse | `User not found.` | 404 |
| Impersonated user cannot read Contact | `Access denied.` | 403 |
| Normalized path empty | Invalid file path | 400 |
| Blob / container missing | File does not exist | 404 |
| Azure Storage `RequestFailedException` | Unable to access blob storage | 500 |
| Invalid POST JSON | Request body is not valid JSON | 400 |
| Frontend `retrieveRecord` privilege | Opener error (skip if OnLoad context is present) | — |

Frontend privilege template from Dynamics (`{0}`…`{6}`) is filled by the opener with table `kofc_bloblinkactivity`, activity GUID, current user, and **Read**.

---

## 16. Test Scenarios

| # | Scenario | Expected |
|---|----------|----------|
| 1 | Valid SPA token + Contact Read + existing blob, `format=file` | 200 file JSON; download off VPN |
| 2 | Same, `format=json` | 200 `{ sasUrl }`; open needs VPN |
| 3 | Token without `Blob.Read` / `access_as_user` | 403 |
| 4 | Token without `oid` / oid not in Dataverse | 401 / 404 |
| 5 | User cannot read `contactId` | 403 `Access denied.` |
| 6 | Missing `path` or `contactId` | 400 |
| 7 | Blob path does not exist | 404 |
| 8 | Legacy `userId` in body | Ignored; identity from `oid` |
| 9 | Boomi omits `Authorization` | 401 |
| 10 | Empty Description on activity | Opener: missing Description / Regarding |
| 11 | Timeline click with OnLoad published | Skips `retrieveRecord`; uses form context |
| 12 | First-time MSAL | Redirect → callback downloads file; checkmark, no spinner |

---

## 17. Boomi Integration Validator

Open in D365:

```text
main.aspx?pagetype=webresource&webresourceName=kofc_BoomiIntegrationValidator
```

Select **Blob Proxy**, method **POST**, clear `x-api-key`, then:

```json
{
  "path": "D:%5CKOFCEXT%20Extractions%5C09272024\\000554\\file.xlsx",
  "contactId": "653df982-6a82-4bbc-8299-0000238ec972",
  "format": "file"
}
```

1. **Validate token** → 2. **Validate full integration**.

---

## 18. Dependencies

| Package | Version |
|---------|---------|
| `Microsoft.Azure.Functions.Worker` | 1.21.0 |
| `Azure.Identity` | 1.17.1 |
| `Azure.Storage.Blobs` | 12.27.0 |
| `Microsoft.PowerPlatform.Dataverse.Client` | 1.2.10 |
| `Newtonsoft.Json` | 13.0.3 |

---

## 19. File locations in repo

```text
proxyBlobFunction/KOFC.Azure.Functions.GetSaasBlobUrl/   Function source
TEST-01/KOFC.Azure.Functions.GetSaasBlobUrl/             Parallel copy (use if pipeline points here)
webresources/blob-link-activity/                         Opener, client, form OnLoad
webresources/eapp-boomi-button/kofc_authcallback.html    Shared callback (blob + EApp + Policy)
docs/KOFC-ProxyBlobFunction-Architecture.wiki.md         This document
docs/KOFC-Blob-Client-Integration.wiki.md                Client-focused companion
```

---

## 20. Related documentation

- `docs/KOFC-EApp-SSO-Architecture.wiki.md` — EApp SSO (same MSAL + Boomi pattern)
- `docs/KOFC-PolicyNonHeader-TierOne-Architecture.wiki.md` — Policy Non-Header (same pattern)
- `docs/KOFC-Blob-Client-Integration.wiki.md` — Timeline / ADF client notes
- `webresources/blob-link-activity/BLOB_LINK_ACTIVITY_SETUP.md` — Maker setup
- `webresources/eapp-boomi-button/kofc_authclient.js` — shared `KOFC.Auth`
- `webresources/eapp-boomi-button/kofc_authcallback.html` — shared callback (`callBlobApi`)
- Microsoft Learn — *Impersonate another user (Dataverse)*
- Microsoft Learn — *Authorize access to blobs using Microsoft Entra ID*
