namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public sealed class BlobLinkAssociationResult
{
    public bool IsLinked { get; init; }
    public Guid? ActivityId { get; init; }
    public string? Subject { get; init; }
    public string? MatchedDescription { get; init; }
    public int ActivitiesReviewed { get; init; }
    public string EntityLogicalName { get; init; } = "";
    public string Message { get; init; } = "";
}

public interface IBlobLinkAssociationGuard
{
    /// <summary>
    /// Confirms the requested path is stored on a Blob Link Activity regarding this Contact.
    /// Impersonates the signed-in user so Dataverse security applies.
    /// </summary>
    BlobLinkAssociationResult CheckPathLinkedToContact(
        Guid systemUserId,
        Guid contactId,
        string requestedPath,
        string normalizedBlobPath);
}
