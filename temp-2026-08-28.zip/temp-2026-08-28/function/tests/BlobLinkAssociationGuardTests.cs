using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using KOFC.Azure.Functions.GetSaasBlobUrl.Tests.Support;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Moq;
using Xunit;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests.Services;

public class BlobLinkAssociationGuardTests
{
    [Fact]
    public void CheckPathLinkedToContact_GrantsWhenDescriptionMatchesNormalizedPath()
    {
        var userId = Guid.NewGuid();
        var contactId = Guid.NewGuid();
        var activityId = Guid.NewGuid();
        var activity = new Entity("kofc_bloblinkactivity", activityId);
        activity["subject"] = "file.xlsx";
        activity["description"] = @"D:\KOFCEXT Extractions\09272024\file.xlsx";
        activity["regardingobjectid"] = new EntityReference("contact", contactId);

        var fake = new FakeDataverseClient
        {
            ActivityEntities = new EntityCollection(new List<Entity> { activity })
        };
        var blobService = new Mock<IBlobService>();
        blobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns<string>(path => path.Contains("KOFCEXT", StringComparison.OrdinalIgnoreCase)
                ? "KOFCEXT Extractions/09272024/file.xlsx"
                : "other");
        var config = new ConfigurationBuilder().AddInMemoryCollection().Build();
        var guard = new BlobLinkAssociationGuard(
            NullLogger<BlobLinkAssociationGuard>.Instance,
            fake,
            blobService.Object,
            config);

        var result = guard.CheckPathLinkedToContact(
            userId,
            contactId,
            @"D:\KOFCEXT Extractions\09272024\file.xlsx",
            "KOFCEXT Extractions/09272024/file.xlsx");

        Assert.True(result.IsLinked);
        Assert.Equal(activityId, result.ActivityId);
        Assert.Equal(1, result.ActivitiesReviewed);
        Assert.Equal(Guid.Empty, fake.CallerId);
    }

    [Fact]
    public void CheckPathLinkedToContact_DeniesWhenNoMatchingActivity()
    {
        var fake = new FakeDataverseClient
        {
            ActivityEntities = new EntityCollection(new List<Entity>
            {
                Activity(Guid.NewGuid(), @"D:\other\file.xlsx")
            })
        };
        var blobService = new Mock<IBlobService>();
        blobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns<string>(path => path.Contains("other", StringComparison.OrdinalIgnoreCase)
                ? "other/file.xlsx"
                : "requested/path.xlsx");
        var guard = new BlobLinkAssociationGuard(
            NullLogger<BlobLinkAssociationGuard>.Instance,
            fake,
            blobService.Object,
            new ConfigurationBuilder().AddInMemoryCollection().Build());

        var result = guard.CheckPathLinkedToContact(
            Guid.NewGuid(),
            Guid.NewGuid(),
            @"D:\requested\path.xlsx",
            "requested/path.xlsx");

        Assert.False(result.IsLinked);
        Assert.Null(result.ActivityId);
    }

    [Fact]
    public void CheckPathLinkedToContact_DeniesWhenContactHasNoActivities()
    {
        var fake = new FakeDataverseClient();
        var blobService = new Mock<IBlobService>();
        var guard = new BlobLinkAssociationGuard(
            NullLogger<BlobLinkAssociationGuard>.Instance,
            fake,
            blobService.Object,
            new ConfigurationBuilder().AddInMemoryCollection().Build());

        var result = guard.CheckPathLinkedToContact(
            Guid.NewGuid(),
            Guid.NewGuid(),
            @"D:\file.xlsx",
            "file.xlsx");

        Assert.False(result.IsLinked);
        Assert.Equal(0, result.ActivitiesReviewed);
    }

    private static Entity Activity(Guid id, string description)
    {
        var entity = new Entity("kofc_bloblinkactivity", id);
        entity["description"] = description;
        entity["subject"] = "file.xlsx";
        return entity;
    }
}
