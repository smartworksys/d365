using System.Text.Json;
using Microsoft.AspNetCore.Http;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using KOFC.Azure.Functions.GetSaasBlobUrl.Tests.Support;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests;

internal sealed class AzureEnvironmentScope : IDisposable
{
    private readonly string? _originalSiteName;

    public AzureEnvironmentScope(bool simulateAzureHost)
    {
        _originalSiteName = Environment.GetEnvironmentVariable("WEBSITE_SITE_NAME");
        Environment.SetEnvironmentVariable(
            "WEBSITE_SITE_NAME",
            simulateAzureHost ? "unit-test-app" : null);
    }

    public void Dispose()
    {
        Environment.SetEnvironmentVariable("WEBSITE_SITE_NAME", _originalSiteName);
    }
}

public class GetSaasBlobUrlTests
{
    private readonly Mock<ILogger<GetSaasBlobUrl>> _mockLogger;
    private readonly Mock<IContactAccessGuard> _mockContactAccessGuard;
    private readonly Mock<IBlobLinkAssociationGuard> _mockBlobLinkAssociationGuard;
    private readonly Mock<IBlobService> _mockBlobService;
    private readonly Mock<IConfiguration> _mockConfiguration;

    private const string DefaultQuery =
        "?path=D%3A%5Ctest%5Cfile.txt&contactId=12345678-1234-1234-1234-123456789012";

    public GetSaasBlobUrlTests()
    {
        _mockLogger = new Mock<ILogger<GetSaasBlobUrl>>();
        _mockContactAccessGuard = new Mock<IContactAccessGuard>();
        _mockBlobLinkAssociationGuard = new Mock<IBlobLinkAssociationGuard>();
        _mockBlobLinkAssociationGuard
            .Setup(g => g.CheckPathLinkedToContact(
                It.IsAny<Guid>(),
                It.IsAny<Guid>(),
                It.IsAny<string>(),
                It.IsAny<string>()))
            .Returns(new BlobLinkAssociationResult
            {
                IsLinked = true,
                Message = "Requested path is associated with a Blob Link Activity for this contact."
            });
        _mockBlobService = new Mock<IBlobService>();
        _mockConfiguration = new Mock<IConfiguration>();
        _mockConfiguration.Setup(c => c["BlobContainerName"]).Returns("test-container");
    }

    [Fact]
    public async Task RunAsync_ReturnsUnauthorizedWhenNotAuthenticatedInAzure()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var function = CreateFunction();
        var request = HttpRequestTestHelper.CreateRequest(DefaultQuery);

        var result = await function.RunCoreAsync(request, _mockLogger.Object);

        var unauthorized = Assert.IsType<UnauthorizedObjectResult>(result);
        Assert.Equal("Authentication required.", unauthorized.Value);
    }

    [Fact]
    public async Task RunAsync_ReturnsForbiddenWhenAppRoleOnlyWithoutDelegatedScope()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var function = CreateFunction();
        var request = HttpRequestTestHelper.CreateRequest(
            queryString: DefaultQuery + "&format=json",
            principalRoleClaims: new[]
            {
                ("roles", "Blob.Read"),
                ("appid", "boomi-service-principal")
            });

        var result = await function.RunCoreAsync(request, _mockLogger.Object);

        var forbidden = Assert.IsType<ObjectResult>(result);
        Assert.Equal(403, forbidden.StatusCode);
    }

    [Fact]
    public async Task RunAsync_ReturnsForbiddenWhenDelegatedScopeMissing()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var function = CreateFunction();
        var request = HttpRequestTestHelper.CreateRequest(
            queryString: DefaultQuery,
            principalRoleClaims: new[]
            {
                ("oid", Guid.NewGuid().ToString()),
                ("scp", "Other.Read")
            });

        var result = await function.RunCoreAsync(request, _mockLogger.Object);

        var forbidden = Assert.IsType<ObjectResult>(result);
        Assert.Equal(403, forbidden.StatusCode);
    }

    [Fact]
    public async Task RunAsync_MissingPathParameter_ReturnsBadRequest()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var function = CreateFunction();
        var request = CreateDelegatedRequest("?contactId=12345678-1234-1234-1234-123456789012");

        var result = await function.RunCoreAsync(request, _mockLogger.Object);

        var badRequest = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal("Bad Request: Missing 'path' parameter", badRequest.Value);
    }

    [Fact]
    public async Task RunAsync_MissingContactIdParameter_ReturnsBadRequest()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var function = CreateFunction();
        var request = CreateDelegatedRequest("?path=D:\\test\\file.txt");

        var result = await function.RunCoreAsync(request, _mockLogger.Object);

        var badRequest = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal("Bad Request: Missing or invalid 'contactId' parameter", badRequest.Value);
    }

    [Fact]
    public async Task RunAsync_ContactAccessDenied_ReturnsForbidden()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var oid = Guid.NewGuid();
        var contactId = Guid.Parse("12345678-1234-1234-1234-123456789012");
        var function = CreateFunction();
        var request = CreateDelegatedRequest(
            $"?path=D:\\test\\file.txt&contactId={contactId}",
            oid);

        _mockContactAccessGuard
            .Setup(g => g.CheckContactAccessByEntraOid(oid, contactId))
            .Returns(ContactAccessResult.AccessDenied(Guid.NewGuid(), "Access denied."));

        var result = await function.RunCoreAsync(request, _mockLogger.Object);

        var forbidden = Assert.IsType<ObjectResult>(result);
        Assert.Equal(403, forbidden.StatusCode);
    }

    [Fact]
    public async Task RunAsync_PathNotLinkedToContact_ReturnsForbidden()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var oid = Guid.NewGuid();
        var contactId = Guid.Parse("12345678-1234-1234-1234-123456789012");
        var function = CreateFunction();
        var request = CreateDelegatedRequest(
            $"?path=D:\\other\\secret.xlsx&contactId={contactId}",
            oid);

        SetupGrantedAccess(oid, contactId);
        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns("other/secret.xlsx");
        _mockBlobLinkAssociationGuard
            .Setup(g => g.CheckPathLinkedToContact(
                It.IsAny<Guid>(),
                contactId,
                It.IsAny<string>(),
                "other/secret.xlsx"))
            .Returns(new BlobLinkAssociationResult
            {
                IsLinked = false,
                Message = "No Blob Link Activity regarding this contact has a Description that matches the requested path."
            });

        var result = await function.RunCoreAsync(request, _mockLogger.Object);

        var forbidden = Assert.IsType<ObjectResult>(result);
        Assert.Equal(403, forbidden.StatusCode);
        Assert.Equal("Access denied.", forbidden.Value);
    }

    [Fact]
    public async Task RunAsync_BlobNotFound_ReturnsNotFound()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var oid = Guid.NewGuid();
        var contactId = Guid.Parse("12345678-1234-1234-1234-123456789012");
        var function = CreateFunction();
        var request = CreateDelegatedRequest(
            $"?path=D:\\test\\file.txt&contactId={contactId}",
            oid);

        SetupGrantedAccess(oid, contactId);
        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns("test/file.txt");
        _mockBlobService.Setup(s => s.GenerateSasUrlAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(new InvalidOperationException("Blob not found"));

        var result = await function.RunCoreAsync(request, _mockLogger.Object);

        Assert.IsType<NotFoundObjectResult>(result);
    }

    [Fact]
    public async Task RunAsync_SuccessfulRequest_ReturnsRedirect()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var oid = Guid.NewGuid();
        var contactId = Guid.Parse("12345678-1234-1234-1234-123456789012");
        var function = CreateFunction();
        var request = CreateDelegatedRequest(
            $"?path=D:\\KOFCExt%20Extractions\\test\\file.txt&contactId={contactId}",
            oid);

        SetupGrantedAccess(oid, contactId);
        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns("KOFCExt Extractions/test/file.txt");

        var expectedSasUrl = "https://storage.blob.core.windows.net/container/test/file.txt?sv=2021-06-08&sig=...";
        _mockBlobService.Setup(s => s.GenerateSasUrlAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(expectedSasUrl);

        var result = await function.RunCoreAsync(request, _mockLogger.Object);

        var redirect = Assert.IsType<RedirectResult>(result);
        Assert.Equal(expectedSasUrl, redirect.Url);
    }

    [Fact]
    public async Task RunAsync_DelegatedSpaCaller_ReturnsJsonSasUrl()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var oid = Guid.NewGuid();
        var contactId = Guid.Parse("12345678-1234-1234-1234-123456789012");
        var function = CreateFunction();
        var request = CreateDelegatedRequest(
            $"?path=D:\\test\\file.txt&contactId={contactId}&format=json",
            oid);

        SetupGrantedAccess(oid, contactId);
        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns("test/file.txt");

        var expectedSasUrl = "https://storage.blob.core.windows.net/container/test/file.txt?sv=2021-06-08&sig=...";
        _mockBlobService.Setup(s => s.GenerateSasUrlAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(expectedSasUrl);

        var result = await function.RunCoreAsync(request, _mockLogger.Object);

        var ok = Assert.IsType<OkObjectResult>(result);
        var json = JsonSerializer.Serialize(ok.Value);
        using var document = JsonDocument.Parse(json);
        Assert.Equal(expectedSasUrl, document.RootElement.GetProperty("sasUrl").GetString());
        _mockContactAccessGuard.Verify(
            g => g.CheckContactAccessByEntraOid(oid, contactId),
            Times.Once);
    }

    [Fact]
    public async Task RunAsync_DelegatedSpaCaller_IgnoresLegacyUserIdParameter()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var oid = Guid.NewGuid();
        var legacyUserId = Guid.NewGuid();
        var contactId = Guid.Parse("12345678-1234-1234-1234-123456789012");
        var function = CreateFunction();
        var request = CreateDelegatedRequest(
            $"?path=D:\\test\\file.txt&contactId={contactId}&userId={legacyUserId}&format=json",
            oid);

        SetupGrantedAccess(oid, contactId);
        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns("test/file.txt");
        _mockBlobService.Setup(s => s.GenerateSasUrlAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync("https://storage.example/file?sig=test");

        var result = await function.RunCoreAsync(request, _mockLogger.Object);

        Assert.IsType<OkObjectResult>(result);
        _mockContactAccessGuard.Verify(
            g => g.CheckContactAccessByEntraOid(oid, contactId),
            Times.Once);
        _mockContactAccessGuard.Verify(
            g => g.CheckContactAccess(It.IsAny<Guid>(), It.IsAny<Guid>()),
            Times.Never);
    }

    [Fact]
    public async Task RunAsync_NormalizedPathIsEmpty_ReturnsBadRequest()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var oid = Guid.NewGuid();
        var contactId = Guid.Parse("12345678-1234-1234-1234-123456789012");
        var function = CreateFunction();
        var request = CreateDelegatedRequest(
            $"?path=D:\\&contactId={contactId}",
            oid);

        SetupGrantedAccess(oid, contactId);
        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns(string.Empty);

        var result = await function.RunCoreAsync(request, _mockLogger.Object);

        var badRequest = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal("Bad Request: Invalid file path", badRequest.Value);
    }

    [Fact]
    public async Task RunAsync_PostBodyMergesParameters()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var oid = Guid.NewGuid();
        var contactId = Guid.Parse("12345678-1234-1234-1234-123456789012");
        var function = CreateFunction();
        var request = HttpRequestTestHelper.CreateRequest(
            postBody: JsonSerializer.Serialize(new
            {
                path = "D:\\test\\file.txt",
                contactId = contactId.ToString(),
                format = "json"
            }),
            principalRoleClaims: new[]
            {
                ("scp", "Blob.Read"),
                ("oid", oid.ToString())
            });

        SetupGrantedAccess(oid, contactId);
        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns("test/file.txt");
        _mockBlobService.Setup(s => s.GenerateSasUrlAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync("https://storage.example/file?sig=test");

        var result = await function.RunCoreAsync(request, _mockLogger.Object);

        Assert.IsType<OkObjectResult>(result);
    }

    private GetSaasBlobUrl CreateFunction() =>
        new(
            _mockContactAccessGuard.Object,
            _mockBlobLinkAssociationGuard.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

    private static HttpRequest CreateDelegatedRequest(string queryString, Guid? oid = null)
    {
        oid ??= Guid.NewGuid();
        return HttpRequestTestHelper.CreateRequest(
            queryString: queryString,
            principalRoleClaims: new[]
            {
                ("scp", "Blob.Read"),
                ("oid", oid.Value.ToString())
            });
    }

    private void SetupGrantedAccess(Guid oid, Guid contactId)
    {
        _mockContactAccessGuard
            .Setup(g => g.CheckContactAccessByEntraOid(oid, contactId))
            .Returns(ContactAccessResult.Granted(Guid.NewGuid(), "agent@example.com"));
    }
}
