using System.Diagnostics;
using System.Text.Json;
using Azure;
using KOFC.Azure.Functions.GetSaasBlobUrl.Helpers;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace KOFC.Azure.Functions.GetSaasBlobUrl;

public class GetSaasBlobUrl
{
    private readonly IContactAccessGuard _contactAccessGuard;
    private readonly IBlobService _blobService;
    private readonly IConfiguration _configuration;

    public GetSaasBlobUrl(
        IContactAccessGuard contactAccessGuard,
        IBlobService blobService,
        IConfiguration configuration)
    {
        _contactAccessGuard = contactAccessGuard;
        _blobService = blobService;
        _configuration = configuration;
    }

    [Function("GetSaasBlobUrl")]
    public Task<IActionResult> RunAsync(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post")] HttpRequest req,
        FunctionContext context)
    {
        var log = context.GetLogger("GetSaasBlobUrl");
        return RunCoreAsync(req, log);
    }

    public async Task<IActionResult> RunCoreAsync(HttpRequest req, ILogger log)
    {
        log.LogInformation("C# HTTP trigger function processed a request.");

        if (!FunctionAppRoleAuth.IsAuthenticated(req))
        {
            return new UnauthorizedObjectResult("Authentication required.");
        }

        var callerRoles = FunctionAppRoleAuth.GetCallerRoles(req);
        var callerScopes = FunctionAppRoleAuth.GetCallerScopes(req);
        var callerOid = FunctionAppRoleAuth.GetCallerObjectId(req);
        var isDelegatedCaller = FunctionAppRoleAuth.IsDelegatedCaller(req);

        var principalName = req.Headers.ContainsKey("X-MS-CLIENT-PRINCIPAL-NAME")
            ? req.Headers["X-MS-CLIENT-PRINCIPAL-NAME"].ToString()
            : null;
        var forwardedFor = req.Headers.ContainsKey("X-Forwarded-For")
            ? req.Headers["X-Forwarded-For"].ToString()
            : req.HttpContext.Connection.RemoteIpAddress?.ToString();

        using var scope = log.BeginScope(new Dictionary<string, object?>
        {
            ["oid"] = callerOid?.ToString() ?? "",
            ["userName"] = principalName ?? "",
            ["authMode"] = isDelegatedCaller ? "delegated" : "app",
            ["clientIP"] = forwardedFor ?? ""
        });
        Activity.Current?.SetTag("oid", callerOid?.ToString() ?? "");
        Activity.Current?.SetTag("userName", principalName ?? "");
        Activity.Current?.SetTag("authMode", isDelegatedCaller ? "delegated" : "app");
        Activity.Current?.SetTag("clientIP", forwardedFor ?? "");

        log.LogInformation(
            "Auth context: roles={Roles}, scopes={Scopes}, oid={Oid}, userName={UserName}, delegated={IsDelegated}",
            string.Join(", ", callerRoles),
            string.Join(", ", callerScopes),
            callerOid,
            principalName,
            isDelegatedCaller);

        if (!isDelegatedCaller)
        {
            log.LogWarning(
                "Rejected non-delegated caller. Production requires forwarded SPA token with {BlobRead} or {AccessAsUser}.",
                FunctionAppRoleAuth.BlobReadRole,
                FunctionAppRoleAuth.AccessAsUserScope);
            return new ObjectResult(
                $"Missing required delegated scope: {FunctionAppRoleAuth.BlobReadRole} or {FunctionAppRoleAuth.AccessAsUserScope}.")
            {
                StatusCode = StatusCodes.Status403Forbidden
            };
        }

        if (!callerOid.HasValue)
        {
            return new UnauthorizedObjectResult("The delegated token does not contain a valid oid claim.");
        }

        try
        {
            var queryParams = ParseQuery(req);
            await MergePostBodyAsync(req, queryParams);

            var rawPath = GetParam(queryParams, "path");
            var contactId = GetParam(queryParams, "contactId");
            var responseFormat = (GetParam(queryParams, "format") ?? "redirect").ToLowerInvariant();

            if (string.IsNullOrWhiteSpace(rawPath))
            {
                log.LogWarning("path is missing in the request.");
                return new BadRequestObjectResult("Bad Request: Missing 'path' parameter");
            }

            if (string.IsNullOrWhiteSpace(contactId) || !Guid.TryParse(contactId, out var contactGuid))
            {
                log.LogWarning("contactId is missing or not a valid GUID.");
                return new BadRequestObjectResult("Bad Request: Missing or invalid 'contactId' parameter");
            }

            var legacyUserId = GetParam(queryParams, "userId");
            var legacyOid = GetParam(queryParams, "oid");
            if (!string.IsNullOrWhiteSpace(legacyUserId) || !string.IsNullOrWhiteSpace(legacyOid))
            {
                log.LogInformation(
                    "Ignoring legacy userId/oid parameters for delegated caller. Using oid {Oid} from token.",
                    callerOid);
            }

            log.LogInformation(
                "Processing blob request for contact {ContactId}, path {Path}, format {Format}",
                contactGuid,
                rawPath,
                responseFormat);

            var accessResult = _contactAccessGuard.CheckContactAccessByEntraOid(
                callerOid.Value,
                contactGuid);
            if (!accessResult.IsGranted)
            {
                var status = accessResult.Status == ContactAccessStatus.UserNotFound
                    ? StatusCodes.Status404NotFound
                    : StatusCodes.Status403Forbidden;
                log.LogWarning(
                    "Contact access denied for user {UserId} ({UserName}) on contact {ContactId}: {Reason}",
                    accessResult.UserId,
                    accessResult.UserName,
                    contactGuid,
                    accessResult.Message);
                return new ObjectResult(accessResult.Message) { StatusCode = status };
            }

            log.LogInformation(
                "Contact access granted for user {UserId} ({UserName}), contact {ContactId}",
                accessResult.UserId,
                accessResult.UserName,
                contactGuid);

            var blobPath = _blobService.NormalizePathToBlob(rawPath);
            if (string.IsNullOrWhiteSpace(blobPath))
            {
                log.LogWarning("Normalized blob path is empty for raw path {RawPath}.", rawPath);
                return new BadRequestObjectResult("Bad Request: Invalid file path");
            }

            var containerName = _configuration["BlobContainerName"] ?? "kofcext-extractions";
            try
            {
                if (responseFormat is "file" or "proxy")
                {
                    var file = await _blobService.DownloadAsync(containerName, blobPath);
                    log.LogInformation(
                        "Proxied blob download for contact {ContactId}, blob {BlobPath}, bytes {Length}",
                        contactGuid,
                        blobPath,
                        file.Content.Length);
                    return new OkObjectResult(new
                    {
                        fileName = file.FileName,
                        contentType = file.ContentType,
                        contentBase64 = Convert.ToBase64String(file.Content)
                    });
                }

                var sasUrl = await _blobService.GenerateSasUrlAsync(containerName, blobPath);
                log.LogInformation(
                    "Generated SAS URL for contact {ContactId}, blob {BlobPath}, format {Format}",
                    contactGuid,
                    blobPath,
                    responseFormat);

                if (responseFormat == "json")
                {
                    return new OkObjectResult(new { sasUrl });
                }

                return new RedirectResult(sasUrl);
            }
            catch (InvalidOperationException ex)
            {
                log.LogWarning(ex, "Blob or container not found: {BlobPath}", blobPath);
                return new NotFoundObjectResult("Not Found: The requested file does not exist");
            }
            catch (RequestFailedException ex)
            {
                log.LogError(ex,
                    "Azure Storage error accessing blob {BlobPath} in container {ContainerName}. Status={Status}",
                    blobPath,
                    containerName,
                    ex.Status);
                return new ObjectResult("Internal Server Error: Unable to access blob storage.")
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }
        }
        catch (JsonException ex)
        {
            log.LogWarning(ex, "Invalid JSON in POST body.");
            return new BadRequestObjectResult("Request body is not valid JSON.");
        }
        catch (Exception ex)
        {
            log.LogError(ex, "Unexpected error processing blob request.");
            return new ObjectResult("Internal Server Error: An unexpected error occurred.")
            {
                StatusCode = StatusCodes.Status500InternalServerError
            };
        }
    }

    private static Dictionary<string, string> ParseQuery(HttpRequest req)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var pair in req.Query)
        {
            if (!string.IsNullOrWhiteSpace(pair.Key))
            {
                result[pair.Key] = pair.Value.ToString();
            }
        }

        return result;
    }

    private static async Task MergePostBodyAsync(HttpRequest req, Dictionary<string, string> queryParams)
    {
        if (!HttpMethods.IsPost(req.Method))
        {
            return;
        }

        req.EnableBuffering();
        using var reader = new StreamReader(req.Body, leaveOpen: true);
        var body = await reader.ReadToEndAsync();
        req.Body.Position = 0;

        if (string.IsNullOrWhiteSpace(body))
        {
            return;
        }

        using var document = JsonDocument.Parse(body);
        foreach (var property in document.RootElement.EnumerateObject())
        {
            if (!queryParams.ContainsKey(property.Name))
            {
                queryParams[property.Name] = property.Value.ToString();
            }
        }
    }

    private static string? GetParam(Dictionary<string, string> queryParams, string name) =>
        queryParams.TryGetValue(name, out var value) && !string.IsNullOrWhiteSpace(value)
            ? value
            : null;
}
