namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public interface IBlobService
{
    /// <summary>
    /// Generates a read-only SAS URL for the specified blob with 15-minute expiration
    /// </summary>
    /// <param name="containerName">The name of the blob container</param>
    /// <param name="blobPath">The path to the blob within the container</param>
    /// <returns>The SAS URL for the blob</returns>
    Task<string> GenerateSasUrlAsync(string containerName, string blobPath);

    /// <summary>
    /// Downloads blob bytes using the Function Managed Identity (no SAS / no public blob access).
    /// </summary>
    Task<BlobFileContent> DownloadAsync(string containerName, string blobPath);

    string NormalizePathToBlob(string rawPath);
}