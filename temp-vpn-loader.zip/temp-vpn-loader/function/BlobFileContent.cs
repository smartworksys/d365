namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public sealed class BlobFileContent
{
    public BlobFileContent(byte[] content, string contentType, string fileName)
    {
        Content = content;
        ContentType = contentType;
        FileName = fileName;
    }

    public byte[] Content { get; }
    public string ContentType { get; }
    public string FileName { get; }
}
