/*
 * kofc_blobLinkBuilder.js — timeline links for kofc_blob_open.html
 *
 * Usage (browser / form script):
 *   var url = KOFC.BlobLink.buildOpenerUrl({ filePath: "D:\\...", contactId: "{guid}" });
 *   var html = KOFC.BlobLink.buildTimelineMessageHtml({ orgUrl, filePath, contactId, linkText: "View file" });
 *
 * Usage (ADF — use buildDataParam logic in derived column; see docs/KOFC-Blob-Client-Integration.wiki.md)
 */
(function (global) {
    "use strict";

    var DEFAULT_WEB_RESOURCE = "kofc_blob_open.html";

    function stripBraces(value) {
        return String(value || "").replace(/[{}]/g, "").trim();
    }

    /**
     * Builds the inner data= query for kofc_blob_open.html (path + contactId).
     * Matches ADF: uriComponent(concat('path=', uriComponent(filePath), '&contactId=', contactId))
     */
    function buildDataParam(filePath, contactId) {
        if (!filePath || !contactId) {
            throw new Error("buildDataParam requires filePath and contactId.");
        }
        return "path=" + encodeURIComponent(String(filePath)) +
            "&contactId=" + encodeURIComponent(stripBraces(contactId)) +
            "&format=json";
    }

    /**
     * Pipe-separated data param (alternate format supported by kofc_blob_open.html).
     */
    function buildPipeDataParam(filePath, contactId) {
        if (!filePath || !contactId) {
            throw new Error("buildPipeDataParam requires filePath and contactId.");
        }
        return String(filePath) + "|" + stripBraces(contactId);
    }

    function resolveOrgUrl(options) {
        var orgUrl = options.orgUrl;
        if (!orgUrl && typeof Xrm !== "undefined" && Xrm.Utility) {
            orgUrl = Xrm.Utility.getGlobalContext().getClientUrl();
        }
        if (!orgUrl) {
            throw new Error("buildOpenerUrl requires orgUrl when not running inside Dynamics.");
        }
        return orgUrl.replace(/\/$/, "");
    }

    function buildActivityDataParam(activityId) {
        var id = stripBraces(activityId);
        if (!id) {
            throw new Error("buildActivityDataParam requires activityId.");
        }
        return id;
    }

    function buildOpenerUrl(options) {
        var orgUrl = resolveOrgUrl(options || {});
        var webResource = (options && options.webResourceName) || DEFAULT_WEB_RESOURCE;
        var data;

        if (options && options.activityId) {
            data = buildActivityDataParam(options.activityId);
        } else if (options && options.filePath && options.contactId) {
            var dataFormat = (options.dataFormat || "query").toLowerCase();
            data = dataFormat === "pipe"
                ? buildPipeDataParam(options.filePath, options.contactId)
                : buildDataParam(options.filePath, options.contactId);
        } else {
            throw new Error("buildOpenerUrl requires activityId, or filePath and contactId.");
        }

        return orgUrl +
            "/main.aspx?pagetype=webresource" +
            "&webresourceName=" + encodeURIComponent(webResource) +
            "&data=" + encodeURIComponent(data) +
            "&forceUCI=1";
    }

    function buildTimelineAnchorHtml(options) {
        var linkText = options.linkText || options.label || "View file";
        var url = buildOpenerUrl(options);
        return '<a href="' + url + '" target="_blank" rel="noopener noreferrer">' +
            linkText + "</a>";
    }

    /**
     * HTML snippet for Contact timeline / activity message field.
     * Example: "File available: <a href=...>View file</a>"
     */
    function buildTimelineMessageHtml(options) {
        if (!options || (!options.activityId && (!options.filePath || !options.contactId))) {
            throw new Error("buildTimelineMessageHtml requires activityId, or filePath and contactId.");
        }
        var prefix = options.prefix || options.messagePrefix || "File available: ";
        return prefix + buildTimelineAnchorHtml(options);
    }

    function buildAnchorHtml(options) {
        var label = options.label || "View file";
        return buildTimelineAnchorHtml({
            linkText: label,
            activityId: options.activityId,
            filePath: options.filePath,
            contactId: options.contactId,
            orgUrl: options.orgUrl,
            webResourceName: options.webResourceName,
            dataFormat: options.dataFormat
        });
    }

    global.KOFC = global.KOFC || {};
    global.KOFC.BlobLink = {
        buildDataParam: buildDataParam,
        buildPipeDataParam: buildPipeDataParam,
        buildActivityDataParam: buildActivityDataParam,
        buildOpenerUrl: buildOpenerUrl,
        buildTimelineAnchorHtml: buildTimelineAnchorHtml,
        buildTimelineMessageHtml: buildTimelineMessageHtml,
        buildAnchorHtml: buildAnchorHtml
    };
})(typeof window !== "undefined" ? window : this);
