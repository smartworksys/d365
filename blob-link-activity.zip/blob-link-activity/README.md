# Blob Link Activity web resources

D365 publish names stay the same (`kofc_blob_open.html`, etc.). This folder is only the repo layout.

| File | Publish as |
|------|------------|
| `kofc_blobLinkActivity.js` | `kofc_blobLinkActivity.js` |
| `kofc_blob_open.html` | `kofc_blob_open.html` |
| `kofc_blobClient.js` | `kofc_blobClient.js` |
| `kofc_blobLinkBuilder.js` | `kofc_blobLinkBuilder.js` (optional) |

Shared auth files stay in `webresources/eapp-boomi-button/` (`kofc_authclient.js`, `kofc_authcallback.html`).

Setup: `BLOB_LINK_ACTIVITY_SETUP.md`
