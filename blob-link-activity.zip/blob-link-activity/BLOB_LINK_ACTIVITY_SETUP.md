# Blob Link Activity — setup

Recommended timeline design: users click the activity **Subject** on Contact timeline. The form OnLoad sends them to `kofc_blob_open.html` with the activity GUID. The opener reads **Description** (path) and **Regarding** (Contact), then calls Boomi.

## 1. Create the table (Power Apps)

1. Solutions → your unmanaged solution → **New** → **Table** → **Activity**.
2. Display name: `Blob Link Activity`
3. Plural: `Blob Link Activities`
4. Schema / logical name should become `kofc_bloblinkactivity` (publisher prefix `kofc_`).
5. Enable the table on the **Contact** timeline (form designer → Timeline → Activities → show this type).

If the logical name is different, change `BLOB_LINK_ACTIVITY` in `kofc_blob_open.html`.

## 2. Form fields

On the Blob Link Activity main form show:

| Field | Logical name | Value |
|-------|----------------|-------|
| Subject | `subject` | File name |
| Regarding | `regardingobjectid` | Contact |
| Description | `description` | Full Windows blob path |

Hide unused activity fields (due date, duration, etc.).

## 3. Form OnLoad (makes Subject clickable)

Publish web resource:

| Name | Type | File |
|------|------|------|
| `kofc_blobLinkActivity.js` | Script (JScript) | `webresources/blob-link-activity/kofc_blobLinkActivity.js` |

Form designer → Form libraries → add `kofc_blobLinkActivity.js`.

Event:

- Event: **OnLoad**
- Library: `kofc_blobLinkActivity.js`
- Function: `KOFC.BlobLinkActivity.onLoad`
- Pass execution context: **Yes**

Save and publish the form.

Create forms are skipped so new records can still be saved.

## 4. Other web resources to publish

| Name | File |
|------|------|
| `kofc_blob_open.html` | `webresources/blob-link-activity/kofc_blob_open.html` |
| `kofc_blobClient.js` | `webresources/blob-link-activity/kofc_blobClient.js` |
| `kofc_blobLinkBuilder.js` | optional |
| `kofc_authclient.js` | existing shared |
| `kofc_authcallback.html` | existing shared |
| `kofc_msalbrowsermin` | existing shared |

## 5. Security

Users who open files need **Read** on Blob Link Activity.

## 6. ADF / Boomi create

```http
POST /api/data/v9.2/kofc_bloblinkactivities
```

```json
{
  "subject": "380_11_exceltemplate1333211.xlsx",
  "description": "D:\\KOFCEXT Extractions\\09272024\\000554\\KOFCEXT\\000554(380)\\30-9-2024_17-54-24\\EZMAILATTACH_ATTACHMENT\\EZMAILATTACH_ATTACHMENT1\\380_11_exceltemplate1333211.xlsx",
  "regardingobjectid_contact@odata.bind": "/contacts(653df982-6a82-4bbc-8299-0000238ec972)"
}
```

No opener URL is required on the record. The Subject click + OnLoad script is the link.

If you still need a standalone URL (email, test):

```text
https://<org>.crm.dynamics.com/main.aspx?pagetype=webresource&webresourceName=kofc_blob_open.html&data=<ACTIVITY_GUID>&forceUCI=1
```

## 7. Click path

```text
Contact timeline
  → click Blob Link Activity Subject
  → activity form OnLoad
  → new tab: kofc_blob_open.html?data=<activity-guid>
  → original tab returns to Contact
  → WebApi: description + regarding
  → POST Boomi { path, contactId, format: json }
  → same new tab navigates to sasUrl (xlsx typically downloads)
```
