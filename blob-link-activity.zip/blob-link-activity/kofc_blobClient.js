/*
 * kofc_blobClient.js — SaaS blob opener (MSAL + Boomi + GetSaasBlobUrl)
 *
 * Browser sends path + contactId to Boomi (no userId — Boomi derives user from token oid).
 * Boomi calls Function with client-credentials token + userId/oid.
 * Returns { sasUrl } and opens the file.
 */
(function (global) {
    "use strict";

    var AUTH_LIBRARY = "/WebResources/kofc_authclient.js";
    var PENDING_KEY = "kofc_blob_pending";
    var RESULT_KEY = "kofc_blob_result";

    var CONFIG = {
        tenantId: null,
        clientId: null,
        apiAppId: null,
        apiKey: null,
        boomiUrl: null,
        scope: ".default",
        httpMethod: "POST",
        redirectWebResource: "kofc_authcallback.html",
        msalWebResourcePath: "/WebResources/kofc_msalbrowsermin",
        allowRedirect: true,
        debug: false
    };

    function log() {
        if (!CONFIG.debug) {
            return;
        }
        var args = ["[KOFC.Blob]"].concat(Array.prototype.slice.call(arguments));
        if (typeof console !== "undefined" && console.log) {
            console.log.apply(console, args);
        }
    }

    function clientUrl() {
        try {
            if (typeof Xrm !== "undefined" && Xrm.Utility) {
                return Xrm.Utility.getGlobalContext().getClientUrl();
            }
        } catch (e) {
            // ignore
        }
        try {
            if (typeof parent !== "undefined" && parent.Xrm && parent.Xrm.Utility) {
                return parent.Xrm.Utility.getGlobalContext().getClientUrl();
            }
        } catch (e2) {
            // ignore
        }
        return window.location.origin;
    }

    function apiScopes() {
        return ["api://" + CONFIG.apiAppId + "/" + CONFIG.scope];
    }

    function requireConfig() {
        var missing = [];
        if (!CONFIG.tenantId) { missing.push("tenantId"); }
        if (!CONFIG.clientId) { missing.push("clientId"); }
        if (!CONFIG.apiAppId) { missing.push("apiAppId"); }
        if (!CONFIG.boomiUrl) { missing.push("boomiUrl"); }
        if (!CONFIG.apiKey) { missing.push("apiKey"); }
        if (missing.length > 0) {
            throw new Error("KOFC.Blob is not configured. Missing: " + missing.join(", "));
        }
    }

    function ensureAuthClient() {
        return new Promise(function (resolve, reject) {
            if (global.KOFC && global.KOFC.Auth) {
                resolve();
                return;
            }
            var script = document.createElement("script");
            script.src = clientUrl() + AUTH_LIBRARY;
            script.onload = function () {
                if (global.KOFC && global.KOFC.Auth) {
                    resolve();
                } else {
                    reject(new Error("Auth client loaded but KOFC.Auth is undefined."));
                }
            };
            script.onerror = function () {
                reject(new Error("Failed to load auth client: " + script.src));
            };
            document.head.appendChild(script);
        });
    }

    function applyAuthConfig() {
        global.KOFC.Auth.configure({
            tenantId: CONFIG.tenantId,
            clientId: CONFIG.clientId,
            apiAppId: CONFIG.apiAppId,
            apiKey: CONFIG.apiKey,
            boomiUrl: CONFIG.boomiUrl,
            scope: CONFIG.scope,
            httpMethod: CONFIG.httpMethod,
            redirectWebResource: CONFIG.redirectWebResource,
            msalWebResourcePath: CONFIG.msalWebResourcePath,
            allowRedirect: CONFIG.allowRedirect,
            debug: CONFIG.debug
        });
    }

    function getReturnUrl() {
        try {
            return window.top.location.href;
        } catch (e) {
            return window.location.href;
        }
    }

    function stripBraces(value) {
        return String(value || "").replace(/[{}]/g, "");
    }

    function persistPending(params) {
        try {
            localStorage.setItem(PENDING_KEY, JSON.stringify({
                action: "blob",
                path: params.path,
                contactId: stripBraces(params.contactId),
                boomiUrl: CONFIG.boomiUrl,
                apiKey: CONFIG.apiKey,
                httpMethod: "POST",
                apiScopes: apiScopes(),
                returnUrl: getReturnUrl()
            }));
        } catch (e) {
            log("Failed to persist pending blob request", e);
        }
    }

    function clearPending() {
        try {
            localStorage.removeItem(PENDING_KEY);
        } catch (e) {
            // ignore
        }
    }

    function buildBlobUrl(params) {
        var base = CONFIG.boomiUrl;
        var parts = [
            "path=" + encodeURIComponent(params.path),
            "contactId=" + encodeURIComponent(stripBraces(params.contactId)),
            "format=json"
        ];
        return base + (base.indexOf("?") >= 0 ? "&" : "?") + parts.join("&");
    }

    function parseResponseBody(text) {
        if (!text) {
            return null;
        }
        try {
            return JSON.parse(text);
        } catch (e) {
            return { sasUrl: text };
        }
    }

    function callBlobBoomi(token, params) {
        // The Blob Boomi operation is POST-only. Do not allow stale/shared
        // configuration to switch this request back to GET.
        var method = "POST";
        var base = CONFIG.boomiUrl;
        var url = base;
        var options = {
            method: method,
            headers: {
                "Authorization": "Bearer " + token,
                "x-api-key": CONFIG.apiKey,
                "Accept": "application/json"
            }
        };

        var payload = {
            path: params.path,
            contactId: stripBraces(params.contactId),
            format: "json"
        };

        if (method === "GET" || method === "HEAD") {
            var parts = [
                "path=" + encodeURIComponent(payload.path),
                "contactId=" + encodeURIComponent(payload.contactId),
                "format=json"
            ];
            url = base + (base.indexOf("?") >= 0 ? "&" : "?") + parts.join("&");
        } else {
            options.headers["Content-Type"] = "application/json";
            options.body = JSON.stringify(payload);
        }

        return fetch(url, options).then(function (response) {
            return response.text().then(function (text) {
                return {
                    ok: response.ok,
                    status: response.status,
                    data: parseResponseBody(text),
                    raw: text,
                    redirecting: false
                };
            });
        });
    }

    function configure(options) {
        if (!options || typeof options !== "object") {
            throw new Error("KOFC.Blob.configure(options) requires an object.");
        }
        Object.keys(options).forEach(function (key) {
            if (options[key] !== undefined) {
                CONFIG[key] = options[key];
            }
        });
    }

    function consumePendingResult() {
        try {
            var raw = localStorage.getItem(RESULT_KEY);
            if (!raw) {
                return null;
            }
            localStorage.removeItem(RESULT_KEY);
            return JSON.parse(raw);
        } catch (e) {
            return null;
        }
    }

    function openSaasBlob(params) {
        requireConfig();
        if (!params || !params.path || !params.contactId) {
            return Promise.reject(new Error("openSaasBlob requires path and contactId."));
        }

        return ensureAuthClient().then(function () {
            applyAuthConfig();
            persistPending(params);
            return global.KOFC.Auth.getAccessToken();
        }).then(function (token) {
            if (!token) {
                return { ok: false, status: 0, data: null, raw: "", redirecting: true };
            }
            return callBlobBoomi(token, params).then(function (result) {
                clearPending();
                if (!result.ok) {
                    return result;
                }
                var sasUrl = result.data && (result.data.sasUrl || result.data.SasUrl);
                if (!sasUrl) {
                    throw new Error("Boomi response did not include sasUrl.");
                }
                window.location.href = sasUrl;
                return result;
            });
        });
    }

    global.KOFC = global.KOFC || {};
    global.KOFC.Blob = {
        configure: configure,
        openSaasBlob: openSaasBlob,
        consumePendingResult: consumePendingResult
    };
})(typeof window !== "undefined" ? window : this);
