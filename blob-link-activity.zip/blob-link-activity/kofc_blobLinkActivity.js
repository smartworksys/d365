/*
 * kofc_blobLinkActivity.js — Blob Link Activity form OnLoad
 *
 * Register on the Blob Link Activity main form OnLoad event:
 *   Library: kofc_blobLinkActivity.js
 *   Function: KOFC.BlobLinkActivity.onLoad
 *
 * Clicking the timeline Subject opens this form; OnLoad opens
 * kofc_blob_open.html in a new tab, then returns to the previous page.
 */
(function (global) {
    "use strict";

    var OPENER_WEB_RESOURCE = "kofc_blob_open.html";

    function stripBraces(value) {
        return String(value || "").replace(/[{}]/g, "").trim();
    }

    function getClientUrl(formContext) {
        try {
            if (formContext && formContext.context) {
                return formContext.context.getClientUrl();
            }
        } catch (e0) { /* ignore */ }
        try {
            return Xrm.Utility.getGlobalContext().getClientUrl();
        } catch (e1) {
            return window.location.origin;
        }
    }

    function buildOpenerUrl(orgUrl, activityId) {
        return orgUrl.replace(/\/$/, "") +
            "/main.aspx?pagetype=webresource" +
            "&webresourceName=" + encodeURIComponent(OPENER_WEB_RESOURCE) +
            "&data=" + encodeURIComponent(activityId) +
            "&forceUCI=1";
    }

    /**
     * Form OnLoad handler. Skip Create forms so ADF/users can still save a new record.
     */
    function onLoad(executionContext) {
        var formContext = executionContext.getFormContext();
        var formType = formContext.ui.getFormType();
        // 1 = Create — stay on the form
        if (formType === 1) {
            return;
        }

        var activityId = stripBraces(formContext.data.entity.getId());
        if (!activityId) {
            return;
        }

        var url = buildOpenerUrl(getClientUrl(formContext), activityId);
        var opened = window.open(url, "_blank", "noopener");
        if (!opened) {
            window.location.replace(url);
            return;
        }

        try {
            Xrm.Navigation.navigateBack();
        } catch (e) {
            try {
                formContext.ui.close();
            } catch (e2) { /* leave the activity form open */ }
        }
    }

    global.KOFC = global.KOFC || {};
    global.KOFC.BlobLinkActivity = {
        onLoad: onLoad,
        buildOpenerUrl: buildOpenerUrl
    };
})(typeof window !== "undefined" ? window : this);
