using System.Net;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using Xunit;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests.Services;

public class DataverseServiceTests
{
    [Fact]
    public async Task ValidateContactAccessAsync_ValidAccess_ReturnsTrue()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<DataverseService>>();
        var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
        
        mockHttpMessageHandler
            .Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent("{\"contactid\":\"12345678-1234-1234-1234-123456789012\"}")
            });

        var httpClient = new HttpClient(mockHttpMessageHandler.Object);
        var dataverseService = new DataverseService(mockLogger.Object, httpClient);

        // Act
        var result = await dataverseService.ValidateContactAccessAsync(
            "12345678-1234-1234-1234-123456789012",
            "test-token",
            "https://test.crm.dynamics.com");

        // Assert
        Assert.True(result);
    }

    [Fact]
    public async Task ValidateContactAccessAsync_Forbidden_ReturnsFalse()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<DataverseService>>();
        var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
        
        mockHttpMessageHandler
            .Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.Forbidden
            });

        var httpClient = new HttpClient(mockHttpMessageHandler.Object);
        var dataverseService = new DataverseService(mockLogger.Object, httpClient);

        // Act
        var result = await dataverseService.ValidateContactAccessAsync(
            "12345678-1234-1234-1234-123456789012",
            "test-token",
            "https://test.crm.dynamics.com");

        // Assert
        Assert.False(result);
    }

    [Fact]
    public async Task ValidateContactAccessAsync_NotFound_ReturnsFalse()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<DataverseService>>();
        var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
        
        mockHttpMessageHandler
            .Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.NotFound
            });

        var httpClient = new HttpClient(mockHttpMessageHandler.Object);
        var dataverseService = new DataverseService(mockLogger.Object, httpClient);

        // Act
        var result = await dataverseService.ValidateContactAccessAsync(
            "12345678-1234-1234-1234-123456789012",
            "test-token",
            "https://test.crm.dynamics.com");

        // Assert
        Assert.False(result);
    }

    [Theory]
    [InlineData(null, "token", "url")]
    [InlineData("", "token", "url")]
    [InlineData("   ", "token", "url")]
    [InlineData("contactId", null, "url")]
    [InlineData("contactId", "", "url")]
    [InlineData("contactId", "   ", "url")]
    [InlineData("contactId", "token", null)]
    [InlineData("contactId", "token", "")]
    [InlineData("contactId", "token", "   ")]
    public async Task ValidateContactAccessAsync_InvalidParameters_ReturnsFalse(
        string contactId, 
        string accessToken, 
        string dataverseUrl)
    {
        // Arrange
        var mockLogger = new Mock<ILogger<DataverseService>>();
        var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
        var httpClient = new HttpClient(mockHttpMessageHandler.Object);
        var dataverseService = new DataverseService(mockLogger.Object, httpClient);

        // Act
        var result = await dataverseService.ValidateContactAccessAsync(contactId, accessToken, dataverseUrl);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public async Task ValidateContactAccessAsync_InvalidGuidFormat_ReturnsFalse()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<DataverseService>>();
        var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
        var httpClient = new HttpClient(mockHttpMessageHandler.Object);
        var dataverseService = new DataverseService(mockLogger.Object, httpClient);

        // Act
        var result = await dataverseService.ValidateContactAccessAsync(
            "not-a-valid-guid",
            "test-token",
            "https://test.crm.dynamics.com");

        // Assert
        Assert.False(result);
    }

    [Fact]
    public async Task ValidateContactAccessAsync_HttpException_ReturnsFalse()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<DataverseService>>();
        var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
        
        mockHttpMessageHandler
            .Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ThrowsAsync(new HttpRequestException("Network error"));

        var httpClient = new HttpClient(mockHttpMessageHandler.Object);
        var dataverseService = new DataverseService(mockLogger.Object, httpClient);

        // Act
        var result = await dataverseService.ValidateContactAccessAsync(
            "12345678-1234-1234-1234-123456789012",
            "test-token",
            "https://test.crm.dynamics.com");

        // Assert
        Assert.False(result);
    }
}

