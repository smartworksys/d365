using System.Net;
using System.Text;
using System.Text.Json;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using KOFC.Azure.Functions.GetSaasBlobUrl.Models;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using Moq;
using Xunit;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests;

public class GetSaasBlobUrlTests
{
    private readonly Mock<ILogger<GetSaasBlobUrl>> _mockLogger;
    private readonly Mock<IPrincipalService> _mockPrincipalService;
    private readonly Mock<IDataverseService> _mockDataverseService;
    private readonly Mock<IBlobService> _mockBlobService;
    private readonly Mock<IConfiguration> _mockConfiguration;

    public GetSaasBlobUrlTests()
    {
        _mockLogger = new Mock<ILogger<GetSaasBlobUrl>>();
        _mockPrincipalService = new Mock<IPrincipalService>();
        _mockDataverseService = new Mock<IDataverseService>();
        _mockBlobService = new Mock<IBlobService>();
        _mockConfiguration = new Mock<IConfiguration>();

        // Setup default configuration values
        _mockConfiguration.Setup(c => c["DataverseUrl"]).Returns("https://test.crm.dynamics.com");
        _mockConfiguration.Setup(c => c["BlobContainerName"]).Returns("test-container");
    }

    [Fact]
    public async Task Run_MissingAccessToken_ReturnsUnauthorized()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData();
        // Don't add access token header

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Run_MissingPrincipalHeader_ReturnsUnauthorized()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData();
        AddHeader(mockRequest, "X-MS-TOKEN-AAD-ACCESS-TOKEN", "test-token");
        // Don't add principal header

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Run_InvalidUserPrincipal_ReturnsUnauthorized()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData();
        AddHeader(mockRequest, "X-MS-TOKEN-AAD-ACCESS-TOKEN", "test-token");
        AddHeader(mockRequest, "X-MS-CLIENT-PRINCIPAL", "invalid-principal");

        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns((UserPrincipal?)null);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Run_MissingPathParameter_ReturnsBadRequest()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData("?contactId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Run_MissingContactIdParameter_ReturnsBadRequest()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData("?path=D:\\test\\file.txt");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Run_UserHasNoAccess_ReturnsForbidden()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(
            "?path=D:\\test\\file.txt&contactId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        _mockDataverseService.Setup(s => s.ValidateContactAccessAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(false);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Run_BlobNotFound_ReturnsNotFound()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(
            "?path=D:\\test\\file.txt&contactId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        _mockDataverseService.Setup(s => s.ValidateContactAccessAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns("test/file.txt");

        _mockBlobService.Setup(s => s.GenerateSasUrlAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(new InvalidOperationException("Blob not found"));

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Run_SuccessfulRequest_ReturnsRedirect()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(
            "?path=D:\\KOFCExt%20Extractions\\test\\file.txt&contactId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        _mockDataverseService.Setup(s => s.ValidateContactAccessAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns("test/file.txt");

        var expectedSasUrl = "https://storage.blob.core.windows.net/container/test/file.txt?sv=2021-06-08&sig=...";
        _mockBlobService.Setup(s => s.GenerateSasUrlAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(expectedSasUrl);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.Redirect, response.StatusCode);
        Assert.True(response.Headers.TryGetValues("Location", out var locationValues));
        Assert.Equal(expectedSasUrl, locationValues.FirstOrDefault());
    }

    [Fact]
    public async Task Run_NormalizedPathIsEmpty_ReturnsBadRequest()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(
            "?path=D:\\&contactId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        _mockDataverseService.Setup(s => s.ValidateContactAccessAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns(string.Empty);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Run_DataverseUrlMissing_ReturnsInternalServerError()
    {
        // Arrange
        _mockConfiguration.Setup(c => c["DataverseUrl"]).Returns((string?)null);

        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(
            "?path=D:\\test\\file.txt&contactId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.InternalServerError, response.StatusCode);
    }

    // Helper methods
    private Mock<HttpRequestData> CreateMockHttpRequestData(string queryString = "")
    {
        var mockRequest = new Mock<HttpRequestData>(MockBehavior.Strict, Mock.Of<FunctionContext>());
        
        mockRequest.Setup(r => r.Url).Returns(new Uri($"https://localhost:7071/api/GetSaasBlobUrl{queryString}"));
        mockRequest.Setup(r => r.Headers).Returns(new HttpHeadersCollection());
        
        var mockResponse = new Mock<HttpResponseData>(MockBehavior.Strict, Mock.Of<FunctionContext>());
        mockResponse.SetupProperty(r => r.StatusCode);
        mockResponse.SetupProperty(r => r.Headers, new HttpHeadersCollection());
        mockResponse.Setup(r => r.Body).Returns(new MemoryStream());
        mockResponse.Setup(r => r.WriteStringAsync(It.IsAny<string>(), default))
            .Returns<string, CancellationToken>((content, ct) =>
            {
                var bytes = Encoding.UTF8.GetBytes(content);
                mockResponse.Object.Body.Write(bytes, 0, bytes.Length);
                return Task.CompletedTask;
            });

        mockRequest.Setup(r => r.CreateResponse()).Returns(mockResponse.Object);

        return mockRequest;
    }

    private void AddHeader(Mock<HttpRequestData> mockRequest, string name, string value)
    {
        mockRequest.Object.Headers.Add(name, new[] { value });
    }

    private void SetupAuthHeaders(Mock<HttpRequestData> mockRequest)
    {
        AddHeader(mockRequest, "X-MS-TOKEN-AAD-ACCESS-TOKEN", "test-access-token");
        
        var principal = CreateTestUserPrincipal();
        var json = JsonSerializer.Serialize(principal);
        var base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
        
        AddHeader(mockRequest, "X-MS-CLIENT-PRINCIPAL", base64);
        AddHeader(mockRequest, "X-MS-CLIENT-PRINCIPAL-NAME", "test@example.com");
        AddHeader(mockRequest, "X-MS-CLIENT-PRINCIPAL-ID", "12345678-1234-1234-1234-123456789012");
    }

    private UserPrincipal CreateTestUserPrincipal()
    {
        return new UserPrincipal
        {
            AuthType = "aad",
            Claims = new List<Claim>
            {
                new Claim { Type = "name", Value = "Test User" },
                new Claim { Type = "oid", Value = "12345678-1234-1234-1234-123456789012" }
            }
        };
    }
}

