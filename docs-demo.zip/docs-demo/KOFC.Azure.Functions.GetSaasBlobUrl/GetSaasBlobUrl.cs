using System.Net;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;

namespace KOFC.Azure.Functions.GetSaasBlobUrl;

public class GetSaasBlobUrl
{
    private readonly ILogger<GetSaasBlobUrl> _logger;
    private readonly IPrincipalService _principalService;
    private readonly IDataverseService _dataverseService;
    private readonly IBlobService _blobService;
    private readonly IConfiguration _configuration;

    public GetSaasBlobUrl(
        ILogger<GetSaasBlobUrl> logger,
        IPrincipalService principalService,
        IDataverseService dataverseService,
        IBlobService blobService,
        IConfiguration configuration)
    {
        _logger = logger;
        _principalService = principalService;
        _dataverseService = dataverseService;
        _blobService = blobService;
        _configuration = configuration;
    }

    [Function("GetSaasBlobUrl")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequestData req)
    {
        _logger.LogInformation("Processing request for GetSaasBlobUrl");

        try
        {
            // Extract and validate Easy Auth headers
            var accessToken = GetHeaderValue(req, "X-MS-TOKEN-AAD-ACCESS-TOKEN");
            var principalHeader = GetHeaderValue(req, "X-MS-CLIENT-PRINCIPAL");
            var principalName = GetHeaderValue(req, "X-MS-CLIENT-PRINCIPAL-NAME");
            var principalId = GetHeaderValue(req, "X-MS-CLIENT-PRINCIPAL-ID");

            if (string.IsNullOrWhiteSpace(accessToken) || string.IsNullOrWhiteSpace(principalHeader))
            {
                _logger.LogWarning("Missing authentication headers. Request is not authenticated.");
                return await CreateErrorResponse(req, HttpStatusCode.Unauthorized, 
                    "Unauthorized: Missing or invalid authentication token");
            }

            // Decode user principal
            var userPrincipal = _principalService.DecodeUserPrincipal(principalHeader);
            if (userPrincipal == null)
            {
                _logger.LogWarning("Failed to decode user principal");
                return await CreateErrorResponse(req, HttpStatusCode.Unauthorized, 
                    "Unauthorized: Invalid user principal");
            }

            _logger.LogInformation("Authenticated user: {UserName}, Principal ID: {PrincipalId}", 
                principalName ?? userPrincipal.Identity.Name, principalId);

            // Extract and validate query parameters
            var queryParams = System.Web.HttpUtility.ParseQueryString(req.Url.Query);
            var rawPath = queryParams["path"];
            var contactId = queryParams["contactId"];

            if (string.IsNullOrWhiteSpace(rawPath))
            {
                _logger.LogWarning("Missing 'path' parameter");
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest, 
                    "Bad Request: Missing 'path' parameter");
            }

            if (string.IsNullOrWhiteSpace(contactId))
            {
                _logger.LogWarning("Missing 'contactId' parameter");
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest, 
                    "Bad Request: Missing 'contactId' parameter");
            }

            _logger.LogInformation("Request parameters - Path: {Path}, ContactId: {ContactId}", rawPath, contactId);

            // Validate contact access via Dataverse
            var dataverseUrl = _configuration["DataverseUrl"];
            if (string.IsNullOrWhiteSpace(dataverseUrl))
            {
                _logger.LogError("DataverseUrl configuration is missing");
                return await CreateErrorResponse(req, HttpStatusCode.InternalServerError, 
                    "Internal Server Error: Dataverse configuration missing");
            }

            var hasAccess = await _dataverseService.ValidateContactAccessAsync(contactId, accessToken, dataverseUrl);
            if (!hasAccess)
            {
                _logger.LogWarning("User {UserName} does not have access to contact {ContactId}", 
                    principalName ?? userPrincipal.Identity.Name, contactId);
                return await CreateErrorResponse(req, HttpStatusCode.Forbidden, 
                    "Forbidden: You do not have access to this resource");
            }

            _logger.LogInformation("User {UserName} has access to contact {ContactId}", 
                principalName ?? userPrincipal.Identity.Name, contactId);

            // Normalize path to blob format
            var blobPath = _blobService.NormalizePathToBlob(rawPath);
            if (string.IsNullOrWhiteSpace(blobPath))
            {
                _logger.LogWarning("Failed to normalize path: {RawPath}", rawPath);
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest, 
                    "Bad Request: Invalid file path");
            }

            // Generate SAS URL
            // Note: Container name should be configurable or derived from business logic
            // For this implementation, using "kofcext-extractions" as default
            var containerName = _configuration["BlobContainerName"] ?? "kofcext-extractions";
            
            string sasUrl;
            try
            {
                sasUrl = await _blobService.GenerateSasUrlAsync(containerName, blobPath);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(ex, "Blob or container not found: {BlobPath}", blobPath);
                return await CreateErrorResponse(req, HttpStatusCode.NotFound, 
                    "Not Found: The requested file does not exist");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating SAS URL for blob: {BlobPath}", blobPath);
                return await CreateErrorResponse(req, HttpStatusCode.InternalServerError, 
                    "Internal Server Error: Failed to generate access URL");
            }

            _logger.LogInformation("Successfully generated SAS URL for user {UserName}, contact {ContactId}, blob {BlobPath}", 
                principalName ?? userPrincipal.Identity.Name, contactId, blobPath);

            // Return 302 redirect to the SAS URL
            var response = req.CreateResponse(HttpStatusCode.Redirect);
            response.Headers.Add("Location", sasUrl);
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error processing request");
            return await CreateErrorResponse(req, HttpStatusCode.InternalServerError, 
                "Internal Server Error: An unexpected error occurred");
        }
    }

    private static string? GetHeaderValue(HttpRequestData req, string headerName)
    {
        if (req.Headers.TryGetValues(headerName, out var values))
        {
            return values.FirstOrDefault();
        }
        return null;
    }

    private static async Task<HttpResponseData> CreateErrorResponse(
        HttpRequestData req, 
        HttpStatusCode statusCode, 
        string message)
    {
        var response = req.CreateResponse(statusCode);
        await response.WriteStringAsync(message);
        return response;
    }
}

