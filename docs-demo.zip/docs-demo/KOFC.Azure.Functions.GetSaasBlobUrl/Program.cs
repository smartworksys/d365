using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Azure.Storage.Blobs;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureServices((context, services) =>
    {
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();

        // Register BlobServiceClient
        // Use BLOB_CONNECTION_STRING for blob storage (with fallback to AzureWebJobsStorage)
        var storageConnectionString = context.Configuration["BLOB_CONNECTION_STRING"] 
            ?? context.Configuration["AzureWebJobsStorage"];
        
        if (string.IsNullOrWhiteSpace(storageConnectionString))
        {
            throw new InvalidOperationException(
                "Blob storage connection string is not configured. " +
                "Please set BLOB_CONNECTION_STRING or AzureWebJobsStorage " +
                "in local.settings.json (local) or Application Settings (Azure). " +
                "Format: 'DefaultEndpointsProtocol=https;AccountName=...;AccountKey=...;EndpointSuffix=core.windows.net' " +
                "Or for local emulator: 'UseDevelopmentStorage=true'");
        }

        try
        {
            services.AddSingleton(x => new BlobServiceClient(storageConnectionString));
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"Failed to initialize BlobServiceClient. " +
                $"Please verify your BLOB_CONNECTION_STRING or AzureWebJobsStorage connection string is valid. " +
                $"Error: {ex.Message}", ex);
        }

        // Register services
        services.AddSingleton<IPrincipalService, PrincipalService>();
        services.AddSingleton<IDataverseService, DataverseService>();
        services.AddSingleton<IBlobService, BlobService>();

        // Register HttpClient for Dataverse
        services.AddHttpClient<IDataverseService, DataverseService>();
    })
    .Build();

host.Run();

