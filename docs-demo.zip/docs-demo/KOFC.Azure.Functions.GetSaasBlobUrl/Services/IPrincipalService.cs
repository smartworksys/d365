using KOFC.Azure.Functions.GetSaasBlobUrl.Models;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public interface IPrincipalService
{
    /// <summary>
    /// Decodes the Base64-encoded user principal from Azure AD Easy Auth headers
    /// </summary>
    /// <param name="base64Principal">Base64-encoded JSON principal from X-MS-CLIENT-PRINCIPAL header</param>
    /// <returns>Decoded UserPrincipal object</returns>
    UserPrincipal? DecodeUserPrincipal(string base64Principal);
}

