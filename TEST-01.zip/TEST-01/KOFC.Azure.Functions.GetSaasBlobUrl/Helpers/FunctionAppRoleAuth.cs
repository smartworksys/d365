using System.Text;
using System.Text.Json;
using Microsoft.Azure.Functions.Worker.Http;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Helpers;

/// <summary>
/// Validates Easy Auth app-role tokens on inbound requests from Boomi.
/// </summary>
public static class FunctionAppRoleAuth
{
    public const string ContactReadRole = "Contact.Read";

    public static bool IsAuthenticated(HttpRequestData req)
    {
        if (!IsRunningInAzure())
        {
            return true;
        }

        return !string.IsNullOrWhiteSpace(GetHeader(req, "X-MS-CLIENT-PRINCIPAL"));
    }

    public static IReadOnlyCollection<string> GetCallerRoles(HttpRequestData req)
    {
        if (!IsRunningInAzure())
        {
            return new[] { ContactReadRole };
        }

        return GetClaimValues(
            req,
            "roles",
            "http://schemas.microsoft.com/ws/2008/06/identity/claims/role");
    }

    public static IReadOnlyCollection<string> GetCallerScopes(HttpRequestData req)
    {
        return GetClaimValues(
                req,
                "scp",
                "http://schemas.microsoft.com/identity/claims/scope")
            .SelectMany(value => value.Split(' ', StringSplitOptions.RemoveEmptyEntries))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    public static bool HasScope(HttpRequestData req, string scope) =>
        GetCallerScopes(req).Contains(scope, StringComparer.OrdinalIgnoreCase);

    public static Guid? GetCallerObjectId(HttpRequestData req)
    {
        var value = GetClaimValues(
                req,
                "oid",
                "http://schemas.microsoft.com/identity/claims/objectidentifier")
            .FirstOrDefault();

        return Guid.TryParse(value, out var objectId) ? objectId : null;
    }

    public static bool IsDelegatedCaller(HttpRequestData req) =>
        GetCallerObjectId(req).HasValue && GetCallerScopes(req).Count > 0;

    public static bool HasAppRole(IReadOnlyCollection<string> callerRoles, string role) =>
        callerRoles.Contains(role, StringComparer.OrdinalIgnoreCase);

    public static bool IsRunningInAzure() =>
        !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("WEBSITE_SITE_NAME"));

    private static IReadOnlyCollection<string> GetClaimValues(
        HttpRequestData req,
        params string[] claimTypes)
    {
        var principalHeader = GetHeader(req, "X-MS-CLIENT-PRINCIPAL");
        if (string.IsNullOrWhiteSpace(principalHeader))
        {
            return Array.Empty<string>();
        }

        try
        {
            var json = Encoding.UTF8.GetString(Convert.FromBase64String(principalHeader));
            using var document = JsonDocument.Parse(json);
            if (!document.RootElement.TryGetProperty("claims", out var claims))
            {
                return Array.Empty<string>();
            }

            var values = new List<string>();
            foreach (var claim in claims.EnumerateArray())
            {
                if (!claim.TryGetProperty("typ", out var typ) || !claim.TryGetProperty("val", out var val))
                {
                    continue;
                }

                var type = typ.GetString();
                if (type is not null
                    && claimTypes.Contains(type, StringComparer.OrdinalIgnoreCase))
                {
                    var value = val.GetString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        values.Add(value);
                    }
                }
            }

            return values;
        }
        catch
        {
            return Array.Empty<string>();
        }
    }

    private static string? GetHeader(HttpRequestData req, string headerName)
    {
        if (req.Headers.TryGetValues(headerName, out var values))
        {
            return values.FirstOrDefault();
        }

        return null;
    }
}
