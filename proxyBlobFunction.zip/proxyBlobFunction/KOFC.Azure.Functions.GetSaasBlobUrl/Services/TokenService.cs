using System.Net.Http.Json;
using System.Text.Json;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public class TokenService : ITokenService
{
    private readonly ILogger<TokenService> _logger;
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _configuration;

    public TokenService(ILogger<TokenService> logger, HttpClient httpClient, IConfiguration configuration)
    {
        _logger = logger;
        _httpClient = httpClient;
        _configuration = configuration;
    }

    public async Task<string> GetDataverseTokenAsync(string currentToken, string? refreshToken, string dataverseUrl)
    {
        // Check if current token is already for Dataverse
        var tokenAudience = DecodeTokenAudience(currentToken);
        if (tokenAudience == dataverseUrl || tokenAudience?.StartsWith(dataverseUrl, StringComparison.OrdinalIgnoreCase) == true)
        {
            _logger.LogInformation("Token is already for Dataverse audience: {Audience}", tokenAudience);
            return currentToken;
        }

        _logger.LogInformation("Token audience is {Audience}, need to get Dataverse token", tokenAudience);

        // Try refresh token if available (best option for user delegation)
        if (!string.IsNullOrWhiteSpace(refreshToken))
        {
            try
            {
                return await ExchangeRefreshTokenForDataverseTokenAsync(refreshToken, dataverseUrl);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Refresh token exchange failed");
            }
        }

        // Fallback: Use service principal (client credentials) for Dataverse
        // Note: This uses app-only authentication, not user delegation
        try
        {
            var dataverseToken = await GetDataverseTokenUsingServicePrincipalAsync(dataverseUrl);
            if (!string.IsNullOrWhiteSpace(dataverseToken))
            {
                _logger.LogInformation("Successfully obtained Dataverse token using service principal");
                return dataverseToken;
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Service principal token acquisition failed: {Error}", ex.Message);
        }

        // Last resort: try to use the current token (will likely fail but we'll try)
        _logger.LogWarning("All token exchange methods failed, using original token (will likely fail with Dataverse).");
        return currentToken;
    }


    private async Task<string?> GetDataverseTokenUsingServicePrincipalAsync(string dataverseUrl)
    {
        try
        {
            // Get service principal credentials from configuration
            // Use the same ClientId and ClientSecret as Easy Auth
            var clientId = _configuration["ClientId"];
            if (string.IsNullOrWhiteSpace(clientId))
            {
                clientId = _configuration["WEBSITE_AUTH_CLIENT_ID"];
            }
            
            var clientSecret = _configuration["ClientSecret"];
            var tenantId = _configuration["TenantId"];

            if (string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(clientSecret))
            {
                _logger.LogWarning("ClientId or ClientSecret not configured. Service principal authentication not available.");
                return null;
            }

            if (string.IsNullOrWhiteSpace(tenantId))
            {
                // Try to get from configuration
                tenantId = _configuration["WEBSITE_AUTH_AAD_ALLOWED_TENANTS"];
                if (string.IsNullOrWhiteSpace(tenantId))
                {
                    _logger.LogWarning("TenantId not configured. Please set TenantId in app settings.");
                    return null;
                }
            }

            var tokenEndpoint = $"https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token";

            var requestBody = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("grant_type", "client_credentials"),
                new KeyValuePair<string, string>("client_id", clientId),
                new KeyValuePair<string, string>("client_secret", clientSecret),
                new KeyValuePair<string, string>("scope", $"{dataverseUrl}/.default")
            });

            _logger.LogInformation("Requesting Dataverse token using service principal (client credentials)");

            var response = await _httpClient.PostAsync(tokenEndpoint, requestBody);

            if (response.IsSuccessStatusCode)
            {
                var tokenResponse = await response.Content.ReadFromJsonAsync<JsonElement>();
                if (tokenResponse.TryGetProperty("access_token", out var accessTokenElement))
                {
                    var accessToken = accessTokenElement.GetString();
                    if (!string.IsNullOrWhiteSpace(accessToken))
                    {
                        _logger.LogInformation("Service principal token acquisition successful");
                        return accessToken;
                    }
                }
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                _logger.LogWarning("Service principal token acquisition failed. Status: {StatusCode}, Error: {Error}",
                    response.StatusCode, errorContent);
            }

            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error acquiring Dataverse token using service principal");
            return null;
        }
    }


    private async Task<string> ExchangeRefreshTokenForDataverseTokenAsync(string refreshToken, string dataverseUrl)
    {
        try
        {
            // Get tenant ID from the current token or configuration
            var tenantId = GetTenantIdFromToken(refreshToken) ?? _configuration["TenantId"];
            if (string.IsNullOrWhiteSpace(tenantId))
            {
                // Try to extract from Dataverse URL or use common tenant
                tenantId = "common";
            }

            var tokenEndpoint = $"https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token";
            
            // Get client ID from configuration or extract from token
            var clientId = _configuration["ClientId"];
            if (string.IsNullOrWhiteSpace(clientId))
            {
                // Try to get from WEBSITE_AUTH_CLIENT_ID (set by Easy Auth)
                clientId = _configuration["WEBSITE_AUTH_CLIENT_ID"];
            }

            if (string.IsNullOrWhiteSpace(clientId))
            {
                throw new InvalidOperationException("ClientId is not configured. Set ClientId or WEBSITE_AUTH_CLIENT_ID in app settings.");
            }

            var requestBody = new FormUrlEncodedContent(new[]
            {
                new KeyValuePair<string, string>("grant_type", "refresh_token"),
                new KeyValuePair<string, string>("refresh_token", refreshToken),
                new KeyValuePair<string, string>("client_id", clientId),
                new KeyValuePair<string, string>("scope", $"{dataverseUrl}/.default"),
                new KeyValuePair<string, string>("resource", dataverseUrl)
            });

            _logger.LogInformation("Exchanging refresh token for Dataverse token");

            var response = await _httpClient.PostAsync(tokenEndpoint, requestBody);
            
            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                _logger.LogError("Failed to exchange token. Status: {StatusCode}, Error: {Error}", 
                    response.StatusCode, errorContent);
                throw new InvalidOperationException($"Token exchange failed: {response.StatusCode}");
            }

            var tokenResponse = await response.Content.ReadFromJsonAsync<JsonElement>();
            var accessToken = tokenResponse.GetProperty("access_token").GetString();

            if (string.IsNullOrWhiteSpace(accessToken))
            {
                throw new InvalidOperationException("Token exchange returned empty access token");
            }

            _logger.LogInformation("Successfully exchanged token for Dataverse");
            return accessToken;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error exchanging refresh token for Dataverse token");
            throw;
        }
    }

    private static string? DecodeTokenAudience(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
            return null;

        try
        {
            var parts = token.Split('.');
            if (parts.Length != 3)
                return null;

            var payload = parts[1];
            var padding = 4 - (payload.Length % 4);
            if (padding != 4)
            {
                payload += new string('=', padding);
            }
            
            payload = payload.Replace('-', '+').Replace('_', '/');
            var payloadBytes = Convert.FromBase64String(payload);
            var payloadJson = System.Text.Encoding.UTF8.GetString(payloadBytes);
            
            using var doc = JsonDocument.Parse(payloadJson);
            if (doc.RootElement.TryGetProperty("aud", out var audElement))
            {
                return audElement.GetString();
            }
            
            return null;
        }
        catch
        {
            return null;
        }
    }

    private static string? GetTenantIdFromToken(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
            return null;

        try
        {
            var parts = token.Split('.');
            if (parts.Length != 3)
                return null;

            var payload = parts[1];
            var padding = 4 - (payload.Length % 4);
            if (padding != 4)
            {
                payload += new string('=', padding);
            }
            
            payload = payload.Replace('-', '+').Replace('_', '/');
            var payloadBytes = Convert.FromBase64String(payload);
            var payloadJson = System.Text.Encoding.UTF8.GetString(payloadBytes);
            
            using var doc = JsonDocument.Parse(payloadJson);
            if (doc.RootElement.TryGetProperty("tid", out var tidElement))
            {
                return tidElement.GetString();
            }
            
            return null;
        }
        catch
        {
            return null;
        }
    }
}

