using System.Net;
using Microsoft.Extensions.Logging;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public class DataverseService : IDataverseService
{
    private readonly ILogger<DataverseService> _logger;
    private readonly HttpClient _httpClient;

    public DataverseService(ILogger<DataverseService> logger, HttpClient httpClient)
    {
        _logger = logger;
        _httpClient = httpClient;
    }

    public async Task<bool> ValidateEntityAccessAsync(string entityId, string entityName, string accessToken, string dataverseUrl)
    {
        if (string.IsNullOrWhiteSpace(entityId))
        {
            _logger.LogWarning("EntityId is null or empty");
            return false;
        }

        if (string.IsNullOrWhiteSpace(entityName))
        {
            _logger.LogWarning("Entity name is null or empty");
            return false;
        }

        if (string.IsNullOrWhiteSpace(accessToken))
        {
            _logger.LogWarning("Access token is null or empty");
            return false;
        }

        if (string.IsNullOrWhiteSpace(dataverseUrl))
        {
            _logger.LogWarning("Dataverse URL is null or empty");
            return false;
        }

        try
        {
            // Validate GUID format
            if (!Guid.TryParse(entityId, out _))
            {
                _logger.LogWarning("Invalid entity ID format: {EntityId}", entityId);
                return false;
            }

            // Build the entity ID field name (typically {entityname}id, e.g., contactid, accountid)
            // IMPORTANT: Entity ID field ALWAYS uses singular form, even though API endpoint uses plural
            // Example: entity "contact" -> field "contactid", endpoint "contacts"
            // Example: entity "chit_apptracker" -> field "chit_apptrackerid", endpoint "chit_apptrackers"
            var singularEntityName = GetSingularEntityName(entityName);
            var entityIdField = $"{singularEntityName.ToLowerInvariant()}id";
            
            // Pluralize entity name for API endpoint (Dataverse uses plural forms in URLs)
            // Simple pluralization: add 's' to the end (works for most entities)
            // For irregular plurals, specify the plural form directly in DataverseEntityName config
            var pluralEntityName = PluralizeEntityName(entityName);
            
            var requestUri = $"{dataverseUrl.TrimEnd('/')}/api/data/v9.2/{pluralEntityName}({entityId})?$select={entityIdField}";
            
            using var request = new HttpRequestMessage(HttpMethod.Get, requestUri);
            request.Headers.Add("Authorization", $"Bearer {accessToken}");
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("OData-MaxVersion", "4.0");
            request.Headers.Add("OData-Version", "4.0");

            _logger.LogInformation("Validating access to {EntityName} {EntityId} at {DataverseUrl}", entityName, entityId, dataverseUrl);

            var response = await _httpClient.SendAsync(request);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                _logger.LogInformation("User has access to {EntityName} {EntityId}", entityName, entityId);
                return true;
            }
            else if (response.StatusCode == HttpStatusCode.Forbidden || response.StatusCode == HttpStatusCode.NotFound)
            {
                _logger.LogWarning("User does not have access to {EntityName} {EntityId}. Status: {StatusCode}", 
                    entityName, entityId, response.StatusCode);
                return false;
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                _logger.LogError("Unexpected response from Dataverse. Status: {StatusCode}, Content: {Content}", 
                    response.StatusCode, errorContent);
                return false;
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error validating {EntityName} access for {EntityId}", entityName, entityId);
            return false;
        }
    }

    /// <summary>
    /// Gets the singular form of entity name for ID field construction.
    /// If the name ends with 's', remove it to get singular form.
    /// </summary>
    private static string GetSingularEntityName(string entityName)
    {
        if (string.IsNullOrWhiteSpace(entityName))
            return entityName;

        var lowerName = entityName.ToLowerInvariant();
        
        // If ends with 's', assume it's plural and remove 's' to get singular
        if (lowerName.EndsWith("s"))
            return lowerName.Substring(0, lowerName.Length - 1);
        
        // Already singular
        return lowerName;
    }

    /// <summary>
    /// Pluralizes entity name for Dataverse API endpoint.
    /// Most entities just add 's', but some are irregular.
    /// If the entity name already ends with 's', assume it's already plural.
    /// </summary>
    private static string PluralizeEntityName(string entityName)
    {
        if (string.IsNullOrWhiteSpace(entityName))
            return entityName;

        var lowerName = entityName.ToLowerInvariant();
        
        // If already ends with 's', assume it's plural
        if (lowerName.EndsWith("s"))
            return lowerName;
        
        // Simple pluralization: add 's'
        return lowerName + "s";
    }
}

