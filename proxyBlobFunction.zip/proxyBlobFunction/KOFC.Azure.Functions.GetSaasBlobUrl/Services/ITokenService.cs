namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public interface ITokenService
{
    /// <summary>
    /// Gets an access token for Dataverse.
    /// Attempts to use refresh token if available, otherwise falls back to service principal authentication.
    /// </summary>
    /// <param name="currentToken">The current access token (used to check audience)</param>
    /// <param name="refreshToken">Optional refresh token for user delegation</param>
    /// <param name="dataverseUrl">The Dataverse URL to get a token for</param>
    /// <returns>The access token for Dataverse</returns>
    Task<string> GetDataverseTokenAsync(string currentToken, string? refreshToken, string dataverseUrl);
}

