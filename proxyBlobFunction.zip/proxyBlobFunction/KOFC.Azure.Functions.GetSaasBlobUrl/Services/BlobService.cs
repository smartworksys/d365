using System.Text.RegularExpressions;
using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Sas;
using Microsoft.Extensions.Logging;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public class BlobService : IBlobService
{
    private readonly ILogger<BlobService> _logger;
    private readonly BlobServiceClient _blobServiceClient;

    public BlobService(ILogger<BlobService> logger, BlobServiceClient blobServiceClient)
    {
        _logger = logger;
        _blobServiceClient = blobServiceClient;
    }

    public string NormalizePathToBlob(string rawPath)
    {
        if (string.IsNullOrWhiteSpace(rawPath))
        {
            _logger.LogWarning("Raw path is null or empty");
            return string.Empty;
        }

        // Remove drive letter and colon (e.g., "D:\")
        var cleaned = Regex.Replace(rawPath, @"^[A-Za-z]:\\", string.Empty);
        
        // Replace backslashes with forward slashes
        cleaned = cleaned.Replace("\\", "/");
        
        // Collapse multiple consecutive slashes into a single slash
        cleaned = Regex.Replace(cleaned, @"/+", "/");
        
        // Remove all leading whitespace, tabs, and slashes using regex
        cleaned = Regex.Replace(cleaned, @"^[\s/\\]+", string.Empty);
        
        // Remove all trailing whitespace, tabs, and slashes
        cleaned = Regex.Replace(cleaned, @"[\s/\\]+$", string.Empty);

        _logger.LogInformation("Normalized path from '{RawPath}' to '{CleanedPath}'", rawPath, cleaned);
        
        return cleaned;
    }

    public async Task<string> GenerateSasUrlAsync(string containerName, string blobPath)
    {
        if (string.IsNullOrWhiteSpace(containerName))
        {
            throw new ArgumentException("Container name cannot be null or empty", nameof(containerName));
        }

        if (string.IsNullOrWhiteSpace(blobPath))
        {
            throw new ArgumentException("Blob path cannot be null or empty", nameof(blobPath));
        }

        // Trim any remaining whitespace from the blob path
        blobPath = blobPath.Trim();

        try
        {
            var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
            
            // Verify container exists (skip if permission error - we can still generate SAS token)
            try
            {
                if (!await containerClient.ExistsAsync())
                {
                    _logger.LogError("Container '{ContainerName}' does not exist", containerName);
                    throw new InvalidOperationException($"Container '{containerName}' does not exist");
                }
            }
            catch (RequestFailedException ex) when (ex.Status == 403 && ex.ErrorCode == "AuthorizationPermissionMismatch")
            {
                _logger.LogWarning("Cannot verify container existence due to permissions, proceeding with SAS token generation. Error: {Error}", ex.Message);
                // Continue - we can still generate SAS token even if we can't check existence
            }

            var blobClient = containerClient.GetBlobClient(blobPath);
            
            // Verify blob exists (skip if permission error - we can still generate SAS token)
            try
            {
                if (!await blobClient.ExistsAsync())
                {
                    _logger.LogError("Blob '{BlobPath}' does not exist in container '{ContainerName}'", blobPath, containerName);
                    throw new InvalidOperationException($"Blob '{blobPath}' does not exist in container '{containerName}'");
                }
            }
            catch (RequestFailedException ex) when (ex.Status == 403 && ex.ErrorCode == "AuthorizationPermissionMismatch")
            {
                _logger.LogWarning("Cannot verify blob existence due to permissions, proceeding with SAS token generation. Error: {Error}", ex.Message);
                // Continue - we can still generate SAS token even if we can't check existence
            }

            // Create SAS builder with read-only permissions
            var startsOn = DateTimeOffset.UtcNow.AddMinutes(-5); // Account for clock skew
            var expiresOn = DateTimeOffset.UtcNow.AddMinutes(15);
            
            var sasBuilder = new BlobSasBuilder
            {
                BlobContainerName = containerName,
                BlobName = blobPath,
                Resource = "b", // "b" for blob
                StartsOn = startsOn,
                ExpiresOn = expiresOn
            };

            sasBuilder.SetPermissions(BlobSasPermissions.Read);

            // When using Managed Identity (or Azure CLI credentials), we need to use User Delegation Key
            // instead of account keys to generate SAS tokens
            // The User Delegation Key must be valid for at least as long as the SAS token
            var userDelegationKeyResponse = await _blobServiceClient.GetUserDelegationKeyAsync(
                startsOn,
                expiresOn);
            var userDelegationKey = userDelegationKeyResponse.Value;

            // Generate the SAS query parameters using the User Delegation Key
            var sasQueryParameters = sasBuilder.ToSasQueryParameters(userDelegationKey, _blobServiceClient.AccountName);
            
            // Construct the full SAS URI
            var sasUri = new UriBuilder(blobClient.Uri)
            {
                Query = sasQueryParameters.ToString()
            };
            
            _logger.LogInformation("Generated SAS URL for blob '{BlobPath}' in container '{ContainerName}', expires at {ExpiresOn}", 
                blobPath, containerName, sasBuilder.ExpiresOn);

            return sasUri.ToString();
        }
        catch (RequestFailedException ex)
        {
            _logger.LogError(ex, "Azure Storage error generating SAS URL for blob '{BlobPath}' in container '{ContainerName}'", 
                blobPath, containerName);
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error generating SAS URL for blob '{BlobPath}' in container '{ContainerName}'", 
                blobPath, containerName);
            throw;
        }
    }
}

