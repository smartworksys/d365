namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public interface IDataverseService
{
    /// <summary>
    /// Validates that the user has access to the specified entity record in Dataverse
    /// </summary>
    /// <param name="entityId">The GUID of the entity record</param>
    /// <param name="entityName">The logical name of the entity (e.g., "contacts", "accounts")</param>
    /// <param name="accessToken">The Azure AD access token for Dataverse API</param>
    /// <param name="dataverseUrl">The Dataverse organization URL</param>
    /// <returns>True if the user has access, false otherwise</returns>
    Task<bool> ValidateEntityAccessAsync(string entityId, string entityName, string accessToken, string dataverseUrl);
}

