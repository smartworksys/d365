using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Azure.Storage.Blobs;
using Azure.Identity;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureServices((context, services) =>
    {
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();

        // Register BlobServiceClient using Managed Identity only
        var storageAccountName = context.Configuration["BlobStorageAccountName"];
        
        if (string.IsNullOrWhiteSpace(storageAccountName))
        {
            throw new InvalidOperationException(
                "BlobStorageAccountName is not configured. " +
                "Please set 'BlobStorageAccountName' in Application Settings (Azure) or local.settings.json (local). " +
                "The function uses Managed Identity for blob storage access. " +
                "For local development, ensure you're logged into Azure CLI: az login");
        }

        try
        {
            // Use Managed Identity via DefaultAzureCredential
            // This works in Azure (Managed Identity) and locally (Azure CLI credentials)
            var credential = new DefaultAzureCredential();
            var blobServiceUri = new Uri($"https://{storageAccountName}.blob.core.windows.net");
            services.AddSingleton(x => new BlobServiceClient(blobServiceUri, credential));
        }
        catch (Exception ex)
        {
            throw new InvalidOperationException(
                $"Failed to initialize BlobServiceClient with Managed Identity. " +
                $"Please verify: " +
                $"1. Managed Identity is enabled on the Function App (Azure), or " +
                $"2. You're logged into Azure CLI: az login (local development), and " +
                $"3. The identity has 'Storage Blob Data Contributor' role on the storage account. " +
                $"Error: {ex.Message}", ex);
        }

        // Register services
        services.AddSingleton<IPrincipalService, PrincipalService>();
        services.AddSingleton<IDataverseService, DataverseService>();
        services.AddSingleton<IBlobService, BlobService>();
        services.AddSingleton<ITokenService, TokenService>();

        // Register HttpClient for Dataverse and TokenService
        services.AddHttpClient<IDataverseService, DataverseService>();
        services.AddHttpClient<ITokenService, TokenService>();
    })
    .Build();

host.Run();

