using System.Net;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;

namespace KOFC.Azure.Functions.GetSaasBlobUrl;

/// <summary>
/// LOCAL TESTING VERSION - Bypasses Easy Auth for local development
/// DO NOT DEPLOY THIS TO PRODUCTION
/// </summary>
public class GetLocalSaasBlobUrl
{
    private readonly ILogger<GetLocalSaasBlobUrl> _logger;
    private readonly IBlobService _blobService;
    private readonly IConfiguration _configuration;

    public GetLocalSaasBlobUrl(
        ILogger<GetLocalSaasBlobUrl> logger,
        IBlobService blobService,
        IConfiguration configuration)
    {
        _logger = logger;
        _blobService = blobService;
        _configuration = configuration;
    }

    [Function("GetLocalSaasBlobUrl")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get")] HttpRequestData req)
    {
        _logger.LogWarning("⚠️ USING LOCAL TESTING ENDPOINT - NO AUTH VALIDATION ⚠️");

        try
        {
            // Extract query parameters
            var query = req.Url.Query;
            var rawPath = GetQueryParameter(query, "path");
            var entityId = GetQueryParameter(query, "entityId");

            if (string.IsNullOrWhiteSpace(rawPath))
            {
                _logger.LogWarning("Missing 'path' parameter");
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest, 
                    "Bad Request: Missing 'path' parameter");
            }

            if (string.IsNullOrWhiteSpace(entityId))
            {
                _logger.LogWarning("Missing 'entityId' parameter");
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest, 
                    "Bad Request: Missing 'entityId' parameter");
            }

            _logger.LogInformation("Request parameters - Path: {Path}, EntityId: {EntityId}", rawPath, entityId);

            // Normalize path to blob format
            var blobPath = _blobService.NormalizePathToBlob(rawPath);
            if (string.IsNullOrWhiteSpace(blobPath))
            {
                _logger.LogWarning("Failed to normalize path: {RawPath}", rawPath);
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest, 
                    "Bad Request: Invalid file path");
            }

            // Generate SAS URL
            var containerName = _configuration["BlobContainerName"] ?? "kofcext-extractions";
            
            string sasUrl;
            try
            {
                sasUrl = await _blobService.GenerateSasUrlAsync(containerName, blobPath);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(ex, "Blob or container not found: {BlobPath}", blobPath);
                return await CreateErrorResponse(req, HttpStatusCode.NotFound, 
                    "Not Found: The requested file does not exist");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating SAS URL for blob: {BlobPath}", blobPath);
                return await CreateErrorResponse(req, HttpStatusCode.InternalServerError, 
                    "Internal Server Error: Failed to generate access URL");
            }

            _logger.LogInformation("Successfully generated SAS URL for blob {BlobPath}", blobPath);

            // Return 302 redirect to the SAS URL
            var response = req.CreateResponse(HttpStatusCode.Redirect);
            response.Headers.Add("Location", sasUrl);
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error processing request");
            return await CreateErrorResponse(req, HttpStatusCode.InternalServerError, 
                "Internal Server Error: An unexpected error occurred");
        }
    }

    private static async Task<HttpResponseData> CreateErrorResponse(
        HttpRequestData req, 
        HttpStatusCode statusCode, 
        string message)
    {
        var response = req.CreateResponse(statusCode);
        await response.WriteStringAsync(message);
        return response;
    }

    private static string? GetQueryParameter(string query, string parameterName)
    {
        if (string.IsNullOrWhiteSpace(query) || string.IsNullOrWhiteSpace(parameterName))
        {
            return null;
        }

        // Remove leading '?' if present
        if (query.StartsWith("?"))
        {
            query = query.Substring(1);
        }

        var pairs = query.Split('&');
        foreach (var pair in pairs)
        {
            var parts = pair.Split('=', 2);
            if (parts.Length == 2 && 
                Uri.UnescapeDataString(parts[0]).Equals(parameterName, StringComparison.OrdinalIgnoreCase))
            {
                return Uri.UnescapeDataString(parts[1]);
            }
        }

        return null;
    }
}

