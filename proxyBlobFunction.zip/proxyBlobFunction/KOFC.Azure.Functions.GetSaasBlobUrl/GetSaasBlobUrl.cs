using System.Net;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;

namespace KOFC.Azure.Functions.GetSaasBlobUrl;

public class GetSaasBlobUrl
{
    private readonly ILogger<GetSaasBlobUrl> _logger;
    private readonly IPrincipalService _principalService;
    private readonly IDataverseService _dataverseService;
    private readonly IBlobService _blobService;
    private readonly IConfiguration _configuration;
    private readonly ITokenService _tokenService;

    public GetSaasBlobUrl(
        ILogger<GetSaasBlobUrl> logger,
        IPrincipalService principalService,
        IDataverseService dataverseService,
        IBlobService blobService,
        IConfiguration configuration,
        ITokenService tokenService)
    {
        _logger = logger;
        _principalService = principalService;
        _dataverseService = dataverseService;
        _blobService = blobService;
        _configuration = configuration;
        _tokenService = tokenService;
    }

    [Function("GetSaasBlobUrl")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequestData req)
    {
        _logger.LogInformation("Processing request for GetSaasBlobUrl");

        try
        {
            // Extract and validate Easy Auth headers
            var accessToken = GetHeaderValue(req, "X-MS-TOKEN-AAD-ACCESS-TOKEN");
            var refreshToken = GetHeaderValue(req, "X-MS-TOKEN-AAD-REFRESH-TOKEN");
            var principalHeader = GetHeaderValue(req, "X-MS-CLIENT-PRINCIPAL");
            var principalName = GetHeaderValue(req, "X-MS-CLIENT-PRINCIPAL-NAME");
            var principalId = GetHeaderValue(req, "X-MS-CLIENT-PRINCIPAL-ID");
            
            if (string.IsNullOrWhiteSpace(accessToken) || string.IsNullOrWhiteSpace(principalHeader))
            {
                _logger.LogWarning("Missing authentication headers. Request is not authenticated.");
                return await CreateErrorResponse(req, HttpStatusCode.Unauthorized, 
                    "Unauthorized: Missing or invalid authentication token");
            }

            // Decode user principal
            var userPrincipal = _principalService.DecodeUserPrincipal(principalHeader);
            if (userPrincipal == null)
            {
                _logger.LogWarning("Failed to decode user principal");
                return await CreateErrorResponse(req, HttpStatusCode.Unauthorized, 
                    "Unauthorized: Invalid user principal");
            }

            _logger.LogInformation("Authenticated user: {UserName}, Principal ID: {PrincipalId}", 
                principalName ?? userPrincipal.Identity.Name, principalId);

            // Extract and validate query parameters
            var query = req.Url.Query;
            var rawPath = GetQueryParameter(query, "path");
            var entityId = GetQueryParameter(query, "entityId");

            if (string.IsNullOrWhiteSpace(rawPath))
            {
                _logger.LogWarning("Missing 'path' parameter");
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest, 
                    "Bad Request: Missing 'path' parameter");
            }

            if (string.IsNullOrWhiteSpace(entityId))
            {
                _logger.LogWarning("Missing 'entityId' parameter");
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest, 
                    "Bad Request: Missing 'entityId' parameter");
            }

            // Get entity name from configuration (defaults to "contacts" for backward compatibility)
            var entityName = _configuration["DataverseEntityName"] ?? "contacts";
            var dataverseUrl = _configuration["DataverseUrl"];
            
            if (string.IsNullOrWhiteSpace(dataverseUrl))
            {
                _logger.LogError("DataverseUrl configuration is missing");
                return await CreateErrorResponse(req, HttpStatusCode.InternalServerError, 
                    "Internal Server Error: Dataverse configuration missing");
            }

            _logger.LogInformation("Request parameters - Path: {Path}, EntityId: {EntityId}, EntityName: {EntityName}", 
                rawPath, entityId, entityName);

            // Get Dataverse token (exchange if necessary)
            string dataverseToken;
            try
            {
                dataverseToken = await _tokenService.GetDataverseTokenAsync(accessToken, refreshToken, dataverseUrl);
                _logger.LogInformation("Using Dataverse token for validation");
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to get Dataverse token, using original token (may fail)");
                dataverseToken = accessToken;
            }

            // Validate entity access via Dataverse
            var hasAccess = await _dataverseService.ValidateEntityAccessAsync(entityId, entityName, dataverseToken, dataverseUrl);
            if (!hasAccess)
            {
                var userName = principalName ?? userPrincipal.Identity.Name ?? "Unknown User";
                _logger.LogWarning("User {UserName} does not have access to {EntityName} {EntityId}", 
                    userName, entityName, entityId);
                
                var errorMessage = $"Access Denied: You do not have permission to access this {entityName} record (ID: {entityId}). " +
                                 $"Please contact your administrator if you believe you should have access to this resource.";
                
                return await CreateErrorResponse(req, HttpStatusCode.Forbidden, errorMessage);
            }

            _logger.LogInformation("User {UserName} has access to {EntityName} {EntityId}", 
                principalName ?? userPrincipal.Identity.Name, entityName, entityId);

            // Normalize path to blob format
            var blobPath = _blobService.NormalizePathToBlob(rawPath);
            if (string.IsNullOrWhiteSpace(blobPath))
            {
                _logger.LogWarning("Failed to normalize path: {RawPath}", rawPath);
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest, 
                    "Bad Request: Invalid file path");
            }

            // Generate SAS URL
            // Note: Container name should be configurable or derived from business logic
            // For this implementation, using "kofcext-extractions" as default
            var containerName = _configuration["BlobContainerName"] ?? "kofcext-extractions";
            
            string sasUrl;
            try
            {
                sasUrl = await _blobService.GenerateSasUrlAsync(containerName, blobPath);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(ex, "Blob or container not found: {BlobPath}", blobPath);
                return await CreateErrorResponse(req, HttpStatusCode.NotFound, 
                    "Not Found: The requested file does not exist");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating SAS URL for blob: {BlobPath}", blobPath);
                return await CreateErrorResponse(req, HttpStatusCode.InternalServerError, 
                    "Internal Server Error: Failed to generate access URL");
            }

            _logger.LogInformation("Successfully generated SAS URL for user {UserName}, {EntityName} {EntityId}, blob {BlobPath}", 
                principalName ?? userPrincipal.Identity.Name, entityName, entityId, blobPath);

            // Return 302 redirect to the SAS URL
            var response = req.CreateResponse(HttpStatusCode.Redirect);
            response.Headers.Add("Location", sasUrl);
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error processing request");
            return await CreateErrorResponse(req, HttpStatusCode.InternalServerError, 
                "Internal Server Error: An unexpected error occurred");
        }
    }

    private static string? GetHeaderValue(HttpRequestData req, string headerName)
    {
        if (req.Headers.TryGetValues(headerName, out var values))
        {
            return values.FirstOrDefault();
        }
        return null;
    }

    private static string? GetQueryParameter(string query, string parameterName)
    {
        if (string.IsNullOrWhiteSpace(query) || string.IsNullOrWhiteSpace(parameterName))
        {
            return null;
        }

        // Remove leading '?' if present
        if (query.StartsWith("?"))
        {
            query = query.Substring(1);
        }

        var pairs = query.Split('&');
        foreach (var pair in pairs)
        {
            var parts = pair.Split('=', 2);
            if (parts.Length == 2 && 
                Uri.UnescapeDataString(parts[0]).Equals(parameterName, StringComparison.OrdinalIgnoreCase))
            {
                return Uri.UnescapeDataString(parts[1]);
            }
        }

        return null;
    }

    private static async Task<HttpResponseData> CreateErrorResponse(
        HttpRequestData req, 
        HttpStatusCode statusCode, 
        string message)
    {
        var response = req.CreateResponse(statusCode);
        await response.WriteStringAsync(message);
        return response;
    }

    /// <summary>
    /// Decodes JWT token to extract audience claim for debugging
    /// </summary>
    private static string? DecodeTokenAudience(string token)
    {
        if (string.IsNullOrWhiteSpace(token))
            return null;

        try
        {
            // JWT format: header.payload.signature
            var parts = token.Split('.');
            if (parts.Length != 3)
                return null;

            // Decode payload (second part)
            var payload = parts[1];
            
            // Add padding if needed (Base64Url may not have padding)
            var padding = 4 - (payload.Length % 4);
            if (padding != 4)
            {
                payload += new string('=', padding);
            }
            
            // Replace Base64Url characters with Base64
            payload = payload.Replace('-', '+').Replace('_', '/');
            
            var payloadBytes = Convert.FromBase64String(payload);
            var payloadJson = System.Text.Encoding.UTF8.GetString(payloadBytes);
            
            // Parse JSON to find "aud" claim
            using var doc = System.Text.Json.JsonDocument.Parse(payloadJson);
            if (doc.RootElement.TryGetProperty("aud", out var audElement))
            {
                return audElement.GetString();
            }
            
            return null;
        }
        catch
        {
            return null;
        }
    }
}

