# Azure Function - SAS Blob URL Generator with Dataverse Authentication

Generate secure SAS URLs for Azure Blob Storage with Azure AD Easy Auth and Dataverse entity validation.

## 🏗️ Architecture

```
User Browser
    ↓
Easy Auth (Azure AD) - User Authentication
    ↓
Azure Function
    ├─→ Dataverse API - Entity Validation (Service Principal)
    └─→ Blob Storage - SAS URL Generation (Managed Identity)
```

## ✨ Features

- **Azure AD Easy Auth**: Secure user authentication
- **Dataverse Validation**: Validates user has access to specific entity records  
- **Managed Identity**: Secure blob storage access without connection strings
- **Service Principal**: Reliable Dataverse API access
- **Configurable Entities**: Works with any Dataverse entity (not just contacts)
- **Clean Architecture**: Well-tested, production-ready code

## 🚀 Quick Start

### Prerequisites

- Azure subscription
- Azure Function App with Easy Auth enabled
- Azure Blob Storage account
- Dataverse environment

### 1. Configure App Settings

#### Option A: Azure Portal (Manual)

1. Go to [Azure Portal](https://portal.azure.com)
2. Navigate to your Function App
3. Click **Configuration** in the left menu
4. Under **Application settings**, click **+ New application setting** for each:

| Name | Value | Example |
|------|-------|---------|
| `BlobStorageAccountName` | Your storage account name | `mystorageaccount` |
| `BlobContainerName` | Your container name | `smart-office` |
| `DataverseUrl` | Your Dataverse URL | `https://orgabc123.crm.dynamics.com` |
| `DataverseEntityName` | Default entity name | `contacts` |
| `TenantId` | Your Azure AD tenant ID | `12345678-1234-1234-1234-123456789012` |

5. Click **Save** at the top
6. Click **Continue** to restart the app

#### Option B: Azure CLI

```bash
az functionapp config appsettings set \
  --name YOUR_FUNCTION_APP \
  --resource-group YOUR_RESOURCE_GROUP \
  --settings \
    "BlobStorageAccountName=yourstorageaccount" \
    "BlobContainerName=your-container" \
    "DataverseUrl=https://yourorg.crm.dynamics.com" \
    "DataverseEntityName=contacts" \
    "TenantId=your-tenant-id"
```

### 2. Enable Managed Identity

#### Option A: Azure Portal (Manual)

**Enable Managed Identity:**
1. Go to your Function App in Azure Portal
2. Click **Identity** in the left menu
3. Under **System assigned** tab:
   - Set **Status** to **On**
   - Click **Save**
   - Copy the **Object (principal) ID** (you'll need this next)

**Assign Storage Role:**
1. Go to your Storage Account in Azure Portal
2. Click **Access Control (IAM)** in the left menu
3. Click **+ Add** → **Add role assignment**
4. Select **Storage Blob Data Contributor** role
5. Click **Next**
6. Click **+ Select members**
7. Search for your Function App name
8. Select it and click **Select**
9. Click **Review + assign**

#### Option B: Azure CLI

```bash
# Enable system-assigned managed identity
az functionapp identity assign \
  --name YOUR_FUNCTION_APP \
  --resource-group YOUR_RESOURCE_GROUP

# Get the principal ID
PRINCIPAL_ID=$(az functionapp identity show \
  --name YOUR_FUNCTION_APP \
  --resource-group YOUR_RESOURCE_GROUP \
  --query principalId -o tsv)

# Assign Storage Blob Data Contributor role
az role assignment create \
  --assignee $PRINCIPAL_ID \
  --role "Storage Blob Data Contributor" \
  --scope /subscriptions/YOUR_SUBSCRIPTION_ID/resourceGroups/YOUR_RESOURCE_GROUP/providers/Microsoft.Storage/storageAccounts/YOUR_STORAGE_ACCOUNT
```

### 3. Configure Easy Auth and Client Secret

#### Enable Easy Auth (Azure Portal)

1. Go to your Function App in Azure Portal
2. Click **Authentication** in the left menu
3. Click **Add identity provider**
4. Select **Microsoft**
5. Configure:
   - **App registration type**: Create new app registration (or select existing)
   - **Name**: Give it a meaningful name
   - **Supported account types**: Current tenant - Single tenant
   - **Restrict access**: Require authentication
   - **Unauthenticated requests**: HTTP 302 Found redirect
6. Click **Add**
7. **Copy the Client ID** - you'll need this for the next steps

#### Create Client Secret

1. Go to [Azure Portal](https://portal.azure.com)
2. Navigate to **Azure Active Directory** → **App registrations**
3. Find your Easy Auth app registration (use the Client ID from above)
4. Click **Certificates & secrets** in the left menu
5. Click **+ New client secret**
6. Add a description (e.g., "Function App Secret")
7. Set expiration (e.g., 24 months)
8. Click **Add**
9. **Copy the secret Value** immediately (you can't see it again!)

#### Add Client Secret to Function App

1. Go back to your Function App
2. Click **Configuration** → **Application settings**
3. Click **+ New application setting**:
   - **Name**: `ClientSecret`
   - **Value**: Paste the secret you copied
4. Click **OK** and **Save**

#### Add Dataverse API Permission

1. Go back to your App Registration
2. Click **API permissions** in the left menu
3. Click **+ Add a permission**
4. Select **Dynamics CRM**
5. Select **Delegated permissions**
6. Check **user_impersonation**
7. Click **Add permissions**
8. Click **Grant admin consent for [Your Tenant]** (admin only)
9. Confirm by clicking **Yes**

### 4. Create Dataverse Application User

1. Go to [Power Platform Admin Center](https://admin.powerplatform.microsoft.com)
2. Select your environment
3. Navigate to **Settings** → **Users + permissions** → **Application users**
4. Click **+ New app user**
5. Click **+ Add an app**
6. Search for and select your Easy Auth app registration
7. Click **Add**
8. Select a **Business unit**
9. Click **+ Add security roles** and assign appropriate roles:
   - For testing: **System Administrator**
   - For production: Assign minimal required roles
10. Click **Create**

### 5. Deploy the Function

#### Option A: Visual Studio / VS Code

1. Right-click the project in Solution Explorer
2. Select **Publish**
3. Follow the wizard to publish to your Function App

#### Option B: Command Line

```powershell
cd KOFC.Azure.Functions.GetSaasBlobUrl
dotnet publish -c Release
cd publish
func azure functionapp publish YOUR_FUNCTION_APP
```

#### Option C: Azure Portal (Upload ZIP)

1. Build the project:
   ```powershell
   cd KOFC.Azure.Functions.GetSaasBlobUrl
   dotnet publish -c Release -o ./publish
   cd publish
   # Create a zip of all files
   ```
2. Go to your Function App in Azure Portal
3. Click **Advanced Tools** → **Go**
4. In Kudu, click **Tools** → **Zip Push Deploy**
5. Drag and drop your ZIP file

## 📖 Usage

### API Endpoint

```
GET /api/GetSaasBlobUrl
  ?path={blobPath}
  &entityId={entityId}
  &entityName={entityName}
```

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `path` | string | Yes | Path to blob in container (e.g., "folder/file.xlsx") |
| `entityId` | guid | Yes | Dataverse entity record GUID |
| `entityName` | string | No | Entity name (defaults to `DataverseEntityName` setting) |

### Example Request

```
https://yourapp.azurewebsites.net/api/GetSaasBlobUrl
  ?path=data/report.xlsx
  &entityId=18afe4dc-aebd-f011-bbd3-000d3a4d5cd1
  &entityName=chit_apptrackers
```

### Example Response

```json
{
  "sasUrl": "https://yourstorage.blob.core.windows.net/container/data/report.xlsx?sv=2023-11-03&se=...&sig=..."
}
```

### cURL Example

```bash
curl -X GET "https://yourapp.azurewebsites.net/api/GetSaasBlobUrl?path=data/report.xlsx&entityId=18afe4dc-aebd-f011-bbd3-000d3a4d5cd1&entityName=chit_apptrackers" \
  -H "Accept: application/json"
```

## 🔧 Local Development

### Setup

1. **Login to Azure CLI** (for Managed Identity simulation):
   ```bash
   az login
   ```

2. **Configure local settings** (`local.settings.json`):
   ```json
   {
     "IsEncrypted": false,
     "Values": {
       "AzureWebJobsStorage": "UseDevelopmentStorage=true",
       "FUNCTIONS_WORKER_RUNTIME": "dotnet-isolated",
       "BlobStorageAccountName": "yourstorageaccount",
       "BlobContainerName": "your-container",
       "DataverseUrl": "https://yourorg.crm.dynamics.com",
       "DataverseEntityName": "contacts",
       "ClientSecret": "your-client-secret",
       "TenantId": "your-tenant-id"
     }
   }
   ```

3. **Run the function**:
   ```bash
   cd KOFC.Azure.Functions.GetSaasBlobUrl
   func start
   ```

### Local Testing (Bypass Easy Auth)

Use the `GetLocalSaasBlobUrl` endpoint for local testing:

```
http://localhost:7071/api/GetLocalSaasBlobUrl
  ?path=data/file.xlsx
  &entityId=18afe4dc-aebd-f011-bbd3-000d3a4d5cd1
```

## 🔐 Authentication Flow

### 1. User Authentication (Easy Auth)
- User accesses the function URL
- Redirected to Azure AD for authentication
- Easy Auth validates user and injects headers

### 2. Dataverse Token Acquisition
The function attempts to get a Dataverse token in this order:

1. **Check current token audience** - If already for Dataverse, use it
2. **Try refresh token** - If available, exchange for Dataverse token (user delegation)
3. **Fallback to service principal** - Use client credentials (app-only authentication)

### 3. Dataverse Validation
- Makes API call to Dataverse to verify entity exists
- Uses service principal token (app-only authentication)
- Access controlled by Application User security roles

### 4. SAS URL Generation
- Uses Managed Identity to generate user delegation SAS token
- No connection strings required
- Inherits permissions from Managed Identity's role assignment

## 📁 Project Structure

```
proxyBlobFunction/
├── KOFC.Azure.Functions.GetSaasBlobUrl/
│   ├── GetSaasBlobUrl.cs              # Main function (with Easy Auth)
│   ├── GetLocalSaasBlobUrl.cs         # Local testing function
│   ├── Program.cs                     # Dependency injection setup
│   ├── Services/
│   │   ├── TokenService.cs            # Dataverse token acquisition
│   │   ├── DataverseService.cs        # Dataverse API client
│   │   ├── BlobService.cs             # Blob storage SAS generation
│   │   └── PrincipalService.cs        # Easy Auth principal decoding
│   └── Models/
│       └── UserPrincipal.cs           # User principal model
├── KOFC.Azure.Functions.GetSaasBlobUrl.Tests/
│   └── ...                            # Unit tests
├── build-and-deploy.ps1               # Deployment script
├── deploy-with-easy-auth.ps1          # Full infrastructure deployment
├── fix-dataverse-unauthorized.ps1     # Troubleshooting script
└── README.md                          # This file
```

## 🛠️ Configuration Reference

### Required App Settings

Configure these in your Function App (Configuration → Application settings):

| Setting | Description | How to Find | Required |
|---------|-------------|-------------|----------|
| `BlobStorageAccountName` | Storage account name | Your storage account name (no URL) | Yes |
| `BlobContainerName` | Blob container name | Container where files are stored | Yes |
| `DataverseUrl` | Dataverse environment URL | Format: `https://orgXXX.crm.dynamics.com` | Yes |
| `DataverseEntityName` | Default entity name | Usually `contacts` or custom entity | Yes |
| `ClientSecret` | App registration client secret | From App Registration → Certificates & secrets | Yes |
| `TenantId` | Azure AD tenant ID | From Azure AD → Overview page | Yes |

### How to Find Your Dataverse URL

1. Go to [Power Platform Admin Center](https://admin.powerplatform.microsoft.com)
2. Select your environment
3. The **Environment URL** is your `DataverseUrl`
4. Format: `https://orgabc123.crm.dynamics.com`

### How to Find Your Tenant ID

**Option 1: Azure Portal**
1. Go to **Azure Active Directory**
2. Click **Overview**
3. Copy the **Tenant ID**

**Option 2: From Function App**
1. Go to your Function App
2. Click **Authentication**
3. Click your identity provider
4. Look for **Issuer URL**: `https://login.microsoftonline.com/{TenantId}/v2.0`

### Azure Resources Checklist

✅ **Function App**
- Easy Auth enabled with Microsoft identity provider
- System-assigned Managed Identity enabled
- All app settings configured

✅ **Storage Account**
- Function App's Managed Identity has "Storage Blob Data Contributor" role
- Container exists with correct name

✅ **App Registration**
- Client secret created and added to Function App settings
- Dynamics CRM `user_impersonation` permission granted
- Admin consent granted for the permission

✅ **Dataverse**
- Application User created for the App Registration
- Security roles assigned to Application User
- Environment URL matches `DataverseUrl` setting

## 🔍 Troubleshooting

### "Unauthorized" from Dataverse

**Possible causes:**
- Application User not created in Dataverse
- Security roles not assigned to Application User
- `ClientSecret` or `TenantId` incorrect/missing

**Fix:**
```powershell
.\fix-dataverse-unauthorized.ps1 `
  -FunctionAppName "YOUR_FUNCTION_APP" `
  -ResourceGroupName "YOUR_RESOURCE_GROUP"
```

### Blob Storage Access Errors

**Possible causes:**
- Managed Identity not enabled
- Storage Blob Data Contributor role not assigned
- Wrong `BlobStorageAccountName`

**Fix:**
```bash
# Verify managed identity is enabled
az functionapp identity show --name YOUR_FUNCTION_APP --resource-group YOUR_RESOURCE_GROUP

# Verify role assignment
az role assignment list --assignee PRINCIPAL_ID --scope /subscriptions/.../storageAccounts/YOUR_STORAGE
```

### Easy Auth Not Working

**Possible causes:**
- Easy Auth not properly configured
- Token Store not enabled
- Cached tokens in browser

**Fix:**
- Test in incognito/private window
- Verify Easy Auth is enabled in Azure Portal
- Check Token Store is enabled

### Local Development: "Could not extract tenant ID"

**Cause**: Not logged into Azure CLI

**Fix:**
```bash
az login
az account show  # Verify you're logged in
```

## 📜 Scripts

### `build-and-deploy.ps1`
Builds and deploys the function code.

```powershell
.\build-and-deploy.ps1 -FunctionAppName "YOUR_FUNCTION_APP" -SkipInfrastructure
```

### `deploy-with-easy-auth.ps1`
Full infrastructure deployment including Easy Auth configuration.

```powershell
.\deploy-with-easy-auth.ps1 `
  -FunctionAppName "YOUR_FUNCTION_APP" `
  -ResourceGroupName "YOUR_RESOURCE_GROUP" `
  -Location "eastus" `
  -StorageAccountName "yourstorage" `
  -DataverseUrl "https://yourorg.crm.dynamics.com" `
  -BlobContainerName "your-container" `
  -BlobStorageAccountName "blobstorage"
```

### `fix-dataverse-unauthorized.ps1`
Troubleshoots and fixes Dataverse authentication issues.

```powershell
.\fix-dataverse-unauthorized.ps1 `
  -FunctionAppName "YOUR_FUNCTION_APP" `
  -ResourceGroupName "YOUR_RESOURCE_GROUP"
```

## 🧪 Testing

### Run Unit Tests

```bash
cd KOFC.Azure.Functions.GetSaasBlobUrl.Tests
dotnet test
```

### Test Locally

```bash
cd KOFC.Azure.Functions.GetSaasBlobUrl
func start
```

Then call:
```
http://localhost:7071/api/GetLocalSaasBlobUrl?path=test.xlsx&entityId=<guid>
```

### Test in Azure

```bash
curl "https://yourapp.azurewebsites.net/api/GetSaasBlobUrl?path=test.xlsx&entityId=<guid>&entityName=contacts"
```

## 📝 Notes

### Service Principal vs User Delegation

This function uses **service principal authentication** for Dataverse access:

✅ **Advantages:**
- Reliable and works in all scenarios
- Simple configuration
- Well-tested and production-ready

⚠️ **Trade-offs:**
- Uses app-only authentication (not per-user)
- Security controlled by Application User roles in Dataverse
- User identity validated via Easy Auth but Dataverse calls use service principal

**Why not user delegation?**
- Easy Auth doesn't support requesting tokens for arbitrary resources (like Dataverse)
- OBO (On-Behalf-Of) flow failed due to token signature validation issues
- Refresh tokens not available in Easy Auth headers

### Dataverse Entity Pluralization

The function automatically handles entity name pluralization for API calls:
- `contact` → API: `contacts`, ID field: `contactid`
- `chit_apptracker` → API: `chit_apptrackers`, ID field: `chit_apptrackerid`

## 📄 License

[Your License Here]

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📞 Support

For issues or questions:
- Check the Troubleshooting section above
- Review Azure Function logs in Application Insights
- Run `fix-dataverse-unauthorized.ps1` for Dataverse issues

---

**Built with:**
- .NET 8.0 Isolated Worker
- Azure Functions v4
- Azure Identity SDK
- Azure Storage SDK
