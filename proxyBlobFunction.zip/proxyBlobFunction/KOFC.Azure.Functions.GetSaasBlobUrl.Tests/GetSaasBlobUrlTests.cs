using System.Net;
using System.Text;
using System.Text.Json;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using KOFC.Azure.Functions.GetSaasBlobUrl.Models;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using KOFC.Azure.Functions.GetSaasBlobUrl.Tests.TestHelpers;
using Moq;
using Xunit;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests;

public class GetSaasBlobUrlTests
{
    private readonly Mock<ILogger<GetSaasBlobUrl>> _mockLogger;
    private readonly Mock<IPrincipalService> _mockPrincipalService;
    private readonly Mock<IDataverseService> _mockDataverseService;
    private readonly Mock<IBlobService> _mockBlobService;
    private readonly Mock<ITokenService> _mockTokenService;
    private readonly Mock<IConfiguration> _mockConfiguration;

    public GetSaasBlobUrlTests()
    {
        _mockLogger = new Mock<ILogger<GetSaasBlobUrl>>();
        _mockPrincipalService = new Mock<IPrincipalService>();
        _mockDataverseService = new Mock<IDataverseService>();
        _mockBlobService = new Mock<IBlobService>();
        _mockTokenService = new Mock<ITokenService>();
        _mockConfiguration = new Mock<IConfiguration>();

        // Setup default configuration values
        _mockConfiguration.Setup(c => c["DataverseUrl"]).Returns("https://test.crm.dynamics.com");
        _mockConfiguration.Setup(c => c["DataverseEntityName"]).Returns("contacts");
        _mockConfiguration.Setup(c => c["BlobContainerName"]).Returns("test-container");
        
        // Setup default token service behavior - just return the same token
        _mockTokenService.Setup(s => s.GetDataverseTokenAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync((string token, string? refreshToken, string url) => token);
    }

    [Fact]
    public async Task Run_MissingAccessToken_ReturnsUnauthorized()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object,
            _mockTokenService.Object);

        var request = CreateMockHttpRequestData();
        // Don't add access token header

        // Act
        var response = await function.Run(request);

        // Assert
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Run_MissingPrincipalHeader_ReturnsUnauthorized()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object,
            _mockTokenService.Object);

        var request = CreateMockHttpRequestData();
        AddHeader(request, "X-MS-TOKEN-AAD-ACCESS-TOKEN", "test-token");
        // Don't add principal header

        // Act
        var response = await function.Run(request);

        // Assert
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Run_InvalidUserPrincipal_ReturnsUnauthorized()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object,
            _mockTokenService.Object);

        var request = CreateMockHttpRequestData();
        AddHeader(request, "X-MS-TOKEN-AAD-ACCESS-TOKEN", "test-token");
        AddHeader(request, "X-MS-CLIENT-PRINCIPAL", "invalid-principal");

        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns((UserPrincipal?)null);

        // Act
        var response = await function.Run(request);

        // Assert
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Run_MissingPathParameter_ReturnsBadRequest()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object,
            _mockTokenService.Object);

        var request = CreateMockHttpRequestData("?entityId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(request);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        // Act
        var response = await function.Run(request);

        // Assert
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Run_MissingEntityIdParameter_ReturnsBadRequest()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object,
            _mockTokenService.Object);

        var request = CreateMockHttpRequestData("?path=D:\\test\\file.txt");
        SetupAuthHeaders(request);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        // Act
        var response = await function.Run(request);

        // Assert
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Run_UserHasNoAccess_ReturnsForbidden()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object,
            _mockTokenService.Object);

        var entityId = "12345678-1234-1234-1234-123456789012";
        var request = CreateMockHttpRequestData(
            $"?path=D:\\test\\file.txt&entityId={entityId}");
        SetupAuthHeaders(request);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        _mockDataverseService.Setup(s => s.ValidateEntityAccessAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(false);

        // Act
        var response = await function.Run(request);

        // Assert
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
        
        // Verify the response contains a helpful error message
        response.Body.Seek(0, SeekOrigin.Begin);
        var responseBody = await new StreamReader(response.Body).ReadToEndAsync();
        Assert.Contains("Access Denied", responseBody);
        Assert.Contains(entityId, responseBody);
        Assert.Contains("contact your administrator", responseBody);
    }

    [Fact]
    public async Task Run_BlobNotFound_ReturnsNotFound()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object,
            _mockTokenService.Object);

        var request = CreateMockHttpRequestData(
            "?path=D:\\test\\file.txt&entityId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(request);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        _mockDataverseService.Setup(s => s.ValidateEntityAccessAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns("test/file.txt");

        _mockBlobService.Setup(s => s.GenerateSasUrlAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(new InvalidOperationException("Blob not found"));

        // Act
        var response = await function.Run(request);

        // Assert
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Run_SuccessfulRequest_ReturnsRedirect()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object,
            _mockTokenService.Object);

        var request = CreateMockHttpRequestData(
            "?path=D:\\KOFCExt%20Extractions\\test\\file.txt&entityId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(request);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        _mockDataverseService.Setup(s => s.ValidateEntityAccessAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns("test/file.txt");

        var expectedSasUrl = "https://storage.blob.core.windows.net/container/test/file.txt?sv=2021-06-08&sig=...";
        _mockBlobService.Setup(s => s.GenerateSasUrlAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(expectedSasUrl);

        // Act
        var response = await function.Run(request);

        // Assert
        Assert.Equal(HttpStatusCode.Redirect, response.StatusCode);
        Assert.True(response.Headers.TryGetValues("Location", out var locationValues));
        Assert.Equal(expectedSasUrl, locationValues.FirstOrDefault());
    }

    [Fact]
    public async Task Run_NormalizedPathIsEmpty_ReturnsBadRequest()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object,
            _mockTokenService.Object);

        var request = CreateMockHttpRequestData(
            "?path=D:\\&entityId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(request);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        _mockDataverseService.Setup(s => s.ValidateEntityAccessAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns(string.Empty);

        // Act
        var response = await function.Run(request);

        // Assert
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Run_DataverseUrlMissing_ReturnsInternalServerError()
    {
        // Arrange
        _mockConfiguration.Setup(c => c["DataverseUrl"]).Returns((string?)null);

        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object,
            _mockTokenService.Object);

        var request = CreateMockHttpRequestData(
            "?path=D:\\test\\file.txt&entityId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(request);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        // Act
        var response = await function.Run(request);

        // Assert
        Assert.Equal(HttpStatusCode.InternalServerError, response.StatusCode);
    }

    // Helper methods
    private HttpRequestData CreateMockHttpRequestData(string queryString = "")
    {
        var functionContext = Mock.Of<FunctionContext>();
        var headers = new HttpHeadersCollection();
        var url = new Uri($"https://localhost:7071/api/GetSaasBlobUrl{queryString}");
        
        return new TestHttpRequestData(functionContext, url, headers);
    }

    private void AddHeader(HttpRequestData request, string name, string value)
    {
        request.Headers.Add(name, new[] { value });
    }

    private void SetupAuthHeaders(HttpRequestData request)
    {
        AddHeader(request, "X-MS-TOKEN-AAD-ACCESS-TOKEN", "test-access-token");
        
        var principal = CreateTestUserPrincipal();
        var json = JsonSerializer.Serialize(principal);
        var base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
        
        AddHeader(request, "X-MS-CLIENT-PRINCIPAL", base64);
        AddHeader(request, "X-MS-CLIENT-PRINCIPAL-NAME", "test@example.com");
        AddHeader(request, "X-MS-CLIENT-PRINCIPAL-ID", "12345678-1234-1234-1234-123456789012");
    }

    private UserPrincipal CreateTestUserPrincipal()
    {
        return new UserPrincipal
        {
            AuthType = "aad",
            Claims = new List<Claim>
            {
                new Claim { Type = "name", Value = "Test User" },
                new Claim { Type = "oid", Value = "12345678-1234-1234-1234-123456789012" }
            }
        };
    }
}

