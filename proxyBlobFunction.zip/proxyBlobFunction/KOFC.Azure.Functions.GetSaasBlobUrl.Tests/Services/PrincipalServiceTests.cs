using System.Text;
using System.Text.Json;
using KOFC.Azure.Functions.GetSaasBlobUrl.Models;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests.Services;

public class PrincipalServiceTests
{
    [Fact]
    public void DecodeUserPrincipal_ValidBase64_ReturnsUserPrincipal()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<PrincipalService>>();
        var principalService = new PrincipalService(mockLogger.Object);

        var principal = new UserPrincipal
        {
            AuthType = "aad",
            Claims = new List<Claim>
            {
                new Claim { Type = "name", Value = "Test User" },
                new Claim { Type = "oid", Value = "12345678-1234-1234-1234-123456789012" }
            }
        };

        var json = JsonSerializer.Serialize(principal);
        var base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));

        // Act
        var result = principalService.DecodeUserPrincipal(base64);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("aad", result.AuthType);
        Assert.Equal("Test User", result.Identity.Name);
        Assert.Equal(2, result.Claims?.Count);
    }

    [Fact]
    public void DecodeUserPrincipal_NullInput_ReturnsNull()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<PrincipalService>>();
        var principalService = new PrincipalService(mockLogger.Object);

        // Act
        var result = principalService.DecodeUserPrincipal(null!);

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void DecodeUserPrincipal_EmptyInput_ReturnsNull()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<PrincipalService>>();
        var principalService = new PrincipalService(mockLogger.Object);

        // Act
        var result = principalService.DecodeUserPrincipal("");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void DecodeUserPrincipal_WhitespaceInput_ReturnsNull()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<PrincipalService>>();
        var principalService = new PrincipalService(mockLogger.Object);

        // Act
        var result = principalService.DecodeUserPrincipal("   ");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void DecodeUserPrincipal_InvalidBase64_ReturnsNull()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<PrincipalService>>();
        var principalService = new PrincipalService(mockLogger.Object);

        // Act
        var result = principalService.DecodeUserPrincipal("not-valid-base64!");

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void DecodeUserPrincipal_InvalidJson_ReturnsNull()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<PrincipalService>>();
        var principalService = new PrincipalService(mockLogger.Object);

        var invalidJson = "{ this is not valid json }";
        var base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(invalidJson));

        // Act
        var result = principalService.DecodeUserPrincipal(base64);

        // Assert
        Assert.Null(result);
    }

    [Fact]
    public void DecodeUserPrincipal_EmptyClaimsList_ReturnsUserPrincipalWithNullIdentity()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<PrincipalService>>();
        var principalService = new PrincipalService(mockLogger.Object);

        var principal = new UserPrincipal
        {
            AuthType = "aad",
            Claims = new List<Claim>()
        };

        var json = JsonSerializer.Serialize(principal);
        var base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));

        // Act
        var result = principalService.DecodeUserPrincipal(base64);

        // Assert
        Assert.NotNull(result);
        Assert.Null(result.Identity.Name);
    }

    [Fact]
    public void DecodeUserPrincipal_MultipleNameClaims_ReturnsFirstName()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<PrincipalService>>();
        var principalService = new PrincipalService(mockLogger.Object);

        var principal = new UserPrincipal
        {
            AuthType = "aad",
            Claims = new List<Claim>
            {
                new Claim { Type = "name", Value = "First User" },
                new Claim { Type = "name", Value = "Second User" },
                new Claim { Type = "oid", Value = "12345678-1234-1234-1234-123456789012" }
            }
        };

        var json = JsonSerializer.Serialize(principal);
        var base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));

        // Act
        var result = principalService.DecodeUserPrincipal(base64);

        // Assert
        Assert.NotNull(result);
        Assert.Equal("First User", result.Identity.Name);
    }
}

