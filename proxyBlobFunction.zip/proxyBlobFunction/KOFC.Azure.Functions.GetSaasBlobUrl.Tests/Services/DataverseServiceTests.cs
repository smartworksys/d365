using System.Net;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using Xunit;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests.Services;

public class DataverseServiceTests
{
    [Fact]
    public async Task ValidateEntityAccessAsync_ValidAccess_ReturnsTrue()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<DataverseService>>();
        var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
        
        mockHttpMessageHandler
            .Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
                Content = new StringContent("{\"contactid\":\"12345678-1234-1234-1234-123456789012\"}")
            });

        var httpClient = new HttpClient(mockHttpMessageHandler.Object);
        var dataverseService = new DataverseService(mockLogger.Object, httpClient);

        // Act
        var result = await dataverseService.ValidateEntityAccessAsync(
            "12345678-1234-1234-1234-123456789012",
            "contacts",
            "test-token",
            "https://test.crm.dynamics.com");

        // Assert
        Assert.True(result);
    }

    [Fact]
    public async Task ValidateEntityAccessAsync_Forbidden_ReturnsFalse()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<DataverseService>>();
        var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
        
        mockHttpMessageHandler
            .Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.Forbidden
            });

        var httpClient = new HttpClient(mockHttpMessageHandler.Object);
        var dataverseService = new DataverseService(mockLogger.Object, httpClient);

        // Act
        var result = await dataverseService.ValidateEntityAccessAsync(
            "12345678-1234-1234-1234-123456789012",
            "contacts",
            "test-token",
            "https://test.crm.dynamics.com");

        // Assert
        Assert.False(result);
    }

    [Fact]
    public async Task ValidateEntityAccessAsync_NotFound_ReturnsFalse()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<DataverseService>>();
        var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
        
        mockHttpMessageHandler
            .Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ReturnsAsync(new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.NotFound
            });

        var httpClient = new HttpClient(mockHttpMessageHandler.Object);
        var dataverseService = new DataverseService(mockLogger.Object, httpClient);

        // Act
        var result = await dataverseService.ValidateEntityAccessAsync(
            "12345678-1234-1234-1234-123456789012",
            "contacts",
            "test-token",
            "https://test.crm.dynamics.com");

        // Assert
        Assert.False(result);
    }

    [Theory]
    [InlineData(null, "contacts", "token", "url")]
    [InlineData("", "contacts", "token", "url")]
    [InlineData("   ", "contacts", "token", "url")]
    [InlineData("entityId", null, "token", "url")]
    [InlineData("entityId", "", "token", "url")]
    [InlineData("entityId", "   ", "token", "url")]
    [InlineData("entityId", "contacts", null, "url")]
    [InlineData("entityId", "contacts", "", "url")]
    [InlineData("entityId", "contacts", "   ", "url")]
    [InlineData("entityId", "contacts", "token", null)]
    [InlineData("entityId", "contacts", "token", "")]
    [InlineData("entityId", "contacts", "token", "   ")]
    public async Task ValidateEntityAccessAsync_InvalidParameters_ReturnsFalse(
        string entityId,
        string entityName,
        string accessToken, 
        string dataverseUrl)
    {
        // Arrange
        var mockLogger = new Mock<ILogger<DataverseService>>();
        var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
        var httpClient = new HttpClient(mockHttpMessageHandler.Object);
        var dataverseService = new DataverseService(mockLogger.Object, httpClient);

        // Act
        var result = await dataverseService.ValidateEntityAccessAsync(entityId, entityName, accessToken, dataverseUrl);

        // Assert
        Assert.False(result);
    }

    [Fact]
    public async Task ValidateEntityAccessAsync_InvalidGuidFormat_ReturnsFalse()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<DataverseService>>();
        var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
        var httpClient = new HttpClient(mockHttpMessageHandler.Object);
        var dataverseService = new DataverseService(mockLogger.Object, httpClient);

        // Act
        var result = await dataverseService.ValidateEntityAccessAsync(
            "not-a-valid-guid",
            "contacts",
            "test-token",
            "https://test.crm.dynamics.com");

        // Assert
        Assert.False(result);
    }

    [Fact]
    public async Task ValidateEntityAccessAsync_HttpException_ReturnsFalse()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<DataverseService>>();
        var mockHttpMessageHandler = new Mock<HttpMessageHandler>();
        
        mockHttpMessageHandler
            .Protected()
            .Setup<Task<HttpResponseMessage>>(
                "SendAsync",
                ItExpr.IsAny<HttpRequestMessage>(),
                ItExpr.IsAny<CancellationToken>())
            .ThrowsAsync(new HttpRequestException("Network error"));

        var httpClient = new HttpClient(mockHttpMessageHandler.Object);
        var dataverseService = new DataverseService(mockLogger.Object, httpClient);

        // Act
        var result = await dataverseService.ValidateEntityAccessAsync(
            "12345678-1234-1234-1234-123456789012",
            "contacts",
            "test-token",
            "https://test.crm.dynamics.com");

        // Assert
        Assert.False(result);
    }
}

