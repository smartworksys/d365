"""Generate end-to-end design Word document for KOFC EApp SSO Function App."""

from datetime import date
from pathlib import Path

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


OUTPUT = Path(__file__).parent / "KOFC-EApp-SSO-FunctionApp-Design.docx"


def set_document_styles(doc: Document) -> None:
    style = doc.styles["Normal"]
    font = style.font
    font.name = "Calibri"
    font.size = Pt(11)


def add_title_page(doc: Document) -> None:
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run("KOFC Agent Portal\nEApp SSO Function App\n\nEnd-to-End Design Document")
    run.bold = True
    run.font.size = Pt(24)
    run.font.color.rgb = RGBColor(0x1F, 0x4E, 0x79)

    doc.add_paragraph()
    meta = doc.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    meta.add_run(
        f"Version: 1.1\n"
        f"Date: {date.today().strftime('%B %d, %Y')}\n"
        f"Solution: KOFC-FA-AgentPortal-UserProfile\n"
        f"Function: getSOReqForEappSSO"
    )
    doc.add_page_break()


def add_heading(doc: Document, text: str, level: int = 1) -> None:
    doc.add_heading(text, level=level)


def add_para(doc: Document, text: str, bold: bool = False) -> None:
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.bold = bold


def add_bullets(doc: Document, items: list[str]) -> None:
    for item in items:
        doc.add_paragraph(item, style="List Bullet")


def add_numbered(doc: Document, items: list[str]) -> None:
    for item in items:
        doc.add_paragraph(item, style="List Number")


def add_table(doc: Document, headers: list[str], rows: list[list[str]]) -> None:
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    hdr_cells = table.rows[0].cells
    for i, header in enumerate(headers):
        hdr_cells[i].text = header
        for paragraph in hdr_cells[i].paragraphs:
            for run in paragraph.runs:
                run.bold = True
    for row in rows:
        row_cells = table.add_row().cells
        for i, value in enumerate(row):
            row_cells[i].text = value
    doc.add_paragraph()


def add_code_block(doc: Document, text: str) -> None:
    p = doc.add_paragraph()
    run = p.add_run(text)
    run.font.name = "Consolas"
    run.font.size = Pt(9)
    p.paragraph_format.left_indent = Inches(0.25)
    shading = OxmlElement("w:shd")
    shading.set(qn("w:fill"), "F2F2F2")
    p._p.get_or_add_pPr().append(shading)


def build_document() -> Document:
    doc = Document()
    set_document_styles(doc)
    add_title_page(doc)

    # 1. Executive Summary
    add_heading(doc, "1. Executive Summary")
    add_para(
        doc,
        "This document describes the end-to-end design for the KOFC Agent Portal EApp SSO "
        "Azure Function App. The solution exposes an HTTP API that Boomi (or other integration "
        "clients) calls to retrieve agent profile and optional client/opportunity data from "
        "Microsoft Dataverse for Electronic Application (EApp) single sign-on workflows."
    )
    add_para(doc, "Key design characteristics:", bold=True)
    add_bullets(doc, [
        "Two-token model: browser delegated token (SPA to Boomi) and Boomi client-credentials token (Boomi to Function with app roles).",
        "Dynamics 365 Opportunity button dynamically loads reusable auth client (kofc_authclient.js, namespace KOFC.Auth).",
        "Auth configuration supplied at runtime via Dataverse environment variables and KOFC.Auth.configure().",
        "Inbound authentication via Azure App Service Easy Auth; app-role authorization (Contact.Read, Opportunity.Read).",
        "Outbound authentication to Dataverse via Managed Identity and DefaultAzureCredential.",
        "Per-user Dataverse security enforcement using CallerId impersonation.",
        "Scoped ServiceClient per function invocation to support safe concurrent impersonation.",
        "Base64-encoded JSON response for downstream EApp consumption.",
    ])

    # 2. Purpose and Scope
    add_heading(doc, "2. Purpose and Scope")
    add_heading(doc, "2.1 Purpose", level=2)
    add_para(
        doc,
        "Provide a secure, integration-friendly API that returns agent role and identity "
        "attributes, and optionally linked client data, sourced from Dataverse for EApp SSO."
    )
    add_heading(doc, "2.2 In Scope", level=2)
    add_bullets(doc, [
        "HTTP GET/POST endpoint: getSOReqForEappSSO",
        "Easy Auth validation of integration caller (Boomi)",
        "Dataverse queries for systemuser, opportunity, and contact",
        "Managed Identity token acquisition",
        "CallerId impersonation for per-user CRM security",
        "Azure Function App infrastructure (ARM template)",
        "Application Insights telemetry",
    ])
    add_heading(doc, "2.3 Out of Scope", level=2)
    add_bullets(doc, [
        "Boomi process configuration (external to this repository)",
        "Easy Auth portal configuration steps (manual Azure portal setup)",
        "On-behalf-of (OBO) token exchange using Azure AD user_impersonation",
        "Direct pass-through of Boomi token to Dataverse",
        "Write/update operations to Dataverse",
    ])

    # 3. Dynamics 365 Client Integration
    add_heading(doc, "3. Dynamics 365 Client Integration")
    add_heading(doc, "3.1 Overview", level=2)
    add_para(
        doc,
        "The EApp button on the Opportunity form uses a reusable, modular JavaScript auth client "
        "(kofc_authclient.js, namespace KOFC.Auth) loaded on demand from the form script. "
        "Sensitive configuration (tenantId, clientId, apiAppId, apiKey) is read from Dataverse "
        "environment variables; the library itself contains no hard-coded credentials."
    )

    add_heading(doc, "3.2 Web Resources", level=2)
    add_table(doc,
        ["Name (web resource)", "Purpose"],
        [
            ["kofc_authclient.js", "Reusable KOFC.Auth library: MSAL token acquisition, Boomi call, open EApp"],
            ["kofc_authcallback.html", "Generic MSAL redirect URI page; completes sign-in and auto-finishes pending actions"],
            ["kofc_msalbrowsermin", "MSAL.js library (org-hosted; no extension in D365 Name)"],
            ["kofc_Opportunity", "Form script: button chain, env-var config, dynamic loader"],
        ])

    add_heading(doc, "3.3 Environment Variables", level=2)
    add_table(doc,
        ["Schema name", "Purpose"],
        [
            ["kofc_EappURL", "EApp base URL (appended with ?soreq=<base64>)"],
            ["kofc_EappIntfunctionURL", "Boomi REST endpoint"],
            ["kofc_EappTenantId", "Entra tenant (directory) ID"],
            ["kofc_EappClientId", "SPA app registration client ID"],
            ["kofc_EappApiAppId", "Function API app ID (scope api://<id>/access_as_user)"],
            ["kofc_EappApiKey", "Boomi x-api-key for API gateway"],
        ])

    add_heading(doc, "3.4 Public API (KOFC.Auth)", level=2)
    add_table(doc,
        ["Method", "Description"],
        [
            ["configure(options)", "Set/override config at runtime (required before use)"],
            ["openEapp(userId, oppId, eappUrl)", "Token -> Boomi -> open eappUrl + ?soreq=<base64> in new tab"],
            ["callBoomiRaw(userId, oppId)", "Token -> Boomi -> returns raw Base64 response body"],
            ["getAccessToken()", "Returns delegated user access token only"],
            ["clearCache()", "Clears MSAL + pending localStorage (re-test first-time flow)"],
        ])

    add_heading(doc, "3.5 Token Acquisition Flow", level=2)
    add_numbered(doc, [
        "acquireTokenSilent — MSAL cache (works after first sign-in; refresh token renews silently ~24h).",
        "ssoSilent — hidden iframe (only when cached account or loginHint available; skipped otherwise).",
        "acquireTokenRedirect — full-page redirect when allowRedirect is true (default).",
        "kofc_authcallback.html reads auth code via handleRedirectPromise, calls Boomi, opens EApp automatically.",
    ])
    add_para(
        doc,
        "First-time or daily renewal: user sees brief redirect through kofc_authcallback.html. "
        "Subsequent clicks same day: fully silent; EApp opens in a new tab."
    )

    add_heading(doc, "3.6 Entra SPA Redirect URI", level=2)
    add_para(doc, "Register under the SPA app registration (case-sensitive):")
    add_code_block(doc, "https://<org>.crm.dynamics.com/WebResources/kofc_authcallback.html")

    # 4. Solution Overview (Function App)
    add_heading(doc, "4. Solution Overview")
    add_para(
        doc,
        "The solution is a .NET 8 Azure Functions v4 isolated worker application deployed "
        "to Azure with system-assigned Managed Identity. Integration clients authenticate "
        "to the function using Easy Auth. The function then connects to Dataverse using its "
        "own Managed Identity and impersonates the requested Dataverse user to enforce "
        "native CRM record-level security."
    )
    add_table(doc,
        ["Component", "Technology", "Role"],
        [
            ["D365 Auth Client", "kofc_authclient.js (KOFC.Auth)", "Browser MSAL token + Boomi call from Opportunity button"],
            ["D365 Callback", "kofc_authcallback.html", "MSAL redirect URI; auto-completes pending EApp launch"],
            ["Function App", "Azure Functions v4 (.NET 8 isolated)", "Hosts HTTP API"],
            ["Integration Client", "Boomi (client credentials)", "Calls Function API with app-role token"],
            ["Inbound Auth", "Azure Easy Auth + app roles", "Validates caller token; Contact.Read / Opportunity.Read"],
            ["Outbound Auth", "Managed Identity + DefaultAzureCredential", "Acquires Dataverse token"],
            ["CRM", "Microsoft Dataverse", "Source of user, opportunity, contact data"],
            ["Telemetry", "Application Insights", "Logging and monitoring"],
            ["Secrets", "Azure Key Vault", "CRM_URL and legacy CRM secrets"],
        ])

    # 5. Architecture
    add_heading(doc, "5. Architecture")
    add_heading(doc, "5.1 High-Level Architecture", level=2)
    add_code_block(doc,
        "+-------------+     Bearer Token      +----------------------+\n"
        "|   Boomi     | --------------------> |  Azure Function App  |\n"
        "| Integration |                       |  (Easy Auth enabled) |\n"
        "+-------------+                       +----------+-----------+\n"
        "                                                  |\n"
        "                                     Validates caller identity\n"
        "                                                  |\n"
        "                                     Sets CallerId = userId\n"
        "                                                  |\n"
        "                       Managed Identity token  v\n"
        "                                      +----------------------+\n"
        "                                      | Microsoft Dataverse  |\n"
        "                                      | (CRM)                |\n"
        "                                      +----------------------+"
    )
    add_heading(doc, "5.2 Authentication Layers", level=2)
    add_para(
        doc,
        "The implementation uses two independent authentication layers. They are not "
        "connected via token exchange."
    )
    add_table(doc,
        ["Layer", "Direction", "Mechanism", "Identity", "Purpose"],
        [
            ["Layer 1", "Inbound", "Easy Auth + ClaimsPrincipal", "Boomi / integration principal", "Authorize API access"],
            ["Layer 2", "Outbound", "DefaultAzureCredential", "Function App Managed Identity", "Acquire Dataverse access token"],
            ["Impersonation", "Outbound", "ServiceClient.CallerId", "Dataverse systemuser (userId)", "Enforce per-user CRM security"],
        ])

    add_heading(doc, "5.3 Component Diagram", level=2)
    add_table(doc,
        ["Source File", "Component", "Responsibility"],
        [
            ["Program.cs", "DI Host", "Registers scoped ServiceClient per invocation"],
            ["DataverseServiceClientFactory.cs", "CRM Client Factory", "Creates ServiceClient with MI token callback"],
            ["EappSSO.cs", "HTTP Function", "Auth check, impersonation, FetchXML queries, response encoding"],
            ["EappConstants.cs", "Role Mapping", "Maps insurance role codes to EApp role flags"],
            ["SoReqData.cs", "Response DTO", "JSON structure returned to caller"],
            ["functionapp.json", "ARM Template", "Provisions Function App with system-assigned MI"],
        ])

    # 6. End-to-End Request Flow
    add_heading(doc, "6. End-to-End Request Flow")
    add_heading(doc, "6.1 Sequence of Operations", level=2)
    add_numbered(doc, [
        "D365 user clicks EApp button on Opportunity form.",
        "Form loads kofc_authclient.js and configures KOFC.Auth from environment variables.",
        "KOFC.Auth acquires delegated user token via MSAL (silent cache or redirect through kofc_authcallback.html).",
        "Browser calls Boomi with Bearer user token, x-api-key, userId, and oppID.",
        "Boomi acquires client-credentials token for Function App API (roles: Contact.Read, Opportunity.Read).",
        "Boomi sends HTTP GET or POST to the function endpoint with Bearer app token and parameters.",
        "Azure Easy Auth validates the token (signature, expiry, audience, issuer).",
        "Function checks IsAuthenticated() and app roles; returns 401/403 if not authorized.",
        "Function validates userId (required GUID) and optional oppID (GUID if provided).",
        "Function sets ServiceClient.CallerId to the Dataverse systemuserid.",
        "DefaultAzureCredential acquires a Dataverse-scoped token using Managed Identity.",
        "Function queries systemuser, maps role, optionally queries opportunity/contact.",
        "Function serializes SoReqData to JSON, Base64-encodes it, returns text/plain 200.",
        "Browser opens EApp URL with ?soreq=<base64> in a new tab.",
    ])

    add_heading(doc, "6.2 Detailed Flow Diagram", level=2)
    add_code_block(doc,
        "Boomi                    Easy Auth              Function App              Azure AD           Dataverse\n"
        "  |                          |                        |                      |                  |\n"
        "  |-- GET + Bearer token --->|                        |                      |                  |\n"
        "  |                          |-- validate token ----->|                      |                  |\n"
        "  |                          |                        |-- IsAuthenticated? ->|                  |\n"
        "  |                          |                        |                      |                  |\n"
        "  |                          |                        |-- CallerId = userId  |                  |\n"
        "  |                          |                        |-- GetToken (MI) ---->|                  |\n"
        "  |                          |                        |<----- access token --|                  |\n"
        "  |                          |                        |-- RetrieveMultiple --------------------->|\n"
        "  |                          |                        |<----- user/opp/contact data ------------|\n"
        "  |                          |                        |-- Base64(JSON) ------>|                  |\n"
        "  |<------------------------- response 200 -----------------------------------|                  |"
    )

    add_heading(doc, "6.3 Impersonation and Privilege Intersection", level=2)
    add_para(
        doc,
        "When CallerId is set, Dataverse evaluates privileges as the intersection of the "
        "application user (function app Managed Identity) and the impersonated user (userId). "
        "An action is allowed only if both identities possess the required privilege."
    )
    add_bullets(doc, [
        "Application user must have Act on Behalf of Another User (prvActOnBehalfOfAnotherUser).",
        "Application user must have underlying read privileges on queried entities.",
        "Impersonated user must also have read privileges on the records being accessed.",
        "If either identity lacks access, the query returns no data or a privilege fault (403).",
    ])

    # 7. API Specification
    add_heading(doc, "7. API Specification")
    add_heading(doc, "7.1 Endpoint", level=2)
    add_table(doc,
        ["Property", "Value"],
        [
            ["Function Name", "getSOReqForEappSSO"],
            ["HTTP Methods", "GET, POST"],
            ["Authorization Level", "Anonymous (platform auth via Easy Auth)"],
            ["Content-Type (Response)", "text/plain (Base64-encoded JSON)"],
        ])

    add_heading(doc, "7.2 Request Parameters", level=2)
    add_table(doc,
        ["Parameter", "Required", "Type", "Description"],
        [
            ["userId", "Yes", "GUID", "Dataverse systemuserid of the agent to impersonate"],
            ["oppID", "No", "GUID", "Opportunity ID; when provided, linked contact data is returned"],
        ])

    add_heading(doc, "7.3 Request Headers", level=2)
    add_table(doc,
        ["Header", "Set by", "Purpose"],
        [
            ["Authorization: Bearer", "Caller", "User token (D365 to Boomi) or app token (Boomi to Function)"],
            ["x-api-key", "D365 button", "Boomi API gateway authentication"],
        ])

    add_heading(doc, "7.4 Required App Roles (Boomi to Function)", level=2)
    add_table(doc,
        ["Condition", "Required role (roles claim)"],
        [
            ["Every call", "Contact.Read"],
            ["oppID provided", "Opportunity.Read (in addition)"],
        ])

    add_heading(doc, "7.5 Response Payload (decoded JSON)", level=2)
    add_table(doc,
        ["Field", "Type", "Source", "Description"],
        [
            ["reqAction", "string", "Constant", "Always 'EAPP'"],
            ["gmtStamp", "string", "Generated", "Timestamp yyyy-MM-dd.HH:mm:ss"],
            ["agentId", "string", "systemuser.kofc_agentid", "Agent identifier"],
            ["loginUserID", "string", "systemuser.kofc_user_ldap_id", "LDAP login ID"],
            ["clientId", "string", "contact.kofc_clientid", "Populated when oppID provided and accessible"],
            ["clientDob", "string", "contact.kofc_birthdate", "Format yyyy-MM-dd when available"],
            ["isFieldAgent", "bool", "Role mapping", "True for KC20"],
            ["isGeneralAgent", "bool", "Role mapping", "True for KC10"],
            ["isAssistantGeneralAgent", "bool", "Role mapping", "True for KC30"],
            ["isFieldAssistant", "bool", "Role mapping", "True for KC40/KC50"],
            ["isAdmin", "bool", "Role mapping", "True for KC60"],
        ])

    add_heading(doc, "7.6 HTTP Status Codes", level=2)
    add_table(doc,
        ["Status", "Condition", "Response Body"],
        [
            ["200 OK", "Success", "Base64-encoded JSON"],
            ["400 Bad Request", "Invalid/missing userId, invalid oppID, or missing role", "Error message"],
            ["401 Unauthorized", "Easy Auth: caller not authenticated", "Authentication required."],
            ["403 Forbidden", "Missing app role or Dataverse privilege denied", "Access denied."],
            ["404 Not Found", "systemuser not found or not visible", "User not found."],
        ])

    # 8. Dataverse Integration
    add_heading(doc, "8. Dataverse Integration")
    add_heading(doc, "8.1 Connection Configuration", level=2)
    add_table(doc,
        ["Setting", "Source", "Used by Code"],
        [
            ["CRM_URL", "Key Vault / App Setting", "Yes - Dataverse organization URL"],
            ["CRM_CLIENT_ID", "Key Vault / App Setting", "No - legacy/unused in current code"],
            ["CRM_CLIENT_SECRET", "Key Vault / App Setting", "No - legacy/unused in current code"],
        ])

    add_heading(doc, "8.2 Token Acquisition", level=2)
    add_para(doc, "DefaultAzureCredential resolves credentials in the following order:")
    add_numbered(doc, [
        "Environment variables (local development)",
        "Managed Identity (Azure deployment - primary production path)",
        "Azure CLI / Visual Studio / other dev credentials",
    ])
    add_para(doc, "Token scope: {CRM_URL authority}/.default")

    add_heading(doc, "8.3 Entities and Queries", level=2)
    add_table(doc,
        ["Entity", "Query Type", "Attributes Retrieved", "When"],
        [
            ["systemuser", "FetchXML", "kofc_agentid, kofc_user_ldap_id, windowsliveid, kofc_insurancerole", "Always"],
            ["opportunity", "FetchXML + link", "opportunityid, parentcontactid", "When oppID provided"],
            ["contact", "Linked entity", "kofc_clientid, kofc_contacttype, kofc_birthdate", "When oppID provided"],
        ])

    add_heading(doc, "8.4 Role Code Mapping", level=2)
    add_table(doc,
        ["Role Label", "Code", "EApp Flag"],
        [
            ["Insurance-Field Agent", "KC20", "isFieldAgent"],
            ["Insurance-General Agent", "KC10", "isGeneralAgent"],
            ["Insurance-Assistant General Agent", "KC30", "isAssistantGeneralAgent"],
            ["Insurance-Agency Admin", "KC40", "isFieldAssistant"],
            ["Insurance-Field Agent Assistant", "KC50", "isFieldAssistant"],
            ["Insurance-AgencyAdmin", "KC60", "isAdmin"],
        ])

    # 9. Security Design
    add_heading(doc, "9. Security Design")
    add_heading(doc, "9.1 Inbound Security (Boomi to Function App)", level=2)
    add_bullets(doc, [
        "Easy Auth configured manually on the Function App in Azure Portal.",
        "Boomi obtains MSAL token scoped to the Function App API registration.",
        "Function runtime AuthorizationLevel is Anonymous; platform enforces authentication.",
        "Local development bypasses auth when WEBSITE_SITE_NAME is not set.",
    ])

    add_heading(doc, "9.2 Outbound Security (Function App to Dataverse)", level=2)
    add_bullets(doc, [
        "System-assigned Managed Identity on the Function App (ARM template).",
        "Application user created in Power Platform admin center for the MI.",
        "Custom security role recommended (least privilege) with required read privileges.",
        "Act on Behalf of Another User must be assigned directly to the application user.",
        "Do not assign security roles via teams for the impersonation privilege.",
    ])

    add_heading(doc, "9.3 Recommended Dataverse Security Role", level=2)
    add_table(doc,
        ["Privilege", "Entity / Area", "Level", "Required"],
        [
            ["Act on Behalf of Another User", "Business Management", "Organization", "Yes"],
            ["Read", "User (systemuser)", "Organization or appropriate depth", "Yes"],
            ["Read", "Opportunity", "As needed", "Yes (when oppID used)"],
            ["Read", "Contact", "As needed", "Yes (when oppID used)"],
        ])
    add_para(
        doc,
        "For development/POC, System Administrator may be assigned to the application user. "
        "For production, use a custom least-privilege role. System Administrator is not "
        "recommended for production due to excessive blast radius."
    )

    add_heading(doc, "9.4 What Is NOT Used", level=2)
    add_table(doc,
        ["Mechanism", "Reason Not Used"],
        [
            ["Azure AD user_impersonation (delegated)", "Designed for OBO/user-token flows, not MI + CallerId"],
            ["Boomi token pass-through to Dataverse", "Token audience is Function App API, not Dataverse"],
            ["CRM_CLIENT_ID / CRM_CLIENT_SECRET", "Replaced by Managed Identity in application code"],
            ["Easy Auth token exchange", "Easy Auth only validates inbound tokens; no outbound broker"],
        ])

    add_heading(doc, "9.5 Concurrent Request Safety", level=2)
    add_para(
        doc,
        "ServiceClient is registered as Scoped (not Singleton) in Program.cs so each function "
        "invocation receives its own client instance. This prevents concurrent requests from "
        "overwriting each other's CallerId impersonation context."
    )

    add_heading(doc, "9.6 Client-Side Configuration", level=2)
    add_para(
        doc,
        "Auth settings (tenantId, clientId, apiAppId, apiKey) are stored in Dataverse environment "
        "variables and passed to KOFC.Auth.configure() at runtime. The x-api-key is still visible "
        "in browser memory during the call — treat as low-sensitivity and rotate periodically."
    )

    # 10. Infrastructure and Deployment
    add_heading(doc, "10. Infrastructure and Deployment")
    add_heading(doc, "10.1 Azure Resources", level=2)
    add_table(doc,
        ["Resource", "Configuration"],
        [
            ["Function App", "KOFC-Dev-FA-Eapp-Integration (dev example)"],
            ["Runtime", "dotnet-isolated, Functions v4, .NET 8"],
            ["Identity", "System-assigned Managed Identity"],
            ["App Service Plan", "KOC-EUS-Premium-ASP"],
            ["Application Insights", "KOC-CRM-INTDEV-APPINS"],
            ["Key Vault", "KOC-CRM-KOCAZINTDEV1-KV"],
            ["Storage Account", "koccrmdevsa"],
            ["Resource Group", "KOC-CRM-DEV"],
            ["Location", "East US"],
        ])

    add_heading(doc, "10.2 Application Settings", level=2)
    add_table(doc,
        ["App Setting", "Purpose"],
        [
            ["CRM_URL", "Dataverse organization URL"],
            ["APPLICATIONINSIGHTS_CONNECTION_STRING", "Telemetry"],
            ["AzureWebJobsStorage", "Functions runtime storage"],
            ["FUNCTIONS_WORKER_RUNTIME", "dotnet-isolated"],
            ["FUNCTIONS_EXTENSION_VERSION", "~4"],
        ])

    add_heading(doc, "10.3 Deployment Prerequisites Checklist", level=2)
    add_numbered(doc, [
        "Deploy Function App via ARM template / Azure DevOps pipeline.",
        "Enable and note Managed Identity Object (principal) ID.",
        "Create Application User in Dataverse linked to the Managed Identity.",
        "Assign security role with Act on Behalf Of and entity read privileges.",
        "Configure Easy Auth on Function App for Boomi app registration.",
        "Grant Boomi app registration permission to call the Function App API.",
        "Store CRM_URL in Key Vault and reference from app settings.",
        "Upload kofc_authclient.js, kofc_authcallback.html, kofc_msalbrowsermin as web resources.",
        "Create environment variables: kofc_EappTenantId, ClientId, ApiAppId, ApiKey (plus existing EappURL / IntfunctionURL).",
        "Register SPA redirect URI: https://<org>.crm.dynamics.com/WebResources/kofc_authcallback.html",
        "Update kofc_Opportunity form script (see kofc_Opportunity-eapp-updates.js).",
        "Smoke test: first click (redirect + callback), second click (silent).",
    ])

    # 11. Error Handling and Logging
    add_heading(doc, "11. Error Handling and Logging")
    add_table(doc,
        ["Scenario", "Behavior", "HTTP Status"],
        [
            ["Unauthenticated caller (Azure)", "UnauthorizedObjectResult", "401"],
            ["Invalid userId or oppID", "BadRequestObjectResult", "400"],
            ["User not found / not visible", "NotFoundObjectResult", "404"],
            ["Missing kofc_insurancerole", "BadRequestObjectResult", "400"],
            ["Dataverse privilege fault (0x80048303)", "Logged warning, forbidden response", "403"],
            ["CRM connection failure at startup", "InvalidOperationException", "500 (host failure)"],
            ["Opportunity/contact not accessible", "Empty client fields in response", "200"],
        ])
    add_para(doc, "Application Insights captures function execution logs including impersonated userId and JSON results.")

    # 12. Test Scenarios
    add_heading(doc, "12. Test Scenarios")
    add_table(doc,
        ["#", "Scenario", "Expected Result"],
        [
            ["1", "Valid token + valid userId", "200 with Base64 JSON and role flags"],
            ["2", "Valid token + userId + oppID (user has access)", "200 with clientId and clientDob"],
            ["3", "Valid token + userId + oppID (no contact access)", "200 with empty client fields"],
            ["4", "Missing/invalid token (Azure)", "401"],
            ["5", "Missing userId", "400"],
            ["6", "Invalid oppID format", "400"],
            ["7", "userId not found in CRM", "404"],
            ["8", "App user missing Act on Behalf Of", "403"],
            ["10", "First EApp click (no MSAL cache)", "Redirect to Microsoft; callback completes Boomi + opens EApp"],
            ["11", "Second EApp click (cached token)", "Silent; EApp opens in new tab without redirect"],
            ["12", "Delegated SPA token hits Function directly", "403 (no app roles in token)"],
        ])

    # 13. Key Design Decisions
    add_heading(doc, "13. Key Design Decisions")
    add_table(doc,
        ["Decision", "Choice", "Rationale"],
        [
            ["D365 auth client", "Reusable KOFC.Auth + dynamic load", "Same library for any entity; config via env vars"],
            ["Browser token flow", "Redirect + callback auto-complete", "Reliable in D365 iframe; no second click"],
            ["Inbound auth", "Easy Auth + app roles", "Platform validation plus Contact.Read / Opportunity.Read"],
            ["Outbound auth", "Managed Identity", "No secrets in code; automatic credential rotation"],
            ["Per-user CRM security", "CallerId impersonation", "Native Dataverse row-level security"],
            ["ServiceClient lifetime", "Scoped per invocation", "Thread-safe impersonation under concurrency"],
            ["Response format", "Base64 JSON", "Existing EApp integration contract"],
            ["Legacy client secret settings", "Retained in infra, unused in code", "Backward compatibility / future fallback"],
        ])

    # 14. Appendix
    add_heading(doc, "14. Appendix")
    add_heading(doc, "14.1 NuGet Dependencies", level=2)
    add_table(doc,
        ["Package", "Version", "Purpose"],
        [
            ["Microsoft.Azure.Functions.Worker", "1.21.0", "Functions isolated worker"],
            ["Azure.Identity", "1.13.2", "DefaultAzureCredential"],
            ["Microsoft.PowerPlatform.Dataverse.Client", "1.1.32", "ServiceClient / CRM SDK"],
            ["Newtonsoft.Json", "13.0.3", "JSON serialization"],
        ])

    add_heading(doc, "14.2 Related Documentation", level=2)
    add_bullets(doc, [
        "docs/KOFC-EApp-SSO-Architecture.wiki.md — full architecture (source for KOFC-EApp-SSO-Architecture.docx)",
        "webresources/eapp-boomi-button/kofc_Opportunity-eapp-updates.js — form script snippet",
        "Microsoft: Impersonate another user (Dataverse)",
        "Microsoft: DefaultAzureCredential class",
        "Power Platform: Application users and security roles",
    ])

    add_heading(doc, "14.3 Document Revision History", level=2)
    add_table(doc,
        ["Version", "Date", "Author", "Changes"],
        [
            ["1.0", "2026-03-01", "Solution Team", "Initial end-to-end design including CallerId impersonation"],
            ["1.1", date.today().strftime("%Y-%m-%d"), "Solution Team", "Added D365 KOFC.Auth client, env-var config, kofc_authcallback.html, two-token model, app roles"],
        ])

    return doc


def main() -> None:
    doc = build_document()
    doc.save(OUTPUT)
    print(f"Created: {OUTPUT}")


if __name__ == "__main__":
    main()
