using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using KOFC.Azure.Functions.GetSaasBlobUrl.Tests.Support;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;
using Xunit;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests.Services;

public class ContactAccessGuardTests
{
    [Fact]
    public void CheckContactAccess_SetsCallerIdAndGrantsWhenContactReadable()
    {
        var userId = Guid.NewGuid();
        var contactId = Guid.NewGuid();
        var fake = new FakeDataverseClient
        {
            UserEntities = CreateUserCollection(userId, "agent@example.com"),
            ContactEntity = new Entity("contact") { Id = contactId }
        };
        var guard = new ContactAccessGuard(NullLogger<ContactAccessGuard>.Instance, fake);

        var result = guard.CheckContactAccess(userId, contactId);

        Assert.True(result.IsGranted);
        Assert.Equal(userId, result.UserId);
        Assert.Equal("agent@example.com", result.UserName);
        Assert.Equal(Guid.Empty, fake.CallerId);
    }

    [Fact]
    public void CheckContactAccessByEntraOid_ResolvesOidToSystemUserAndImpersonates()
    {
        var entraOid = Guid.NewGuid();
        var userId = Guid.NewGuid();
        var contactId = Guid.NewGuid();
        var user = new Entity("systemuser") { Id = userId };
        user["domainname"] = "agent@example.com";
        user["azureactivedirectoryobjectid"] = entraOid.ToString();

        var fake = new FakeDataverseClient
        {
            UserEntities = new EntityCollection(new List<Entity> { user }),
            ContactEntity = new Entity("contact") { Id = contactId }
        };
        var guard = new ContactAccessGuard(NullLogger<ContactAccessGuard>.Instance, fake);

        var result = guard.CheckContactAccessByEntraOid(entraOid, contactId);

        Assert.True(result.IsGranted);
        Assert.Equal(userId, result.UserId);
        Assert.Equal(Guid.Empty, fake.CallerId);
    }

    [Fact]
    public void CheckContactAccess_DeniesWhenContactNotAccessible()
    {
        var userId = Guid.NewGuid();
        var contactId = Guid.NewGuid();
        var fake = new FakeDataverseClient
        {
            UserEntities = CreateUserCollection(userId, "agent@example.com"),
            DenyContactRetrieve = true
        };
        var guard = new ContactAccessGuard(NullLogger<ContactAccessGuard>.Instance, fake);

        var result = guard.CheckContactAccess(userId, contactId);

        Assert.Equal(ContactAccessStatus.AccessDenied, result.Status);
        Assert.Equal(Guid.Empty, fake.CallerId);
    }

    [Fact]
    public void ResolveSystemUserIdByEntraOid_ReturnsSystemUserId()
    {
        var entraOid = Guid.NewGuid();
        var userId = Guid.NewGuid();
        var user = new Entity("systemuser") { Id = userId };
        user["domainname"] = "agent@example.com";
        user["azureactivedirectoryobjectid"] = entraOid.ToString();

        var fake = new FakeDataverseClient
        {
            UserEntities = new EntityCollection(new List<Entity> { user })
        };
        var guard = new ContactAccessGuard(NullLogger<ContactAccessGuard>.Instance, fake);

        var resolved = guard.ResolveSystemUserIdByEntraOid(entraOid);

        Assert.Equal(userId, resolved);
    }

    private static EntityCollection CreateUserCollection(Guid userId, string userName)
    {
        var user = new Entity("systemuser") { Id = userId };
        user["domainname"] = userName;
        return new EntityCollection(new List<Entity> { user });
    }
}
