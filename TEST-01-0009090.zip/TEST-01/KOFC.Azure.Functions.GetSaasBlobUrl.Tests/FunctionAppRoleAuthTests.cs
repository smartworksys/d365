using KOFC.Azure.Functions.GetSaasBlobUrl.Helpers;
using KOFC.Azure.Functions.GetSaasBlobUrl.Tests.Support;
using Xunit;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests;

public class FunctionAppRoleAuthTests
{
    [Fact]
    public void IsAuthenticated_AllowsLocalRequestsWhenNotRunningInAzure()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var request = HttpRequestTestHelper.CreateRequest();

        Assert.True(FunctionAppRoleAuth.IsAuthenticated(request));
    }

    [Fact]
    public void IsAuthenticated_RequiresPrincipalHeaderInAzure()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var unauthenticated = HttpRequestTestHelper.CreateRequest();
        Assert.False(FunctionAppRoleAuth.IsAuthenticated(unauthenticated));

        var authenticated = HttpRequestTestHelper.CreateRequest(
            principalRoleClaims: new[] { ("scp", "Blob.Read"), ("oid", Guid.NewGuid().ToString()) });
        Assert.True(FunctionAppRoleAuth.IsAuthenticated(authenticated));
    }

    [Fact]
    public void IsDelegatedCaller_RequiresOidAndBlobScopeInAzure()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var oid = Guid.NewGuid();

        var delegated = HttpRequestTestHelper.CreateRequest(
            principalRoleClaims: new[]
            {
                ("scp", "Blob.Read"),
                ("oid", oid.ToString())
            });
        Assert.True(FunctionAppRoleAuth.IsDelegatedCaller(delegated));

        var appRoleOnly = HttpRequestTestHelper.CreateRequest(
            principalRoleClaims: new[] { ("roles", "Blob.Read") });
        Assert.False(FunctionAppRoleAuth.IsDelegatedCaller(appRoleOnly));
    }

    [Fact]
    public void HasDelegatedBlobAccess_AcceptsAccessAsUserScope()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var request = HttpRequestTestHelper.CreateRequest(
            principalRoleClaims: new[]
            {
                ("scp", "access_as_user"),
                ("oid", Guid.NewGuid().ToString())
            });

        Assert.True(FunctionAppRoleAuth.HasDelegatedBlobAccess(request));
    }
}
