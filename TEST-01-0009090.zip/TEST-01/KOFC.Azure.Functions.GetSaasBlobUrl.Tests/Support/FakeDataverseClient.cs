using System.ServiceModel;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests.Support;

internal sealed class FakeDataverseClient : IDataverseClient
{
    public Guid CallerId { get; set; }

    public EntityCollection UserEntities { get; set; } = new();

    public Entity? ContactEntity { get; set; }

    public bool DenyContactRetrieve { get; set; }

    public Entity Retrieve(string entityName, Guid id, ColumnSet columnSet)
    {
        if (entityName == "contact")
        {
            if (DenyContactRetrieve)
            {
                throw new FaultException<OrganizationServiceFault>(
                    new OrganizationServiceFault
                    {
                        ErrorCode = unchecked((int)0x80048303),
                        Message = "Privilege denied"
                    });
            }

            if (ContactEntity is null || ContactEntity.Id != id)
            {
                throw new FaultException<OrganizationServiceFault>(
                    new OrganizationServiceFault
                    {
                        ErrorCode = unchecked((int)0x80040217),
                        Message = "Contact not found"
                    });
            }

            return ContactEntity;
        }

        throw new InvalidOperationException($"Unexpected retrieve: {entityName}");
    }

    public EntityCollection RetrieveMultiple(QueryBase query)
    {
        if (query is QueryExpression expression && expression.EntityName == "systemuser")
        {
            return UserEntities;
        }

        return new EntityCollection();
    }
}
