using System.ServiceModel;
using Microsoft.Extensions.Logging;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public enum ContactAccessStatus
{
    Granted,
    UserNotFound,
    AccessDenied
}

public sealed class ContactAccessResult
{
    public ContactAccessStatus Status { get; init; }
    public string Message { get; init; } = string.Empty;
    public bool IsGranted => Status == ContactAccessStatus.Granted;
    public Guid? UserId { get; init; }
    public string? UserName { get; init; }

    public static ContactAccessResult Granted(Guid userId, string? userName = null) =>
        new()
        {
            Status = ContactAccessStatus.Granted,
            Message = "Access granted.",
            UserId = userId,
            UserName = userName
        };

    public static ContactAccessResult UserNotFound(string message) =>
        new() { Status = ContactAccessStatus.UserNotFound, Message = message };

    public static ContactAccessResult AccessDenied(Guid userId, string message, string? userName = null) =>
        new()
        {
            Status = ContactAccessStatus.AccessDenied,
            Message = message,
            UserId = userId,
            UserName = userName
        };

    public static ContactAccessResult IdentityMismatch(string message) =>
        new() { Status = ContactAccessStatus.AccessDenied, Message = message };

    public static ContactAccessResult MissingUserIdentity(string message) =>
        new() { Status = ContactAccessStatus.UserNotFound, Message = message, IsMissingUserIdentity = true };

    public bool IsMissingUserIdentity { get; init; }
}

/// <summary>
/// Mirrors the EApp/Policy Dataverse pattern: connects via Managed Identity, resolves the
/// calling user (by Dataverse systemuserid or Entra oid), impersonates via CallerId, and
/// lets Dataverse enforce whether that user can read the contact record.
/// </summary>
public class ContactAccessGuard : IContactAccessGuard
{
    private const int PrivilegeDeniedErrorCode = unchecked((int)0x80048303);

    private readonly ILogger<ContactAccessGuard> _log;
    private readonly IDataverseClient _dataverse;

    public ContactAccessGuard(ILogger<ContactAccessGuard> log, IDataverseClient dataverse)
    {
        _log = log;
        _dataverse = dataverse;
    }

    private static string UserNameField =>
        Environment.GetEnvironmentVariable("DATAVERSE_USERNAME_FIELD") ?? "domainname";

    public ContactAccessResult CheckContactAccess(Guid userId, Guid contactId)
    {
        var resolvedUser = ResolveUserById(userId);
        if (resolvedUser is null)
        {
            _log.LogWarning("No enabled Dataverse user found for userId {UserId}.", userId);
            return ContactAccessResult.UserNotFound($"User '{userId}' was not found in Dataverse.");
        }

        return VerifyContactAccess(resolvedUser.Value.UserId, resolvedUser.Value.UserName, contactId);
    }

    public ContactAccessResult CheckContactAccessByEntraOid(Guid entraOid, Guid contactId)
    {
        var resolvedUser = ResolveUserByEntraOid(entraOid);
        if (resolvedUser is null)
        {
            _log.LogWarning("No enabled Dataverse user found for Entra oid {EntraOid}.", entraOid);
            return ContactAccessResult.UserNotFound(
                $"No enabled Dataverse user matches Entra oid '{entraOid}'.");
        }

        _log.LogInformation(
            "Resolved Entra oid {EntraOid} to Dataverse user {UserId} ({UserName}).",
            entraOid,
            resolvedUser.Value.UserId,
            resolvedUser.Value.UserName);

        return VerifyContactAccess(resolvedUser.Value.UserId, resolvedUser.Value.UserName, contactId);
    }

    public Guid? ResolveSystemUserIdByEntraOid(Guid entraOid)
    {
        return ResolveUserByEntraOid(entraOid)?.UserId;
    }

    private ContactAccessResult VerifyContactAccess(Guid systemUserId, string userName, Guid contactId)
    {
        try
        {
            _log.LogInformation(
                "Impersonating Dataverse user {UserId} ({UserName}) to verify contact {ContactId} access.",
                systemUserId,
                userName,
                contactId);
            _dataverse.CallerId = systemUserId;

            _dataverse.Retrieve("contact", contactId, new ColumnSet("contactid"));
            return ContactAccessResult.Granted(systemUserId, userName);
        }
        catch (FaultException<OrganizationServiceFault> ex) when (ex.Detail.ErrorCode == PrivilegeDeniedErrorCode)
        {
            _log.LogWarning(
                ex,
                "Dataverse denied contact read for user {UserId} ({UserName}) on contact {ContactId}.",
                systemUserId,
                userName,
                contactId);
            return ContactAccessResult.AccessDenied(
                systemUserId,
                $"User '{userName}' does not have access to contact '{contactId}'.",
                userName);
        }
        catch (FaultException<OrganizationServiceFault> ex)
        {
            _log.LogWarning(
                ex,
                "Unable to retrieve contact {ContactId} for user {UserId} ({UserName}). ErrorCode={ErrorCode}",
                contactId,
                systemUserId,
                userName,
                ex.Detail.ErrorCode);
            return ContactAccessResult.AccessDenied(
                systemUserId,
                $"User '{userName}' does not have access to contact '{contactId}'.",
                userName);
        }
        finally
        {
            _dataverse.CallerId = Guid.Empty;
        }
    }

    private (Guid UserId, string UserName)? ResolveUserById(Guid userId)
    {
        var query = new QueryExpression("systemuser")
        {
            TopCount = 1,
            ColumnSet = new ColumnSet("systemuserid", UserNameField),
            Criteria = new FilterExpression(LogicalOperator.And)
        };
        query.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, userId);
        query.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, false);

        var result = _dataverse.RetrieveMultiple(query);
        if (result.Entities is not { Count: > 0 })
        {
            return null;
        }

        var entity = result.Entities[0];
        var userName = entity.GetAttributeValue<string>(UserNameField);
        if (string.IsNullOrWhiteSpace(userName))
        {
            _log.LogWarning("User {UserId} was found but {Field} is empty.", userId, UserNameField);
            return null;
        }

        return (entity.Id, userName);
    }

    private (Guid UserId, string UserName)? ResolveUserByEntraOid(Guid entraOid)
    {
        var query = new QueryExpression("systemuser")
        {
            TopCount = 1,
            ColumnSet = new ColumnSet("systemuserid", UserNameField),
            Criteria = new FilterExpression(LogicalOperator.And)
        };
        query.Criteria.AddCondition("azureactivedirectoryobjectid", ConditionOperator.Equal, entraOid);
        query.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, false);

        var result = _dataverse.RetrieveMultiple(query);
        if (result.Entities is not { Count: > 0 })
        {
            return null;
        }

        var entity = result.Entities[0];
        var userName = entity.GetAttributeValue<string>(UserNameField);
        if (string.IsNullOrWhiteSpace(userName))
        {
            _log.LogWarning(
                "Entra oid {EntraOid} matched user {UserId} but {Field} is empty.",
                entraOid,
                entity.Id,
                UserNameField);
            return null;
        }

        return (entity.Id, userName);
    }
}
