using System.Security.Claims;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Helpers;

/// <summary>
/// Validates Easy Auth tokens on inbound requests (mirrors EApp / Policy non-header).
/// Production path: Boomi forwards delegated SPA token with Blob.Read or access_as_user scope.
/// </summary>
public static class FunctionAppRoleAuth
{
    public const string BlobReadRole = "Blob.Read";
    public const string AccessAsUserScope = "access_as_user";

    public static bool IsAuthenticated(HttpRequest req)
    {
        if (req.HttpContext.User.Identity?.IsAuthenticated == true)
        {
            return true;
        }

        if (!IsRunningInAzure())
        {
            return true;
        }

        return HasHeader(req, "X-MS-CLIENT-PRINCIPAL")
            || HasHeader(req, "X-MS-CLIENT-PRINCIPAL-ID")
            || HasHeader(req, "X-MS-TOKEN-AAD-ACCESS-TOKEN")
            || HasBearerAuthorization(req);
    }

    public static IReadOnlyCollection<string> GetCallerRoles(HttpRequest req)
    {
        if (!IsRunningInAzure())
        {
            return new[] { BlobReadRole };
        }

        var roles = GetClaimValues(
            req,
            "roles",
            ClaimTypes.Role,
            "http://schemas.microsoft.com/ws/2008/06/identity/claims/role");

        return roles.Count > 0 ? roles : GetJwtClaimValues(req, "roles");
    }

    public static IReadOnlyCollection<string> GetCallerScopes(HttpRequest req)
    {
        if (!IsRunningInAzure())
        {
            return new[] { BlobReadRole };
        }

        var scopes = GetClaimValues(
                req,
                "scp",
                "http://schemas.microsoft.com/identity/claims/scope")
            .SelectMany(value => value.Split(' ', StringSplitOptions.RemoveEmptyEntries))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (scopes.Count > 0)
        {
            return scopes;
        }

        return GetJwtClaimValues(req, "scp")
            .SelectMany(value => value.Split(' ', StringSplitOptions.RemoveEmptyEntries))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    public static bool HasScope(HttpRequest req, string scope) =>
        GetCallerScopes(req).Contains(scope, StringComparer.OrdinalIgnoreCase);

    public static bool HasDelegatedBlobAccess(HttpRequest req) =>
        HasScope(req, BlobReadRole) || HasScope(req, AccessAsUserScope);

    public static Guid? GetCallerObjectId(HttpRequest req)
    {
        var value = GetClaimValues(
                req,
                "oid",
                "http://schemas.microsoft.com/identity/claims/objectidentifier")
            .FirstOrDefault();

        if (Guid.TryParse(value, out var objectId))
        {
            return objectId;
        }

        if (req.Headers.TryGetValue("X-MS-CLIENT-PRINCIPAL-ID", out var principalIdHeader)
            && Guid.TryParse(principalIdHeader.FirstOrDefault(), out objectId))
        {
            return objectId;
        }

        value = GetJwtClaimValues(req, "oid").FirstOrDefault();
        return Guid.TryParse(value, out objectId) ? objectId : null;
    }

    public static bool IsDelegatedCaller(HttpRequest req)
    {
        if (!IsRunningInAzure())
        {
            return false;
        }

        return GetCallerObjectId(req).HasValue && HasDelegatedBlobAccess(req);
    }

    public static bool HasAppRole(IReadOnlyCollection<string> callerRoles, string role) =>
        callerRoles.Contains(role, StringComparer.OrdinalIgnoreCase);

    public static bool IsRunningInAzure() =>
        !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("WEBSITE_SITE_NAME"));

    private static bool HasHeader(HttpRequest req, string headerName) =>
        req.Headers.TryGetValue(headerName, out var values)
        && !string.IsNullOrWhiteSpace(values.FirstOrDefault());

    private static bool HasBearerAuthorization(HttpRequest req)
    {
        if (!req.Headers.TryGetValue("Authorization", out var authorizationHeader))
        {
            return false;
        }

        var authorization = authorizationHeader.FirstOrDefault();
        return !string.IsNullOrWhiteSpace(authorization)
            && authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase);
    }

    private static IReadOnlyCollection<string> GetClaimValues(HttpRequest req, params string[] claimTypes)
    {
        var values = req.HttpContext.User.Claims
            .Where(c => claimTypes.Contains(c.Type, StringComparer.OrdinalIgnoreCase))
            .Select(c => c.Value)
            .Where(value => !string.IsNullOrWhiteSpace(value))
            .ToList();

        if (values.Count > 0)
        {
            return values;
        }

        if (!req.Headers.TryGetValue("X-MS-CLIENT-PRINCIPAL", out var header)
            || string.IsNullOrWhiteSpace(header.FirstOrDefault()))
        {
            return Array.Empty<string>();
        }

        try
        {
            var json = Encoding.UTF8.GetString(Convert.FromBase64String(header.First()!));
            var principal = JsonConvert.DeserializeObject<ClientPrincipal>(json);

            return principal?.Claims?
                .Where(c => claimTypes.Contains(c.Typ, StringComparer.OrdinalIgnoreCase))
                .Select(c => c.Val)
                .Where(value => !string.IsNullOrWhiteSpace(value))
                .ToList() ?? [];
        }
        catch (FormatException)
        {
            return Array.Empty<string>();
        }
        catch (Newtonsoft.Json.JsonException)
        {
            return Array.Empty<string>();
        }
    }

    private static IReadOnlyCollection<string> GetJwtClaimValues(HttpRequest req, string claimName)
    {
        var token = GetAccessToken(req);
        if (string.IsNullOrWhiteSpace(token))
        {
            return Array.Empty<string>();
        }

        var parts = token.Split('.');
        if (parts.Length < 2)
        {
            return Array.Empty<string>();
        }

        try
        {
            var json = Encoding.UTF8.GetString(Base64UrlDecode(parts[1]));
            using var document = JsonDocument.Parse(json);
            if (!document.RootElement.TryGetProperty(claimName, out var claimElement))
            {
                return Array.Empty<string>();
            }

            return claimElement.ValueKind switch
            {
                JsonValueKind.String => new[] { claimElement.GetString() ?? string.Empty },
                JsonValueKind.Array => claimElement.EnumerateArray()
                    .Select(item => item.GetString() ?? string.Empty)
                    .Where(value => !string.IsNullOrWhiteSpace(value))
                    .ToList(),
                _ => Array.Empty<string>()
            };
        }
        catch (FormatException)
        {
            return Array.Empty<string>();
        }
        catch (System.Text.Json.JsonException)
        {
            return Array.Empty<string>();
        }
    }

    private static string? GetAccessToken(HttpRequest req)
    {
        if (req.Headers.TryGetValue("X-MS-TOKEN-AAD-ACCESS-TOKEN", out var accessTokenHeader))
        {
            var accessToken = accessTokenHeader.FirstOrDefault();
            if (!string.IsNullOrWhiteSpace(accessToken))
            {
                return accessToken;
            }
        }

        if (req.Headers.TryGetValue("Authorization", out var authorizationHeader))
        {
            var authorization = authorizationHeader.FirstOrDefault();
            if (!string.IsNullOrWhiteSpace(authorization)
                && authorization.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            {
                return authorization["Bearer ".Length..].Trim();
            }
        }

        return null;
    }

    private static byte[] Base64UrlDecode(string input)
    {
        var padded = input.Replace('-', '+').Replace('_', '/');
        switch (padded.Length % 4)
        {
            case 2:
                padded += "==";
                break;
            case 3:
                padded += "=";
                break;
        }

        return Convert.FromBase64String(padded);
    }

    private sealed class ClientPrincipal
    {
        [JsonProperty("claims")]
        public List<ClientPrincipalClaim>? Claims { get; set; }
    }

    private sealed class ClientPrincipalClaim
    {
        [JsonProperty("typ")]
        public string Typ { get; set; } = "";

        [JsonProperty("val")]
        public string Val { get; set; } = "";
    }
}
