using System.Linq;
using Azure.Identity;
using Azure.Storage.Blobs;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureServices((context, services) =>
    {
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();

        // Isolated worker defaults to Warning+ for App Insights; remove so Information
        // logs appear in traces and the Invocations blade.
        services.Configure<LoggerFilterOptions>(options =>
        {
            var defaultRule = options.Rules.FirstOrDefault(rule =>
                rule.ProviderName ==
                "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider");
            if (defaultRule is not null)
            {
                options.Rules.Remove(defaultRule);
            }
        });

        var configuration = context.Configuration;
        var accountName = configuration["BlobStorageAccountName"];
        if (!string.IsNullOrWhiteSpace(accountName))
        {
            services.AddSingleton(_ => new BlobServiceClient(
                new Uri($"https://{accountName}.blob.core.windows.net"),
                new DefaultAzureCredential()));
        }
        else
        {
            var storageConnectionString = configuration["BLOB_CONNECTION_STRING"]
                ?? configuration["AzureWebJobsStorage"];

            if (string.IsNullOrWhiteSpace(storageConnectionString))
            {
                throw new InvalidOperationException(
                    "Blob storage is not configured. Set BlobStorageAccountName (Managed Identity) " +
                    "or BLOB_CONNECTION_STRING / AzureWebJobsStorage.");
            }

            services.AddSingleton(_ => new BlobServiceClient(storageConnectionString));
        }

        services.AddScoped<ServiceClient>(sp =>
            DataverseClientFactory.Create(sp.GetRequiredService<ILogger<ServiceClient>>()));
        services.AddScoped<IDataverseClient, DataverseClientAdapter>();
        services.AddScoped<IContactAccessGuard, ContactAccessGuard>();
        services.AddSingleton<IBlobService, BlobService>();
    })
    .ConfigureLogging(logging =>
    {
        logging.SetMinimumLevel(LogLevel.Information);
        logging.AddFilter("Function", LogLevel.Information);
        logging.AddFilter("Function.GetSaasBlobUrl", LogLevel.Information);
        logging.AddFilter("Microsoft", LogLevel.Warning);
        logging.AddFilter("Host", LogLevel.Information);
    })
    .Build();

host.Run();
