# Azure Function - SAS Blob URL Generator with Dataverse Authentication

Generate secure SAS URLs for Azure Blob Storage with Azure AD Easy Auth and Dataverse entity validation.

## 🏗️ Architecture

```
User Browser
    ↓
Easy Auth (Azure AD) - User Authentication
    ↓
Azure Function
    ├─→ Dataverse API - Entity Validation (Service Principal)
    └─→ Blob Storage - SAS URL Generation (Managed Identity)
```

## ✨ Features

- **Azure AD Easy Auth**: Secure user authentication
- **Dataverse Validation**: Validates user has access to specific entity records  
- **Managed Identity**: Secure blob storage access without connection strings
- **Service Principal**: Reliable Dataverse API access
- **Configurable Entities**: Works with any Dataverse entity (not just contacts)

## 🚀 Quick Start

### Prerequisites

- Azure subscription
- Azure Function App with Easy Auth enabled
- Azure Blob Storage account
- Dataverse environment

### 1. Configure App Settings

1. Go to [Azure Portal](https://portal.azure.com)
2. Navigate to  Function App
3. Click **Configuration** in the left menu
4. Under **Application settings**, click **+ New application setting** for each:

| Name | Value | Example |
|------|-------|---------|
| `BlobStorageAccountName` |  storage account name | `storageaccount` |
| `BlobContainerName` |  container name | `smart-office` |
| `DataverseUrl` |  Dataverse URL | `https://kocazintdev1.crm.dynamics.com/` |
| `DataverseEntityName` | Default entity name | `contacts` |
| `TenantId` | Azure AD tenant ID | `8a4b69f8-8bb7-4be5-9eda-6c40a157248c` |

5. Click **Save** at the top
6. Click **Continue** to restart the app

### 2. Enable Managed Identity

#### Option A: Azure Portal (Manual)

**Enable Managed Identity:**
1. Go to  Function App in Azure Portal
2. Click **Identity** in the left menu
3. Under **System assigned** tab:
   - Set **Status** to **On**
   - Click **Save**
   - Copy the **Object (principal) ID** (you'll need this next)

**Assign Storage Role:**
1. Go to  Storage Account in Azure Portal
2. Click **Access Control (IAM)** in the left menu
3. Click **+ Add** → **Add role assignment**
4. Select **Storage Blob Data Contributor** role
5. Click **Next**
6. Click **+ Select members**
7. Search for  Function App name
8. Select it and click **Select**
9. Click **Review + assign**

### 3. Configure Easy Auth and Client Secret

#### Enable Easy Auth (Azure Portal)

1. Go to  Function App in Azure Portal
2. Click **Authentication** in the left menu
3. Click **Add identity provider**
4. Select **Microsoft**
5. Configure:
   - **App registration type**: Create new app registration (or select existing)
   - **Name**: Give it a meaningful name
   - **Supported account types**: Current tenant - Single tenant
   - **Restrict access**: Require authentication
   - **Unauthenticated requests**: HTTP 302 Found redirect
6. Click **Add**
7. **Copy the Client ID** - you'll need this for the next steps

#### Create Client Secret

1. Go to [Azure Portal](https://portal.azure.com)
2. Navigate to **Azure Active Directory** → **App registrations**
3. Find  Easy Auth app registration (use the Client ID from above)
4. Click **Certificates & secrets** in the left menu
5. Click **+ New client secret**
6. Add a description (e.g., "Function App Secret")
7. Set expiration (e.g., 24 months)
8. Click **Add**
9. **Copy the secret Value** immediately (you can't see it again!)

#### Add Client Secret to Function App

1. Go back to  Function App
2. Click **Configuration** → **Application settings**
3. Click **+ New application setting**:
   - **Name**: `ClientSecret`
   - **Value**: Paste the secret you copied
4. Click **OK** and **Save**

#### Add Dataverse API Permission

1. Go back to  App Registration
2. Click **API permissions** in the left menu
3. Click **+ Add a permission**
4. Select **Dynamics CRM**
5. Select **Delegated permissions**
6. Check **user_impersonation**
7. Click **Add permissions**
8. Click **Grant admin consent for [ Tenant]** (admin only)
9. Confirm by clicking **Yes**

### 4. Create Dataverse Application User

1. Go to [Power Platform Admin Center](https://admin.powerplatform.microsoft.com)
2. Select  environment
3. Navigate to **Settings** → **Users + permissions** → **Application users**
4. Click **+ New app user**
5. Click **+ Add an app**
6. Search for and select Easy Auth app registration
7. Click **Add**
8. Select a **Business unit**
9. Click **+ Add security roles** and assign appropriate roles:
   - For testing: **System Administrator**
   - For production: Assign minimal required roles
10. Click **Create**

### 5. Deploy the Function

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `path` | string | Yes | Path to blob in container (e.g., "folder/file.xlsx") |
| `entityId` | guid | Yes | Dataverse entity record GUID |
| `entityName` | string | No | Entity name (defaults to `DataverseEntityName` setting) |

### Example Request

```
https://app.azurewebsites.net/api/GetSaasBlobUrl
  ?path=data/report.xlsx
  &entityId=18afe4dc-aebd-f011-bbd3-000d3a4d5cd1
  &entityName=contact
```

### Example Response

```json
{
  "sasUrl": "https://storage.blob.core.windows.net/container/data/report.xlsx?sv=2023-11-03&se=...&sig=..."
}
```

### cURL Example

```bash
curl -X GET "https://app.azurewebsites.net/api/GetSaasBlobUrl?path=data/report.xlsx&entityId=18afe4dc-aebd-f011-bbd3-000d3a4d5cd1&entityName=contacts" \
  -H "Accept: application/json"
```

## 🔐 Authentication Flow

### 1. User Authentication (Easy Auth)
- User accesses the function URL
- Redirected to Azure AD for authentication
- Easy Auth validates user and injects headers

### 2. Dataverse Token Acquisition
The function attempts to get a Dataverse token in this order:

1. **Check current token audience** - If already for Dataverse, use it
2. **Try refresh token** - If available, exchange for Dataverse token (user delegation)
3. **Fallback to service principal** - Use client credentials (app-only authentication)

### 3. Dataverse Validation
- Makes API call to Dataverse to verify entity exists
- Uses service principal token (app-only authentication)
- Access controlled by Application User security roles

### 4. SAS URL Generation
- Uses Managed Identity to generate user delegation SAS token
- No connection strings required
- Inherits permissions from Managed Identity's role assignment

### Required App Settings

Configure these in Function App (Configuration → Application settings):

| Setting | Description | How to Find | Required |
|---------|-------------|-------------|----------|
| `BlobStorageAccountName` | Storage account name |  storage account name (no URL) | Yes |
| `BlobContainerName` | Blob container name | Container where files are stored | Yes |
| `DataverseUrl` | Dataverse environment URL | Format: `https://orgXXX.crm.dynamics.com` | Yes |
| `DataverseEntityName` | Default entity name | Usually `contacts` or custom entity | Yes |
| `ClientSecret` | App registration client secret | From App Registration → Certificates & secrets | Yes |
| `TenantId` | Azure AD tenant ID | From Azure AD → Overview page | Yes |

### How to Find  Dataverse URL

1. Go to [Power Platform Admin Center](https://admin.powerplatform.microsoft.com)
2. Select  environment
3. The **Environment URL** is  `DataverseUrl`
4. Format: `https://kocazintdev1.crm.dynamics.com/`

### How to Find  Tenant ID

**Option 1: Azure Portal**
1. Go to **Azure Active Directory**
2. Click **Overview**
3. Copy the **Tenant ID**

**Option 2: From Function App**
1. Go to  Function App
2. Click **Authentication**
3. Click  identity provider
4. Look for **Issuer URL**: `https://login.microsoftonline.com/{TenantId}/v2.0`

### Azure Resources Checklist

✅ **Function App**
- Easy Auth enabled with Microsoft identity provider
- System-assigned Managed Identity enabled
- All app settings configured

✅ **Storage Account**
- Function App's Managed Identity has "Storage Blob Data Contributor" role
- Container exists with correct name

✅ **App Registration**
- Client secret created and added to Function App settings
- Dynamics CRM `user_impersonation` permission granted
- Admin consent granted for the permission

✅ **Dataverse**
- Application User created for the App Registration
- Security roles assigned to Application User
- Environment URL matches `DataverseUrl` setting