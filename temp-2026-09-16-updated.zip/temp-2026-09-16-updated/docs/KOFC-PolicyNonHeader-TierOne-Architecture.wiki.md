# KOFC Policy Non-Header Tier One — Function App Architecture

> **Solution:** `KOFC-FA-PolicyNonHeader-TierOne`
> **Function:** `getPolicyData`
> **Runtime:** .NET 8 (Isolated), Azure Functions v4
> **Last updated:** 2026-08-07 (SPA-token forward model)

[[_TOC_]]

---

## 1. Overview

The Policy Non-Header Tier One Function App exposes an HTTP API that aggregates policy data from **multiple upstream systems** (Policy Non-Header REST API, Ingenium, Life70) and returns a merged JSON payload to Dynamics 365 or integration callers.

Before calling upstream APIs, the function performs a **Dataverse access check** (mirroring the EApp pattern): it connects via **Managed Identity**, resolves the signed-in user from the SPA token **`oid`** to a Dataverse `systemuserid`, impersonates that user via `CallerId`, and verifies they can read the requested policy record (by **`policyRecordId`** when supplied, otherwise by policy number query).

**Key characteristics**

- **D365 client path:** MSAL delegated SPA token → **Boomi** (validates JWT + `x-api-key`) → Function (**same SPA token forwarded**).
- **Function inbound auth:** **Easy Auth** + delegated **`scp`** check (`Policy.Read` or `access_as_user`). No function key from browser. No Boomi client-credentials.
- **User identity:** token **`oid`** → Dataverse user. **`userId` is not required**; legacy `userId` is ignored for delegated callers.
- **Dataverse auth:** Function App **Managed Identity** + `DefaultAzureCredential` (no CRM client secret in code).
- **Per-user security:** `DataverseAccessGuard` sets `ServiceClient.CallerId` and lets Dataverse enforce record-level access before upstream calls.
- **Upstream systems:** Policy Non-Header REST API, Ingenium (PING + Headlessflow), Life70 SOAP (Basic auth).
- **Response:** JSON — `NonHeader` only, or merged `NonHeader` + `TIERONE` depending on `source`.

---

## 2. High-Level Architecture

::: mermaid
flowchart LR
    subgraph D365["Dynamics 365"]
        FORM["Policy form<br/>kofc_Policy.js"]
        HTML["kofc_policy_details.html<br/>kofc_policyDetails.js"]
        AUTH["kofc_authclient.js<br/>KOFC.Auth / MSAL"]
    end

    subgraph BOOMI["Boomi"]
        BP["Policy REST process<br/>Validate SPA JWT + x-api-key<br/>Forward SPA token"]
    end

    subgraph AZURE["Azure Function App"]
        EA["Easy Auth<br/>(validates SPA token)"]
        FA["getPolicyData"]
        GUARD["DataverseAccessGuard"]
        MI["Managed Identity"]
    end

    subgraph UPSTREAM["Upstream policy systems"]
        NH["Policy Non-Header API"]
        ING["Ingenium"]
        L70["Life70 SOAP"]
    end

    DV[("Dataverse")]
    AAD["Microsoft Entra ID"]

    FORM -->|Non-Header button| HTML
    HTML --> AUTH
    AUTH -->|MSAL: Policy.Read / access_as_user| AAD
    AAD -->|delegated SPA token| AUTH
    AUTH -->|Bearer SPA token| BP
    HTML -->|x-api-key + policyRecordId| BP
    BP -->|same Bearer SPA token + params| EA
    EA --> FA
    FA -->|scp check + oid resolve| FA
    FA --> GUARD
    GUARD --> MI
    MI --> DV
    FA --> NH
    FA --> ING
    FA --> L70
    FA -.->|policy JSON| BP
    BP -.->|JSON| HTML
:::

---

## 3. Request Flow

::: mermaid
flowchart TD
    START([Request received]) --> VALID{Required params present?}
    VALID -->|No| E400[400 Bad Request]
    VALID -->|Yes| DVCHK[DataverseAccessGuard.CheckPolicyAccess]
    DVCHK -->|User not found| E403a[403 Forbidden]
    DVCHK -->|Access denied| E403b[403 Forbidden]
    DVCHK -->|Granted| SRC{source value}
    SRC -->|ing| MERGE1[NonHeader + Ingenium]
    SRC -->|l70| MERGE2[NonHeader + Life70]
    SRC -->|di / ltc| NHONLY[NonHeader only]
    SRC -->|other| E204[204 No Content]
    MERGE1 --> OK[200 JSON]
    MERGE2 --> OK
    NHONLY --> OK
:::

---

## 4. Authentication (EApp-aligned SPA-token forward model)

| Layer | Who | Token type | Claim checked |
|-------|-----|------------|---------------|
| Browser → Boomi | D365 user (MSAL) | Delegated SPA token | `scp` = `Policy.Read` / `access_as_user` (Boomi validates) |
| Boomi → Function | Same SPA user | Same SPA token forwarded | Easy Auth validates JWT; Function checks **`scp`** |
| Function → Dataverse | Function MI + CallerId | Managed Identity | Dataverse privileges for user resolved from token **`oid`** |

### 4.1 Entra app registration (Function API)

On the **Policy Function API** app registration (same pattern as EApp):

| Item | Value |
|------|-------|
| Exposed scope (delegated) | `Policy.Read` and/or `access_as_user` — used by the D365 SPA |
| Easy Auth | Enable on Function App; validate JWT issued for this API (audience = Policy API app) |

Boomi does **not** obtain a client-credentials token. It validates the SPA JWT and forwards it unchanged.

### 4.3 Boomi gateway validation (browser → Boomi)

Boomi validates the caller at the API gateway, then forwards the SPA token:

| Layer | What Boomi checks | What it proves |
|-------|-------------------|----------------|
| **`x-api-key`** | Header matches configured gateway key | Request is from the D365 integration |
| **`Authorization: Bearer`** | Entra JWT signature, issuer, audience, expiry, **`scp`** | A real signed-in Entra user obtained a delegated token for the Policy API app |

After validation, Boomi calls the Function with the **same SPA Bearer token** and business parameters (`source`, `companyCode`, `policyNo`, `classificationCode`, optional `policyRecordId`). **Do not send `userId`.** Identity for Dataverse impersonation comes from the token **`oid`**.

### 4.2 Function enforcement

`PolicyData.cs` uses `AuthorizationLevel.Anonymous` (Easy Auth at the platform layer) and checks:

1. Caller is authenticated (`HttpContext.User`, `X-MS-CLIENT-PRINCIPAL`, or access-token headers)
2. Caller has delegated scope **`Policy.Read`** or **`access_as_user`** (`FunctionAppRoleAuth.cs`)
3. Token **`oid`** resolves to an enabled Dataverse user (legacy `userId` is ignored for delegated callers)
4. Optional **`policyRecordId`** must be a valid GUID when supplied
5. `DataverseAccessGuard` impersonates resolved user → verifies policy access (direct **Retrieve** when `policyRecordId` is set; otherwise query by policy number)

Locally (no `WEBSITE_SITE_NAME`), auth checks are bypassed and `Policy.Read` is assumed — same as EApp local dev.

---

## 5. API Specification

### 5.1 Endpoint

| Property | Value |
|----------|-------|
| Function name | `getPolicyData` |
| Methods | `GET`, `POST` |
| Authorization | **Easy Auth** + delegated scope **`Policy.Read`** / **`access_as_user`** (SPA token forwarded by Boomi) |
| Response content type | `application/json` |

**Example URL (called by Boomi, not browser):**

```
https://<function-app>.azurewebsites.net/api/getPolicyData?source=ing&companyCode=01&policyNo=123456&classificationCode=ABC&policyRecordId=<policy-record-guid>
Authorization: Bearer <same SPA token>
```

Request must include `Authorization: Bearer <SPA token>` where the token's **`scp`** claim contains `Policy.Read` or `access_as_user`. Empty `roles` is expected.

### 5.2 Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `source` | Yes | Policy source system: `ing`, `l70`, `di`, or `ltc` |
| `companyCode` | Yes | Company code (prepended to policy number for Non-Header API) |
| `policyNo` | Yes | Policy number |
| `classificationCode` | Yes | Classification code (validated; passed through) |
| `policyRecordId` | No | Dataverse policy record GUID — when supplied, guard performs a direct **Retrieve** and cross-checks policy number/company code |

POST body may also supply these fields as JSON properties (merged with query string).

> **Internal resolution:** the Function resolves token **`oid`** → Dataverse `systemuserid` → `systemuser.domainname` (or `DATAVERSE_USERNAME_FIELD`) and passes that UPN/login as `{userName}` to the upstream Non-Header API URL template. Callers do **not** send `userId`.

### 5.3 Source routing

| `source` | Upstream calls | Response shape |
|----------|----------------|----------------|
| `ing` | Non-Header API + Ingenium Tier One | `{"NonHeader":{...},"TIERONE":{...}}` |
| `l70` | Non-Header API + Life70 SOAP | `{"NonHeader":{...},"TIERONE":{...}}` |
| `di` | Non-Header API only | `{"NonHeader":{...}}` |
| `ltc` | Non-Header API only | `{"NonHeader":{...}}` |
| other | — | 204 with error JSON |

### 5.4 HTTP status codes

| Status | Condition |
|--------|-----------|
| `200 OK` | Success (JSON body) |
| `400 Bad Request` | Missing required parameter |
| `401 Unauthorized` | Missing or invalid Bearer token (Easy Auth) |
| `403 Forbidden` | Token lacks **`Policy.Read`** / **`access_as_user`** scope, or Dataverse access denied |
| `204 No Content` | Unknown `source` value |
| `500` | Upstream API failure (wrapped in ERROR JSON when built internally) |

---

## 6. Dataverse Access Guard

Mirrors the EApp impersonation pattern (`DataverseServiceClientFactory` + `CallerId`).

### 6.1 Steps

1. Resolve token **`oid`** → enabled `systemuser` (via `azureactivedirectoryobjectid`).
2. Derive **`userName`** (UPN/login) from the resolved user for upstream API URL substitution.
3. Set `ServiceClient.CallerId` to that user's `systemuserid`.
4. If `DataverseEntity` is configured:
   - When **`policyRecordId`** is supplied: **Retrieve** that record and verify policy number (+ optional company code) match the request.
   - Otherwise: query the policy entity by policy number (+ optional company code).
5. Return `Granted`, `UserNotFound`, or `AccessDenied`.
6. Reset `CallerId = Guid.Empty` in `finally`.

### 6.2 App settings (Dataverse check)

| Setting | Default | Purpose |
|---------|---------|---------|
| `CRM_URL` | *(required)* | Dataverse organization URL |
| `DATAVERSE_USERNAME_FIELD` | `domainname` | Column on `systemuser` used as upstream `{userName}` after oid resolve |
| `DataverseEntity` | *(optional)* | Entity logical name for record-level check |
| `POLICY_DATAVERSE_POLICYNO_FIELD` | `kofc_policynumber` | Policy number column on policy entity |
| `POLICY_DATAVERSE_COMPANYCODE_FIELD` | *(optional)* | Company code column on policy entity |

> If `DataverseEntity` is not set, the guard grants access when the user resolves successfully (user-existence only). If `policyRecordId` is supplied without `DataverseEntity`, the record id is logged and ignored.

---

## 7. Upstream Systems & App Settings

| Setting | Used by | Purpose |
|---------|---------|---------|
| `POLICY_NON_HEADER_API_URL` | `PolicyNonHeaderData` | REST URL template with `{source}`, `{policyNo}`, `{userName}` |
| `INGENIUM_URL` | `PolicyTierOneIngeniumData` | Ingenium production PING URL |
| `INGENIUM_CLONE_URL` | `PolicyTierOneIngeniumData` | Ingenium clone/fallback PING URL |
| `Life70_HB_URL` | `PolicyTierOneLife70Data` | Life70 SOAP endpoint |
| `Life70_HB_CLIENT_ID` | `PolicyTierOneLife70Data` | Basic auth username |
| `Life70_HB_CLIENT_SECRET` | `PolicyTierOneLife70Data` | Basic auth password |

> **Note:** Dataverse uses **Managed Identity**. Life70 uses **Basic auth** (client ID + secret in app settings). Policy Non-Header and Ingenium URLs are configured per environment.

---

## 8. Component Model

| Source file | Responsibility |
|-------------|----------------|
| `Program.cs` | DI host; registers scoped `ServiceClient`, `DataverseAccessGuard`, upstream data services |
| `PolicyData.cs` | HTTP trigger `getPolicyData`; Easy Auth + **Policy.Read** / **access_as_user** scope check, oid resolve, access guard, source routing |
| `Helpers/FunctionAppRoleAuth.cs` | Easy Auth + delegated **`scp`** validation (and optional legacy app-role path) |
| `DataverseServiceClientFactory.cs` | MI + `DefaultAzureCredential` Dataverse connection |
| `DataverseAccessGuard.cs` | oid/user resolve + impersonation + policy record access check |
| `PolicyNonHeaderData.cs` | Calls Policy Non-Header REST API |
| `PolicyTierOneIngeniumData.cs` | Ingenium PING + Headlessflow |
| `PolicyTierOneLife70Data.cs` | Life70 SOAP call |

---

## 9. Client Web Resources (Dynamics 365)

Same **MSAL → Boomi → Function** pattern as EApp. Reuses `kofc_authclient.js` and `kofc_authcallback.html` (shared redirect page; Policy uses pending key `kofc_policy_pending` / `kofc_policy_result`).

| Web resource | Purpose |
|--------------|---------|
| `kofc_authclient.js` | Shared `KOFC.Auth` — MSAL token acquisition |
| `kofc_authcallback.html` | Shared MSAL redirect page (completes Policy pending after sign-in via `callPolicyApi()`) |
| `kofc_msalbrowsermin` | MSAL.js library |
| `kofc_policyClient.js` | `KOFC.Policy` — configure + `ensureAccessToken()` + `getPolicyData()` via Boomi |
| `kofc_policy_details.html` | HTML shell opened from Policy form; loads scripts and renders Non-Header report |
| `kofc_policyDetails.js` | Page logic: env vars, Dataverse record read, Boomi call, visibility profiles |
| `kofc_Policy.js` | Policy form script — `ShowNonHeaderDetails` opens HTML page (Boomi **not** on form) |
| `kofc_PolicyForm-snippet.js` | Copy-paste Non-Header section only (optional alternative to full form merge) |

### 9.1 Public API (`KOFC.Policy`)

```javascript
await loadAuthClient();
await loadPolicyClient();

KOFC.Policy.configure({
    tenantId: "...",
    clientId: "...",
    apiAppId: "...",
    apiKey: "...",          // Boomi x-api-key
    boomiUrl: "https://.../ws/rest/PolicyNonHeader",
    allowRedirect: true
});

var auth = await KOFC.Policy.ensureAccessToken();
if (auth && auth.redirecting) { return; }   // first visit: sign-in only, then page reloads

var result = await KOFC.Policy.getPolicyData({
    source: "ing",
    companyCode: "01",
    policyNo: "123456",
    classificationCode: "ABC",
    policyRecordId: "<policy-record-guid>"   // optional but recommended from form/HTML page
});
// result.redirecting === true when a sign-in redirect is in progress;
// kofc_authcallback.html finishes the Boomi call and stores the result.
// kofc_policyDetails.html init() calls KOFC.Policy.consumePendingResult().
```

### 9.2 Boomi request (from browser)

| Header / param | Value |
|----------------|-------|
| `Authorization` | `Bearer <SPA token>` (delegated; validated at Boomi gateway, then forwarded) |
| `x-api-key` | Boomi API key (from env var `kofc_PolicyApiKey`) |
| Query / body | `source`, `companyCode`, `policyNo`, `classificationCode`, optional **`policyRecordId`** |

Boomi forwards to `getPolicyData` with the **same SPA Bearer token** — not a Boomi client-credentials token and not an Azure function key. **Do not send `userId`.**

### 9.3 Environment variables (D365)

Read by `kofc_policyDetails.js` in the HTML page (via parent Xrm context):

| Schema name | Purpose |
|-------------|---------|
| `kofc_PolicyTenantId` | Entra tenant ID |
| `kofc_PolicyClientId` | SPA client ID |
| `kofc_PolicyApiAppId` | Function API app ID (scope `api://<id>/access_as_user`) |
| `kofc_PolicyApiKey` | Boomi x-api-key |
| `kofc_PolicyBoomiUrl` | Boomi REST URL for Policy integration |

> If Policy and EApp share the same Entra app and Boomi host, you may reuse the EApp env vars — but separate Policy vars keep deployments independent.

### 9.4 Redirect auto-complete (like EApp)

1. `kofc_policyDetails.js` **warms the MSAL token** (`KOFC.Policy.ensureAccessToken`) before Boomi. First visit may redirect with no pending API call; after return the token is in localStorage and the page calls Boomi.
2. If `getPolicyData` still needs a redirect, it persists params to `kofc_policy_pending`.
3. `kofc_authcallback.html` reads the token, calls Boomi (`callPolicyApi()`), stores JSON in `kofc_policy_result`.
4. User returns to **`kofc_policy_details.html`** — **`init()`** calls `KOFC.Policy.consumePendingResult()` (if any) and renders without a second button click.

### 9.5 Policy form integration

Ribbon/command: **`ShowNonHeaderDetails`** (optional 2nd arg `isBoomi` kept for backward compatibility; ignored).

1. Form validates policy fields.
2. Opens `kofc_policy_details.html` in a new tab with `etn` + `id` query params.
3. HTML page reads the policy record from Dataverse, calls Boomi with SPA token + **`policyRecordId`** (from URL record id). Function resolves user from token `oid`.

### 9.6 Multi-day sign-in (MSAL localStorage + refresh token)

Stay signed in for days with the **SPA cache**, not Function Easy Auth cookies:

- `kofc_authclient.js` uses `cacheLocation: "localStorage"`. After the access token expires (~1 hour), `acquireTokenSilent` uses the **refresh token**.
- **Optional Entra settings** (tenant / Conditional Access): sign-in frequency and refresh-token lifetime.
- **Do not** try to make Easy Auth session cookies or MSAL `storeAuthStateInCookie` last for days. Easy Auth only validates the inbound JWT per request. `storeAuthStateInCookie` is short-lived CSRF / auth-state for iframe/Safari redirects.
- Form OnLoad calls `ensureAccessToken({ interactive: false })` to refresh an existing cache without a surprise redirect.

---

## 10. Deployment Checklist

### 10.1 Azure Function App

1. Deploy `KOFC-FA-PolicyNonHeader-TierOne` (Zip Deploy or pipeline).
2. Enable **system-assigned Managed Identity**.
3. Create **Application User** in Dataverse linked to the MI.
4. Assign security role with **Act on Behalf Of** + read on policy entity (if record check enabled).
5. Enable **Easy Auth** on the Function App (validate JWT for the Policy API app registration / audience).
6. Expose delegated scope **`Policy.Read`** (and/or `access_as_user`) on the API registration.
7. Configure app settings: `CRM_URL`, upstream API URLs, Life70 credentials, optional `POLICY_DATAVERSE_*` settings.

### 10.2 Dynamics 365 web resources

1. Upload `kofc_authclient.js`, `kofc_authcallback.html`, `kofc_msalbrowsermin` (shared with EApp if already deployed).
2. Upload `kofc_policyClient.js`, `kofc_policy_details.html`, `kofc_policyDetails.js` (Script/HTML as appropriate).
3. Update **`kofc_Policy.js`** — replace legacy Non-Header custom page with `ShowNonHeaderDetails` / `openPolicyDetailsHtmlPage` (see `kofc_PolicyForm-snippet.js`).
4. Register `kofc_authcallback.html` in Entra as SPA redirect URI (if not already).
5. Create environment variables: `kofc_PolicyTenantId`, `kofc_PolicyClientId`, `kofc_PolicyApiAppId`, `kofc_PolicyApiKey`, `kofc_PolicyBoomiUrl`.

### 10.3 Boomi process

1. Expose REST endpoint matching `kofc_PolicyBoomiUrl`.
2. Accept `Authorization: Bearer` (SPA delegated token) + `x-api-key` + policy query/body params from D365 (optional `policyRecordId`).
3. Validate SPA JWT; **do not** obtain Boomi client-credentials.
4. Forward the **same SPA Bearer token** to Azure Function `getPolicyData` (no `userId`, no function key).
5. Return Function JSON response to the browser.

### 10.4 Smoke test

1. Open a Policy record → click **Non-Header Details** (or equivalent ribbon command).
2. Confirm HTML page loads, calls Boomi, and renders policy data.
3. Confirm **200** JSON or expected **403** when user lacks Dataverse access.
4. First load may redirect to sign-in (token warm-up); after return, Boomi is called only once a token exists. Callback should auto-complete without a second click.

---

## 11. Test Scenarios

| # | Scenario | Expected |
|---|----------|----------|
| 1 | Valid params + user with policy access, `source=ing` | 200 merged JSON |
| 2 | Valid params + user with policy access, `source=di` | 200 NonHeader only |
| 3 | SPA token without `oid` / user not in Dataverse | 401/403 |
| 4 | User cannot read policy record (or `policyRecordId` mismatch) | 403 Access denied |
| 5 | Unknown `source` | 204 |
| 6 | SPA token missing **Policy.Read** / **access_as_user** scope | 403 |
| 7 | Invalid/missing Boomi x-api-key | 401/403 from Boomi |
| 8 | Boomi fails to forward SPA Authorization header | 401 from Easy Auth / Function |
| 9 | First-time user (no MSAL cache) | Token warm-up redirect → page reload → Boomi with cached token (no first-click 401) |
---

## 12. Dependencies

| Package | Version |
|---------|---------|
| `Microsoft.Azure.Functions.Worker` | 2.51.0 |
| `Azure.Identity` | 1.17.1 |
| `Microsoft.PowerPlatform.Dataverse.Client` | 1.2.10 |
| `Newtonsoft.Json` | (via models) |

---

## 13. Related documentation

- `docs/KOFC-EApp-SSO-Architecture.wiki.md` — EApp SSO (same MSAL + Boomi client pattern)
- `docs/KOFC-ProxyBlobFunction-Architecture.wiki.md` — Proxy Blob Function (same MSAL + Boomi pattern)
- `webresources/eapp-boomi-button/kofc_authclient.js` — shared KOFC.Auth library
- `webresources/eapp-boomi-button/kofc_authcallback.html` — shared MSAL callback (`callPolicyApi` + EApp `callApi`)
- `webresources/policy-nonheader/kofc_policyClient.js` — KOFC.Policy library
- `webresources/policy-nonheader/kofc_policyDetails.js` — HTML page orchestration
- `webresources/policy-nonheader/kofc_Policy.js` — Policy form Non-Header button
