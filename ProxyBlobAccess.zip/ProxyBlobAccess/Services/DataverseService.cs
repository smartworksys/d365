using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using GetBlobSasUrl.Models;

namespace GetBlobSasUrl.Services;

public class DataverseService
{
    private readonly ServiceClient _serviceClient;
    private readonly ILogger<DataverseService> _logger;

    public DataverseService(string clientId, string clientSecret, string tenantId, string dataverseUrl, ILogger<DataverseService> logger)
    {
        _logger = logger;
        
        var connectionString = $"AuthType=ClientSecret;Url={dataverseUrl};ClientId={clientId};ClientSecret={clientSecret}";
        _serviceClient = new ServiceClient(connectionString);
        
        if (!_serviceClient.IsReady)
        {
            throw new InvalidOperationException($"Failed to connect to Dataverse: {_serviceClient.LastError}");
        }
        
        _logger.LogInformation("Successfully connected to Dataverse");
    }

    public async Task<AccessResult> GetRelatedContactAsync(Guid timelineRecordId)
    {
        try
        {
            _logger.LogInformation("Retrieving related contact for timeline record {TimelineRecordId}", timelineRecordId);

            // Query the timeline record to get the related contact
            var timelineQuery = new QueryExpression("msdyn_timeline")
            {
                ColumnSet = new ColumnSet("msdyn_contactid", "msdyn_blobcontainername", "msdyn_blobname"),
                Criteria = new FilterExpression(LogicalOperator.And)
                {
                    Conditions =
                    {
                        new ConditionExpression("msdyn_timelineid", ConditionOperator.Equal, timelineRecordId)
                    }
                }
            };

            var timelineResults = await Task.Run(() => _serviceClient.RetrieveMultiple(timelineQuery));
            
            if (timelineResults.Entities.Count == 0)
            {
                _logger.LogWarning("Timeline record {TimelineRecordId} not found", timelineRecordId);
                return new AccessResult
                {
                    HasAccess = false,
                    ErrorMessage = "Timeline record not found"
                };
            }

            var timelineRecord = timelineResults.Entities.First();
            var contactId = timelineRecord.GetAttributeValue<EntityReference>("msdyn_contactid")?.Id;
            var containerName = timelineRecord.GetAttributeValue<string>("msdyn_blobcontainername");
            var blobName = timelineRecord.GetAttributeValue<string>("msdyn_blobname");

            if (contactId == null)
            {
                _logger.LogWarning("No contact associated with timeline record {TimelineRecordId}", timelineRecordId);
                return new AccessResult
                {
                    HasAccess = false,
                    ErrorMessage = "No contact associated with timeline record"
                };
            }

            if (string.IsNullOrEmpty(containerName) || string.IsNullOrEmpty(blobName))
            {
                _logger.LogWarning("Missing blob information for timeline record {TimelineRecordId}", timelineRecordId);
                return new AccessResult
                {
                    HasAccess = false,
                    ErrorMessage = "Missing blob information"
                };
            }

            _logger.LogInformation("Found contact {ContactId} with blob {ContainerName}/{BlobName} for timeline record {TimelineRecordId}", 
                contactId, containerName, blobName, timelineRecordId);

            return new AccessResult
            {
                HasAccess = true,
                ContactId = contactId.Value,
                ContainerName = containerName,
                BlobName = blobName
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving related contact for timeline record {TimelineRecordId}", timelineRecordId);
            return new AccessResult
            {
                HasAccess = false,
                ErrorMessage = "Error retrieving timeline record information"
            };
        }
    }

    public async Task<bool> HasAccessToContactAsync(Guid userOid, Guid contactId)
    {
        try
        {
            _logger.LogInformation("Checking access for user {UserOid} to contact {ContactId}", userOid, contactId);

            // Create a RetrievePrincipalAccessRequest to check user access
            var accessRequest = new RetrievePrincipalAccessRequest
            {
                Principal = new EntityReference("systemuser", userOid),
                Target = new EntityReference("contact", contactId)
            };

            var accessResponse = await Task.Run(() => 
                (RetrievePrincipalAccessResponse)_serviceClient.Execute(accessRequest));

            var hasAccess = accessResponse.AccessRights != AccessRights.None;
            
            _logger.LogInformation("User {UserOid} access to contact {ContactId}: {HasAccess}", 
                userOid, contactId, hasAccess);

            return hasAccess;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error checking access for user {UserOid} to contact {ContactId}", userOid, contactId);
            return false;
        }
    }

    public void Dispose()
    {
        _serviceClient?.Dispose();
    }
}
