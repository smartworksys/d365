using System.Net;
using System.Security.Claims;
using System.Text.Json;
using Azure.Storage.Blobs;
using Azure.Storage.Sas;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using GetBlobSasUrl.Models;
using GetBlobSasUrl.Services;

namespace GetBlobSasUrl;

public class GetBlobSasUrl
{
    private readonly ILogger<GetBlobSasUrl> _logger;
    private readonly BlobServiceClient _blobServiceClient;
    private readonly DataverseService _dataverseService;

    public GetBlobSasUrl(ILogger<GetBlobSasUrl> logger, BlobServiceClient blobServiceClient, DataverseService dataverseService)
    {
        _logger = logger;
        _blobServiceClient = blobServiceClient;
        _dataverseService = dataverseService;
    }

    [Function("GetBlobSasUrl")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get")] HttpRequestData req)
    {
        try
        {
            // Extract recordId from query parameters
            var query = System.Web.HttpUtility.ParseQueryString(req.Url.Query);
            var recordIdString = query["recordId"];

            if (string.IsNullOrEmpty(recordIdString) || !Guid.TryParse(recordIdString, out var recordId))
            {
                _logger.LogWarning("Invalid or missing recordId parameter");
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest, "Invalid or missing recordId parameter");
            }

            // Get user identity from Azure AD token
            var authHeader = req.Headers.FirstOrDefault(h => h.Key.Equals("Authorization", StringComparison.OrdinalIgnoreCase));
            if (authHeader.Value == null || !authHeader.Value.Any())
            {
                _logger.LogWarning("No Authorization header found in request");
                return await CreateErrorResponse(req, HttpStatusCode.Unauthorized, "Authentication required");
            }

            // Extract oid claim from JWT token
            var userOid = ExtractOidFromToken(authHeader.Value.First());
            if (userOid == null)
            {
                _logger.LogWarning("No valid oid claim found in user identity");
                return await CreateErrorResponse(req, HttpStatusCode.Unauthorized, "Invalid user identity");
            }

            _logger.LogInformation("Processing request for recordId: {RecordId}, userOid: {UserOid}", recordId, userOid);

            // Get related contact and blob information
            var accessResult = await _dataverseService.GetRelatedContactAsync(recordId);
            
            if (!accessResult.HasAccess)
            {
                _logger.LogWarning("Failed to retrieve contact information for recordId: {RecordId}, Error: {Error}", 
                    recordId, accessResult.ErrorMessage);
                
                var statusCode = accessResult.ErrorMessage?.Contains("not found") == true 
                    ? HttpStatusCode.NotFound 
                    : HttpStatusCode.InternalServerError;
                
                return await CreateErrorResponse(req, statusCode, accessResult.ErrorMessage ?? "Failed to retrieve contact information");
            }

            // Check if user has access to the contact
            var hasAccess = await _dataverseService.HasAccessToContactAsync(userOid.Value, accessResult.ContactId!.Value);
            
            if (!hasAccess)
            {
                _logger.LogWarning("User {UserOid} does not have access to contact {ContactId}", userOid, accessResult.ContactId);
                return await CreateErrorResponse(req, HttpStatusCode.Forbidden, "Access denied to the requested resource");
            }

            // Generate SAS URL
            var sasUrl = await GenerateSasUrlAsync(accessResult.ContainerName!, accessResult.BlobName!);
            
            if (string.IsNullOrEmpty(sasUrl))
            {
                _logger.LogError("Failed to generate SAS URL for container: {ContainerName}, blob: {BlobName}", 
                    accessResult.ContainerName, accessResult.BlobName);
                return await CreateErrorResponse(req, HttpStatusCode.InternalServerError, "Failed to generate SAS URL");
            }

            _logger.LogInformation("Successfully generated SAS URL for user {UserOid}, recordId: {RecordId}", userOid, recordId);

            // Return success response
            var response = req.CreateResponse(HttpStatusCode.OK);
            response.Headers.Add("Content-Type", "application/json");
            
            var responseBody = new SasUrlResponse { SasUrl = sasUrl };
            await response.WriteStringAsync(System.Text.Json.JsonSerializer.Serialize(responseBody));
            
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error processing request");
            return await CreateErrorResponse(req, HttpStatusCode.InternalServerError, "An unexpected error occurred");
        }
    }

    private Guid? ExtractOidFromToken(string authHeader)
    {
        try
        {
            // Remove "Bearer " prefix
            var token = authHeader.StartsWith("Bearer ") ? authHeader.Substring(7) : authHeader;
            
            // Parse JWT token (simplified - in production, validate signature)
            var parts = token.Split('.');
            if (parts.Length != 3) return null;
            
            // Decode payload (add padding if needed)
            var payload = parts[1];
            var padding = payload.Length % 4;
            if (padding != 0)
                payload += new string('=', 4 - padding);
            
            var payloadBytes = Convert.FromBase64String(payload);
            var payloadJson = System.Text.Encoding.UTF8.GetString(payloadBytes);
            
            using var doc = JsonDocument.Parse(payloadJson);
            if (doc.RootElement.TryGetProperty("oid", out var oidElement))
            {
                if (Guid.TryParse(oidElement.GetString(), out var oid))
                {
                    return oid;
                }
            }
            
            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error extracting OID from token");
            return null;
        }
    }

    private async Task<string> GenerateSasUrlAsync(string containerName, string blobName)
    {
        try
        {
            var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
            var blobClient = containerClient.GetBlobClient(blobName);

            // Check if blob exists
            var blobExists = await blobClient.ExistsAsync();
            if (!blobExists.Value)
            {
                _logger.LogWarning("Blob {BlobName} does not exist in container {ContainerName}", blobName, containerName);
                return string.Empty;
            }

            // Generate SAS token with 15-minute expiry
            var sasBuilder = new BlobSasBuilder
            {
                BlobContainerName = containerName,
                BlobName = blobName,
                Resource = "b", // blob
                ExpiresOn = DateTimeOffset.UtcNow.AddMinutes(15)
            };
            
            sasBuilder.SetPermissions(BlobSasPermissions.Read);

            // Get the account key for signing
            var accountKey = GetAccountKey();
            if (string.IsNullOrEmpty(accountKey))
            {
                _logger.LogError("Failed to retrieve account key for SAS generation");
                return string.Empty;
            }

            var sasToken = sasBuilder.ToSasQueryParameters(new Azure.Storage.StorageSharedKeyCredential(
                _blobServiceClient.AccountName, accountKey)).ToString();

            return $"{blobClient.Uri}?{sasToken}";
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generating SAS URL for container: {ContainerName}, blob: {BlobName}", containerName, blobName);
            return string.Empty;
        }
    }

    private string GetAccountKey()
    {
        try
        {
            // For production, you might want to store the account key in Key Vault as well
            // For now, we'll extract it from the connection string
            var connectionString = Environment.GetEnvironmentVariable("Blob--ConnectionString");
            if (string.IsNullOrEmpty(connectionString))
            {
                return string.Empty;
            }

            // Parse connection string to extract account key
            var parts = connectionString.Split(';');
            var accountKeyPart = parts.FirstOrDefault(p => p.StartsWith("AccountKey="));
            return accountKeyPart?.Split('=')[1] ?? string.Empty;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving account key");
            return string.Empty;
        }
    }

    private async Task<HttpResponseData> CreateErrorResponse(HttpRequestData req, HttpStatusCode statusCode, string message)
    {
        var response = req.CreateResponse(statusCode);
        response.Headers.Add("Content-Type", "application/json");
        
        var errorResponse = new { error = message };
        await response.WriteStringAsync(System.Text.Json.JsonSerializer.Serialize(errorResponse));
        
        return response;
    }
}
