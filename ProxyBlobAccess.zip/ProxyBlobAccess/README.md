# GetBlobSasUrl Azure Function App

A secure Azure Function App that generates SAS URLs for Dataverse timeline blob attachments with proper access control validation.

## 🎯 Overview

This Azure Function App provides a secure way to generate time-limited SAS URLs for blob attachments associated with Dataverse timeline records. It validates user access permissions before generating the SAS URL, ensuring only authorized users can access the blob content.

## 🏗️ Architecture

- **Azure Function App** (.NET 8 Isolated Process)
- **Azure Key Vault** for secure credential storage
- **Microsoft Dataverse** for data access and permission validation
- **Azure Blob Storage** for file storage
- **Azure AD** for authentication

## 📋 Prerequisites

- Azure subscription
- Azure CLI installed and configured
- .NET 8 SDK
- Visual Studio Code or Visual Studio
- Azure Functions Core Tools v4

## 🚀 Setup Instructions

### 1. Azure Key Vault Setup

1. **Create Azure Key Vault:**
   ```bash
   az keyvault create --name <your-key-vault-name> --resource-group <your-resource-group> --location <your-location>
   ```

2. **Add required secrets to Key Vault:**
   ```bash
   # Dataverse Service Principal credentials
   az keyvault secret set --vault-name <your-key-vault-name> --name "Dataverse--ClientId" --value "<your-client-id>"
   az keyvault secret set --vault-name <your-key-vault-name> --name "Dataverse--ClientSecret" --value "<your-client-secret>"
   az keyvault secret set --vault-name <your-key-vault-name> --name "Dataverse--TenantId" --value "<your-tenant-id>"
   az keyvault secret set --vault-name <your-key-vault-name> --name "Dataverse--Url" --value "<your-dataverse-url>"
   
   # Blob Storage credentials
   az keyvault secret set --vault-name <your-key-vault-name> --name "Blob--ConnectionString" --value "<your-blob-connection-string>"
   az keyvault secret set --vault-name <your-key-vault-name> --name "Blob--ContainerName" --value "<your-container-name>"
   ```

### 2. Azure Function App Setup

1. **Create Function App:**
   ```bash
   az functionapp create --resource-group <your-resource-group> --consumption-plan-location <your-location> --runtime dotnet-isolated --runtime-version 8 --functions-version 4 --name <your-function-app-name> --storage-account <your-storage-account>
   ```

2. **Enable Managed Identity:**
   ```bash
   az functionapp identity assign --name <your-function-app-name> --resource-group <your-resource-group>
   ```

3. **Grant Key Vault access to Function App:**
   ```bash
   # Get the Function App's managed identity principal ID
   PRINCIPAL_ID=$(az functionapp identity show --name <your-function-app-name> --resource-group <your-resource-group> --query principalId -o tsv)
   
   # Grant access to Key Vault
   az keyvault set-policy --name <your-key-vault-name> --object-id $PRINCIPAL_ID --secret-permissions get list
   ```

4. **Configure Function App settings:**
   ```bash
   az functionapp config appsettings set --name <your-function-app-name> --resource-group <your-resource-group> --settings "KeyVaultUri=https://<your-key-vault-name>.vault.azure.net/"
   ```

### 3. Azure AD App Registration Setup

1. **Create App Registration:**
   ```bash
   az ad app create --display-name "Dataverse Service Principal" --sign-in-audience AzureADMyOrg
   ```

2. **Create Service Principal:**
   ```bash
   az ad sp create --id <app-id-from-previous-step>
   ```

3. **Generate Client Secret:**
   ```bash
   az ad app credential reset --id <app-id> --display-name "Dataverse Secret"
   ```

4. **Grant Dataverse API permissions:**
   - Navigate to Azure Portal > App Registrations > Your App > API Permissions
   - Add permissions for Microsoft Dataverse:
     - `user_impersonation` (Delegated)
     - `crm.readwrite.all` (Application) - if needed for broader access

### 4. Dataverse Security Role Setup

1. **Create Security Role in Dataverse:**
   - Navigate to Power Platform Admin Center
   - Go to your environment > Settings > Security > Security Roles
   - Create a new security role or modify existing one
   - Grant appropriate permissions for:
     - Timeline records (`msdyn_timeline`)
     - Contact records (`contact`)
     - System User records (`systemuser`)

2. **Assign Security Role to Service Principal:**
   - In Dataverse, go to Settings > Security > Users
   - Find your Service Principal user
   - Assign the appropriate security role

### 5. Blob Storage Setup

1. **Create Storage Account:**
   ```bash
   az storage account create --name <your-storage-account> --resource-group <your-resource-group> --location <your-location> --sku Standard_LRS
   ```

2. **Create Container:**
   ```bash
   az storage container create --name <your-container-name> --account-name <your-storage-account>
   ```

3. **Grant Function App access to Blob Storage:**
   ```bash
   # Assign Storage Blob Data Reader role to Function App's managed identity
   az role assignment create --assignee $PRINCIPAL_ID --role "Storage Blob Data Reader" --scope "/subscriptions/<subscription-id>/resourceGroups/<resource-group>/providers/Microsoft.Storage/storageAccounts/<storage-account>"
   ```

### 6. Azure AD Authentication Setup

1. **Enable Easy Auth on Function App:**
   ```bash
   az functionapp auth update --name <your-function-app-name> --resource-group <your-resource-group> --enabled true --action LoginWithAzureActiveDirectory --aad-client-id <your-aad-client-id>
   ```

2. **Configure Authentication Provider:**
   - Navigate to Azure Portal > Function App > Authentication
   - Add Microsoft identity provider
   - Configure with your Azure AD tenant

## 🔧 Local Development

1. **Clone and build the project:**
   ```bash
   git clone <your-repo-url>
   cd GetBlobSasUrl
   dotnet build
   ```

2. **Configure local settings:**
   - Update `local.settings.json` with your Key Vault URI
   - Ensure you have Azure CLI logged in with appropriate permissions

3. **Run locally:**
   ```bash
   func start
   ```

## 📡 API Usage

### Endpoint
```
GET /api/GetBlobSasUrl?recordId={timeline-record-guid}
```

### Headers
```
Authorization: Bearer <azure-ad-token>
```

### Response Examples

**Success (200 OK):**
```json
{
  "sasUrl": "https://yourstorageaccount.blob.core.windows.net/container/blob?sv=2021-06-08&se=2024-01-01T12%3A00%3A00Z&sr=b&sp=r&sig=..."
}
```

**Error Responses:**
```json
// 400 Bad Request
{
  "error": "Invalid or missing recordId parameter"
}

// 401 Unauthorized
{
  "error": "Authentication required"
}

// 403 Forbidden
{
  "error": "Access denied to the requested resource"
}

// 404 Not Found
{
  "error": "Timeline record not found"
}

// 500 Internal Server Error
{
  "error": "An unexpected error occurred"
}
```

## 🔒 Security Features

- **Service Principal Authentication**: Uses Azure AD Service Principal for Dataverse access
- **Key Vault Integration**: All credentials stored securely in Azure Key Vault
- **Managed Identity**: Function App uses Managed Identity to access Key Vault
- **Access Validation**: Validates user permissions before generating SAS URLs
- **Short-lived SAS Tokens**: SAS URLs expire after 15 minutes
- **Read-only Access**: SAS tokens only provide read permissions
- **Comprehensive Logging**: All operations logged for audit purposes

## 🧪 Testing

### Test Scenarios

1. **Valid Request**: User with access to timeline record
2. **Invalid Record ID**: Non-existent or malformed record ID
3. **Unauthorized User**: User without access to related contact
4. **Missing Authentication**: Request without valid Azure AD token
5. **Missing Blob**: Timeline record exists but blob doesn't exist

### Test Data Setup

1. Create a timeline record in Dataverse with:
   - Associated contact
   - Valid blob container and blob name
   - User with appropriate security role

2. Test with different user contexts to verify access control

## 📊 Monitoring and Logging

- **Application Insights**: Integrated for telemetry and logging
- **Structured Logging**: All operations logged with relevant context
- **Error Tracking**: Comprehensive error handling and logging
- **Performance Monitoring**: Track function execution times and resource usage

## 🚨 Troubleshooting

### Common Issues

1. **Key Vault Access Denied**
   - Verify Function App's Managed Identity has Key Vault access
   - Check Key Vault access policies

2. **Dataverse Connection Failed**
   - Verify Service Principal credentials in Key Vault
   - Check Dataverse API permissions
   - Ensure Service Principal has appropriate security role

3. **Blob Access Denied**
   - Verify Function App's Managed Identity has Storage Blob Data Reader role
   - Check blob exists and container permissions

4. **Authentication Issues**
   - Verify Easy Auth configuration
   - Check Azure AD token claims
   - Ensure user has appropriate Dataverse security role

### Debug Steps

1. Check Function App logs in Azure Portal
2. Verify Key Vault secrets are accessible
3. Test Dataverse connection independently
4. Validate blob storage access
5. Review Azure AD token claims

## 📝 Deployment

### Manual Deployment
```bash
func azure functionapp publish <your-function-app-name>
```

### CI/CD Pipeline
Consider setting up Azure DevOps or GitHub Actions pipeline for automated deployment.

## 🔄 Maintenance

- **Regular Security Reviews**: Review access permissions and security roles
- **Credential Rotation**: Rotate Service Principal secrets periodically
- **Monitoring**: Monitor function performance and error rates
- **Updates**: Keep NuGet packages and dependencies updated

## 📞 Support

For issues or questions:
1. Check the troubleshooting section
2. Review Azure Function App logs
3. Verify all prerequisites and setup steps
4. Contact your Azure administrator for infrastructure issues
