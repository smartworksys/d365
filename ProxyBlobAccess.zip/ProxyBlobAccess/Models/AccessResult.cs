namespace GetBlobSasUrl.Models;

public class AccessResult
{
    public bool HasAccess { get; set; }
    public string? ErrorMessage { get; set; }
    public Guid? ContactId { get; set; }
    public string? ContainerName { get; set; }
    public string? BlobName { get; set; }
}

public class SasUrlResponse
{
    public string SasUrl { get; set; } = string.Empty;
}
