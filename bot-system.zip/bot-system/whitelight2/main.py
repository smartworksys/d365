"""
Whitelight 2.0 - Main Entry Point
Orchestrates data loading, strategy execution, backtesting, and visualization.
"""

import os
import sys
import yaml
import pandas as pd
import numpy as np
import logging
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Import custom modules
from data.data_fetcher import DataFetcher
from core.indicators import calculate_all_indicators
from core.regime import RegimeDetector
from core.subsystems import TradingSubsystems
from core.allocator import PositionAllocator
from core.risk_controller import RiskController
from core.backtester import Backtester
from analytics.performance import PerformanceAnalyzer
from analytics.visualize import Visualizer

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def load_config(config_path: str = 'config/settings.yaml') -> dict:
    """
    Load configuration from YAML file.
    
    Args:
        config_path: Path to configuration file
        
    Returns:
        Configuration dictionary
    """
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    return config


def main():
    """Main execution function."""
    logger.info("=" * 80)
    logger.info("Whitelight 2.0 - Adaptive Dual-Leverage Trading Framework")
    logger.info("=" * 80)
    
    # Load configuration
    config = load_config()
    logger.info("Configuration loaded successfully")
    
    # Initialize components
    data_fetcher = DataFetcher(config)
    regime_detector = RegimeDetector(config['strategy']['adx_threshold'])
    subsystems = TradingSubsystems(config)
    allocator = PositionAllocator(config)
    risk_controller = RiskController(config)
    backtester = Backtester(config)
    performance_analyzer = PerformanceAnalyzer()
    visualizer = Visualizer()
    
    logger.info("Components initialized")
    
    # Get data
    logger.info("Fetching data...")
    start_date = config['backtesting']['start_date']
    end_date = config['backtesting'].get('end_date')
    
    try:
        tqqq_data, sqqq_data = data_fetcher.get_aligned_data(start_date, end_date)
        logger.info(f"Fetched {len(tqqq_data)} days of data")
        logger.info(f"Date range: {tqqq_data.index[0].date()} to {tqqq_data.index[-1].date()}")
    except Exception as e:
        logger.error(f"Failed to fetch data: {e}")
        logger.info("Attempting to fetch NDX data for simulation...")
        
        # Fallback: fetch NDX and simulate TQQQ/SQQQ
        ndx_data = data_fetcher.fetch_data('^NDX', start_date, end_date)
        tqqq_data = data_fetcher.simulate_leveraged_etf(ndx_data, leverage=3.0)
        sqqq_data = data_fetcher.simulate_leveraged_etf(ndx_data, leverage=-3.0)
        logger.info(f"Simulated TQQQ/SQQQ data from NDX")
    
    # Calculate indicators
    logger.info("Calculating indicators...")
    strategy_config = config['strategy']
    tqqq_data = calculate_all_indicators(
        tqqq_data,
        ma_short=strategy_config['ma_short'],
        ma_long=strategy_config['ma_long'],
        bb_period=strategy_config['bb_period'],
        bb_std=strategy_config['bb_std'],
        adx_period=strategy_config['adx_period'],
        vol_lookback=strategy_config['vol_lookback']
    )
    
    # Copy indicators to SQQQ (assume same market)
    sqqq_data = sqqq_data.copy()
    for col in ['rsi', 'ma_short', 'ma_long', 'dist_ma_short', 'dist_ma_long',
                'bb_upper', 'bb_middle', 'bb_lower', 'volatility', 'adx']:
        if col in tqqq_data.columns:
            sqqq_data[col] = tqqq_data[col].reindex(sqqq_data.index, method='ffill')
    
    # Detect regime
    logger.info("Detecting market regimes...")
    tqqq_data = regime_detector.add_regime_to_data(tqqq_data)
    regime_counts = regime_detector.get_regime_counts(tqqq_data['regime'])
    logger.info(f"Regime distribution: {regime_counts}")
    
    # Generate subsystem signals
    logger.info("Generating subsystem signals...")
    subsystem_signals = subsystems.generate_all_signals(tqqq_data, sqqq_data)
    logger.info(f"Generated signals for {len(subsystem_signals.columns)} subsystems")
    
    # Allocate positions
    logger.info("Allocating positions...")
    positions = allocator.allocate_positions(
        subsystem_signals,
        tqqq_data['volatility']
    )
    exposure_stats = allocator.get_exposure_stats(positions)
    logger.info(f"Average leverage: {exposure_stats['avg_leverage']:.2f}")
    logger.info(f"Long: {exposure_stats['long_percentage']:.1f}% | "
               f"Short: {exposure_stats['short_percentage']:.1f}% | "
               f"Neutral: {exposure_stats['neutral_percentage']:.1f}%")
    
    # Run backtest
    logger.info("Running backtest...")
    backtest_results = backtester.run_backtest(tqqq_data, sqqq_data, positions)
    
    # Apply risk controls
    logger.info("Applying risk controls...")
    adjusted_positions, risk_adjustment = risk_controller.apply_risk_controls(
        positions, backtest_results['equity']
    )
    
    # Re-run backtest with adjusted positions
    backtest_results = backtester.run_backtest(tqqq_data, sqqq_data, adjusted_positions)
    
    # Calculate metrics
    logger.info("Calculating performance metrics...")
    
    # Get benchmark (NDX)
    benchmark_data = data_fetcher.fetch_data('^NDX', start_date, end_date)
    benchmark_returns = benchmark_data['close'].pct_change().fillna(0)
    benchmark_aligned = benchmark_returns.loc[backtest_results.index]
    
    metrics = backtester.calculate_metrics(backtest_results, benchmark_aligned)
    
    # Print summary
    logger.info("")
    logger.info("=" * 80)
    logger.info("BACKTEST RESULTS")
    logger.info("=" * 80)
    logger.info(f"Total Return: {metrics['total_return']:.2%}")
    logger.info(f"CAGR: {metrics['cagr']:.2%}")
    logger.info(f"Sharpe Ratio: {metrics['sharpe_ratio']:.2f}")
    logger.info(f"Sortino Ratio: {metrics['sortino_ratio']:.2f}")
    logger.info(f"Max Drawdown: {metrics['max_drawdown']:.2%}")
    logger.info(f"Calmar Ratio: {metrics['calmar_ratio']:.2f}")
    logger.info(f"Win Rate: {metrics['win_rate']:.1f}%")
    if 'beta' in metrics:
        logger.info(f"Beta (vs NDX): {metrics['beta']:.2f}")
        logger.info(f"Alpha (vs NDX): {metrics['alpha']:.2%}")
    
    logger.info("=" * 80)
    
    # Generate visualizations
    logger.info("Generating visualizations...")
    
    # Create output directory
    output_dir = Path('output')
    output_dir.mkdir(exist_ok=True)
    
    # Plot 1: Equity curve
    regimes_for_viz = tqqq_data['regime'].loc[backtest_results.index]
    fig1 = visualizer.plot_equity_curve(
        backtest_results['equity'],
        regimes_for_viz,
        benchmark=tqqq_data['close'].reindex(backtest_results.index)
    )
    fig1.savefig(output_dir / 'equity_curve.png', dpi=300, bbox_inches='tight')
    logger.info("Saved: equity_curve.png")
    
    # Plot 2: Drawdown
    fig2 = visualizer.plot_drawdown(backtest_results['drawdown'])
    fig2.savefig(output_dir / 'drawdown.png', dpi=300, bbox_inches='tight')
    logger.info("Saved: drawdown.png")
    
    # Plot 3: Leverage over time
    fig3 = visualizer.plot_leverage_over_time(positions)
    fig3.savefig(output_dir / 'leverage.png', dpi=300, bbox_inches='tight')
    logger.info("Saved: leverage.png")
    
    # Plot 4: Monthly returns heatmap
    monthly_returns = backtester.get_monthly_returns(backtest_results)
    fig4 = visualizer.plot_monthly_returns_heatmap(monthly_returns)
    fig4.savefig(output_dir / 'monthly_heatmap.png', dpi=300, bbox_inches='tight')
    logger.info("Saved: monthly_heatmap.png")
    
    # Plot 5: Metrics summary
    fig5 = visualizer.plot_metrics_summary(metrics)
    fig5.savefig(output_dir / 'metrics.png', dpi=300, bbox_inches='tight')
    logger.info("Saved: metrics.png")
    
    # Save results to CSV
    backtest_results.to_csv(output_dir / 'backtest_results.csv')
    logger.info("Saved: backtest_results.csv")
    
    # Save metrics to JSON
    import json
    metrics_for_json = {k: (float(v) if isinstance(v, (np.number, pd.Timestamp)) else str(v))
                       for k, v in metrics.items()}
    with open(output_dir / 'metrics.json', 'w') as f:
        json.dump(metrics_for_json, f, indent=2)
    logger.info("Saved: metrics.json")
    
    logger.info("")
    logger.info("=" * 80)
    logger.info("Backtest complete! Results saved to 'output' directory.")
    logger.info("=" * 80)


if __name__ == "__main__":
    main()

