"""
Risk management and control for Whitelight 2.0.
Implements drawdown limiter and exposure normalization.
"""

import pandas as pd
import numpy as np
from typing import Optional


class RiskController:
    """
    Controls risk through drawdown limiting and position adjustments.
    
    Features:
    - Rolling max drawdown tracking
    - Automatic exposure reduction when drawdown exceeds threshold
    - Smooth transitions
    """
    
    def __init__(self, config: dict):
        """
        Initialize risk controller with configuration.
        
        Args:
            config: Configuration dictionary from settings.yaml
        """
        risk_config = config['risk']
        
        self.max_drawdown_threshold = risk_config['max_drawdown_threshold']
        self.drawdown_reduction = risk_config['drawdown_reduction']
        self.lookback = risk_config['drawdown_lookback']
    
    def calculate_rolling_max_drawdown(
        self,
        equity: pd.Series,
        lookback: Optional[int] = None
    ) -> pd.Series:
        """
        Calculate rolling maximum drawdown.
        
        Args:
            equity: Series of cumulative equity values
            lookback: Lookback period (default: self.lookback)
            
        Returns:
            Series of maximum drawdown values (0 to 1)
        """
        if lookback is None:
            lookback = self.lookback
        
        rolling_max = equity.rolling(window=lookback, min_periods=1).max()
        drawdown = (equity - rolling_max) / rolling_max
        
        return drawdown.abs()
    
    def generate_risk_adjustment(
        self,
        rolling_dd: pd.Series
    ) -> pd.Series:
        """
        Generate risk adjustment multiplier based on drawdown.
        
        Reduces exposure by drawdown_reduction when DD > threshold.
        
        Args:
            rolling_dd: Series of rolling maximum drawdown values
            
        Returns:
            Series of risk adjustment multipliers (0 to 1)
        """
        # Start with full exposure
        adjustment = pd.Series(1.0, index=rolling_dd.index)
        
        # Reduce exposure when drawdown exceeds threshold
        high_dd = rolling_dd > self.max_drawdown_threshold
        adjustment.loc[high_dd] = self.drawdown_reduction
        
        # Smooth transitions to avoid abrupt changes
        adjustment = adjustment.rolling(window=5, min_periods=1, center=True).mean()
        
        return adjustment
    
    def check_drawdown_status(
        self,
        rolling_dd: pd.Series
    ) -> pd.Series:
        """
        Check if current drawdown is above threshold.
        
        Args:
            rolling_dd: Series of rolling drawdown values
            
        Returns:
            Series of boolean values indicating if drawdown exceeds threshold
        """
        return rolling_dd > self.max_drawdown_threshold
    
    def get_risk_summary(
        self,
        rolling_dd: pd.Series
    ) -> dict:
        """
        Get summary of risk status.
        
        Args:
            rolling_dd: Series of rolling drawdown values
            
        Returns:
            Dictionary with risk statistics
        """
        max_dd = rolling_dd.max()
        avg_dd = rolling_dd.mean()
        periods_above_threshold = (rolling_dd > self.max_drawdown_threshold).sum()
        percentage_above_threshold = periods_above_threshold / len(rolling_dd) * 100
        
        return {
            'max_drawdown': max_dd,
            'avg_drawdown': avg_dd,
            'current_drawdown': rolling_dd.iloc[-1] if len(rolling_dd) > 0 else 0,
            'periods_above_threshold': periods_above_threshold,
            'percentage_above_threshold': percentage_above_threshold,
            'is_above_threshold': max_dd > self.max_drawdown_threshold
        }
    
    def apply_risk_controls(
        self,
        positions: pd.DataFrame,
        equity: pd.Series
    ) -> tuple[pd.DataFrame, pd.Series]:
        """
        Apply all risk controls to positions.
        
        Args:
            positions: DataFrame with position allocations
            equity: Series of cumulative equity values
            
        Returns:
            Tuple of (adjusted_positions, risk_adjustment)
        """
        rolling_dd = self.calculate_rolling_max_drawdown(equity)
        risk_adjustment = self.generate_risk_adjustment(rolling_dd)
        
        # Apply risk adjustment to positions
        adjusted_positions = positions.copy()
        adjusted_positions['tqqq_long'] = adjusted_positions['tqqq_long'] * risk_adjustment
        adjusted_positions['sqqq_short'] = adjusted_positions['sqqq_short'] * risk_adjustment
        
        return adjusted_positions, risk_adjustment

