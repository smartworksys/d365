"""
Market regime detection for Whitelight 2.0.
Classifies market as Bullish, Bearish, or Neutral based on ADX and price action.
"""

import pandas as pd
from typing import Literal

RegimeType = Literal['Bullish', 'Bearish', 'Neutral']


class RegimeDetector:
    """
    Detects market regimes using ADX and price vs moving averages.
    
    Rules:
    - Bullish: Close > MA250 AND ADX > 20
    - Bearish: Close < MA250 AND ADX > 20
    - Neutral: Otherwise
    """
    
    def __init__(self, adx_threshold: float = 20.0):
        """
        Initialize regime detector.
        
        Args:
            adx_threshold: ADX threshold for strong trends (default: 20)
        """
        self.adx_threshold = adx_threshold
    
    def detect_regime(
        self,
        close: pd.Series,
        ma_long: pd.Series,
        adx: pd.Series
    ) -> pd.Series:
        """
        Detect market regime for each period.
        
        Args:
            close: Series of closing prices
            ma_long: Series of long-term moving average (e.g., MA250)
            adx: Series of ADX values
            
        Returns:
            Series of regime classifications ('Bullish', 'Bearish', 'Neutral')
        """
        regime = pd.Series('Neutral', index=close.index, dtype=object)
        
        # Strong bullish regime
        bullish_mask = (close > ma_long) & (adx > self.adx_threshold)
        regime.loc[bullish_mask] = 'Bullish'
        
        # Strong bearish regime
        bearish_mask = (close < ma_long) & (adx > self.adx_threshold)
        regime.loc[bearish_mask] = 'Bearish'
        
        return regime
    
    def add_regime_to_data(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Add regime column to data DataFrame.
        
        Args:
            data: DataFrame with required columns: 'close', 'ma_long', 'adx'
            
        Returns:
            DataFrame with added 'regime' column
        """
        if 'regime' not in data.columns:
            data = data.copy()
            data['regime'] = self.detect_regime(
                data['close'],
                data['ma_long'],
                data['adx']
            )
        return data
    
    def get_regime_counts(self, regimes: pd.Series) -> dict:
        """
        Get count of each regime type.
        
        Args:
            regimes: Series of regime classifications
            
        Returns:
            Dictionary with regime counts
        """
        counts = regimes.value_counts().to_dict()
        return {
            'Bullish': counts.get('Bullish', 0),
            'Bearish': counts.get('Bearish', 0),
            'Neutral': counts.get('Neutral', 0),
            'Total': len(regimes)
        }
    
    def get_regime_percentages(self, regimes: pd.Series) -> dict:
        """
        Get percentage distribution of regimes.
        
        Args:
            regimes: Series of regime classifications
            
        Returns:
            Dictionary with regime percentages
        """
        counts = self.get_regime_counts(regimes)
        total = counts['Total']
        
        return {
            'Bullish': (counts['Bullish'] / total * 100) if total > 0 else 0,
            'Bearish': (counts['Bearish'] / total * 100) if total > 0 else 0,
            'Neutral': (counts['Neutral'] / total * 100) if total > 0 else 0
        }

