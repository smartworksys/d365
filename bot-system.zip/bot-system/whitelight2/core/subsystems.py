"""
Trading subsystems for Whitelight 2.0.
Implements 7 different trading strategies combining momentum and mean reversion.
"""

import pandas as pd
import numpy as np
from typing import Optional


class TradingSubsystems:
    """
    Implements 7 trading subsystems:
    - TF1: Trend Following Long (Momentum)
    - MR1-3: Mean Reversion Long (various RSI thresholds)
    - TFShort1-2: Trend Following Short (Momentum)
    - MRShort1: Mean Reversion Short (Countertrend)
    """
    
    def __init__(self, config: dict):
        """
        Initialize trading subsystems with configuration.
        
        Args:
            config: Configuration dictionary from settings.yaml
        """
        self.config = config
        self.rsi_thresholds = config['strategy']['rsi_thresholds']
        self.subsystems_config = config['subsystems']
    
    def signal_tf1(
        self,
        data: pd.DataFrame,
        regime: pd.Series
    ) -> pd.Series:
        """
        TF1: Trend Following Long (Momentum TQQQ)
        
        Signals:
        - +1: Long TQQQ when bullish regime and price above short MA
        - -1: Short SQQQ when bearish regime and price below short MA
        - 0: Neutral otherwise
        
        Args:
            data: DataFrame with indicators
            regime: Series of regime classifications
            
        Returns:
            Series of signals: +1 (long), -1 (short), 0 (neutral)
        """
        signals = pd.Series(0, index=data.index)
        
        # Bullish: Long TQQQ when price > MA20
        bullish_long = (regime == 'Bullish') & (data['close'] > data['ma_short'])
        signals.loc[bullish_long] = 1
        
        # Bearish: Short SQQQ when price < MA20
        bearish_short = (regime == 'Bearish') & (data['close'] < data['ma_short'])
        signals.loc[bearish_short] = -1
        
        return signals
    
    def signal_mr1(self, data: pd.DataFrame, regime: pd.Series) -> pd.Series:
        """
        MR1: Mean Reversion Long (RSI < 35)
        
        Buy TQQQ when RSI oversold in neutral/bullish environment.
        
        Args:
            data: DataFrame with indicators
            regime: Series of regime classifications
            
        Returns:
            Series of signals: +1 (long), 0 (neutral)
        """
        signals = pd.Series(0, index=data.index)
        
        # Long when RSI < 35 and not in strong bear market
        long_signal = (data['rsi'] < self.rsi_thresholds[0]) & (regime != 'Bearish')
        signals.loc[long_signal] = 1
        
        return signals
    
    def signal_mr2(self, data: pd.DataFrame, regime: pd.Series) -> pd.Series:
        """
        MR2: Mean Reversion Long (RSI < 25)
        
        More aggressive mean reversion entry.
        
        Args:
            data: DataFrame with indicators
            regime: Series of regime classifications
            
        Returns:
            Series of signals: +1 (long), 0 (neutral)
        """
        signals = pd.Series(0, index=data.index)
        
        # Long when RSI < 25 and not in strong bear market
        long_signal = (data['rsi'] < self.rsi_thresholds[1]) & (regime != 'Bearish')
        signals.loc[long_signal] = 1
        
        return signals
    
    def signal_mr3(self, data: pd.DataFrame, regime: pd.Series) -> pd.Series:
        """
        MR3: Mean Reversion Long (RSI < 20)
        
        Most aggressive mean reversion entry (extreme oversold).
        
        Args:
            data: DataFrame with indicators
            regime: Series of regime classifications
            
        Returns:
            Series of signals: +1 (long), 0 (neutral)
        """
        signals = pd.Series(0, index=data.index)
        
        # Long when RSI < 20 (extreme oversold)
        long_signal = data['rsi'] < self.rsi_thresholds[2]
        signals.loc[long_signal] = 1
        
        return signals
    
    def signal_tfshort1(
        self,
        data: pd.DataFrame,
        regime: pd.Series
    ) -> pd.Series:
        """
        TFShort1: Trend Following Short (Momentum)
        
        Short SQQQ in bearish trends.
        
        Args:
            data: DataFrame with indicators
            regime: Series of regime classifications
            
        Returns:
            Series of signals: -1 (short), 0 (neutral)
        """
        signals = pd.Series(0, index=data.index)
        
        # Short when bearish regime and price declining
        short_signal = (regime == 'Bearish') & (data['close'] < data['ma_short'])
        signals.loc[short_signal] = -1
        
        return signals
    
    def signal_tfshort2(
        self,
        data: pd.DataFrame,
        regime: pd.Series
    ) -> pd.Series:
        """
        TFShort2: Trend Following Short (Additional momentum)
        
        Short on lower highs and declining price.
        
        Args:
            data: DataFrame with indicators
            regime: Series of regime classifications
            
        Returns:
            Series of signals: -1 (short), 0 (neutral)
        """
        signals = pd.Series(0, index=data.index)
        
        # Short when bearish/neutral and price below both MAs
        short_signal = (
            (regime != 'Bullish') &
            (data['close'] < data['ma_short']) &
            (data['close'] < data['ma_long'])
        )
        signals.loc[short_signal] = -1
        
        return signals
    
    def signal_mrshort1(
        self,
        data: pd.DataFrame,
        regime: pd.Series
    ) -> pd.Series:
        """
        MRShort1: Mean Reversion Short (Countertrend)
        
        Short rallies in downtrends (mean reversion to downside).
        
        Args:
            data: DataFrame with indicators
            regime: Series of regime classifications
            
        Returns:
            Series of signals: -1 (short), 0 (neutral)
        """
        signals = pd.Series(0, index=data.index)
        
        # Short when RSI > 65 in bearish/neutral market
        short_signal = (data['rsi'] > 65) & (regime != 'Bullish')
        signals.loc[short_signal] = -1
        
        return signals
    
    def generate_all_signals(
        self,
        tqqq_data: pd.DataFrame,
        sqqq_data: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Generate signals from all 7 subsystems for both TQQQ and SQQQ.
        
        Args:
            tqqq_data: TQQQ data with indicators
            sqqq_data: SQQQ data with indicators
            
        Returns:
            DataFrame with subsystem signals
        """
        # Create results DataFrame aligned on dates
        aligned_dates = tqqq_data.index.intersection(sqqq_data.index)
        results = pd.DataFrame(index=aligned_dates)
        
        # Get regime from TQQQ data (using NDX-based regime)
        regime = tqqq_data['regime']
        
        # Subsystems for TQQQ (long signals)
        if self.subsystems_config['TF1']['enabled']:
            results['TF1'] = self.signal_tf1(tqqq_data.loc[aligned_dates], regime.loc[aligned_dates])
        
        if self.subsystems_config['MR1']['enabled']:
            results['MR1'] = self.signal_mr1(tqqq_data.loc[aligned_dates], regime.loc[aligned_dates])
        
        if self.subsystems_config['MR2']['enabled']:
            results['MR2'] = self.signal_mr2(tqqq_data.loc[aligned_dates], regime.loc[aligned_dates])
        
        if self.subsystems_config['MR3']['enabled']:
            results['MR3'] = self.signal_mr3(tqqq_data.loc[aligned_dates], regime.loc[aligned_dates])
        
        # Subsystems for SQQQ (short signals)
        if self.subsystems_config['TFShort1']['enabled']:
            results['TFShort1'] = self.signal_tfshort1(
                tqqq_data.loc[aligned_dates], regime.loc[aligned_dates]
            )
        
        if self.subsystems_config['TFShort2']['enabled']:
            results['TFShort2'] = self.signal_tfshort2(
                tqqq_data.loc[aligned_dates], regime.loc[aligned_dates]
            )
        
        if self.subsystems_config['MRShort1']['enabled']:
            results['MRShort1'] = self.signal_mrshort1(
                tqqq_data.loc[aligned_dates], regime.loc[aligned_dates]
            )
        
        return results
    
    def get_subsystem_info(self) -> dict:
        """
        Get information about all subsystems.
        
        Returns:
            Dictionary with subsystem descriptions
        """
        return {
            'TF1': {
                'name': self.subsystems_config['TF1']['name'],
                'type': 'Momentum Long',
                'enabled': self.subsystems_config['TF1']['enabled']
            },
            'MR1': {
                'name': self.subsystems_config['MR1']['name'],
                'type': 'Mean Reversion Long (RSI < 35)',
                'enabled': self.subsystems_config['MR1']['enabled']
            },
            'MR2': {
                'name': self.subsystems_config['MR2']['name'],
                'type': 'Mean Reversion Long (RSI < 25)',
                'enabled': self.subsystems_config['MR2']['enabled']
            },
            'MR3': {
                'name': self.subsystems_config['MR3']['name'],
                'type': 'Mean Reversion Long (RSI < 20)',
                'enabled': self.subsystems_config['MR3']['enabled']
            },
            'TFShort1': {
                'name': self.subsystems_config['TFShort1']['name'],
                'type': 'Momentum Short',
                'enabled': self.subsystems_config['TFShort1']['enabled']
            },
            'TFShort2': {
                'name': self.subsystems_config['TFShort2']['name'],
                'type': 'Momentum Short (Advanced)',
                'enabled': self.subsystems_config['TFShort2']['enabled']
            },
            'MRShort1': {
                'name': self.subsystems_config['MRShort1']['name'],
                'type': 'Mean Reversion Short (Countertrend)',
                'enabled': self.subsystems_config['MRShort1']['enabled']
            }
        }

