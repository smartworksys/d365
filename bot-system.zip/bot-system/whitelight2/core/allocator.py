"""
Position allocation and sizing for Whitelight 2.0.
Implements volatility normalization and risk parity between TQQQ/SQQQ.
"""

import pandas as pd
import numpy as np
from typing import Optional


class PositionAllocator:
    """
    Allocates positions based on subsystem signals with volatility scaling.
    
    Implements:
    - Volatility-normalized exposure scaling
    - Risk parity between TQQQ/SQQQ
    - Maximum leverage cap
    """
    
    def __init__(self, config: dict):
        """
        Initialize position allocator with configuration.
        
        Args:
            config: Configuration dictionary from settings.yaml
        """
        self.config = config
        pos_config = config['position_sizing']
        
        self.vol_multiplier = pos_config['vol_multiplier']
        self.min_exposure = pos_config['min_exposure']
        self.max_leverage = pos_config['max_leverage']
        self.risk_parity = pos_config['risk_parity']
    
    def calculate_volatility_scaling(
        self,
        volatility: pd.Series
    ) -> pd.Series:
        """
        Calculate volatility-based exposure scaling.
        
        Formula: max(0.2, 1 - 3 * vol20)
        This reduces exposure when volatility is high.
        
        Args:
            volatility: Series of rolling volatility values
            
        Returns:
            Series of scaling factors (0.2 to 1.0)
        """
        scaling = np.maximum(
            self.min_exposure,
            1 - self.vol_multiplier * volatility
        )
        return scaling.clip(0.0, 1.0)
    
    def aggregate_signals(
        self,
        signals: pd.DataFrame,
        volatility: pd.Series
    ) -> tuple[pd.Series, pd.Series]:
        """
        Aggregate subsystem signals into net long/short positions.
        
        Args:
            signals: DataFrame with subsystem signals (-1, 0, 1)
            volatility: Series of volatility values for scaling
            
        Returns:
            Tuple of (net_long_exposure, net_short_exposure)
        """
        # Separate long and short signals
        long_signals = signals[signals > 0].sum(axis=1).fillna(0)
        short_signals = signals[signals < 0].abs().sum(axis=1).fillna(0)
        
        # Normalize by number of subsystems
        n_subsystems = len([col for col in signals.columns if signals[col].notna().any()])
        long_normalized = long_signals / n_subsystems
        short_normalized = short_signals / n_subsystems
        
        # Apply volatility scaling
        volatility_scaling = self.calculate_volatility_scaling(volatility)
        
        long_exposure = long_normalized * volatility_scaling
        short_exposure = short_normalized * volatility_scaling
        
        # Ensure leverage cap
        total_exposure = long_exposure + short_exposure
        if (total_exposure > self.max_leverage).any():
            excess = total_exposure - self.max_leverage
            # Reduce proportionally
            reduction_ratio = np.where(
                total_exposure > 0,
                (total_exposure - excess) / total_exposure,
                1.0
            )
            long_exposure = long_exposure * reduction_ratio
            short_exposure = short_exposure * reduction_ratio
        
        return long_exposure, short_exposure
    
    def allocate_positions(
        self,
        signals: pd.DataFrame,
        volatility: pd.Series,
        risk_adjustment: Optional[pd.Series] = None
    ) -> pd.DataFrame:
        """
        Allocate positions based on subsystem signals.
        
        Args:
            signals: DataFrame with subsystem signals
            volatility: Series of volatility values
            risk_adjustment: Optional series of risk multipliers (e.g., from drawdown controller)
            
        Returns:
            DataFrame with columns: 'tqqq_long', 'sqqq_short'
        """
        long_exposure, short_exposure = self.aggregate_signals(signals, volatility)
        
        # Apply additional risk adjustment if provided
        if risk_adjustment is not None:
            long_exposure = long_exposure * risk_adjustment
            short_exposure = short_exposure * risk_adjustment
        
        # Create position allocation DataFrame
        positions = pd.DataFrame(index=signals.index)
        
        # Long positions in TQQQ
        positions['tqqq_long'] = long_exposure
        
        # Short positions (using SQQQ instead of shorting TQQQ)
        positions['sqqq_short'] = short_exposure
        
        # Ensure we don't go both long and short at the same time
        # If both are positive, keep the higher one
        both_positive = (positions['tqqq_long'] > 0) & (positions['sqqq_short'] > 0)
        for idx in positions[both_positive].index:
            if positions.loc[idx, 'tqqq_long'] >= positions.loc[idx, 'sqqq_short']:
                positions.loc[idx, 'sqqq_short'] = 0
            else:
                positions.loc[idx, 'tqqq_long'] = 0
        
        return positions
    
    def calculate_leverage(self, positions: pd.DataFrame) -> pd.Series:
        """
        Calculate total leverage from position allocations.
        
        Args:
            positions: DataFrame with 'tqqq_long' and 'sqqq_short' columns
            
        Returns:
            Series of total leverage values
        """
        return positions['tqqq_long'] + positions['sqqq_short']
    
    def get_exposure_stats(self, positions: pd.DataFrame) -> dict:
        """
        Calculate exposure statistics.
        
        Args:
            positions: DataFrame with position allocations
            
        Returns:
            Dictionary with exposure statistics
        """
        leverage = self.calculate_leverage(positions)
        
        return {
            'avg_leverage': leverage.mean(),
            'max_leverage': leverage.max(),
            'min_leverage': leverage.min(),
            'long_percentage': (positions['tqqq_long'] > 0).sum() / len(positions) * 100,
            'short_percentage': (positions['sqqq_short'] > 0).sum() / len(positions) * 100,
            'neutral_percentage': (
                (positions['tqqq_long'] == 0) & (positions['sqqq_short'] == 0)
            ).sum() / len(positions) * 100
        }

