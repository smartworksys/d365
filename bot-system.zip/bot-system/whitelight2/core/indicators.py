"""
Technical indicators for Whitelight 2.0.
Implements RSI, Moving Averages, Bollinger Bands, Volatility, and ADX.
"""

import numpy as np
import pandas as pd
from typing import Optional


def calculate_rsi(prices: pd.Series, period: int = 14) -> pd.Series:
    """
    Calculate Relative Strength Index (RSI).
    
    Args:
        prices: Series of closing prices
        period: Period for RSI calculation (default: 14)
        
    Returns:
        Series with RSI values (0-100)
    """
    delta = prices.diff()
    
    gain = delta.where(delta > 0, 0)
    loss = -delta.where(delta < 0, 0)
    
    avg_gain = gain.rolling(window=period, min_periods=1).mean()
    avg_loss = loss.rolling(window=period, min_periods=1).mean()
    
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    
    return rsi


def calculate_ma(prices: pd.Series, period: int) -> pd.Series:
    """
    Calculate Simple Moving Average (SMA).
    
    Args:
        prices: Series of closing prices
        period: Period for moving average
        
    Returns:
        Series with moving average values
    """
    return prices.rolling(window=period, min_periods=1).mean()


def calculate_bollinger_bands(
    prices: pd.Series,
    period: int = 20,
    num_std: float = 2.0
) -> tuple[pd.Series, pd.Series, pd.Series]:
    """
    Calculate Bollinger Bands.
    
    Args:
        prices: Series of closing prices
        period: Period for moving average (default: 20)
        num_std: Number of standard deviations (default: 2.0)
        
    Returns:
        Tuple of (upper_band, middle_band, lower_band)
    """
    middle = calculate_ma(prices, period)
    std = prices.rolling(window=period, min_periods=1).std()
    
    upper = middle + (std * num_std)
    lower = middle - (std * num_std)
    
    return upper, middle, lower


def calculate_volatility(
    returns: pd.Series,
    window: int = 20,
    annualize: bool = True
) -> pd.Series:
    """
    Calculate rolling volatility (standard deviation of returns).
    
    Args:
        returns: Series of returns (pct_change)
        window: Rolling window period (default: 20)
        annualize: If True, annualize volatility (default: True)
        
    Returns:
        Series with volatility values
    """
    vol = returns.rolling(window=window, min_periods=1).std()
    
    if annualize:
        vol = vol * np.sqrt(252)  # Annualize daily volatility
    
    return vol


def calculate_adx(
    high: pd.Series,
    low: pd.Series,
    close: pd.Series,
    period: int = 14
) -> pd.Series:
    """
    Calculate Average Directional Index (ADX).
    
    ADX measures trend strength without regard to direction.
    Values above 25 indicate strong trend.
    
    Args:
        high: Series of high prices
        low: Series of low prices
        close: Series of closing prices
        period: Period for ADX calculation (default: 14)
        
    Returns:
        Series with ADX values
    """
    def _calc_tr(high, low, close, prev_close):
        """Calculate True Range."""
        tr1 = high - low
        tr2 = abs(high - prev_close)
        tr3 = abs(low - prev_close)
        return max(tr1, tr2, tr3)
    
    # Calculate True Range
    tr = pd.Series(index=close.index, dtype=float)
    tr.iloc[0] = high.iloc[0] - low.iloc[0]
    
    for i in range(1, len(close)):
        tr.iloc[i] = _calc_tr(
            high.iloc[i], low.iloc[i], close.iloc[i], close.iloc[i-1]
        )
    
    # Calculate Directional Movement
    dm_plus = pd.Series(index=close.index, dtype=float)
    dm_minus = pd.Series(index=close.index, dtype=float)
    
    for i in range(1, len(close)):
        move_up = high.iloc[i] - high.iloc[i-1]
        move_down = low.iloc[i-1] - low.iloc[i]
        
        dm_plus.iloc[i] = move_up if move_up > move_down and move_up > 0 else 0
        dm_minus.iloc[i] = move_down if move_down > move_up and move_down > 0 else 0
    
    # Smooth using Wilder's method (EMA-like)
    def _smooth_wilder(series, period):
        """Wilder's smoothing method (simplified EMA)."""
        smoothed = series.copy()
        for i in range(1, len(series)):
            smoothed.iloc[i] = (
                smoothed.iloc[i-1] * (period - 1) + series.iloc[i]
            ) / period
        return smoothed
    
    # Initial period
    atr = tr.rolling(window=period, min_periods=1).mean()
    di_plus_raw = dm_plus.rolling(window=period, min_periods=1).mean()
    di_minus_raw = dm_minus.rolling(window=period, min_periods=1).mean()
    
    # Then apply Wilder's smoothing
    atr = _smooth_wilder(tr, period)
    di_plus = _smooth_wilder(dm_plus, period)
    di_minus = _smooth_wilder(dm_minus, period)
    
    # Calculate Directional Indicators
    di_plus_norm = 100 * (di_plus / atr)
    di_minus_norm = 100 * (di_minus / atr)
    
    # Calculate DX and ADX
    dx = 100 * abs(di_plus_norm - di_minus_norm) / (di_plus_norm + di_minus_norm)
    adx = dx.rolling(window=period, min_periods=1).mean()
    
    return adx.fillna(0)


def calculate_distance_from_ma(price: pd.Series, ma: pd.Series) -> pd.Series:
    """
    Calculate percent distance from moving average.
    
    Args:
        price: Series of closing prices
        ma: Series of moving average values
        
    Returns:
        Series with percent distance from MA
    """
    return (price - ma) / ma * 100


def calculate_all_indicators(
    data: pd.DataFrame,
    ma_short: int = 20,
    ma_long: int = 250,
    rsi_period: int = 14,
    bb_period: int = 20,
    bb_std: float = 2.0,
    adx_period: int = 14,
    vol_lookback: int = 20
) -> pd.DataFrame:
    """
    Calculate all indicators for a dataset.
    
    Args:
        data: DataFrame with OHLCV data (columns: open, high, low, close, volume)
        ma_short: Short-term moving average period
        ma_long: Long-term moving average period
        rsi_period: RSI period
        bb_period: Bollinger Bands period
        bb_std: Bollinger Bands standard deviation
        adx_period: ADX period
        vol_lookback: Volatility lookback period
        
    Returns:
        DataFrame with added indicator columns
    """
    result = data.copy()
    
    close = data['close']
    high = data['high']
    low = data['low']
    
    # RSI
    result['rsi'] = calculate_rsi(close, rsi_period)
    
    # Moving Averages
    result['ma_short'] = calculate_ma(close, ma_short)
    result['ma_long'] = calculate_ma(close, ma_long)
    
    # Distance from MAs
    result['dist_ma_short'] = calculate_distance_from_ma(close, result['ma_short'])
    result['dist_ma_long'] = calculate_distance_from_ma(close, result['ma_long'])
    
    # Bollinger Bands
    bb_upper, bb_middle, bb_lower = calculate_bollinger_bands(
        close, bb_period, bb_std
    )
    result['bb_upper'] = bb_upper
    result['bb_middle'] = bb_middle
    result['bb_lower'] = bb_lower
    
    # Volatility
    returns = close.pct_change()
    result['volatility'] = calculate_volatility(returns, vol_lookback)
    
    # ADX
    result['adx'] = calculate_adx(high, low, close, adx_period)
    
    return result

