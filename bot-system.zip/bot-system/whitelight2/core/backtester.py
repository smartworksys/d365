"""
Backtesting engine for Whitelight 2.0.
Simulates portfolio performance with position tracking and metrics calculation.
"""

import pandas as pd
import numpy as np
from typing import Optional


class Backtester:
    """
    Backtest the Whitelight 2.0 strategy with comprehensive metrics.
    
    Tracks:
    - Position sizes
    - Equity curve
    - Returns
    - Drawdowns
    - Subsystem contributions
    """
    
    def __init__(self, config: dict):
        """
        Initialize backtester with configuration.
        
        Args:
            config: Configuration dictionary from settings.yaml
        """
        self.config = config
        self.initial_capital = config['backtesting']['initial_capital']
        self.commission = config['backtesting']['commission']
    
    def run_backtest(
        self,
        tqqq_data: pd.DataFrame,
        sqqq_data: pd.DataFrame,
        positions: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Run backtest simulation.
        
        Args:
            tqqq_data: TQQQ data with close prices
            sqqq_data: SQQQ data with close prices
            positions: DataFrame with 'tqqq_long' and 'sqqq_short' position sizes
            
        Returns:
            DataFrame with backtest results including equity curve
        """
        # Align all data on common dates
        common_dates = positions.index.intersection(
            tqqq_data.index.intersection(sqqq_data.index)
        )
        
        positions_aligned = positions.loc[common_dates]
        tqqq_aligned = tqqq_data.loc[common_dates]
        sqqq_aligned = sqqq_data.loc[common_dates]
        
        # Calculate daily returns
        tqqq_returns = tqqq_aligned['close'].pct_change().fillna(0)
        sqqq_returns = sqqq_aligned['close'].pct_change().fillna(0)
        
        # Calculate portfolio returns
        portfolio_returns = (
            positions_aligned['tqqq_long'] * tqqq_returns +
            positions_aligned['sqqq_short'] * sqqq_returns
        )
        
        # Calculate cumulative equity
        equity = self.initial_capital * (1 + portfolio_returns).cumprod()
        
        # Create results DataFrame
        results = pd.DataFrame(index=common_dates)
        results['equity'] = equity
        results['returns'] = portfolio_returns
        results['positions_long'] = positions_aligned['tqqq_long']
        results['positions_short'] = positions_aligned['sqqq_short']
        
        # Add drawdown
        results['drawdown'] = self._calculate_drawdown(equity)
        
        return results
    
    def _calculate_drawdown(self, equity: pd.Series) -> pd.Series:
        """Calculate drawdown from equity curve."""
        rolling_max = equity.expanding().max()
        drawdown = (equity - rolling_max) / rolling_max
        return drawdown
    
    def calculate_metrics(
        self,
        backtest_results: pd.DataFrame,
        benchmark_returns: Optional[pd.Series] = None
    ) -> dict:
        """
        Calculate comprehensive performance metrics.
        
        Args:
            backtest_results: DataFrame with equity curve and returns
            benchmark_returns: Optional benchmark returns for comparison
            
        Returns:
            Dictionary with all performance metrics
        """
        equity = backtest_results['equity']
        returns = backtest_results['returns']
        
        # Basic metrics
        total_return = (equity.iloc[-1] / equity.iloc[0] - 1) if len(equity) > 0 else 0
        num_years = len(returns) / 252
        cagr = (equity.iloc[-1] / equity.iloc[0]) ** (1 / num_years) - 1 if num_years > 0 else 0
        
        # Volatility
        annual_vol = returns.std() * np.sqrt(252)
        
        # Sharpe ratio (assuming 0% risk-free rate)
        sharpe = (returns.mean() * 252) / (returns.std() * np.sqrt(252)) if returns.std() > 0 else 0
        
        # Sortino ratio (downside deviation)
        downside_returns = returns[returns < 0]
        downside_std = downside_returns.std() * np.sqrt(252) if len(downside_returns) > 0 else 0
        sortino = (returns.mean() * 252) / downside_std if downside_std > 0 else 0
        
        # Drawdown metrics
        max_dd = backtest_results['drawdown'].min()
        avg_dd = backtest_results['drawdown'][backtest_results['drawdown'] < 0].mean()
        
        # Calmar ratio
        calmar = cagr / abs(max_dd) if max_dd != 0 else 0
        
        # MAR ratio (mean return / max drawdown)
        mar = returns.mean() * 252 / abs(max_dd) if max_dd != 0 else 0
        
        # Win rate
        win_rate = (returns > 0).sum() / len(returns) * 100 if len(returns) > 0 else 0
        
        # Best and worst days
        best_day = returns.max()
        worst_day = returns.min()
        
        # Value at Risk (95%)
        var_95 = returns.quantile(0.05)
        
        # Beta (if benchmark provided)
        beta = None
        alpha = None
        if benchmark_returns is not None:
            aligned = pd.DataFrame({'strategy': returns, 'benchmark': benchmark_returns}).dropna()
            if len(aligned) > 1 and aligned['benchmark'].std() > 0:
                covariance = aligned['strategy'].cov(aligned['benchmark'])
                benchmark_var = aligned['benchmark'].var()
                beta = covariance / benchmark_var if benchmark_var > 0 else 0
                
                # Alpha = Strategy Return - (Beta * Benchmark Return)
                strategy_annual = aligned['strategy'].mean() * 252
                benchmark_annual = aligned['benchmark'].mean() * 252
                alpha = strategy_annual - (beta * benchmark_annual)
        
        metrics = {
            'total_return': total_return,
            'cagr': cagr,
            'annual_volatility': annual_vol,
            'sharpe_ratio': sharpe,
            'sortino_ratio': sortino,
            'max_drawdown': max_dd,
            'avg_drawdown': avg_dd,
            'calmar_ratio': calmar,
            'mar_ratio': mar,
            'win_rate': win_rate,
            'best_day': best_day,
            'worst_day': worst_day,
            'var_95': var_95,
            'num_trading_days': len(returns),
            'start_date': backtest_results.index[0],
            'end_date': backtest_results.index[-1]
        }
        
        if beta is not None:
            metrics['beta'] = beta
            metrics['alpha'] = alpha
        
        return metrics
    
    def get_monthly_returns(self, backtest_results: pd.DataFrame) -> pd.Series:
        """
        Calculate monthly returns from backtest results.
        
        Args:
            backtest_results: DataFrame with returns column
            
        Returns:
            Series of monthly returns
        """
        returns = backtest_results['returns']
        monthly = returns.resample('M').apply(lambda x: (1 + x).prod() - 1)
        return monthly
    
    def get_exposure_by_regime(
        self,
        backtest_results: pd.DataFrame,
        regimes: pd.Series
    ) -> dict:
        """
        Calculate average exposure by regime.
        
        Args:
            backtest_results: DataFrame with position columns
            regimes: Series of regime classifications
            
        Returns:
            Dictionary with exposure statistics by regime
        """
        aligned_regimes = regimes.loc[backtest_results.index]
        
        exposure_long = backtest_results['positions_long']
        exposure_short = backtest_results['positions_short']
        total_leverage = exposure_long + exposure_short
        
        regimes_present = aligned_regimes.value_counts().index
        
        stats = {}
        for regime in regimes_present:
            mask = aligned_regimes == regime
            stats[f'{regime}_avg_leverage'] = total_leverage[mask].mean()
            stats[f'{regime}_avg_long'] = exposure_long[mask].mean()
            stats[f'{regime}_avg_short'] = exposure_short[mask].mean()
        
        return stats

