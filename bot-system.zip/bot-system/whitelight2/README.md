# Whitelight 2.0 - Adaptive Dual-Leverage Trading Framework

## Overview

Whitelight 2.0 is a production-ready Python trading system designed to trade **TQQQ** and **SQQQ** using an adaptive dual-leverage framework. The system combines momentum, mean-reversion, and volatility-based rules to dynamically switch between leveraged long and short positions.

## Features

- **7 Trading Subsystems**: Momentum longs, mean reversion longs, momentum shorts, and mean reversion shorts
- **Adaptive Position Allocation**: Volatility-normalized exposure with risk parity
- **Regime Detection**: Bull/Bear/Neutral market classification using ADX and moving averages
- **Risk Management**: Drawdown limiter and exposure control
- **Comprehensive Backtesting**: Portfolio simulation with detailed performance metrics
- **Visualization Dashboard**: Equity curves, heatmaps, regime overlays, and subsystem analysis

## Installation

```bash
# Clone or download the repository
cd whitelight2

# Install dependencies
pip install -r requirements.txt
```

## Configuration

1. Edit `config/settings.yaml` to configure your API keys and strategy parameters
2. (Optional) Get a free API key from [Polygon.io](https://polygon.io/) for better data quality

## Quick Start

### Run Backtest

```bash
python main.py
```

### Research and Analysis

Open the Jupyter notebook for detailed analysis:

```bash
jupyter notebook notebooks/research.ipynb
```

## Project Structure

```
whitelight2/
├── main.py                     # Entry point: orchestrates strategy and execution
├── data/
│   └── data_fetcher.py         # Polygon.io or yfinance data loader
├── core/
│   ├── indicators.py           # RSI, MA, Bollinger, ADX, volatility
│   ├── regime.py               # Market regime classification logic
│   ├── subsystems.py           # TF1, TFShort1, MR1-3, MRShort1 logic
│   ├── allocator.py            # Position sizing and volatility overlay
│   ├── backtester.py           # Portfolio simulation and metrics
│   └── risk_controller.py      # Exposure normalization and drawdown limiter
├── analytics/
│   ├── performance.py          # CAGR, Sharpe, Calmar, MaxDD, exposure stats
│   └── visualize.py            # Equity curve, heatmaps, regime overlay
├── config/
│   └── settings.yaml           # Parameters, API keys, and system thresholds
└── notebooks/
    └── research.ipynb          # Backtest analysis, rolling Sharpe, subsystem returns
```

## Subsystems

The system uses 7 trading subsystems:

1. **TF1** - Trend Following Long (Momentum TQQQ)
2. **MR1** - Mean Reversion Long (RSI < 35)
3. **MR2** - Mean Reversion Long (RSI < 25)
4. **MR3** - Mean Reversion Long (RSI < 20)
5. **TFShort1** - Trend Following Short (Momentum SQQQ)
6. **TFShort2** - Trend Following Short (Additional momentum)
7. **MRShort1** - Mean Reversion Short (Countertrend)

## Performance Metrics

The backtester calculates:
- **CAGR**: Compound Annual Growth Rate
- **Sharpe Ratio**: Risk-adjusted returns
- **Sortino Ratio**: Downside risk-adjusted returns
- **Max Drawdown**: Maximum peak-to-trough decline
- **Calmar Ratio**: CAGR / Max Drawdown
- **MAR Ratio**: Average Return / Max Drawdown
- **Win Rate**: Percentage of profitable trades
- **Exposure Statistics**: Long/short/neutral percentages

## License

MIT License

## Disclaimer

This system is for educational and research purposes only. Trading leveraged ETFs involves substantial risk. Past performance does not guarantee future results. Always do your own research and consult with a licensed financial advisor before making investment decisions.

