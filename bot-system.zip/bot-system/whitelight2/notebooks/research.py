"""
Whitelight 2.0 - Research Script
Detailed analysis and exploration of backtest results.
Run this script or open in Jupyter Notebook for interactive analysis.
"""

import sys
import os
sys.path.insert(0, '..')

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
import yaml

warnings.filterwarnings('ignore')

from data.data_fetcher import DataFetcher
from core.indicators import calculate_all_indicators
from core.regime import RegimeDetector
from core.subsystems import TradingSubsystems
from core.allocator import PositionAllocator
from core.risk_controller import RiskController
from core.backtester import Backtester
from analytics.performance import PerformanceAnalyzer
from analytics.visualize import Visualizer

# Load configuration
with open('../config/settings.yaml', 'r') as f:
    config = yaml.safe_load(f)

print("Whitelight 2.0 - Research Analysis")
print("=" * 80)

# Initialize components
print("Initializing components...")
data_fetcher = DataFetcher(config)
regime_detector = RegimeDetector(config['strategy']['adx_threshold'])
subsystems = TradingSubsystems(config)
allocator = PositionAllocator(config)
risk_controller = RiskController(config)
backtester = Backtester(config)
performance_analyzer = PerformanceAnalyzer()
visualizer = Visualizer(figsize=(15, 8))

# Fetch data
print("\nFetching data...")
start_date = config['backtesting']['start_date']
try:
    tqqq_data, sqqq_data = data_fetcher.get_aligned_data(start_date, None)
    print(f"✓ Loaded {len(tqqq_data)} days of data")
except Exception as e:
    print(f"Error: {e}")
    print("Using NDX simulation...")
    ndx_data = data_fetcher.fetch_data('^NDX', start_date, None)
    tqqq_data = data_fetcher.simulate_leveraged_etf(ndx_data, leverage=3.0)
    sqqq_data = data_fetcher.simulate_leveraged_etf(ndx_data, leverage=-3.0)

# Calculate indicators
print("\nCalculating indicators...")
strategy_config = config['strategy']
tqqq_data = calculate_all_indicators(
    tqqq_data, ma_short=strategy_config['ma_short'],
    ma_long=strategy_config['ma_long'],
    bb_period=strategy_config['bb_period'],
    bb_std=strategy_config['bb_std'],
    adx_period=strategy_config['adx_period'],
    vol_lookback=strategy_config['vol_lookback']
)

for col in ['rsi', 'ma_short', 'ma_long', 'dist_ma_short', 'dist_ma_long',
            'bb_upper', 'bb_middle', 'bb_lower', 'volatility', 'adx']:
    if col in tqqq_data.columns:
        sqqq_data[col] = tqqq_data[col]

# Detect regimes
print("\nDetecting market regimes...")
tqqq_data = regime_detector.add_regime_to_data(tqqq_data)
regime_counts = regime_detector.get_regime_counts(tqqq_data['regime'])
print(f"Regime Distribution:")
print(f"  Bullish: {regime_counts['Bullish']} ({regime_counts['Bullish']/regime_counts['Total']*100:.1f}%)")
print(f"  Bearish: {regime_counts['Bearish']} ({regime_counts['Bearish']/regime_counts['Total']*100:.1f}%)")
print(f"  Neutral: {regime_counts['Neutral']} ({regime_counts['Neutral']/regime_counts['Total']*100:.1f}%)")

# Generate signals
print("\nGenerating subsystem signals...")
subsystem_signals = subsystems.generate_all_signals(tqqq_data, sqqq_data)

# Allocate positions
print("\nAllocating positions...")
positions = allocator.allocate_positions(
    subsystem_signals,
    tqqq_data['volatility']
)

# Run backtest
print("\nRunning backtest...")
backtest_results = backtester.run_backtest(tqqq_data, sqqq_data, positions)

# Apply risk controls
print("Applying risk controls...")
adjusted_positions, risk_adjustment = risk_controller.apply_risk_controls(
    positions, backtest_results['equity']
)
backtest_results = backtester.run_backtest(tqqq_data, sqqq_data, adjusted_positions)

# Calculate metrics
print("\nCalculating metrics...")
metrics = backtester.calculate_metrics(backtest_results)

# Print summary
print("\n" + "=" * 80)
print("PERFORMANCE SUMMARY")
print("=" * 80)
print(f"CAGR: {metrics['cagr']:.2%}")
print(f"Total Return: {metrics['total_return']:.2%}")
print(f"Sharpe Ratio: {metrics['sharpe_ratio']:.2f}")
print(f"Sortino Ratio: {metrics['sortino_ratio']:.2f}")
print(f"Max Drawdown: {metrics['max_drawdown']:.2%}")
print(f"Calmar Ratio: {metrics['calmar_ratio']:.2f}")
print(f"Win Rate: {metrics['win_rate']:.1f}%")
print(f"Best Day: {metrics['best_day']:.2%}")
print(f"Worst Day: {metrics['worst_day']:.2%}")
print("=" * 80)

# Create visualizations
print("\nGenerating visualizations...")
os.makedirs('../output', exist_ok=True)

# Plot 1: Equity curve
fig1 = visualizer.plot_equity_curve(
    backtest_results['equity'],
    tqqq_data['regime'].loc[backtest_results.index]
)
fig1.savefig('../output/equity_curve.png', dpi=300, bbox_inches='tight')
print("✓ Saved: equity_curve.png")

# Plot 2: Drawdown
fig2 = visualizer.plot_drawdown(backtest_results['drawdown'])
fig2.savefig('../output/drawdown.png', dpi=300, bbox_inches='tight')
print("✓ Saved: drawdown.png")

# Plot 3: Leverage
fig3 = visualizer.plot_leverage_over_time(positions)
fig3.savefig('../output/leverage.png', dpi=300, bbox_inches='tight')
print("✓ Saved: leverage.png")

# Plot 4: Monthly returns
monthly_returns = backtester.get_monthly_returns(backtest_results)
fig4 = visualizer.plot_monthly_returns_heatmap(monthly_returns)
fig4.savefig('../output/monthly_heatmap.png', dpi=300, bbox_inches='tight')
print("✓ Saved: monthly_heatmap.png")

# Rolling Sharpe
rolling_sharpe = performance_analyzer.calculate_rolling_sharpe(backtest_results['returns'])
plt.figure(figsize=(15, 6))
plt.plot(rolling_sharpe.index, rolling_sharpe.values, linewidth=2)
plt.axhline(y=1, color='r', linestyle='--', label='Sharpe = 1')
plt.title('Rolling Sharpe Ratio', fontsize=16, fontweight='bold')
plt.xlabel('Date')
plt.ylabel('Sharpe Ratio')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('../output/rolling_sharpe.png', dpi=300, bbox_inches='tight')
print("✓ Saved: rolling_sharpe.png")
plt.close()

# Save results
backtest_results.to_csv('../output/backtest_results.csv')
subsystem_signals.to_csv('../output/subsystem_signals.csv')
positions.to_csv('../output/positions.csv')

# Save metrics
import json
metrics_for_json = {k: (float(v) if isinstance(v, (np.number, pd.Timestamp)) else str(v))
                   for k, v in metrics.items()}
with open('../output/metrics.json', 'w') as f:
    json.dump(metrics_for_json, f, indent=2)

print("\n✓ All results saved to 'output' directory")
print("\nDone!")

