"""
Visualization for Whitelight 2.0.
Creates charts for equity curves, heatmaps, regime overlays, and more.
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
import pandas as pd
import numpy as np
from typing import Optional

# Set style
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")


class Visualizer:
    """Creates visualizations for backtest results and analysis."""
    
    def __init__(self, figsize=(15, 10)):
        """
        Initialize visualizer.
        
        Args:
            figsize: Default figure size
        """
        self.figsize = figsize
    
    def plot_equity_curve(
        self,
        equity: pd.Series,
        regimes: Optional[pd.Series] = None,
        benchmark: Optional[pd.Series] = None,
        title: str = "Equity Curve - Whitelight 2.0"
    ) -> plt.Figure:
        """
        Plot equity curve with regime overlay and optional benchmark.
        
        Args:
            equity: Series of cumulative equity
            regimes: Optional series of regime classifications
            benchmark: Optional benchmark equity curve
            title: Chart title
            
        Returns:
            Matplotlib figure
        """
        fig, ax = plt.subplots(figsize=self.figsize)
        
        # Plot main equity curve
        ax.plot(equity.index, equity.values, label='Strategy', linewidth=2, color='#2E86AB')
        
        # Plot benchmark if provided
        if benchmark is not None:
            aligned_benchmark = benchmark.loc[equity.index]
            ax.plot(aligned_benchmark.index, aligned_benchmark.values,
                   label='Benchmark', linewidth=2, color='#A23B72', linestyle='--')
        
        # Add regime overlay
        if regimes is not None:
            aligned_regimes = regimes.loc[equity.index]
            self._add_regime_overlay(ax, equity.index, aligned_regimes)
        
        ax.set_xlabel('Date', fontsize=12)
        ax.set_ylabel('Equity ($)', fontsize=12)
        ax.set_title(title, fontsize=16, fontweight='bold')
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig
    
    def _add_regime_overlay(
        self,
        ax: plt.Axes,
        dates: pd.DatetimeIndex,
        regimes: pd.Series
    ):
        """Add colored background for regime classification."""
        colors = {'Bullish': '#90EE90', 'Bearish': '#FFB6C1', 'Neutral': '#D3D3D3'}
        
        regime_colors = regimes.map(colors)
        
        for date in dates:
            color = regime_colors.loc[date]
            if pd.notna(color):
                # Draw a vertical line for each day (very thin)
                ax.axvline(x=date, color=color, alpha=0.2, linewidth=0.5)
    
    def plot_drawdown(
        self,
        drawdown: pd.Series,
        title: str = "Drawdown Analysis"
    ) -> plt.Figure:
        """
        Plot drawdown curve.
        
        Args:
            drawdown: Series of drawdown values (0 to -1)
            title: Chart title
            
        Returns:
            Matplotlib figure
        """
        fig, ax = plt.subplots(figsize=self.figsize)
        
        ax.fill_between(drawdown.index, drawdown.values, 0,
                        alpha=0.3, color='#F77F00')
        ax.plot(drawdown.index, drawdown.values, linewidth=2, color='#D62828')
        
        ax.set_xlabel('Date', fontsize=12)
        ax.set_ylabel('Drawdown', fontsize=12)
        ax.set_title(title, fontsize=16, fontweight='bold')
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig
    
    def plot_monthly_returns_heatmap(
        self,
        monthly_returns: pd.Series,
        title: str = "Monthly Returns Heatmap"
    ) -> plt.Figure:
        """
        Plot monthly returns as a heatmap.
        
        Args:
            monthly_returns: Series of monthly returns
            title: Chart title
            
        Returns:
            Matplotlib figure
        """
        # Reshape into year x month format
        monthly_df = pd.DataFrame(monthly_returns)
        monthly_df['year'] = monthly_df.index.year
        monthly_df['month'] = monthly_df.index.month
        
        pivot = monthly_df.pivot_table(values=monthly_returns.name, index='year', columns='month')
        pivot.columns = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        
        fig, ax = plt.subplots(figsize=self.figsize)
        sns.heatmap(pivot, annot=True, fmt='.2%', cmap='RdYlGn', center=0,
                   cbar_kws={'label': 'Monthly Return'}, ax=ax)
        
        ax.set_xlabel('Month', fontsize=12)
        ax.set_ylabel('Year', fontsize=12)
        ax.set_title(title, fontsize=16, fontweight='bold')
        
        plt.tight_layout()
        return fig
    
    def plot_leverage_over_time(
        self,
        positions: pd.DataFrame,
        title: str = "Position Leverage Over Time"
    ) -> plt.Figure:
        """
        Plot leverage over time with long/short breakdown.
        
        Args:
            positions: DataFrame with 'tqqq_long' and 'sqqq_short' columns
            title: Chart title
            
        Returns:
            Matplotlib figure
        """
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=self.figsize, sharex=True)
        
        leverage = positions['tqqq_long'] + positions['sqqq_short']
        
        # Plot total leverage
        ax1.plot(positions.index, leverage.values, linewidth=2, color='#2E86AB')
        ax1.fill_between(positions.index, 0, leverage.values, alpha=0.3, color='#2E86AB')
        ax1.axhline(y=1.0, color='r', linestyle='--', linewidth=1, label='Max Leverage')
        ax1.set_ylabel('Total Leverage', fontsize=12)
        ax1.set_title(title, fontsize=16, fontweight='bold')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # Plot long/short breakdown
        ax2.plot(positions.index, positions['tqqq_long'].values,
                linewidth=2, color='green', label='Long (TQQQ)')
        ax2.plot(positions.index, positions['sqqq_short'].values,
                linewidth=2, color='red', label='Short (SQQQ)')
        ax2.set_xlabel('Date', fontsize=12)
        ax2.set_ylabel('Position Size', fontsize=12)
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        return fig
    
    def plot_subsystem_signals(
        self,
        subsystem_signals: pd.DataFrame,
        title: str = "Subsystem Signals Over Time"
    ) -> plt.Figure:
        """
        Plot subsystem signals over time.
        
        Args:
            subsystem_signals: DataFrame with subsystem signals
            title: Chart title
            
        Returns:
            Matplotlib figure
        """
        fig, axes = plt.subplots(len(subsystem_signals.columns), 1,
                                 figsize=self.figsize, sharex=True)
        
        if len(subsystem_signals.columns) == 1:
            axes = [axes]
        
        for i, (col, ax) in enumerate(zip(subsystem_signals.columns, axes)):
            signals = subsystem_signals[col]
            
            # Plot positive signals in green, negative in red
            positive = signals[signals > 0]
            negative = signals[signals < 0]
            
            if len(positive) > 0:
                ax.scatter(positive.index, positive.values,
                          color='green', marker='^', s=50, alpha=0.6)
            if len(negative) > 0:
                ax.scatter(negative.index, negative.values,
                          color='red', marker='v', s=50, alpha=0.6)
            
            ax.set_ylabel(col, fontsize=10)
            ax.grid(True, alpha=0.3)
        
        axes[-1].set_xlabel('Date', fontsize=12)
        fig.suptitle(title, fontsize=16, fontweight='bold', y=0.995)
        
        plt.tight_layout()
        return fig
    
    def plot_regime_distribution(
        self,
        regimes: pd.Series,
        title: str = "Regime Distribution"
    ) -> plt.Figure:
        """
        Plot regime distribution as pie chart.
        
        Args:
            regimes: Series of regime classifications
            title: Chart title
            
        Returns:
            Matplotlib figure
        """
        fig, ax = plt.subplots(figsize=(10, 8))
        
        counts = regimes.value_counts()
        colors = ['#90EE90', '#FFB6C1', '#D3D3D3']
        
        ax.pie(counts.values, labels=counts.index, autopct='%1.1f%%',
              colors=colors, startangle=90)
        ax.set_title(title, fontsize=16, fontweight='bold')
        
        plt.tight_layout()
        return fig
    
    def plot_metrics_summary(
        self,
        metrics: dict,
        title: str = "Performance Metrics Summary"
    ) -> plt.Figure:
        """
        Create a visual summary of key performance metrics.
        
        Args:
            metrics: Dictionary with performance metrics
            title: Chart title
            
        Returns:
            Matplotlib figure
        """
        # Select key metrics for visualization
        key_metrics = {
            'CAGR': metrics.get('cagr', 0),
            'Sharpe Ratio': metrics.get('sharpe_ratio', 0),
            'Max Drawdown': metrics.get('max_drawdown', 0),
            'Calmar Ratio': metrics.get('calmar_ratio', 0),
            'Win Rate': metrics.get('win_rate', 0),
            'Total Return': metrics.get('total_return', 0)
        }
        
        # Format as percentages where appropriate
        formatted_values = {
            k: f"{v:.2%}" if k in ['CAGR', 'Max Drawdown', 'Total Return', 'Win Rate']
            else f"{v:.2f}"
            for k, v in key_metrics.items()
        }
        
        fig, ax = plt.subplots(figsize=(12, 8))
        
        # Create a simple text-based visualization
        y_pos = np.arange(len(key_metrics))
        ax.axis('off')
        
        text_y = 1.0
        for metric, value in formatted_values.items():
            ax.text(0.1, text_y, f"{metric}:", fontsize=14, fontweight='bold',
                   verticalalignment='top', transform=ax.transAxes)
            ax.text(0.5, text_y, value, fontsize=14,
                   verticalalignment='top', transform=ax.transAxes)
            text_y -= 0.12
        
        ax.set_title(title, fontsize=18, fontweight='bold', y=0.95)
        
        plt.tight_layout()
        return fig

