"""
Performance analytics for Whitelight 2.0.
Additional metrics and rolling statistics calculation.
"""

import pandas as pd
import numpy as np
from typing import Optional


class PerformanceAnalyzer:
    """Analyzes performance with rolling metrics and advanced statistics."""
    
    def calculate_rolling_sharpe(
        self,
        returns: pd.Series,
        window: int = 252
    ) -> pd.Series:
        """
        Calculate rolling Sharpe ratio.
        
        Args:
            returns: Series of daily returns
            window: Rolling window in days (default: 252 = 1 year)
            
        Returns:
            Series of rolling Sharpe ratios
        """
        mean_return = returns.rolling(window=window, min_periods=1).mean()
        std_return = returns.rolling(window=window, min_periods=1).std()
        
        sharpe = (mean_return * 252) / (std_return * np.sqrt(252))
        
        return sharpe
    
    def calculate_rolling_calmar(
        self,
        equity: pd.Series,
        window: int = 252
    ) -> pd.Series:
        """
        Calculate rolling Calmar ratio (CAGR / Max Drawdown).
        
        Args:
            equity: Series of cumulative equity
            window: Rolling window in days (default: 252)
            
        Returns:
            Series of rolling Calmar ratios
        """
        rolling_calmar = pd.Series(index=equity.index, dtype=float)
        
        for i in range(window, len(equity)):
            window_equity = equity.iloc[i-window:i]
            
            # Calculate CAGR for window
            num_years = len(window_equity) / 252
            if num_years > 0 and window_equity.iloc[0] > 0:
                cagr = (window_equity.iloc[-1] / window_equity.iloc[0]) ** (1 / num_years) - 1
            else:
                cagr = 0
            
            # Calculate max drawdown for window
            rolling_max = window_equity.cummax()
            drawdowns = (window_equity - rolling_max) / rolling_max
            max_dd = drawdowns.min()
            
            # Calmar ratio
            rolling_calmar.iloc[i] = cagr / abs(max_dd) if max_dd != 0 else 0
        
        return rolling_calmar
    
    def calculate_subsystem_contribution(
        self,
        subsystem_signals: pd.DataFrame,
        backtest_results: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Calculate contribution of each subsystem to overall returns.
        
        Args:
            subsystem_signals: DataFrame with subsystem signals
            backtest_results: DataFrame with equity and returns
            
        Returns:
            DataFrame with subsystem contributions
        """
        aligned = subsystem_signals.loc[backtest_results.index]
        contributions = pd.DataFrame(index=aligned.index)
        
        # For each subsystem, calculate weighted returns
        # This is a simplified approach - could be more sophisticated
        for col in aligned.columns:
            # Normalize signals to create weights
            subsystem_weight = aligned[col].abs() / aligned.abs().sum(axis=1).replace(0, 1)
            # Weight the portfolio returns by this subsystem's influence
            contributions[col] = subsystem_weight * backtest_results['returns']
        
        return contributions
    
    def calculate_monthly_stats(
        self,
        backtest_results: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Calculate monthly statistics.
        
        Args:
            backtest_results: DataFrame with returns column
            
        Returns:
            DataFrame with monthly statistics
        """
        returns = backtest_results['returns']
        
        # Resample to monthly
        monthly = returns.resample('M').apply(lambda x: (1 + x).prod() - 1)
        
        stats = pd.DataFrame({
            'monthly_return': monthly,
            'year': monthly.index.year,
            'month': monthly.index.month
        })
        
        # Add cumulative stats
        stats['cumulative_return'] = (1 + monthly).cumprod() - 1
        
        # Add win/loss
        stats['is_positive'] = monthly > 0
        
        return stats
    
    def get_top_months(
        self,
        monthly_stats: pd.DataFrame,
        n: int = 10
    ) -> pd.DataFrame:
        """
        Get top performing months.
        
        Args:
            monthly_stats: DataFrame with monthly statistics
            n: Number of months to return (default: 10)
            
        Returns:
            DataFrame with top N months
        """
        return monthly_stats.nlargest(n, 'monthly_return')
    
    def get_worst_months(
        self,
        monthly_stats: pd.DataFrame,
        n: int = 10
    ) -> pd.DataFrame:
        """
        Get worst performing months.
        
        Args:
            monthly_stats: DataFrame with monthly statistics
            n: Number of months to return (default: 10)
            
        Returns:
            DataFrame with worst N months
        """
        return monthly_stats.nsmallest(n, 'monthly_return')
    
    def calculate_recovery_periods(
        self,
        backtest_results: pd.DataFrame
    ) -> dict:
        """
        Calculate recovery periods from drawdowns.
        
        Args:
            backtest_results: DataFrame with drawdown and equity columns
            
        Returns:
            Dictionary with recovery statistics
        """
        drawdowns = backtest_results['drawdown']
        equity = backtest_results['equity']
        
        # Find drawdown periods (when drawdown < 0)
        in_dd = drawdowns < 0
        
        if not in_dd.any():
            return {
                'num_drawdowns': 0,
                'avg_recovery_days': 0,
                'max_recovery_days': 0
            }
        
        # Track drawdowns
        dd_periods = []
        recovery_days = []
        
        in_dd_prev = False
        dd_start = None
        recovery_start = None
        
        for i, (date, dd) in enumerate(in_dd.items()):
            if dd and not in_dd_prev:  # Entering drawdown
                dd_start = date
            elif not dd and in_dd_prev:  # Exiting drawdown
                if dd_start is not None:
                    dd_periods.append((dd_start, date))
                    recovery_days.append((date - dd_start).days)
                    dd_start = None
            
            in_dd_prev = dd
        
        return {
            'num_drawdowns': len(dd_periods),
            'avg_recovery_days': np.mean(recovery_days) if recovery_days else 0,
            'max_recovery_days': max(recovery_days) if recovery_days else 0,
            'min_recovery_days': min(recovery_days) if recovery_days else 0
        }

