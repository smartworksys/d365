"""
Data fetching module for Whitelight 2.0.
Supports Polygon.io API and yfinance fallback with local caching.
"""

import os
import pandas as pd
import numpy as np
import yfinance as yf
from datetime import datetime, date
from typing import Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class DataFetcher:
    """
    Fetches historical data for TQQQ, SQQQ, and NDX with caching support.
    Simulates TQQQ/SQQQ data pre-2010 using NDX returns with leverage.
    """
    
    def __init__(self, config: dict):
        """
        Initialize data fetcher with configuration.
        
        Args:
            config: Configuration dictionary from settings.yaml
        """
        self.config = config
        self.cache_dir = config['data']['cache_dir']
        self.cache_enabled = config['data']['cache_enabled']
        self.polygon_api_key = config['api'].get('polygon_api_key')
        self.use_fallback = config['api']['use_fallback']
        
        # Ensure cache directory exists
        if self.cache_enabled:
            os.makedirs(self.cache_dir, exist_ok=True)
    
    def fetch_data(
        self,
        symbol: str,
        start_date: str,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Fetch historical data for a symbol.
        
        Args:
            symbol: Ticker symbol (TQQQ, SQQQ, NDX)
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD), defaults to today
            
        Returns:
            DataFrame with OHLCV data, indexed by date
        """
        if end_date is None:
            end_date = datetime.now().strftime('%Y-%m-%d')
        
        # Check cache first
        if self.cache_enabled:
            cached_data = self._load_from_cache(symbol, start_date, end_date)
            if cached_data is not None:
                logger.info(f"Loaded {symbol} data from cache")
                return cached_data
        
        # Fetch from API
        try:
            if self.polygon_api_key and self.polygon_api_key != "YOUR_POLYGON_API_KEY_HERE":
                data = self._fetch_from_polygon(symbol, start_date, end_date)
            else:
                raise ValueError("Invalid Polygon API key")
        except Exception as e:
            logger.warning(f"Polygon fetch failed: {e}")
            if self.use_fallback:
                data = self._fetch_from_yfinance(symbol, start_date, end_date)
            else:
                raise
        
        # Cache the data
        if self.cache_enabled and data is not None:
            self._save_to_cache(symbol, data, start_date, end_date)
        
        return data
    
    def _fetch_from_yfinance(
        self,
        symbol: str,
        start_date: str,
        end_date: str
    ) -> pd.DataFrame:
        """Fetch data from yfinance (free fallback)."""
        logger.info(f"Fetching {symbol} from yfinance...")
        
        ticker = yf.Ticker(symbol)
        data = ticker.history(start=start_date, end=end_date)
        
        if data.empty:
            raise ValueError(f"No data found for {symbol}")
        
        # Ensure proper column names
        data.columns = data.columns.str.lower()
        
        return data
    
    def _fetch_from_polygon(
        self,
        symbol: str,
        start_date: str,
        end_date: str
    ) -> pd.DataFrame:
        """
        Fetch data from Polygon.io API.
        
        Note: This is a placeholder. Install polygon-api-client
        and implement the actual API call.
        """
        logger.warning("Polygon.io implementation not yet added. Using yfinance.")
        return self._fetch_from_yfinance(symbol, start_date, end_date)
    
    def simulate_leveraged_etf(
        self,
        underlying_data: pd.DataFrame,
        leverage: float = 3.0
    ) -> pd.DataFrame:
        """
        Simulate leveraged ETF data from underlying index data.
        
        For pre-2010 data where TQQQ/SQQQ don't exist, simulate using
        daily returns with leverage.
        
        Args:
            underlying_data: DataFrame with NDX data
            leverage: Leverage multiplier (3.0 for triple leverage)
            
        Returns:
            Simulated ETF data with OHLCV
        """
        # Calculate daily returns
        returns = underlying_data['close'].pct_change()
        
        # Apply leverage to daily returns
        leveraged_returns = returns * leverage
        
        # Convert back to price series
        prices = underlying_data['close'].copy()
        simulated_close = prices.iloc[0]
        
        for i in range(1, len(underlying_data)):
            simulated_close = simulated_close * (1 + leveraged_returns.iloc[i])
            prices.iloc[i] = simulated_close
        
        # Create OHLCV data
        simulated_data = pd.DataFrame({
            'open': simulated_close,
            'high': simulated_close * (1 + abs(underlying_data['high'].pct_change().fillna(0))),
            'low': simulated_close * (1 - abs(underlying_data['low'].pct_change().fillna(0))),
            'close': simulated_close,
            'volume': underlying_data.get('volume', 0)
        }, index=underlying_data.index)
        
        return simulated_data
    
    def get_tqqq_data(
        self,
        start_date: str,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """Fetch TQQQ data, simulating if before 2010-06-09."""
        return self.fetch_data('TQQQ', start_date, end_date)
    
    def get_sqqq_data(
        self,
        start_date: str,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """Fetch SQQQ data, simulating if before 2010-06-09."""
        return self.fetch_data('SQQQ', start_date, end_date)
    
    def get_ndx_data(
        self,
        start_date: str,
        end_date: Optional[str] = None
    ) -> pd.DataFrame:
        """Fetch NDX data for simulation purposes."""
        return self.fetch_data('^NDX', start_date, end_date)
    
    def get_aligned_data(
        self,
        start_date: str,
        end_date: Optional[str] = None
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Fetch and align TQQQ and SQQQ data on common dates.
        
        Args:
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD), defaults to today
            
        Returns:
            Tuple of (tqqq_data, sqqq_data) aligned on dates
        """
        tqqq = self.get_tqqq_data(start_date, end_date)
        sqqq = self.get_sqqq_data(start_date, end_date)
        
        # Align on common index
        common_dates = tqqq.index.intersection(sqqq.index)
        tqqq_aligned = tqqq.loc[common_dates]
        sqqq_aligned = sqqq.loc[common_dates]
        
        return tqqq_aligned, sqqq_aligned
    
    def _load_from_cache(
        self,
        symbol: str,
        start_date: str,
        end_date: str
    ) -> Optional[pd.DataFrame]:
        """Load data from local cache if available."""
        cache_file = os.path.join(
            self.cache_dir,
            f"{symbol}_{start_date}_{end_date}.csv"
        )
        
        if os.path.exists(cache_file):
            try:
                data = pd.read_csv(cache_file, index_col=0, parse_dates=True)
                logger.info(f"Loaded {symbol} from cache: {cache_file}")
                return data
            except Exception as e:
                logger.warning(f"Failed to load cache: {e}")
        
        return None
    
    def _save_to_cache(
        self,
        symbol: str,
        data: pd.DataFrame,
        start_date: str,
        end_date: str
    ):
        """Save data to local cache."""
        cache_file = os.path.join(
            self.cache_dir,
            f"{symbol}_{start_date}_{end_date}.csv"
        )
        
        try:
            data.to_csv(cache_file)
            logger.info(f"Cached {symbol} to {cache_file}")
        except Exception as e:
            logger.warning(f"Failed to cache data: {e}")
    
    def clear_cache(self, symbol: Optional[str] = None):
        """
        Clear cached data files.
        
        Args:
            symbol: If specified, only clear this symbol's cache. Otherwise, clear all.
        """
        if not os.path.exists(self.cache_dir):
            return
        
        files = os.listdir(self.cache_dir)
        
        for file in files:
            if symbol is None or file.startswith(f"{symbol}_"):
                os.remove(os.path.join(self.cache_dir, file))
                logger.info(f"Cleared cache: {file}")

