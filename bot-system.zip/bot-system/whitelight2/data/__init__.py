"""Data fetching and caching module for Whitelight 2.0."""

