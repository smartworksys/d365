# Whitelight 2.0 - Quick Start Guide

## Installation

1. **Navigate to the project directory:**
   ```bash
   cd whitelight2
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

## Configuration

1. **Edit `config/settings.yaml`** (optional):
   - Add your Polygon.io API key for better data quality (free tier available)
   - Or leave it as-is to use yfinance (works fine, no key needed)

## Running the Backtest

### Option 1: Run the main script

```bash
python main.py
```

This will:
- Fetch TQQQ/SQQQ data
- Calculate indicators
- Generate trading signals
- Run the backtest
- Save results to `output/` directory

### Option 2: Run the research script for detailed analysis

```bash
python notebooks/research.py
```

### Option 3: Use Jupyter Notebook (recommended for exploration)

```bash
jupyter notebook notebooks/research.py
```

## Output Files

After running, you'll find in the `output/` directory:

- `equity_curve.png` - Portfolio equity over time with regime overlay
- `drawdown.png` - Drawdown analysis chart
- `leverage.png` - Position leverage over time
- `monthly_heatmap.png` - Monthly returns heatmap
- `rolling_sharpe.png` - Rolling Sharpe ratio analysis
- `backtest_results.csv` - Full backtest results
- `subsystem_signals.csv` - Trading signals from each subsystem
- `positions.csv` - Position allocations over time
- `metrics.json` - Performance metrics summary

## Understanding the Results

### Key Metrics

- **CAGR**: Compound Annual Growth Rate
- **Sharpe Ratio**: Risk-adjusted return (typically >1 is good)
- **Max Drawdown**: Worst peak-to-trough decline
- **Calmar Ratio**: CAGR / Max Drawdown (higher is better)
- **Win Rate**: Percentage of profitable days

### Subsystems

The system uses 7 trading subsystems:

1. **TF1** - Trend Following Long (Momentum)
2. **MR1** - Mean Reversion Long (RSI < 35)
3. **MR2** - Mean Reversion Long (RSI < 25)
4. **MR3** - Mean Reversion Long (RSI < 20)
5. **TFShort1** - Trend Following Short
6. **TFShort2** - Additional Momentum Short
7. **MRShort1** - Mean Reversion Short (Countertrend)

### Market Regimes

The system classifies markets as:
- **Bullish**: Price > MA250 AND ADX > 20
- **Bearish**: Price < MA250 AND ADX > 20
- **Neutral**: Otherwise

## Customizing the Strategy

Edit `config/settings.yaml` to adjust:

- **RSI Thresholds**: Change mean reversion entry points
- **Moving Average Periods**: Modify trend detection
- **Volatility Scaling**: Adjust position sizing sensitivity
- **Risk Management**: Modify drawdown limits
- **Subsystems**: Enable/disable specific strategies

## Advanced Usage

### Adding Custom Subsystems

1. Edit `core/subsystems.py`
2. Add your signal generation logic
3. Register it in `config/settings.yaml`
4. Re-run the backtest

### Machine Learning Integration

The system is designed to be extended with ML:

1. Use subsystem signals as features
2. Train ensemble models to weight subsystems dynamically
3. Integrate with `allocator.py` for position sizing

### Live Trading

For production trading (use at your own risk):

1. Implement API connections (Alpaca, Fidelity, etc.)
2. Add order execution logic
3. Add monitoring and alerting
4. **Test thoroughly on paper trading first!**

## Troubleshooting

### "No data found" error

- Check your internet connection
- Verify the ticker symbols are correct
- Try using yfinance fallback by leaving Polygon key empty

### Slow performance

- Data is cached in `data/cache/`
- Delete cache to re-fetch fresh data
- First run will be slower while caching

### Import errors

- Ensure all dependencies are installed: `pip install -r requirements.txt`
- Check you're in the correct directory
- Verify Python version (3.8+)

## Support

For issues, questions, or contributions:
- Review the README.md
- Check config/settings.yaml for parameter descriptions
- Examine the code documentation in each module

## Disclaimer

**This is educational software. Trading leveraged ETFs involves substantial risk.**
- Past performance does not guarantee future results
- Always do your own research
- Consult with a licensed financial advisor
- Never risk more than you can afford to lose

## License

MIT License - See LICENSE file for details

