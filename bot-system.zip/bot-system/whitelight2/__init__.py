"""
Whitelight 2.0 - Adaptive Dual-Leverage Trading Framework
A production-ready Python trading system for TQQQ/SQQQ trading.
"""

__version__ = "2.0.0"
__author__ = "Whitelight Team"

