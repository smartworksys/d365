using System.Text.Json.Serialization;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Models;

public class UserPrincipal
{
    [JsonPropertyName("auth_typ")]
    public string? AuthType { get; set; }

    [JsonPropertyName("claims")]
    public List<Claim>? Claims { get; set; }

    [JsonPropertyName("name_typ")]
    public string? NameType { get; set; }

    [JsonPropertyName("role_typ")]
    public string? RoleType { get; set; }

    public Identity Identity
    {
        get
        {
            var nameClaim = Claims?.FirstOrDefault(c => c.Type == "name")?.Value;
            return new Identity { Name = nameClaim };
        }
    }
}

public class Claim
{
    [JsonPropertyName("typ")]
    public string? Type { get; set; }

    [JsonPropertyName("val")]
    public string? Value { get; set; }
}

public class Identity
{
    public string? Name { get; set; }
}

