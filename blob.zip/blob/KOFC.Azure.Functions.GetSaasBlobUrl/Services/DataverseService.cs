using System.Net;
using Microsoft.Extensions.Logging;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public class DataverseService : IDataverseService
{
    private readonly ILogger<DataverseService> _logger;
    private readonly HttpClient _httpClient;

    public DataverseService(ILogger<DataverseService> logger, HttpClient httpClient)
    {
        _logger = logger;
        _httpClient = httpClient;
    }

    public async Task<bool> ValidateContactAccessAsync(string contactId, string accessToken, string dataverseUrl)
    {
        if (string.IsNullOrWhiteSpace(contactId))
        {
            _logger.LogWarning("ContactId is null or empty");
            return false;
        }

        if (string.IsNullOrWhiteSpace(accessToken))
        {
            _logger.LogWarning("Access token is null or empty");
            return false;
        }

        if (string.IsNullOrWhiteSpace(dataverseUrl))
        {
            _logger.LogWarning("Dataverse URL is null or empty");
            return false;
        }

        try
        {
            // Validate GUID format
            if (!Guid.TryParse(contactId, out _))
            {
                _logger.LogWarning("Invalid contact ID format: {ContactId}", contactId);
                return false;
            }

            var requestUri = $"{dataverseUrl.TrimEnd('/')}/api/data/v9.2/contacts({contactId})?$select=contactid";
            
            using var request = new HttpRequestMessage(HttpMethod.Get, requestUri);
            request.Headers.Add("Authorization", $"Bearer {accessToken}");
            request.Headers.Add("Accept", "application/json");
            request.Headers.Add("OData-MaxVersion", "4.0");
            request.Headers.Add("OData-Version", "4.0");

            _logger.LogInformation("Validating access to contact {ContactId} at {DataverseUrl}", contactId, dataverseUrl);

            var response = await _httpClient.SendAsync(request);

            if (response.StatusCode == HttpStatusCode.OK)
            {
                _logger.LogInformation("User has access to contact {ContactId}", contactId);
                return true;
            }
            else if (response.StatusCode == HttpStatusCode.Forbidden || response.StatusCode == HttpStatusCode.NotFound)
            {
                _logger.LogWarning("User does not have access to contact {ContactId}. Status: {StatusCode}", 
                    contactId, response.StatusCode);
                return false;
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                _logger.LogError("Unexpected response from Dataverse. Status: {StatusCode}, Content: {Content}", 
                    response.StatusCode, errorContent);
                return false;
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error validating contact access for contact {ContactId}", contactId);
            return false;
        }
    }
}

