namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public interface IDataverseService
{
    /// <summary>
    /// Validates that the user has access to the specified contact record in Dataverse
    /// </summary>
    /// <param name="contactId">The GUID of the contact record</param>
    /// <param name="accessToken">The Azure AD access token for Dataverse API</param>
    /// <param name="dataverseUrl">The Dataverse organization URL</param>
    /// <returns>True if the user has access, false otherwise</returns>
    Task<bool> ValidateContactAccessAsync(string contactId, string accessToken, string dataverseUrl);
}

