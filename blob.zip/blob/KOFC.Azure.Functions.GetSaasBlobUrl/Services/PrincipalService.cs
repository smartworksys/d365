using System.Text;
using System.Text.Json;
using KOFC.Azure.Functions.GetSaasBlobUrl.Models;
using Microsoft.Extensions.Logging;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public class PrincipalService : IPrincipalService
{
    private readonly ILogger<PrincipalService> _logger;

    public PrincipalService(ILogger<PrincipalService> logger)
    {
        _logger = logger;
    }

    public UserPrincipal? DecodeUserPrincipal(string base64Principal)
    {
        if (string.IsNullOrWhiteSpace(base64Principal))
        {
            _logger.LogWarning("Base64 principal string is null or empty");
            return null;
        }

        try
        {
            var decodedBytes = Convert.FromBase64String(base64Principal);
            var decodedJson = Encoding.UTF8.GetString(decodedBytes);
            var principal = JsonSerializer.Deserialize<UserPrincipal>(decodedJson);
            
            _logger.LogInformation("Successfully decoded user principal for user: {UserName}", principal?.Identity.Name);
            return principal;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to decode user principal from Base64 string");
            return null;
        }
    }
}

