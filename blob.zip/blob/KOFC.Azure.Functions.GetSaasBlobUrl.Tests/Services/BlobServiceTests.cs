using Azure.Storage.Blobs;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests.Services;

public class BlobServiceTests
{
    [Theory]
    [InlineData("D:\\KOFCExt Extractions\\09272024\\000554\\test.xlsx", "KOFCExt Extractions/09272024/000554/test.xlsx")]
    [InlineData("D:\\KOFCExt Extractions\\file.pdf", "KOFCExt Extractions/file.pdf")]
    [InlineData("C:\\KOFCExt Extractions\\folder\\document.docx", "KOFCExt Extractions/folder/document.docx")]
    [InlineData("E:\\Test\\subfolder\\file.txt", "Test/subfolder/file.txt")]
    [InlineData("D:\\KOFCExt Extractions\\", "KOFCExt Extractions")]
    [InlineData("D:\\KOFCExt Extractions", "KOFCExt Extractions")]
    public void NormalizePathToBlob_ValidWindowsPath_ReturnsNormalizedPath(string input, string expected)
    {
        // Arrange
        var mockLogger = new Mock<ILogger<BlobService>>();
        var mockBlobServiceClient = new Mock<BlobServiceClient>();
        var blobService = new BlobService(mockLogger.Object, mockBlobServiceClient.Object);

        // Act
        var result = blobService.NormalizePathToBlob(input);

        // Assert
        Assert.Equal(expected, result);
    }

    [Fact]
    public void NormalizePathToBlob_NullPath_ReturnsEmpty()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<BlobService>>();
        var mockBlobServiceClient = new Mock<BlobServiceClient>();
        var blobService = new BlobService(mockLogger.Object, mockBlobServiceClient.Object);

        // Act
        var result = blobService.NormalizePathToBlob(null!);

        // Assert
        Assert.Equal(string.Empty, result);
    }

    [Fact]
    public void NormalizePathToBlob_EmptyPath_ReturnsEmpty()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<BlobService>>();
        var mockBlobServiceClient = new Mock<BlobServiceClient>();
        var blobService = new BlobService(mockLogger.Object, mockBlobServiceClient.Object);

        // Act
        var result = blobService.NormalizePathToBlob("");

        // Assert
        Assert.Equal(string.Empty, result);
    }

    [Fact]
    public void NormalizePathToBlob_WhitespacePath_ReturnsEmpty()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<BlobService>>();
        var mockBlobServiceClient = new Mock<BlobServiceClient>();
        var blobService = new BlobService(mockLogger.Object, mockBlobServiceClient.Object);

        // Act
        var result = blobService.NormalizePathToBlob("   ");

        // Assert
        Assert.Equal(string.Empty, result);
    }

    [Theory]
    [InlineData("D:\\test\\\\file.txt", "test/file.txt")]
    [InlineData("D:\\test//file.txt", "test/file.txt")]
    [InlineData("D:\\test\\/\\file.txt", "test/file.txt")]
    [InlineData("D:\\\\test\\file.txt", "test/file.txt")]
    public void NormalizePathToBlob_PathWithMultipleSlashes_CollapsesSlashes(string input, string expected)
    {
        // Arrange
        var mockLogger = new Mock<ILogger<BlobService>>();
        var mockBlobServiceClient = new Mock<BlobServiceClient>();
        var blobService = new BlobService(mockLogger.Object, mockBlobServiceClient.Object);

        // Act
        var result = blobService.NormalizePathToBlob(input);

        // Assert
        Assert.Equal(expected, result);
    }

    [Theory]
    [InlineData("D:\\KOFCEXT EXTRACTIONS\\file.txt", "KOFCEXT EXTRACTIONS/file.txt")]
    [InlineData("D:\\kofcext extractions\\file.txt", "kofcext extractions/file.txt")]
    [InlineData("D:\\KoFcExT eXtRaCtIoNs\\file.txt", "KoFcExT eXtRaCtIoNs/file.txt")]
    [InlineData("D:\\KOFCExt Extractions\\subfolder\\file.txt", "KOFCExt Extractions/subfolder/file.txt")]
    public void NormalizePathToBlob_PreservesKOFCExtExtractions_PreservesPrefix(string input, string expected)
    {
        // Arrange
        var mockLogger = new Mock<ILogger<BlobService>>();
        var mockBlobServiceClient = new Mock<BlobServiceClient>();
        var blobService = new BlobService(mockLogger.Object, mockBlobServiceClient.Object);

        // Act
        var result = blobService.NormalizePathToBlob(input);

        // Assert
        Assert.Equal(expected, result);
    }

    [Fact]
    public async Task GenerateSasUrlAsync_NullContainerName_ThrowsArgumentException()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<BlobService>>();
        var mockBlobServiceClient = new Mock<BlobServiceClient>();
        var blobService = new BlobService(mockLogger.Object, mockBlobServiceClient.Object);

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentException>(async () =>
            await blobService.GenerateSasUrlAsync(null!, "test.txt"));
    }

    [Fact]
    public async Task GenerateSasUrlAsync_EmptyContainerName_ThrowsArgumentException()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<BlobService>>();
        var mockBlobServiceClient = new Mock<BlobServiceClient>();
        var blobService = new BlobService(mockLogger.Object, mockBlobServiceClient.Object);

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentException>(async () =>
            await blobService.GenerateSasUrlAsync("", "test.txt"));
    }

    [Fact]
    public async Task GenerateSasUrlAsync_NullBlobPath_ThrowsArgumentException()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<BlobService>>();
        var mockBlobServiceClient = new Mock<BlobServiceClient>();
        var blobService = new BlobService(mockLogger.Object, mockBlobServiceClient.Object);

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentException>(async () =>
            await blobService.GenerateSasUrlAsync("container", null!));
    }

    [Fact]
    public async Task GenerateSasUrlAsync_EmptyBlobPath_ThrowsArgumentException()
    {
        // Arrange
        var mockLogger = new Mock<ILogger<BlobService>>();
        var mockBlobServiceClient = new Mock<BlobServiceClient>();
        var blobService = new BlobService(mockLogger.Object, mockBlobServiceClient.Object);

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentException>(async () =>
            await blobService.GenerateSasUrlAsync("container", ""));
    }
}

