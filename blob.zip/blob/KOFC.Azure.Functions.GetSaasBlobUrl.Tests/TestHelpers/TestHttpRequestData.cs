using System.IO;
using System.Net;
using System.Security.Claims;
using System.Text;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests.TestHelpers;

public class TestHttpRequestData : HttpRequestData
{
    public TestHttpRequestData(FunctionContext functionContext, Uri url, HttpHeadersCollection headers)
        : base(functionContext)
    {
        Url = url;
        Headers = headers;
    }

    public override Stream Body { get; } = new MemoryStream();
    public override HttpHeadersCollection Headers { get; }
    public override IReadOnlyCollection<IHttpCookie> Cookies => new List<IHttpCookie>();
    public override Uri Url { get; }
    public override IEnumerable<ClaimsIdentity> Identities => new List<ClaimsIdentity>();
    public override string Method { get; } = "GET";

    public override HttpResponseData CreateResponse()
    {
        return new TestHttpResponseData(FunctionContext);
    }
}

public class TestHttpResponseData : HttpResponseData
{
    public TestHttpResponseData(FunctionContext functionContext)
        : base(functionContext)
    {
        Headers = new HttpHeadersCollection();
        Body = new MemoryStream();
    }

    public override HttpStatusCode StatusCode { get; set; }
    public override HttpHeadersCollection Headers { get; set; }
    public override Stream Body { get; set; }
    public override HttpCookies Cookies { get; } = new TestHttpCookies();

    // WriteStringAsync is an extension method, so we implement it directly
    public async Task WriteStringAsync(string value, CancellationToken cancellationToken = default)
    {
        var bytes = Encoding.UTF8.GetBytes(value);
        await Body.WriteAsync(bytes, cancellationToken);
        Body.Position = 0;
    }
}

public class TestHttpCookies : HttpCookies
{
    public override void Append(string name, string value)
    {
        // No-op for testing
    }

    public override void Append(IHttpCookie cookie)
    {
        // No-op for testing
    }

    public override IHttpCookie CreateNew()
    {
        return new TestHttpCookie();
    }
}

public class TestHttpCookie : IHttpCookie
{
    public string Name { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
    public DateTimeOffset? Expires { get; set; }
    public string? Domain { get; set; }
    public string? Path { get; set; }
    public bool? Secure { get; set; }
    public bool? HttpOnly { get; set; }
    public SameSite SameSite { get; set; }
    public double? MaxAge { get; set; }
}

