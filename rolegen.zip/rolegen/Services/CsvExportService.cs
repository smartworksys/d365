using CsvHelper;
using CsvHelper.Configuration;
using Dynamics365PermissionExporter.Models;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace Dynamics365PermissionExporter.Services
{
    public class CsvExportService
    {
        public void ExportHierarchyToCsv(List<BusinessUnitHierarchy> hierarchy, string filePath)
        {
            var config = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HasHeaderRecord = true,
                Delimiter = ","
            };

            using (var writer = new StreamWriter(filePath))
            using (var csv = new CsvWriter(writer, config))
            {
                csv.WriteRecords(hierarchy);
            }
        }

        public void ExportHierarchyWithRolesToCsv(List<PermissionHierarchy> hierarchy, string filePath)
        {
            var config = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HasHeaderRecord = true,
                Delimiter = ","
            };

            using (var writer = new StreamWriter(filePath))
            using (var csv = new CsvWriter(writer, config))
            {
                csv.WriteRecords(hierarchy);
            }
        }

        public void ExportHierarchyWithRolesAndPermissionsToCsv(List<RolePermission> permissions, string filePath)
        {
            var config = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                HasHeaderRecord = true,
                Delimiter = ","
            };

            using (var writer = new StreamWriter(filePath))
            using (var csv = new CsvWriter(writer, config))
            {
                csv.WriteRecords(permissions);
            }
        }
    }
}

