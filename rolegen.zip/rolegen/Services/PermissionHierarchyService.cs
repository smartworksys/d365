using Dynamics365PermissionExporter.Models;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace Dynamics365PermissionExporter.Services;

public class PermissionHierarchyService
{
    private readonly IOrganizationService _service;

    public PermissionHierarchyService(IOrganizationService service)
    {
        _service = service;
    }

    public List<PermissionHierarchy> GetCompletePermissionsHierarchy()
    {
        var hierarchy = new List<PermissionHierarchy>();
        
        // Get all Business Units
        var businessUnits = GetAllBusinessUnits();
        
        // Get all Roles
        var roles = GetAllRoles();
        
        // Get all Teams
        var teams = GetAllTeams();
        
        // Get all Users
        var users = GetAllUsers();
        
        // Build hierarchy for each Business Unit
        foreach (var bu in businessUnits)
        {
            var parentBu = businessUnits.FirstOrDefault(p => p.Id == bu.GetAttributeValue<EntityReference>("parentbusinessunitid")?.Id);
            var buLevel = CalculateBusinessUnitLevel(bu, businessUnits);
            
            // Get roles directly assigned to Business Unit
            var buRoles = GetRolesForBusinessUnit(bu.Id, roles);
            
            foreach (var role in buRoles)
            {
                hierarchy.Add(new PermissionHierarchy
                {
                    BusinessUnitName = bu.GetAttributeValue<string>("name") ?? string.Empty,
                    BusinessUnitId = bu.Id.ToString(),
                    ParentBusinessUnitName = parentBu?.GetAttributeValue<string>("name") ?? "Root",
                    ParentBusinessUnitId = parentBu?.Id.ToString() ?? string.Empty,
                    TeamName = string.Empty,
                    TeamId = string.Empty,
                    RoleName = role.GetAttributeValue<string>("name") ?? string.Empty,
                    RoleId = role.Id.ToString(),
                    RoleDescription = role.GetAttributeValue<string>("description") ?? string.Empty,
                    UserName = string.Empty,
                    UserId = string.Empty,
                    UserEmail = string.Empty,
                    SecurityRoleType = "Business Unit",
                    HierarchyLevel = buLevel.ToString()
                });
            }
            
            // Get teams in this Business Unit
            var buTeams = teams.Where(t => 
                t.GetAttributeValue<EntityReference>("businessunitid")?.Id == bu.Id).ToList();
            
            foreach (var team in buTeams)
            {
                // Get roles assigned to team
                var teamRoles = GetRolesForTeam(team.Id, roles);
                
                foreach (var role in teamRoles)
                {
                    hierarchy.Add(new PermissionHierarchy
                    {
                        BusinessUnitName = bu.GetAttributeValue<string>("name") ?? string.Empty,
                        BusinessUnitId = bu.Id.ToString(),
                        ParentBusinessUnitName = parentBu?.GetAttributeValue<string>("name") ?? "Root",
                        ParentBusinessUnitId = parentBu?.Id.ToString() ?? string.Empty,
                        TeamName = team.GetAttributeValue<string>("name") ?? string.Empty,
                        TeamId = team.Id.ToString(),
                        RoleName = role.GetAttributeValue<string>("name") ?? string.Empty,
                        RoleId = role.Id.ToString(),
                        RoleDescription = role.GetAttributeValue<string>("description") ?? string.Empty,
                        UserName = string.Empty,
                        UserId = string.Empty,
                        UserEmail = string.Empty,
                        SecurityRoleType = "Team",
                        HierarchyLevel = buLevel.ToString()
                    });
                }
                
                // Get users in this team
                var teamUsers = GetUsersInTeam(team.Id, users);
                
                foreach (var user in teamUsers)
                {
                    // Get roles directly assigned to user
                    var userRoles = GetRolesForUser(user.Id, roles);
                    
                    foreach (var role in userRoles)
                    {
                        hierarchy.Add(new PermissionHierarchy
                        {
                            BusinessUnitName = bu.GetAttributeValue<string>("name") ?? string.Empty,
                            BusinessUnitId = bu.Id.ToString(),
                            ParentBusinessUnitName = parentBu?.GetAttributeValue<string>("name") ?? "Root",
                            ParentBusinessUnitId = parentBu?.Id.ToString() ?? string.Empty,
                            TeamName = team.GetAttributeValue<string>("name") ?? string.Empty,
                            TeamId = team.Id.ToString(),
                            RoleName = role.GetAttributeValue<string>("name") ?? string.Empty,
                            RoleId = role.Id.ToString(),
                            RoleDescription = role.GetAttributeValue<string>("description") ?? string.Empty,
                            UserName = user.GetAttributeValue<string>("fullname") ?? string.Empty,
                            UserId = user.Id.ToString(),
                            UserEmail = user.GetAttributeValue<string>("internalemailaddress") ?? string.Empty,
                            SecurityRoleType = "User",
                            HierarchyLevel = buLevel.ToString()
                        });
                    }
                }
            }
            
            // Get users directly in Business Unit (not in teams)
            var buUsers = users.Where(u => 
                u.GetAttributeValue<EntityReference>("businessunitid")?.Id == bu.Id &&
                !buTeams.Any(t => GetUsersInTeam(t.Id, users).Any(tu => tu.Id == u.Id))).ToList();
            
            foreach (var user in buUsers)
            {
                var userRoles = GetRolesForUser(user.Id, roles);
                
                foreach (var role in userRoles)
                {
                    hierarchy.Add(new PermissionHierarchy
                    {
                        BusinessUnitName = bu.GetAttributeValue<string>("name") ?? string.Empty,
                        BusinessUnitId = bu.Id.ToString(),
                        ParentBusinessUnitName = parentBu?.GetAttributeValue<string>("name") ?? "Root",
                        ParentBusinessUnitId = parentBu?.Id.ToString() ?? string.Empty,
                        TeamName = string.Empty,
                        TeamId = string.Empty,
                        RoleName = role.GetAttributeValue<string>("name") ?? string.Empty,
                        RoleId = role.Id.ToString(),
                        RoleDescription = role.GetAttributeValue<string>("description") ?? string.Empty,
                        UserName = user.GetAttributeValue<string>("fullname") ?? string.Empty,
                        UserId = user.Id.ToString(),
                        UserEmail = user.GetAttributeValue<string>("internalemailaddress") ?? string.Empty,
                        SecurityRoleType = "User",
                        HierarchyLevel = buLevel.ToString()
                    });
                }
            }
        }
        
        return hierarchy;
    }

    private List<Entity> GetAllBusinessUnits()
    {
        var query = new QueryExpression("businessunit")
        {
            ColumnSet = new ColumnSet("businessunitid", "name", "parentbusinessunitid", "description"),
            Orders = { new OrderExpression("name", OrderType.Ascending) }
        };
        
        return _service.RetrieveMultiple(query).Entities.ToList();
    }

    private List<Entity> GetAllRoles()
    {
        var query = new QueryExpression("role")
        {
            ColumnSet = new ColumnSet("roleid", "name", "description", "businessunitid"),
            Orders = { new OrderExpression("name", OrderType.Ascending) }
        };
        
        return _service.RetrieveMultiple(query).Entities.ToList();
    }

    private List<Entity> GetAllTeams()
    {
        var query = new QueryExpression("team")
        {
            ColumnSet = new ColumnSet("teamid", "name", "businessunitid"),
            Orders = { new OrderExpression("name", OrderType.Ascending) }
        };
        
        return _service.RetrieveMultiple(query).Entities.ToList();
    }

    private List<Entity> GetAllUsers()
    {
        var query = new QueryExpression("systemuser")
        {
            ColumnSet = new ColumnSet("systemuserid", "fullname", "internalemailaddress", "businessunitid"),
            Orders = { new OrderExpression("fullname", OrderType.Ascending) }
        };
        
        return _service.RetrieveMultiple(query).Entities.ToList();
    }

    private List<Entity> GetRolesForBusinessUnit(Guid businessUnitId, List<Entity> allRoles)
    {
        return allRoles.Where(r => 
            r.GetAttributeValue<EntityReference>("businessunitid")?.Id == businessUnitId).ToList();
    }

    private List<Entity> GetRolesForTeam(Guid teamId, List<Entity> allRoles)
    {
        try
        {
            // Query teamroles intersection entity to get roles for team
            var query = new QueryExpression("role")
            {
                ColumnSet = new ColumnSet("roleid", "name", "description"),
                LinkEntities =
                {
                    new LinkEntity
                    {
                        LinkFromEntityName = "role",
                        LinkFromAttributeName = "roleid",
                        LinkToEntityName = "teamroles",
                        LinkToAttributeName = "roleid",
                        LinkCriteria = new FilterExpression
                        {
                            Conditions =
                            {
                                new ConditionExpression("teamid", ConditionOperator.Equal, teamId)
                            }
                        }
                    }
                }
            };

            return _service.RetrieveMultiple(query).Entities.ToList();
        }
        catch
        {
            // Fallback: return empty list if query fails
            return new List<Entity>();
        }
    }

    private List<Entity> GetRolesForUser(Guid userId, List<Entity> allRoles)
    {
        try
        {
            // Query using relationship through systemuserroles intersection entity
            var query = new QueryExpression("role")
            {
                ColumnSet = new ColumnSet("roleid", "name", "description"),
                LinkEntities =
                {
                    new LinkEntity
                    {
                        LinkFromEntityName = "role",
                        LinkFromAttributeName = "roleid",
                        LinkToEntityName = "systemuserroles",
                        LinkToAttributeName = "roleid",
                        LinkCriteria = new FilterExpression
                        {
                            Conditions =
                            {
                                new ConditionExpression("systemuserid", ConditionOperator.Equal, userId)
                            }
                        }
                    }
                }
            };

            return _service.RetrieveMultiple(query).Entities.ToList();
        }
        catch
        {
            // Fallback: return empty list if query fails
            return new List<Entity>();
        }
    }

    private List<Entity> GetUsersInTeam(Guid teamId, List<Entity> allUsers)
    {
        var query = new QueryExpression("systemuser")
        {
            ColumnSet = new ColumnSet("systemuserid", "fullname", "internalemailaddress", "businessunitid"),
            LinkEntities = 
            {
                new LinkEntity
                {
                    LinkFromEntityName = "systemuser",
                    LinkFromAttributeName = "systemuserid",
                    LinkToEntityName = "teammembership",
                    LinkToAttributeName = "systemuserid",
                    LinkCriteria = new FilterExpression
                    {
                        Conditions =
                        {
                            new ConditionExpression("teamid", ConditionOperator.Equal, teamId)
                        }
                    }
                }
            }
        };
        
        return _service.RetrieveMultiple(query).Entities.ToList();
    }

    public List<BusinessUnitHierarchy> GetBusinessUnitHierarchy()
    {
        var hierarchy = new List<BusinessUnitHierarchy>();
        var businessUnits = GetAllBusinessUnits();
        
        foreach (var bu in businessUnits)
        {
            var parentBu = businessUnits.FirstOrDefault(p => p.Id == bu.GetAttributeValue<EntityReference>("parentbusinessunitid")?.Id);
            var buLevel = CalculateBusinessUnitLevel(bu, businessUnits);
            
            hierarchy.Add(new BusinessUnitHierarchy
            {
                BusinessUnitName = bu.GetAttributeValue<string>("name") ?? string.Empty,
                BusinessUnitId = bu.Id.ToString(),
                ParentBusinessUnitName = parentBu?.GetAttributeValue<string>("name") ?? "Root",
                ParentBusinessUnitId = parentBu?.Id.ToString() ?? string.Empty,
                HierarchyLevel = buLevel.ToString(),
                BusinessUnitDescription = bu.GetAttributeValue<string>("description") ?? string.Empty
            });
        }
        
        return hierarchy;
    }

    public List<RolePermission> GetHierarchyWithRolesAndPermissions()
    {
        var permissions = new List<RolePermission>();
        
        // Get all Business Units
        var businessUnits = GetAllBusinessUnits();
        
        // Get all Roles
        var roles = GetAllRoles();
        
        // Get all Teams
        var teams = GetAllTeams();
        
        // Get all Users
        var users = GetAllUsers();
        
        // Get all Privileges
        var privileges = GetAllPrivileges();
        
        // Get all Role Privileges
        var rolePrivileges = GetAllRolePrivileges();
        
        // Get Entity Metadata for display names
        var entityMetadata = GetEntityMetadata();
        
        // Build permissions for each Business Unit
        foreach (var bu in businessUnits)
        {
            var parentBu = businessUnits.FirstOrDefault(p => p.Id == bu.GetAttributeValue<EntityReference>("parentbusinessunitid")?.Id);
            var buLevel = CalculateBusinessUnitLevel(bu, businessUnits);
            
            // Get roles directly assigned to Business Unit
            var buRoles = GetRolesForBusinessUnit(bu.Id, roles);
            
            foreach (var role in buRoles)
            {
                var rolePrivs = rolePrivileges.Where(rp => rp.GetAttributeValue<EntityReference>("roleid")?.Id == role.Id).ToList();
                
                foreach (var rolePriv in rolePrivs)
                {
                    var privilege = privileges.FirstOrDefault(p => p.Id == rolePriv.GetAttributeValue<EntityReference>("privilegeid")?.Id);
                    if (privilege != null)
                    {
                        var privilegeName = privilege.GetAttributeValue<string>("name") ?? string.Empty;
                        var entityName = ExtractEntityName(privilegeName);
                        var entityDisplayName = entityMetadata.ContainsKey(entityName) ? entityMetadata[entityName] : entityName;
                        
                        permissions.Add(new RolePermission
                        {
                            BusinessUnitName = bu.GetAttributeValue<string>("name") ?? string.Empty,
                            BusinessUnitId = bu.Id.ToString(),
                            ParentBusinessUnitName = parentBu?.GetAttributeValue<string>("name") ?? "Root",
                            ParentBusinessUnitId = parentBu?.Id.ToString() ?? string.Empty,
                            TeamName = string.Empty,
                            TeamId = string.Empty,
                            RoleName = role.GetAttributeValue<string>("name") ?? string.Empty,
                            RoleId = role.Id.ToString(),
                            RoleDescription = role.GetAttributeValue<string>("description") ?? string.Empty,
                            UserName = string.Empty,
                            UserId = string.Empty,
                            UserEmail = string.Empty,
                            SecurityRoleType = "Business Unit",
                            HierarchyLevel = buLevel.ToString(),
                            EntityName = entityName,
                            EntityDisplayName = entityDisplayName,
                            PrivilegeName = privilegeName,
                            PrivilegeType = GetPrivilegeType(privilegeName),
                            AccessRight = GetAccessRightName(rolePriv.GetAttributeValue<OptionSetValue>("depth")?.Value ?? 0)
                        });
                    }
                }
            }
            
            // Get teams in this Business Unit
            var buTeams = teams.Where(t => 
                t.GetAttributeValue<EntityReference>("businessunitid")?.Id == bu.Id).ToList();
            
            foreach (var team in buTeams)
            {
                var teamRoles = GetRolesForTeam(team.Id, roles);
                
                foreach (var role in teamRoles)
                {
                    var rolePrivs = rolePrivileges.Where(rp => rp.GetAttributeValue<EntityReference>("roleid")?.Id == role.Id).ToList();
                    
                    foreach (var rolePriv in rolePrivs)
                    {
                        var privilege = privileges.FirstOrDefault(p => p.Id == rolePriv.GetAttributeValue<EntityReference>("privilegeid")?.Id);
                        if (privilege != null)
                        {
                            var privilegeName = privilege.GetAttributeValue<string>("name") ?? string.Empty;
                            var entityName = ExtractEntityName(privilegeName);
                            var entityDisplayName = entityMetadata.ContainsKey(entityName) ? entityMetadata[entityName] : entityName;
                            
                            permissions.Add(new RolePermission
                            {
                                BusinessUnitName = bu.GetAttributeValue<string>("name") ?? string.Empty,
                                BusinessUnitId = bu.Id.ToString(),
                                ParentBusinessUnitName = parentBu?.GetAttributeValue<string>("name") ?? "Root",
                                ParentBusinessUnitId = parentBu?.Id.ToString() ?? string.Empty,
                                TeamName = team.GetAttributeValue<string>("name") ?? string.Empty,
                                TeamId = team.Id.ToString(),
                                RoleName = role.GetAttributeValue<string>("name") ?? string.Empty,
                                RoleId = role.Id.ToString(),
                                RoleDescription = role.GetAttributeValue<string>("description") ?? string.Empty,
                                UserName = string.Empty,
                                UserId = string.Empty,
                                UserEmail = string.Empty,
                                SecurityRoleType = "Team",
                                HierarchyLevel = buLevel.ToString(),
                                EntityName = entityName,
                                EntityDisplayName = entityDisplayName,
                                PrivilegeName = privilegeName,
                                PrivilegeType = GetPrivilegeType(privilegeName),
                                AccessRight = GetAccessRightName(rolePriv.GetAttributeValue<OptionSetValue>("depth")?.Value ?? 0)
                            });
                        }
                    }
                }
                
                var teamUsers = GetUsersInTeam(team.Id, users);
                
                foreach (var user in teamUsers)
                {
                    var userRoles = GetRolesForUser(user.Id, roles);
                    
                    foreach (var role in userRoles)
                    {
                        var rolePrivs = rolePrivileges.Where(rp => rp.GetAttributeValue<EntityReference>("roleid")?.Id == role.Id).ToList();
                        
                        foreach (var rolePriv in rolePrivs)
                        {
                            var privilege = privileges.FirstOrDefault(p => p.Id == rolePriv.GetAttributeValue<EntityReference>("privilegeid")?.Id);
                            if (privilege != null)
                            {
                                var privilegeName = privilege.GetAttributeValue<string>("name") ?? string.Empty;
                                var entityName = ExtractEntityName(privilegeName);
                                var entityDisplayName = entityMetadata.ContainsKey(entityName) ? entityMetadata[entityName] : entityName;
                                
                                permissions.Add(new RolePermission
                                {
                                    BusinessUnitName = bu.GetAttributeValue<string>("name") ?? string.Empty,
                                    BusinessUnitId = bu.Id.ToString(),
                                    ParentBusinessUnitName = parentBu?.GetAttributeValue<string>("name") ?? "Root",
                                    ParentBusinessUnitId = parentBu?.Id.ToString() ?? string.Empty,
                                    TeamName = team.GetAttributeValue<string>("name") ?? string.Empty,
                                    TeamId = team.Id.ToString(),
                                    RoleName = role.GetAttributeValue<string>("name") ?? string.Empty,
                                    RoleId = role.Id.ToString(),
                                    RoleDescription = role.GetAttributeValue<string>("description") ?? string.Empty,
                                    UserName = user.GetAttributeValue<string>("fullname") ?? string.Empty,
                                    UserId = user.Id.ToString(),
                                    UserEmail = user.GetAttributeValue<string>("internalemailaddress") ?? string.Empty,
                                    SecurityRoleType = "User",
                                    HierarchyLevel = buLevel.ToString(),
                                    EntityName = entityName,
                                    EntityDisplayName = entityDisplayName,
                                    PrivilegeName = privilegeName,
                                    PrivilegeType = GetPrivilegeType(privilegeName),
                                    AccessRight = GetAccessRightName(rolePriv.GetAttributeValue<OptionSetValue>("depth")?.Value ?? 0)
                                });
                            }
                        }
                    }
                }
            }
            
            var buUsers = users.Where(u => 
                u.GetAttributeValue<EntityReference>("businessunitid")?.Id == bu.Id &&
                !buTeams.Any(t => GetUsersInTeam(t.Id, users).Any(tu => tu.Id == u.Id))).ToList();
            
            foreach (var user in buUsers)
            {
                var userRoles = GetRolesForUser(user.Id, roles);
                
                foreach (var role in userRoles)
                {
                    var rolePrivs = rolePrivileges.Where(rp => rp.GetAttributeValue<EntityReference>("roleid")?.Id == role.Id).ToList();
                    
                    foreach (var rolePriv in rolePrivs)
                    {
                        var privilege = privileges.FirstOrDefault(p => p.Id == rolePriv.GetAttributeValue<EntityReference>("privilegeid")?.Id);
                        if (privilege != null)
                        {
                            var privilegeName = privilege.GetAttributeValue<string>("name") ?? string.Empty;
                            var entityName = ExtractEntityName(privilegeName);
                            var entityDisplayName = entityMetadata.ContainsKey(entityName) ? entityMetadata[entityName] : entityName;
                            
                            permissions.Add(new RolePermission
                            {
                                BusinessUnitName = bu.GetAttributeValue<string>("name") ?? string.Empty,
                                BusinessUnitId = bu.Id.ToString(),
                                ParentBusinessUnitName = parentBu?.GetAttributeValue<string>("name") ?? "Root",
                                ParentBusinessUnitId = parentBu?.Id.ToString() ?? string.Empty,
                                TeamName = string.Empty,
                                TeamId = string.Empty,
                                RoleName = role.GetAttributeValue<string>("name") ?? string.Empty,
                                RoleId = role.Id.ToString(),
                                RoleDescription = role.GetAttributeValue<string>("description") ?? string.Empty,
                                UserName = user.GetAttributeValue<string>("fullname") ?? string.Empty,
                                UserId = user.Id.ToString(),
                                UserEmail = user.GetAttributeValue<string>("internalemailaddress") ?? string.Empty,
                                SecurityRoleType = "User",
                                HierarchyLevel = buLevel.ToString(),
                                EntityName = entityName,
                                EntityDisplayName = entityDisplayName,
                                PrivilegeName = privilegeName,
                                PrivilegeType = GetPrivilegeType(privilegeName),
                                AccessRight = GetAccessRightName(rolePriv.GetAttributeValue<OptionSetValue>("depth")?.Value ?? 0)
                            });
                        }
                    }
                }
            }
        }
        
        return permissions;
    }

    private List<Entity> GetAllPrivileges()
    {
        var query = new QueryExpression("privilege")
        {
            ColumnSet = new ColumnSet("privilegeid", "name"),
            Orders = { new OrderExpression("name", OrderType.Ascending) }
        };
        
        return _service.RetrieveMultiple(query).Entities.ToList();
    }

    private List<Entity> GetAllRolePrivileges()
    {
        var query = new QueryExpression("roleprivileges")
        {
            ColumnSet = new ColumnSet("roleprivilegeid", "roleid", "privilegeid", "depth"),
            Orders = { new OrderExpression("roleid", OrderType.Ascending) }
        };
        
        return _service.RetrieveMultiple(query).Entities.ToList();
    }

    private Dictionary<string, string> GetEntityMetadata()
    {
        var metadata = new Dictionary<string, string>();
        
        try
        {
            var query = new QueryExpression("entity")
            {
                ColumnSet = new ColumnSet("name", "logicalname", "displayname"),
                Orders = { new OrderExpression("logicalname", OrderType.Ascending) }
            };
            
            var entities = _service.RetrieveMultiple(query).Entities;
            
            foreach (var entity in entities)
            {
                var logicalName = entity.GetAttributeValue<string>("logicalname") ?? string.Empty;
                var displayName = entity.GetAttributeValue<string>("displayname") ?? logicalName;
                metadata[logicalName] = displayName;
            }
        }
        catch
        {
            // If entity metadata query fails, return empty dictionary
        }
        
        return metadata;
    }

    private string ExtractEntityName(string privilegeName)
    {
        if (string.IsNullOrEmpty(privilegeName)) return string.Empty;
        
        // Privilege names are typically like: prvReadAccount, prvCreateContact, etc.
        // Remove the privilege type prefix and get the entity name
        var prefixes = new[] { "prvCreate", "prvRead", "prvWrite", "prvDelete", "prvAppend", "prvAppendTo", "prvAssign", "prvShare" };
        
        foreach (var prefix in prefixes)
        {
            if (privilegeName.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            {
                return privilegeName.Substring(prefix.Length);
            }
        }
        
        // If no prefix matches, try to extract from common patterns
        if (privilegeName.StartsWith("prv", StringComparison.OrdinalIgnoreCase))
        {
            // Remove "prv" and try to find entity name
            var withoutPrv = privilegeName.Substring(3);
            // Find first capital letter after privilege type
            for (int i = 1; i < withoutPrv.Length; i++)
            {
                if (char.IsUpper(withoutPrv[i]))
                {
                    return withoutPrv.Substring(i);
                }
            }
        }
        
        return privilegeName;
    }

    private string GetPrivilegeType(string privilegeName)
    {
        if (string.IsNullOrEmpty(privilegeName)) return "Unknown";
        
        if (privilegeName.StartsWith("prvCreate", StringComparison.OrdinalIgnoreCase)) return "Create";
        if (privilegeName.StartsWith("prvRead", StringComparison.OrdinalIgnoreCase)) return "Read";
        if (privilegeName.StartsWith("prvWrite", StringComparison.OrdinalIgnoreCase)) return "Write";
        if (privilegeName.StartsWith("prvDelete", StringComparison.OrdinalIgnoreCase)) return "Delete";
        if (privilegeName.StartsWith("prvAppendTo", StringComparison.OrdinalIgnoreCase)) return "AppendTo";
        if (privilegeName.StartsWith("prvAppend", StringComparison.OrdinalIgnoreCase)) return "Append";
        if (privilegeName.StartsWith("prvAssign", StringComparison.OrdinalIgnoreCase)) return "Assign";
        if (privilegeName.StartsWith("prvShare", StringComparison.OrdinalIgnoreCase)) return "Share";
        
        return "Unknown";
    }

    private string GetAccessRightName(int depth)
    {
        return depth switch
        {
            0 => "None",
            1 => "User",
            2 => "BusinessUnit",
            4 => "ParentChildBusinessUnit",
            8 => "Organization",
            _ => "Unknown"
        };
    }

    private int CalculateBusinessUnitLevel(Entity businessUnit, List<Entity> allBusinessUnits)
    {
        int level = 1;
        var currentBu = businessUnit;
        
        while (currentBu.GetAttributeValue<EntityReference>("parentbusinessunitid") != null)
        {
            level++;
            var parentId = currentBu.GetAttributeValue<EntityReference>("parentbusinessunitid").Id;
            currentBu = allBusinessUnits.FirstOrDefault(bu => bu.Id == parentId);
            
            if (currentBu == null) break;
        }
        
        return level;
    }
}

