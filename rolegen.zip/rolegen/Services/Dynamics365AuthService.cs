using Microsoft.Crm.Sdk.Messages;
using Microsoft.Identity.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;

namespace Dynamics365PermissionExporter.Services;

public class Dynamics365AuthService
{
    private readonly string _instanceUrl;
    private readonly string _tenantId;
    private readonly string _clientId;
    private readonly string _clientSecret;

    public Dynamics365AuthService(string instanceUrl, string tenantId, string clientId, string clientSecret)
    {
        _instanceUrl = instanceUrl;
        _tenantId = tenantId;
        _clientId = clientId;
        _clientSecret = clientSecret;
    }

    public IOrganizationService GetOrganizationService()
    {
        var connectionString = $"AuthType=ClientSecret;Url={_instanceUrl};ClientId={_clientId};ClientSecret={_clientSecret}";
        var crmServiceClient = new CrmServiceClient(connectionString);

        if (!crmServiceClient.IsReady)
        {
            throw new Exception($"Failed to connect to Dynamics 365: {crmServiceClient.LastCrmError}");
        }

        return crmServiceClient;
    }
}

