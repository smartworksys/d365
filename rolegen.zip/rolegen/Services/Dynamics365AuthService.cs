using Microsoft.Crm.Sdk.Messages;
using Microsoft.Identity.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Tooling.Connector;
using System;

namespace Dynamics365PermissionExporter.Services
{
    public class Dynamics365AuthService
    {
        private readonly string _instanceUrl;
        private readonly string _tenantId;
        private readonly string _clientId;
        private readonly string _clientSecret;

        public Dynamics365AuthService(string instanceUrl, string tenantId, string clientId, string clientSecret)
        {
            _instanceUrl = instanceUrl;
            _tenantId = tenantId;
            _clientId = clientId;
            _clientSecret = clientSecret;
        }

        public IOrganizationService GetOrganizationService()
        {
            var connectionString = string.Format("AuthType=ClientSecret;Url={0};ClientId={1};ClientSecret={2}", _instanceUrl, _clientId, _clientSecret);
            var crmServiceClient = new CrmServiceClient(connectionString);

            if (!crmServiceClient.IsReady)
            {
                throw new Exception(string.Format("Failed to connect to Dynamics 365: {0}", crmServiceClient.LastCrmError));
            }

            return crmServiceClient;
        }
    }
}


