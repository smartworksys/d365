# Dynamics 365 Permissions Hierarchy Exporter

A C# console application that connects to Dynamics 365 using Service Principal (SPN) authentication, retrieves the complete Business Unit permissions hierarchy with roles, teams, and users, and exports the data to CSV.

## Features

- **Service Principal Authentication**: Uses Azure AD Service Principal (SPN) for secure authentication
- **Complete Hierarchy**: Retrieves Business Units, Roles, Teams, and Users with their relationships
- **Multiple CSV Exports**: Creates three separate CSV files:
  1. **Hierarchy Only**: Business Unit hierarchy structure
  2. **Hierarchy with Roles**: Business Units, Teams, Users, and their assigned Roles
  3. **Hierarchy with Roles and Permissions**: Complete permissions including all privileges (Create, Read, Write, Delete, etc.)
- **Hierarchy Levels**: Includes Business Unit hierarchy levels for better understanding

## Prerequisites

- .NET 8.0 SDK or later
- Visual Studio 2022
- Dynamics 365 instance with appropriate permissions
- Azure AD App Registration with:
  - Application (client) ID
  - Client Secret
  - Permissions to access Dynamics 365

## Setup

1. **Configure Azure AD App Registration**:
   - Register an application in Azure AD
   - Create a client secret
   - Grant the application appropriate permissions to Dynamics 365 (e.g., Dynamics CRM user impersonation)
   - Note the Tenant ID, Client ID, and Client Secret

2. **Configure the Application**:
   - Open `appsettings.json`
   - Update the following values:
     - `InstanceUrl`: Your Dynamics 365 instance URL (e.g., `https://yourorg.crm.dynamics.com`)
     - `TenantId`: Your Azure AD Tenant ID
     - `ClientId`: Your Azure AD Application (Client) ID
     - `ClientSecret`: Your Azure AD Client Secret
     - `HierarchyPath`: Path for the Business Unit hierarchy CSV (optional, defaults to `Dynamics365Hierarchy.csv`)
     - `HierarchyWithRolesPath`: Path for the hierarchy with roles CSV (optional, defaults to `Dynamics365HierarchyWithRoles.csv`)
     - `HierarchyWithRolesAndPermissionsPath`: Path for the complete permissions CSV (optional, defaults to `Dynamics365HierarchyWithRolesAndPermissions.csv`)

## Building the Project

1. Open the project in Visual Studio 2022
2. Restore NuGet packages (should happen automatically)
3. Build the solution (Ctrl+Shift+B)

## Running the Application

1. Run the application from Visual Studio (F5) or from command line:
   ```bash
   dotnet run
   ```

2. The application will:
   - Connect to Dynamics 365
   - Retrieve all Business Units, Roles, Teams, Users, and Permissions
   - Build the complete permissions hierarchy
   - Export three separate CSV files

## Output CSV Files

### 1. Hierarchy CSV (Dynamics365Hierarchy.csv)

Contains the Business Unit hierarchy structure with the following columns:

- `BusinessUnitName`: Name of the Business Unit
- `BusinessUnitId`: GUID of the Business Unit
- `ParentBusinessUnitName`: Name of the parent Business Unit (or "Root")
- `ParentBusinessUnitId`: GUID of the parent Business Unit
- `HierarchyLevel`: Level in the Business Unit hierarchy (1 = root level)
- `BusinessUnitDescription`: Description of the Business Unit

### 2. Hierarchy with Roles CSV (Dynamics365HierarchyWithRoles.csv)

Contains the Business Unit hierarchy with role assignments:

- `BusinessUnitName`: Name of the Business Unit
- `BusinessUnitId`: GUID of the Business Unit
- `ParentBusinessUnitName`: Name of the parent Business Unit (or "Root")
- `ParentBusinessUnitId`: GUID of the parent Business Unit
- `TeamName`: Name of the Team (if applicable)
- `TeamId`: GUID of the Team (if applicable)
- `RoleName`: Name of the Security Role
- `RoleId`: GUID of the Security Role
- `RoleDescription`: Description of the Security Role
- `UserName`: Full name of the User (if applicable)
- `UserId`: GUID of the User (if applicable)
- `UserEmail`: Email address of the User (if applicable)
- `SecurityRoleType`: Type of role assignment (Business Unit, Team, or User)
- `HierarchyLevel`: Level in the Business Unit hierarchy (1 = root level)

### 3. Hierarchy with Roles and Permissions CSV (Dynamics365HierarchyWithRolesAndPermissions.csv)

Contains the complete permissions hierarchy including all privileges:

- All columns from "Hierarchy with Roles" plus:
- `EntityName`: Logical name of the entity (e.g., "account", "contact")
- `EntityDisplayName`: Display name of the entity (e.g., "Account", "Contact")
- `PrivilegeName`: Full name of the privilege (e.g., "prvReadAccount")
- `PrivilegeType`: Type of privilege (Create, Read, Write, Delete, Append, AppendTo, Assign, Share)
- `AccessRight`: Access level (None, User, BusinessUnit, ParentChildBusinessUnit, Organization)

## Required Permissions

The Service Principal needs the following permissions in Dynamics 365:
- Read access to Business Units
- Read access to Security Roles
- Read access to Teams
- Read access to Users
- Read access to Team Memberships
- Read access to User Role Assignments
- Read access to Role Privileges
- Read access to Privileges
- Read access to Entity Metadata

## Troubleshooting

- **Connection Errors**: Verify your `InstanceUrl`, `TenantId`, `ClientId`, and `ClientSecret` in `appsettings.json`
- **Permission Errors**: Ensure the Service Principal has appropriate permissions in Dynamics 365
- **Empty Results**: Check that your Dynamics 365 instance has Business Units, Roles, Teams, and Users configured

## Dependencies

- Microsoft.CrmSdk.CoreAssemblies (9.0.0.50)
- Microsoft.CrmSdk.Workflow (9.0.0.50)
- Microsoft.CrmSdk.XrmTooling.CoreAssembly (9.0.0.50)
- Microsoft.Identity.Client (4.60.1)
- Microsoft.Extensions.Configuration (8.0.0)
- Microsoft.Extensions.Configuration.Json (8.0.0)
- CsvHelper (30.0.1)

