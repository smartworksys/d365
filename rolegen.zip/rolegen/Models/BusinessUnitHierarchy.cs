namespace Dynamics365PermissionExporter.Models;

public class BusinessUnitHierarchy
{
    public string BusinessUnitName { get; set; } = string.Empty;
    public string BusinessUnitId { get; set; } = string.Empty;
    public string ParentBusinessUnitName { get; set; } = string.Empty;
    public string ParentBusinessUnitId { get; set; } = string.Empty;
    public string HierarchyLevel { get; set; } = string.Empty;
    public string BusinessUnitDescription { get; set; } = string.Empty;
}

