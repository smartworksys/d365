namespace Dynamics365PermissionExporter.Models
{
    public class BusinessUnitHierarchy
    {
        public string BusinessUnitName { get; set; }
        public string BusinessUnitId { get; set; }
        public string ParentBusinessUnitName { get; set; }
        public string ParentBusinessUnitId { get; set; }
        public string HierarchyLevel { get; set; }
        public string BusinessUnitDescription { get; set; }
    }
}


