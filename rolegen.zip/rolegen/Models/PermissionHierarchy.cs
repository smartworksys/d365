namespace Dynamics365PermissionExporter.Models
{
    public class PermissionHierarchy
    {
        public string BusinessUnitName { get; set; }
        public string BusinessUnitId { get; set; }
        public string ParentBusinessUnitName { get; set; }
        public string ParentBusinessUnitId { get; set; }
        public string TeamName { get; set; }
        public string TeamId { get; set; }
        public string RoleName { get; set; }
        public string RoleId { get; set; }
        public string RoleDescription { get; set; }
        public string UserName { get; set; }
        public string UserId { get; set; }
        public string UserEmail { get; set; }
        public string SecurityRoleType { get; set; } // User or Team
        public string HierarchyLevel { get; set; }
    }
}


