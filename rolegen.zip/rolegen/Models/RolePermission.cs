namespace Dynamics365PermissionExporter.Models
{
    public class RolePermission
    {
        public string BusinessUnitName { get; set; }
        public string BusinessUnitId { get; set; }
        public string ParentBusinessUnitName { get; set; }
        public string ParentBusinessUnitId { get; set; }
        public string TeamName { get; set; }
        public string TeamId { get; set; }
        public string RoleName { get; set; }
        public string RoleId { get; set; }
        public string RoleDescription { get; set; }
        public string UserName { get; set; }
        public string UserId { get; set; }
        public string UserEmail { get; set; }
        public string SecurityRoleType { get; set; }
        public string HierarchyLevel { get; set; }
        public string EntityName { get; set; }
        public string EntityDisplayName { get; set; }
        public string PrivilegeName { get; set; }
        public string PrivilegeType { get; set; } // Create, Read, Write, Delete, Append, AppendTo, Assign, Share
        public string AccessRight { get; set; } // None, User, BusinessUnit, ParentChildBusinessUnit, Organization
    }
}


