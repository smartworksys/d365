namespace Dynamics365PermissionExporter.Models;

public class RolePermission
{
    public string BusinessUnitName { get; set; } = string.Empty;
    public string BusinessUnitId { get; set; } = string.Empty;
    public string ParentBusinessUnitName { get; set; } = string.Empty;
    public string ParentBusinessUnitId { get; set; } = string.Empty;
    public string TeamName { get; set; } = string.Empty;
    public string TeamId { get; set; } = string.Empty;
    public string RoleName { get; set; } = string.Empty;
    public string RoleId { get; set; } = string.Empty;
    public string RoleDescription { get; set; } = string.Empty;
    public string UserName { get; set; } = string.Empty;
    public string UserId { get; set; } = string.Empty;
    public string UserEmail { get; set; } = string.Empty;
    public string SecurityRoleType { get; set; } = string.Empty;
    public string HierarchyLevel { get; set; } = string.Empty;
    public string EntityName { get; set; } = string.Empty;
    public string EntityDisplayName { get; set; } = string.Empty;
    public string PrivilegeName { get; set; } = string.Empty;
    public string PrivilegeType { get; set; } = string.Empty; // Create, Read, Write, Delete, Append, AppendTo, Assign, Share
    public string AccessRight { get; set; } = string.Empty; // None, User, BusinessUnit, ParentChildBusinessUnit, Organization
}

