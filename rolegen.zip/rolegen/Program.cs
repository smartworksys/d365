using Dynamics365PermissionExporter.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Xrm.Sdk;
using System;
using System.IO;
using System.Linq;

namespace Dynamics365PermissionExporter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Dynamics 365 Permissions Hierarchy Exporter");
            Console.WriteLine("===========================================\n");

            try
            {
                // Load configuration
                var configuration = new ConfigurationBuilder()
                    .SetBasePath(Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                    .Build();

                var instanceUrl = configuration["Dynamics365:InstanceUrl"] 
                    ?? throw new InvalidOperationException("InstanceUrl is not configured");
                var tenantId = configuration["Dynamics365:TenantId"] 
                    ?? throw new InvalidOperationException("TenantId is not configured");
                var clientId = configuration["Dynamics365:ClientId"] 
                    ?? throw new InvalidOperationException("ClientId is not configured");
                var clientSecret = configuration["Dynamics365:ClientSecret"] 
                    ?? throw new InvalidOperationException("ClientSecret is not configured");
                
                var hierarchyPath = configuration["Export:HierarchyPath"] ?? "Dynamics365Hierarchy.csv";
                var hierarchyWithRolesPath = configuration["Export:HierarchyWithRolesPath"] ?? "Dynamics365HierarchyWithRoles.csv";
                var hierarchyWithRolesAndPermissionsPath = configuration["Export:HierarchyWithRolesAndPermissionsPath"] ?? "Dynamics365HierarchyWithRolesAndPermissions.csv";

                Console.WriteLine(string.Format("Connecting to Dynamics 365: {0}", instanceUrl));
                
                // Authenticate and get service
                var authService = new Dynamics365AuthService(instanceUrl, tenantId, clientId, clientSecret);
                var orgService = authService.GetOrganizationService();
                
                Console.WriteLine("Connected successfully!\n");
                
                var hierarchyService = new PermissionHierarchyService(orgService);
                var csvService = new CsvExportService();

                // Export 1: Business Unit Hierarchy Only
                Console.WriteLine("1. Retrieving Business Unit Hierarchy...");
                var buHierarchy = hierarchyService.GetBusinessUnitHierarchy();
                Console.WriteLine(string.Format("   Retrieved {0} Business Units.", buHierarchy.Count));
                Console.WriteLine("   Exporting to CSV...");
                csvService.ExportHierarchyToCsv(buHierarchy, hierarchyPath);
                Console.WriteLine(string.Format("   ✓ Exported to: {0}\n", Path.GetFullPath(hierarchyPath)));

                // Export 2: Hierarchy with Roles
                Console.WriteLine("2. Retrieving Hierarchy with Roles...");
                var hierarchyWithRoles = hierarchyService.GetCompletePermissionsHierarchy();
                Console.WriteLine(string.Format("   Retrieved {0} role assignment records.", hierarchyWithRoles.Count));
                Console.WriteLine("   Exporting to CSV...");
                csvService.ExportHierarchyWithRolesToCsv(hierarchyWithRoles, hierarchyWithRolesPath);
                Console.WriteLine(string.Format("   ✓ Exported to: {0}\n", Path.GetFullPath(hierarchyWithRolesPath)));

                // Export 3: Hierarchy with Roles and Permissions
                Console.WriteLine("3. Retrieving Hierarchy with Roles and Permissions...");
                var hierarchyWithPermissions = hierarchyService.GetHierarchyWithRolesAndPermissions();
                Console.WriteLine(string.Format("   Retrieved {0} permission records.", hierarchyWithPermissions.Count));
                Console.WriteLine("   Exporting to CSV...");
                csvService.ExportHierarchyWithRolesAndPermissionsToCsv(hierarchyWithPermissions, hierarchyWithRolesAndPermissionsPath);
                Console.WriteLine(string.Format("   ✓ Exported to: {0}\n", Path.GetFullPath(hierarchyWithRolesAndPermissionsPath)));

                Console.WriteLine("All exports completed successfully!\n");
                Console.WriteLine("Summary:");
                Console.WriteLine(string.Format("  - Business Units: {0}", buHierarchy.Count));
                Console.WriteLine(string.Format("  - Role Assignments: {0}", hierarchyWithRoles.Count));
                Console.WriteLine(string.Format("  - Permission Records: {0}", hierarchyWithPermissions.Count));
                Console.WriteLine(string.Format("  - Unique Business Units: {0}", buHierarchy.Select(h => h.BusinessUnitId).Distinct().Count()));
                Console.WriteLine(string.Format("  - Unique Teams: {0}", hierarchyWithRoles.Where(h => !string.IsNullOrEmpty(h.TeamId)).Select(h => h.TeamId).Distinct().Count()));
                Console.WriteLine(string.Format("  - Unique Roles: {0}", hierarchyWithRoles.Select(h => h.RoleId).Distinct().Count()));
                Console.WriteLine(string.Format("  - Unique Users: {0}", hierarchyWithRoles.Where(h => !string.IsNullOrEmpty(h.UserId)).Select(h => h.UserId).Distinct().Count()));
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(string.Format("\nError: {0}", ex.Message));
                Console.WriteLine(string.Format("Stack Trace: {0}", ex.StackTrace));
                Console.ResetColor();
                Environment.Exit(1);
            }
        }
    }
}

