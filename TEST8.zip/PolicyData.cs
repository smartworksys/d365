using Azure;
using KOFC_FA_PolicyNonHeader_TierOne.Helpers;
using KOFC_FA_PolicyNonHeader_TierOne.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Text.Json;

namespace KOFC_FA_PolicyNonHeader_TierOne
{
    public class PolicyData
    {
        private readonly ILogger<PolicyData> _log;
        private readonly PolicyNonHeaderData _nonHeaderData;
        private readonly PolicyTierOneIngeniumData _tierOneIngeniumData;
        private readonly PolicyTierOneLife70Data _tierOneLife70Data;
        private readonly DataverseAccessGuard _accessGuard;
        private static readonly JsonSerializerOptions _jsonOptions = new JsonSerializerOptions()
        {
            PropertyNamingPolicy = new UpperCaseNamingPolicy(),
            DictionaryKeyPolicy = new UpperCaseNamingPolicy(),
            WriteIndented = false
        };

        public PolicyData(
            ILogger<PolicyData> log,
            PolicyNonHeaderData nonHeaderData,
            PolicyTierOneIngeniumData tierOneIngeniumData,
            PolicyTierOneLife70Data tierOneLife70Data,
            DataverseAccessGuard accessGuard
            )
        {
            _log = log;
            _nonHeaderData = nonHeaderData;
            _tierOneIngeniumData = tierOneIngeniumData;
            _tierOneLife70Data = tierOneLife70Data;
            _accessGuard = accessGuard;
        }


        [Function("getPolicyData")]
        public async Task<IActionResult> RunAsync(
            [Microsoft.Azure.Functions.Worker.HttpTrigger(Microsoft.Azure.Functions.Worker.AuthorizationLevel.Anonymous, "get", "post")]
            HttpRequest req)
        {
            _log.LogInformation("C# HTTP trigger function processed a request.");

            if (!FunctionAppRoleAuth.IsAuthenticated(req))
            {
                return new UnauthorizedObjectResult("Authentication required.");
            }

            var callerRoles = FunctionAppRoleAuth.GetCallerRoles(req);
            _log.LogInformation("Caller app roles: {Roles}", string.Join(", ", callerRoles));

            if (!FunctionAppRoleAuth.HasAppRole(callerRoles, FunctionAppRoleAuth.PolicyReadRole))
            {
                return new ObjectResult($"Missing required app role: {FunctionAppRoleAuth.PolicyReadRole}.")
                {
                    StatusCode = StatusCodes.Status403Forbidden
                };
            }

            string source = req.Query["source"];
            string companyCode = req.Query["companyCode"];
            string policyNo = req.Query["policyNo"];
            string classificationCode = req.Query["classificationCode"];
            string? userId = req.Query["userId"];

            if (req.Method == HttpMethods.Post)
            {
                using var reader = new StreamReader(req.Body);
                var body = await reader.ReadToEndAsync();
                var bodyJson = JsonDocument.Parse(body).RootElement;

                source ??= bodyJson.TryGetProperty("source", out var ss) ? ss.GetString() : null;
                companyCode ??= bodyJson.TryGetProperty("companyCode", out var cc) ? cc.GetString() : null;
                policyNo ??= bodyJson.TryGetProperty("policyNo", out var pn) ? pn.GetString() : null;
                classificationCode ??= bodyJson.TryGetProperty("classificationCode", out var cfc) ? cfc.GetString() : null;
                userId ??= bodyJson.TryGetProperty("userId", out var uid) ? uid.GetString() : null;
            }

            if (string.IsNullOrEmpty(source))
            {
                _log.LogWarning("Source is missing in the request.");
                return new ObjectResult(new { ERROR = "Source is missing in the request URL" })
                {
                    StatusCode = StatusCodes.Status400BadRequest
                };
            }

            if (string.IsNullOrEmpty(companyCode))
            {
                _log.LogWarning("Company code is missing in the request.");
                return new ObjectResult(new { ERROR = "Company Code is missing in the request URL" })
                {
                    StatusCode = StatusCodes.Status400BadRequest
                };
            }

            if (string.IsNullOrEmpty(policyNo))
            {
                _log.LogWarning("Policy number is missing in the request.");
                return new ObjectResult(new { ERROR = "Policy Number is missing in the request URL" })
                {
                    StatusCode = StatusCodes.Status400BadRequest
                };
            }

            if (string.IsNullOrEmpty(classificationCode))
            {
                _log.LogWarning("Classification code is missing in the request.");
                return new ObjectResult(new { ERROR = "Classification Code is missing in the request URL" })
                {
                    StatusCode = StatusCodes.Status400BadRequest
                };
            }

            if (string.IsNullOrWhiteSpace(userId) || !Guid.TryParse(userId, out var dataverseUserId))
            {
                _log.LogWarning("userId is missing or not a valid GUID.");
                return new BadRequestObjectResult("A valid userId query parameter is required.");
            }

            _log.LogInformation("CRM connection ready.");
            _log.LogInformation(
                "Processing policy request for source {Source}, policy {PolicyNo}, company {CompanyCode}, userId {UserId}",
                source,
                policyNo,
                companyCode,
                dataverseUserId);

            // Dataverse access check (mirrors eapp): resolve userId -> userName, impersonate,
            // and let Dataverse confirm they can read the requested policy record.
            var accessResult = _accessGuard.CheckPolicyAccess(dataverseUserId, companyCode, policyNo);
            if (!accessResult.IsGranted)
            {
                _log.LogWarning(
                    "Policy access denied for userId {UserId} on policy {PolicyNo}: {Reason}",
                    dataverseUserId, policyNo, accessResult.Message);
                return new ObjectResult(new { ERROR = accessResult.Message })
                {
                    StatusCode = StatusCodes.Status403Forbidden
                };
            }

            var userName = accessResult.UserName
                ?? throw new InvalidOperationException("Resolved user name is missing after access check.");

            string finalJson = source.ToLower() switch
            {
                "ing" => await BuildNonHeaderAndIngeniumResponse(policyNo, companyCode, source, userName),
                "l70" => await BuildNonHeaderAndL70Response(policyNo, companyCode, source, userName),
                "di" => await BuildNonHeader(policyNo, companyCode, source, userName),
                "ltc" => await BuildNonHeader(policyNo, companyCode, source, userName),
                _ => null
            };

            if (finalJson == null) {
                _log.LogWarning("Unknown source value: {Source}", source);
                return new ObjectResult(new { ERROR = $"Unknown soure system request :{source}, expected source - Ingenium OR L70" })
                {
                    StatusCode = StatusCodes.Status204NoContent
                };
            }
            else
            {
                _log.LogInformation("Policy JSON response:\n{JsonResult}", finalJson);
                return new ContentResult
                {
                    Content = finalJson,
                    ContentType = "application/json",
                    StatusCode = StatusCodes.Status200OK
                };
            }

            /*
            #region PolicyNonHeader

            try
            {
                var nonHeaderPayload = await _nonHeaderData.GetPolicyNonHeaderDataAsyn(source, companyCode, policyNo, userName);

                if (nonHeaderPayload != null)
                {
                    var json = JsonSerializer.Serialize(nonHeaderPayload);
                    return new ContentResult
                    {
                        Content = json,
                        ContentType = "application/json",
                        StatusCode = StatusCodes.Status200OK
                    };

                }
                

              
            }
            catch (Exception ex)
            {
                return new ObjectResult(new { ERROR = $"{ex.Message}"})
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }


            #endregion


            #region PolicyTierOne

            if (source.Equals("Ingenium"))
            {
                try
                {
                    TierOneINGResponseJson tierOneResponse = await _tierOneIngeniumData.GetPolicyTierOneIngeniumDataAsync(policyNo, companyCode);
                    if (tierOneResponse == null) 
                    {
                        return new ObjectResult(new { ERROR = "Source system is currently unavailable" })
                        {
                            StatusCode = StatusCodes.Status503ServiceUnavailable
                        };
                    }

                    var json = JsonSerializer.Serialize(tierOneResponse, _jsonOptions);
                    return new ContentResult
                    {
                        Content = json,
                        ContentType = "application/json",
                        StatusCode=StatusCodes.Status200OK
                    };
                }
                catch (Exception ex) {
                    return new ObjectResult(new { ERROR = $"Internal server error - {ex.Message}" })
                    {
                        StatusCode = StatusCodes.Status500InternalServerError
                    };
                }
                
            }
            else if (source.Equals("Life70"))
            {
                var tierOnePayload = _tierOneLife70Data.getPolicyTierOneLife70Data(policyNo);
            }
            else
            {
                _log.LogError("Invalid source value :", source);
                return new ObjectResult(new { ERROR = $"Invalid source" })
                {
                    StatusCode = StatusCodes.Status400BadRequest
                };
            }

            #endregion
            */
        }

        private async Task<string> BuildNonHeaderAndIngeniumResponse(string policyNo, string companyCode, string source, string userName)
        {
            try
            {
                var nonHeaderPayload = _nonHeaderData.GetPolicyNonHeaderDataAsyn(source, companyCode, policyNo, userName);
                var tierOneResponse = _tierOneIngeniumData.GetPolicyTierOneIngeniumDataAsync(policyNo, companyCode);
                await Task.WhenAll(nonHeaderPayload, tierOneResponse);

                var nonHeaderResponse = nonHeaderPayload.Result;
                var IngeniumResponse = tierOneResponse.Result;

                var nonHeaderResponseJson = JsonSerializer.Serialize(nonHeaderResponse);
                var IngeniumResponseJson = JsonSerializer.Serialize(IngeniumResponse, _jsonOptions);

                if (!string.IsNullOrEmpty(nonHeaderResponseJson) && !string.IsNullOrEmpty(IngeniumResponseJson))
                {
                    var response = $"{{\"NonHeader\":{nonHeaderResponseJson},\"TIERONE\":{IngeniumResponseJson}}}";
                    return response;
                }
                else
                {
                    _log.LogWarning("NonHeader or Ingenium response was empty for policy {PolicyNo}.", policyNo);
                    return BuildErrorJson("One or more source systemns are unavailable");
                }
                //return MergedFinalJson("IngeniumSource", nonHeaderResponseJson, IngeniumResponseJson);
            }
            catch (Exception ex)
            {
                _log.LogError(ex, "Failed to build NonHeader + Ingenium response for policy {PolicyNo}.", policyNo);
                return BuildErrorJson($"{ex.Message}");
            };
        }
        private async Task<string> BuildNonHeaderAndL70Response(string policyNo, string companyCode, string source, string userName)
        {
            try
            {
              var nonHeaderPayload = _nonHeaderData.GetPolicyNonHeaderDataAsyn(source, companyCode, policyNo, userName);
                var tierOnePayload = _tierOneLife70Data.getPolicyTierOneLife70Data(policyNo, companyCode);
                await Task.WhenAll(nonHeaderPayload, tierOnePayload);

                var nonHeaderResponse = nonHeaderPayload.Result;
                var l70Response = tierOnePayload.Result;

                var nonHeaderResponseJson = JsonSerializer.Serialize(nonHeaderResponse);
                var l70ResponseJson = JsonSerializer.Serialize(l70Response, _jsonOptions);

                if (!string.IsNullOrEmpty(nonHeaderResponseJson) && !string.IsNullOrEmpty(l70ResponseJson))
                {
                    var response = $"{{\"NonHeader\":{nonHeaderResponseJson},\"TIERONE\":{l70ResponseJson}}}";
                    return response;
                }
                else
                {
                    _log.LogWarning("NonHeader or Ingenium response was empty for policy {PolicyNo}.", policyNo);
                    return BuildErrorJson("One or more source systemns are unavailable");
                }
             
            }
            catch (Exception ex) {
                _log.LogError(ex, "Failed to build NonHeader + Life70 response for policy {PolicyNo}.", policyNo);
                return BuildErrorJson($"{ex.Message}");
            }
        }
        private async Task<string> BuildNonHeader(string policyNo, string companyCode, string source, string userName)
        {
            try
            {
                var nonHeaderPayload = _nonHeaderData.GetPolicyNonHeaderDataAsyn(source, companyCode, policyNo, userName);
                await Task.WhenAll(nonHeaderPayload);

                var nonHeaderResponse = nonHeaderPayload.Result;

                var nonHeaderResponseJson = JsonSerializer.Serialize(nonHeaderResponse);

                if (!string.IsNullOrEmpty(nonHeaderResponseJson))
                {
                    var response = $"{{\"NonHeader\":{nonHeaderResponseJson}}}";
                    return response;
                }
                else
                {
                    _log.LogWarning("NonHeader or Ingenium response was empty for policy {PolicyNo}.", policyNo);
                    return BuildErrorJson("One or more source systemns are unavailable");
                }
                //return MergedFinalJson("IngeniumSource", nonHeaderResponseJson, IngeniumResponseJson);
            }
            catch (Exception ex)
            {
                _log.LogError(ex, "Failed to build NonHeader response for policy {PolicyNo}, source {Source}.", policyNo, source);
                return BuildErrorJson($"{ex.Message}");
            };
        }
        private static string BuildErrorJson(string message)
            {
                return JsonSerializer.Serialize(new { ERROR = message }, _jsonOptions);
            }
    }
}