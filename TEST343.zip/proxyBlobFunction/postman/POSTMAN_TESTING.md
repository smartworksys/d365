# Postman Testing — GetSaasBlobUrl

## Import

1. Open Postman → **Import**
2. Import both files:
   - `GetSaasBlobUrl.postman_collection.json`
   - `GetSaasBlobUrl.postman_environment.json`
3. Select environment **KOFC GetSaasBlobUrl - Local**
4. Fill in variables (`contactId`, `userId`, `path`, etc.)

---

## Start function locally

```powershell
cd proxyBlobFunction\KOFC.Azure.Functions.GetSaasBlobUrl
func start
```

---

## Request guide

| # | Request | When to use |
|---|---------|-------------|
| 1 | **Local - No Auth** | Blob SAS only — no Dataverse check |
| 2 | **Local - Boomi Path (JSON)** | Test Boomi flow with `userId` |
| 3 | **Local - Boomi Path by oid** | Function resolves Entra oid → user |
| 4 | **Local - Legacy Easy Auth** | Old direct user-token path (302 redirect) |
| 5 | **Azure - Boomi Path** | Deployed Function + real client-credentials token |

---

## Boomi path (request #2) — expected response

**200 OK**

```json
{ "sasUrl": "https://<account>.blob.core.windows.net/..." }
```

**Common errors**

| Status | Cause |
|--------|--------|
| 400 | Missing `userId` or `oid` |
| 401 | Missing `Blob.Read` / auth |
| 403 | User cannot read contact |
| 404 | User not found or blob missing |

---

## Get real GUIDs

```powershell
# Your Entra oid
az ad signed-in-user show --query id -o tsv

# Dataverse user token (legacy path #4)
az account get-access-token --resource https://yourorg.crm.dynamics.com --query accessToken -o tsv
```

Look up `systemuserid` in Dataverse for a user whose `azureactivedirectoryobjectid` matches their Entra oid.

---

## Manual cURL (Boomi path local)

```bash
curl -s "http://localhost:7071/api/GetSaasBlobUrl?path=D%3A%5Ctest%5Cfile.xlsx&contactId=CONTACT-GUID&userId=USER-GUID&format=json" \
  -H "X-MS-CLIENT-PRINCIPAL: eyJhdXRoX3R5cCI6ImFhZCIsImNsYWltcyI6W3sidHlwIjoicm9sZXMiLCJ2YWwiOiJCbG9iLlJlYWQifV19"
```

Base64 decodes to: `{"auth_typ":"aad","claims":[{"typ":"roles","val":"Blob.Read"}]}`

---

## Azure Boomi path (request #5)

Pre-request script auto-fetches token:

```http
POST https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials
&client_id={boomiClientId}
&client_secret={boomiClientSecret}
&scope=api://{functionApiAppId}/.default
```

Then calls Function with `Authorization: Bearer {token}`. Easy Auth validates the token; do **not** manually set `X-MS-CLIENT-PRINCIPAL` in Azure.
