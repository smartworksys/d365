using KOFC_FA_AgentPortal_UserProfile.Helpers;

namespace KOFC_FA_AgentPortal_UserProfile.Tests;

public class EappRoleMapperTests
{
    [Theory]
    [InlineData("Insurance-General Agent", "isGeneralAgent")]
    [InlineData("Insurance-Field Agent", "isFieldAgent")]
    [InlineData("Insurance-Assistant General Agent", "isAssistantGeneralAgent")]
    [InlineData("Insurance-Agency Admin", "isFieldAssistant")]
    [InlineData("Insurance-Field Agent Assistant", "isFieldAssistant")]
    [InlineData("Insurance-AgencyAdmin", "isAdmin")]
    [InlineData("KC10", "isGeneralAgent")]
    [InlineData("KC60", "isAdmin")]
    public void ResolveRoleType_MapsLabelsAndCodes(string input, string expectedRoleType)
    {
        var roleType = EappRoleMapper.ResolveRoleType(input);

        Assert.Equal(expectedRoleType, roleType);
    }

    [Fact]
    public void ApplyRoleFlags_SetsAdminFlag()
    {
        var soReq = new SoReqData();

        EappRoleMapper.ApplyRoleFlags(soReq, "isAdmin");

        Assert.True(soReq.isAdmin);
        Assert.False(soReq.isGeneralAgent);
    }

    [Fact]
    public void ApplyRoleFlags_SetsGeneralAgentFlag()
    {
        var soReq = new SoReqData();

        EappRoleMapper.ApplyRoleFlags(soReq, "isGeneralAgent");

        Assert.True(soReq.isGeneralAgent);
        Assert.False(soReq.isAdmin);
    }
}
