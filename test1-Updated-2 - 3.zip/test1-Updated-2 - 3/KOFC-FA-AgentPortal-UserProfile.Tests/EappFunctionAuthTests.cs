using KOFC_FA_AgentPortal_UserProfile.Helpers;
using KOFC_FA_AgentPortal_UserProfile.Tests.Support;
using Microsoft.AspNetCore.Http;

namespace KOFC_FA_AgentPortal_UserProfile.Tests;

public class EappFunctionAuthTests
{
    [Fact]
    public void IsAuthenticated_AllowsLocalRequestsWhenNotRunningInAzure()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var request = HttpRequestTestHelper.CreateRequest();

        Assert.True(EappFunctionAuth.IsAuthenticated(request));
    }

    [Fact]
    public void IsAuthenticated_RequiresIdentityOrPrincipalHeaderInAzure()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var unauthenticated = HttpRequestTestHelper.CreateRequest();
        Assert.False(EappFunctionAuth.IsAuthenticated(unauthenticated));

        var authenticated = HttpRequestTestHelper.CreateRequest(
            principalRoleClaims: new[] { ("roles", "Contact.Read") });
        Assert.True(EappFunctionAuth.IsAuthenticated(authenticated));
    }

    [Fact]
    public void GetCallerRoles_ReturnsBothRolesLocally()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var request = HttpRequestTestHelper.CreateRequest();
        var roles = EappFunctionAuth.GetCallerRoles(request);

        Assert.Contains(EappFunctionAuth.ContactReadRole, roles);
        Assert.Contains(EappFunctionAuth.OpportunityReadRole, roles);
    }

    [Fact]
    public void GetCallerRoles_ReadsRolesFromClaimsPrincipal()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var request = HttpRequestTestHelper.CreateRequest(
            claims: new[]
            {
                new System.Security.Claims.Claim("roles", "Contact.Read")
            });

        var roles = EappFunctionAuth.GetCallerRoles(request);

        Assert.Single(roles);
        Assert.Equal("Contact.Read", roles.First());
    }

    [Fact]
    public void GetCallerRoles_ReadsRolesFromClientPrincipalHeader()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var request = HttpRequestTestHelper.CreateRequest(
            principalRoleClaims: new[]
            {
                ("roles", "Contact.Read"),
                ("roles", "Opportunity.Read")
            });

        var roles = EappFunctionAuth.GetCallerRoles(request);

        Assert.Equal(2, roles.Count);
        Assert.Contains("Opportunity.Read", roles);
    }

    [Fact]
    public void HasAppRole_IsCaseInsensitive()
    {
        IReadOnlyCollection<string> roles = new[] { "contact.read" };

        Assert.True(EappFunctionAuth.HasAppRole(roles, "Contact.Read"));
    }
}
