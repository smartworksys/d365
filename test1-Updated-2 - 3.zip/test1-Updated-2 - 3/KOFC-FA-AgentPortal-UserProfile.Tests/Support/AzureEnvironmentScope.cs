namespace KOFC_FA_AgentPortal_UserProfile.Tests.Support;

internal sealed class AzureEnvironmentScope : IDisposable
{
    private readonly string? _originalSiteName;

    public AzureEnvironmentScope(bool simulateAzureHost)
    {
        _originalSiteName = Environment.GetEnvironmentVariable("WEBSITE_SITE_NAME");
        Environment.SetEnvironmentVariable(
            "WEBSITE_SITE_NAME",
            simulateAzureHost ? "unit-test-app" : null);
    }

    public void Dispose()
    {
        Environment.SetEnvironmentVariable("WEBSITE_SITE_NAME", _originalSiteName);
    }
}
