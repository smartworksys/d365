using KOFC_FA_AgentPortal_UserProfile.Services;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;

namespace KOFC_FA_AgentPortal_UserProfile.Tests.Support;

internal sealed class FakeDataverseService : IDataverseService
{
    public Guid CallerId { get; set; }

    public EntityCollection? UserEntities { get; set; }

    public EntityCollection? OpportunityEntities { get; set; }

    public string OptionSetLabel { get; set; } = "Insurance-General Agent";

    public int OptionSetValue { get; set; } = 1;

    public Exception? RetrieveException { get; set; }

    public EntityCollection RetrieveMultiple(QueryBase query)
    {
        if (RetrieveException != null)
        {
            throw RetrieveException;
        }

        if (query is FetchExpression fetch && fetch.Query.Contains("systemuser", StringComparison.OrdinalIgnoreCase))
        {
            return UserEntities ?? new EntityCollection();
        }

        if (query is FetchExpression opportunityFetch && opportunityFetch.Query.Contains("opportunity", StringComparison.OrdinalIgnoreCase))
        {
            return OpportunityEntities ?? new EntityCollection();
        }

        return new EntityCollection();
    }

    public OrganizationResponse Execute(OrganizationRequest request)
    {
        if (request is not RetrieveAttributeRequest)
        {
            throw new NotSupportedException($"Unexpected request type: {request.GetType().Name}");
        }

        var metadata = new PicklistAttributeMetadata
        {
            OptionSet = new OptionSetMetadata
            {
                Options =
                {
                    new OptionMetadata(
                        new Label(OptionSetLabel, 1033) { UserLocalizedLabel = new LocalizedLabel(OptionSetLabel, 1033) },
                        OptionSetValue)
                }
            }
        };

        var response = new RetrieveAttributeResponse();
        response["AttributeMetadata"] = metadata;
        return response;
    }
}
