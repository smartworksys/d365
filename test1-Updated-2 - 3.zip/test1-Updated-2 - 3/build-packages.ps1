# Build versioned deployment packages for KOFC integrations.
# Output: packages/KOFC-*-v<VERSION>.zip

$ErrorActionPreference = "Stop"
$Root = $PSScriptRoot
$Version = (Get-Content (Join-Path $Root "VERSION") -Raw).Trim()
$PackagesDir = Join-Path $Root "packages"
$PublishRoot = Join-Path $Root "publish"

Write-Host "KOFC package build — version $Version"

if (Test-Path $PublishRoot) { Remove-Item $PublishRoot -Recurse -Force }
if (Test-Path $PackagesDir) { Remove-Item $PackagesDir -Recurse -Force }
New-Item -ItemType Directory -Path $PackagesDir | Out-Null

function Publish-FunctionApp {
    param(
        [string]$ProjectPath,
        [string]$OutputName
    )
    $out = Join-Path $PublishRoot $OutputName
    Write-Host "Publishing $OutputName..."
    dotnet publish $ProjectPath `
        -c Release `
        -o $out `
        --nologo
    if ($LASTEXITCODE -ne 0) { throw "dotnet publish failed for $ProjectPath" }
    return $out
}

function New-VersionedZip {
    param(
        [string]$SourcePath,
        [string]$ZipBaseName
    )
    $zipPath = Join-Path $PackagesDir "${ZipBaseName}-v${Version}.zip"
    if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
    Compress-Archive -Path (Join-Path $SourcePath "*") -DestinationPath $zipPath -CompressionLevel Optimal
    Write-Host "Created $zipPath"
    return $zipPath
}

# --- Function apps ---
$eappOut = Publish-FunctionApp `
    -ProjectPath (Join-Path $Root "KOFC-FA-AgentPortal-UserProfile\KOFC-FA-AgentPortal-UserProfile.csproj") `
    -OutputName "KOFC-FA-AgentPortal-UserProfile"

$policyOut = Publish-FunctionApp `
    -ProjectPath (Join-Path $Root "KOFC-FA-PolicyNonHeader-TierOne\KOFC-FA-PolicyNonHeader-TierOne.csproj") `
    -OutputName "KOFC-FA-PolicyNonHeader-TierOne"

$eappZip = New-VersionedZip -SourcePath $eappOut -ZipBaseName "KOFC-EApp-SSO-FunctionApp"
$policyZip = New-VersionedZip -SourcePath $policyOut -ZipBaseName "KOFC-PolicyNonHeader-TierOne-FunctionApp"

# --- Web resources (staging folder preserves D365 folder layout) ---
$wrStage = Join-Path $PublishRoot "webresources"
New-Item -ItemType Directory -Path $wrStage -Force | Out-Null
Copy-Item (Join-Path $Root "webresources\eapp-boomi-button\*") (Join-Path $wrStage "eapp-boomi-button") -Recurse -Force
Copy-Item (Join-Path $Root "webresources\policy-nonheader\*") (Join-Path $wrStage "policy-nonheader") -Recurse -Force
Copy-Item (Join-Path $Root "webresources\kofc_msal-browser.min.js") $wrStage -Force
@(
    "Upload web resources to Dynamics 365 with matching names.",
    "Shared: kofc_authclient.js, kofc_authcallback.html (eapp-boomi-button/).",
    "Policy: kofc_policy_details.html, kofc_policyDetails.js, kofc_policyClient.js, kofc_Policy.js.",
    "Register kofc_msal-browser.min.js as kofc_msalbrowsermin (no extension in D365 name)."
) | Set-Content (Join-Path $wrStage "README-upload.txt")

$wrZip = New-VersionedZip -SourcePath $wrStage -ZipBaseName "KOFC-webresources"

# --- Documentation ---
$docStage = Join-Path $PublishRoot "docs"
New-Item -ItemType Directory -Path $docStage -Force | Out-Null
Copy-Item (Join-Path $Root "docs\*.wiki.md") $docStage -Force
Copy-Item (Join-Path $Root "docs\*.docx") $docStage -Force -ErrorAction SilentlyContinue
Copy-Item (Join-Path $Root "docs\postman") (Join-Path $docStage "postman") -Recurse -Force

$docZip = New-VersionedZip -SourcePath $docStage -ZipBaseName "KOFC-docs"

# --- Manifest ---
$manifest = @"
KOFC Integration Packages
Version: $Version
Built: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss K")

Artifacts:
  $(Split-Path $eappZip -Leaf)     — Azure Function deploy (getSOReqForEappSSO)
  $(Split-Path $policyZip -Leaf)   — Azure Function deploy (getPolicyData)
  $(Split-Path $wrZip -Leaf)       — D365 web resources
  $(Split-Path $docZip -Leaf)      — Architecture wikis, Word docs, Postman

Deploy function zips via Azure DevOps pipeline or: az functionapp deployment source config-zip
"@

$manifest | Set-Content (Join-Path $PackagesDir "MANIFEST-v${Version}.txt")
Write-Host ""
Write-Host $manifest
Write-Host ""
Write-Host "Done. Packages in: $PackagesDir"
