﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KOFC_FA_PolicyNonHeader_TierOne.Models
{
    public class PolicyNonHeaderAPIModel
    {

        public class Root
        {
            [JsonProperty("DATA")]
            public Data? Data { get; set; }
        }

        public class Data
        {
            
            [JsonProperty("Non_Header")]
            public NonHeader? NonHeader { get; set; }
        }

        public class NonHeader
        {
            [JsonProperty("SOURCE_SYSTEM")]
            public string SourceSystem { get; set; }

            [JsonProperty("POLICY_NUMBER")]
            public string PolicyNumber { get; set; }

            [JsonProperty("INSURANCE_SUB_TYPE")]
            public string InsuranceSubType { get; set; }

            [JsonProperty("ILLUSTRATION_SYSTEM")]
            public string IllustrationSystem { get; set; }

            [JsonProperty("ADMIN_SYSTEM")]
            public string AdminSystem { get; set; }

            [JsonProperty("INFORCE_CODE")]
            public string InforceCode { get; set; }

            [JsonProperty("ISSUE_COUNTRY")]
            public string IssueCountry { get; set; }

            [JsonProperty("LAST_ANNIVERSARY_DATE")]
            public string LastAnniversaryDate { get; set; }

            [JsonProperty("NET_CHANGE_FOR_THE_YEAR")]
            public string NetChangeForTheYear { get; set; }

            [JsonProperty("NON_FORFEITURE_OPTION")]
            public string NonForfeitureOption { get; set; }

            [JsonProperty("MISC_PREMIUM_ON_DEPOSIT")]
            public string MiscPremiumOnDeposit { get; set; }

            [JsonProperty("MISC_PREMIUM_ON_DEPOSIT_INTEREST_RATE")]
            public string MiscPremiumOnDepositInterestRate { get; set; }

            [JsonProperty("DISCOUNTED_PREMIUMS_ON_DEPOSIT")]
            public string DiscountedPremiumsOnDeposit { get; set; }

            [JsonProperty("DISCOUNTED_PREMIUMS_YEARS_LEFT")]
            public string DiscountedPremiumsYearsLeft { get; set; }

            [JsonProperty("OCC_CLASS")]
            public string OccClass { get; set; }

            [JsonProperty("PUA_ELIGIBLITY")]
            public string PuaEligiblity { get; set; }

            [JsonProperty("PUA_LIFETIME_DEPOSIT_AMOUNT")]
            public string PuaLifetimeDepositAmount { get; set; }

            [JsonProperty("PUA_LIFE_TO_DATE_DEPOSIT_AMOUNT")]
            public string PuaLifeToDateDepositAmount { get; set; }

            [JsonProperty("PUA_YEAR_TO_DATE_PREMIUM_PAID")]
            public string PuaYearToDatePremiumPaid { get; set; }

            [JsonProperty("PUA_PRIOR_YEAR_PREMIUM_PAID")]
            public string PuaPriorYearPremiumPaid { get; set; }

            [JsonProperty("ADPUA_PRIOR_YEAR_FACE_AMOUNT")]
            public string AdpuaPriorYearFaceAmount { get; set; }

            [JsonProperty("ADPUA_CURRENT_YEAR_FACE_AMOUNT")]
            public string AdpuaCurrentYearFaceAmount { get; set; }

            [JsonProperty("ADPUA_ANNUAL_INCREASE_AMOUNT")]
            public string AdpuaAnnualIncreaseAmount { get; set; }

            [JsonProperty("APB_CURRENT_DEATH_BENEFIT_AMOUNT")]
            public string ApbCurrentDeathBenefitAmount { get; set; }

            [JsonProperty("LPR_INDICATOR")]
            public string LprIndicator { get; set; }

            [JsonProperty("POLICY_7_PAY_START_DATE")]
            public string Policy7PayStartDate { get; set; }

            [JsonProperty("POLICY_7_PAY_ANNUAL_PREMIUM")]
            public string Policy7PayAnnualPremium { get; set; }

            [JsonProperty("POLICY_7_PAY_PREMIUM_PAID")]
            public string Policy7PayPremiumPaid { get; set; }

            [JsonProperty("CVOA_LAST_MAT_CHANGE")]
            public string CvoaLastMatChange { get; set; }

            [JsonProperty("POLICY_1035_EXCHANGE_AMOUNT")]
            public string Policy1035ExchangeAmount { get; set; }

            [JsonProperty("DB_PURCHASE_BY_PUA")]
            public string DbPurchaseByPua { get; set; }

            [JsonProperty("ADPPUA_DB")]
            public string AdppuaDb { get; set; }

            [JsonProperty("SDPPUA_DB")]
            public string SdppuaDb { get; set; }

            [JsonProperty("MADPUA_DB")]
            public string MadpuaDb { get; set; }

            [JsonProperty("APBPUA_DB")]
            public string ApbpuaDb { get; set; }

            [JsonProperty("SLIPUA_DB")]
            public string SlipuaDb { get; set; }

            [JsonProperty("ADDTL_AMT_INCR_OR_CONV")]
            public string AddtlAmtIncrOrConv { get; set; }

            [JsonProperty("AMOUNT_AVAIL_CONV")]
            public string AmountAvailConv { get; set; }

            [JsonProperty("ANNUITY_ACCUMULATIVE_VALUE")]
            public string AnnuityAccumulativeValue { get; set; }

            [JsonProperty("ANNUITY_PAYOUT_AMOUNT_YTD")]
            public string AnnuityPayoutAmountYtd { get; set; }

            [JsonProperty("ANNUITY_WITHDRAWALS_YTD")]
            public string AnnuityWithdrawalsYtd { get; set; }

            [JsonProperty("ANNUITY_COST")]
            public string AnnuityCost { get; set; }

            [JsonProperty("ANNUAL_INCOME")]
            public string AnnualIncome { get; set; }

            [JsonProperty("SOW_ELIGIBILITY_INDICATOR")]
            public string SowEligibilityIndicator { get; set; }

            [JsonProperty("COMBINED_INDICATOR")]
            public string CombinedIndicator { get; set; }

            [JsonProperty("PERCENTAGE_INDICATOR")]
            public string PercentageIndicator { get; set; }

            [JsonProperty("IOPO_INDICATOR")]
            public string IopoIndicator { get; set; }

            [JsonProperty("PAYMENT_CEASE_DATE")]
            public string PaymentCeaseDate { get; set; }

            [JsonProperty("PREMIUM_LOAN_INDICATOR")]
            public string PremiumLoanIndicator { get; set; }

            [JsonProperty("LOAN_INTEREST_RATE")]
            public string LoanInterestRate { get; set; }

            [JsonProperty("LOAN_PRINCIPAL_AT_ANNIVERSARY")]
            public string LoanPrincipalAtAnniversary { get; set; }

            [JsonProperty("PUA_CASH_VALUE_FROM_DIVIDEND")]
            public string PuaCashValueFromDividend { get; set; }

            [JsonProperty("ISSUE_CLASS")]
            public string IssueClass { get; set; }

            [JsonProperty("APPLICATION_RECEIVED_DATE")]
            public string ApplicationReceivedDate { get; set; }

            [JsonProperty("APPLICATION_SIGN_DATE")]
            public string ApplicationSignDate { get; set; }

            [JsonProperty("CATASTROPHIC_DISABILITY_RIDER_INDICATOR")]
            public string CatastrophicDisabilityRiderIndicator { get; set; }

            [JsonProperty("CLIENT_FRATERNAL_STATUS_CODE")]
            public string ClientFraternalStatusCode { get; set; }

            [JsonProperty("COLA_INDICATOR")]
            public string ColaIndicator { get; set; }

            [JsonProperty("DI_POLICY_CLIENT_ELIGIBILITY_CODE")]
            public string DiPolicyClientEligibilityCode { get; set; }

            [JsonProperty("DI_CVG_FCT_ID")]
            public string DiCvgFctId { get; set; }

            [JsonProperty("DI_FCT_ID")]
            public string DiFctId { get; set; }

            [JsonProperty("GPO_DECLINED_1ST_DATE")]
            public string GpoDeclined1stDate { get; set; }

            [JsonProperty("GPO_DECLINED_2ND_DATE")]
            public string GpoDeclined2ndDate { get; set; }

            [JsonProperty("GPO_OPTION_REMAINING_QUANTITY")]
            public string GpoOptionRemainingQuantity { get; set; }

            [JsonProperty("GPO_OPTION_USED_QUANTITY")]
            public string GpoOptionUsedQuantity { get; set; }

            [JsonProperty("MAX_MTHLY_BNFT_AMT")]
            public string MaxMonthlyBenefitAmt { get; set; }

            [JsonProperty("MONTHLY_PREMIUM_AMOUNT")]
            public string MonthlyPremiumAmount { get; set; }

            [JsonProperty("NEXT_GPO_OPTION_DATE")]
            public string NextGpoOptionDate { get; set; }

            [JsonProperty("NEXT_RENEWAL_DATE")]
            public string NextRenewalDate { get; set; }

            [JsonProperty("OCCP_CLAS_CD")]
            public string OccpClasCd { get; set; }

            [JsonProperty("POLICY_CEASE_DATE")]
            public string PolicyCeaseDate { get; set; }

            [JsonProperty("POLICY_CWA_AMOUNT")]
            public string PolicyCwaAmount { get; set; }

            [JsonProperty("POLICY_GROSS_ANNUAL_PREMIUM_AMOUNT")]
            public string PolicyGrossAnnualPremiumAmount { get; set; }

            [JsonProperty("POLICY_MAIL_DATE")]
            public string PolicyMailDate { get; set; }

            [JsonProperty("POLICY_PRIOR_ANNIVERSARY_DATE")]
            public string PolicyPriorAnniversaryDate { get; set; }

            [JsonProperty("POLICY_QUARTERLY_PREMIUM_AMOUNT")]
            public string PolicyQuarterlyPremiumAmount { get; set; }

            [JsonProperty("POLICY_RISK_EFFECTIVE_DATE")]
            public string PolicyRiskEffectiveDate { get; set; }

            [JsonProperty("POLICY_SEMI_ANNUAL_PREMIUM_AMOUNT")]
            public string PolicySemiAnnualPremiumAmount { get; set; }

            [JsonProperty("POLICY_STATUS_REASON")]
            public string PolicyStatusReason { get; set; }

            [JsonProperty("SOCIAL_INSURANCE_INDICATOR")]
            public string SocialInsuranceIndicator { get; set; }

            [JsonProperty("ACCOUNT_NAME")]
            public string AccountName { get; set; }

            [JsonProperty("ACCOUNT_NUMBER")]
            public string AccountNumber { get; set; }

            [JsonProperty("APPLICATION_APPROVE_DATE")]
            public string ApplicationApproveDate { get; set; }

            [JsonProperty("BASE_INFLATION_MODAL_PREMIUM_AMOUNT")]
            public string BaseInflationModalPremiumAmount { get; set; }

            [JsonProperty("BASE_MODAL_PREMIUM_AMOUNT")]
            public string BaseModalPremiumAmount { get; set; }

            [JsonProperty("BASE_NON_FORFEITURE_MODAL_PREMIUM_AMOUNT")]
            public string BaseNonForfeitureModalPremiumAmount { get; set; }

            [JsonProperty("BASE_RPO_MODAL_PREMIUM_AMOUNT")]
            public string BaseRpoModalPremiumAmount { get; set; }

            [JsonProperty("BASE_SD_MODAL_PREMIUM_AMOUNT")]
            public string BaseSdModalPremiumAmount { get; set; }

            [JsonProperty("CHECK_DATE")]
            public string CheckDate { get; set; }

            [JsonProperty("CHECK_PAYMENT_AMOUNT")]
            public string CheckPaymentAmount { get; set; }

            [JsonProperty("CWA_AMOUNT")]
            public string CwaAmount { get; set; }

            [JsonProperty("DAILY_BENEFIT_AMOUNT")]
            public string DailyBenefitAmount { get; set; }

            [JsonProperty("ELIGIBILITY_DATE")]
            public string EligibilityDate { get; set; }

            [JsonProperty("GPO_BASE_MODEL_PREMIUM_AMOUNT")]
            public string GpoBaseModelPremiumAmount { get; set; }

            [JsonProperty("GPO_CRITICAL_IND")]
            public string GpoCriticalInd { get; set; }

            [JsonProperty("GPO_ELIGIBILITY_INDICATOR")]
            public string GpoEligibilityIndicator { get; set; }

            [JsonProperty("GPO_NON_FORFEITURE_MODEL_PREMIUM")]
            public string GpoNonForfeitureModelPremium { get; set; }

            [JsonProperty("GPO_NUMBER")]
            public string GpoNumber { get; set; }

            [JsonProperty("GPO_OPTION_2_DATE")]
            public string GpoOption2Date { get; set; }

            [JsonProperty("GPO_OPTION_DATE")]
            public string GpoOptionDate { get; set; }

            [JsonProperty("GPO_ROP_MODEL_PREMIUM_AMOUNT")]
            public string GpoRopModelPremiumAmount { get; set; }

            [JsonProperty("GPO_SD_MODEL_PREMIUM_AMOUNT")]
            public string GpoSdModelPremiumAmount { get; set; }

            [JsonProperty("HC_CURRENT_DAILY_BENEFIT")]
            public string HcCurrentDailyBenefit { get; set; }

            [JsonProperty("HC_CURRENT_DAILY_UNLIMITED")]
            public string HcCurrentDailyUnlimited { get; set; }

            [JsonProperty("HC_ELIMINATION_PERIOD_DAYS")]
            public string HcEliminationPeriodDays { get; set; }

            [JsonProperty("HC_MAX_LIFETIME_BENEFIT")]
            public string HcMaxLifetimeBenefit { get; set; }

            [JsonProperty("HC_MAX_LIFETIME_UNLIMITED")]
            public string HcMaxLifetimeUnlimited { get; set; }

            [JsonProperty("HC_MAX_MONTHLY_UNLIMITED")]
            public string HcMaxMonthlyUnlimited { get; set; }

            [JsonProperty("HC_MAX_MONTHLY_BENEFIT")]
            public string HcMaxMonthlyBenefit { get; set; }

            [JsonProperty("INFLATION_OPTION")]
            public string InflationOption { get; set; }

            [JsonProperty("INFLATION_PERCENTAGE")]
            public string InflationPercentage { get; set; }

            [JsonProperty("LONG_TERM_CARE_UNDERWRITING_RISK_CLASS")]
            public string LongTermCareUnderwritingRiskClass { get; set; }

            [JsonProperty("LTC_DURATION_NUMBER")]
            public string LtcDurationNumber { get; set; }

            [JsonProperty("LTC_PREM_INCM_AMT")]
            public string LtcPremIncmAmt { get; set; }

            [JsonProperty("MODIFIED_DECISION_IND")]
            public string ModifiedDecisionInd { get; set; }

            [JsonProperty("NFO_INDICATOR")]
            public string NfoIndicator { get; set; }

            [JsonProperty("NFO_PERCENTAGE")]
            public string NfoPercentage { get; set; }

            [JsonProperty("NH_CURRENT_DAILY_BENEFIT")]
            public string NhCurrentDailyBenefit { get; set; }

            [JsonProperty("NH_CURRENT_DAILY_UNLIMITED")]
            public string NhCurrentDailyUnlimited { get; set; }

            [JsonProperty("NH_ELIMINATION_PERIOD_DAYS")]
            public string NhEliminationPeriodDays { get; set; }

            [JsonProperty("NH_MAX_LIFETIME_BENEFIT")]
            public string NhMaxLifetimeBenefit { get; set; }

            [JsonProperty("NH_MAX_LIFETIME_UNLIMITED")]
            public string NhMaxLifetimeUnlimited { get; set; }

            [JsonProperty("NH_MAX_MONTHLY_BENEFIT")]
            public string NhMaxMonthlyBenefit { get; set; }

            [JsonProperty("NH_MAX_MONTHLY_UNLIMITED")]
            public string NhMaxMonthlyUnlimited { get; set; }

            [JsonProperty("ORIGINAL_DAILY_BENEFIT_AMOUNT")]
            public string OriginalDailyBenefitAmount { get; set; }

            [JsonProperty("PLAN_VAR")]
            public string PlanVar { get; set; }

            [JsonProperty("POLICY_INDICATOR")]
            public string PolicyIndicator { get; set; }

            [JsonProperty("PREMIUM_PAYMENT_QUANTITY")]
            public string PremiumPaymentQuantity { get; set; }

            [JsonProperty("PRIOR_ONE_YEAR_GPO_ANNUALIZED_PREMIUM")]
            public string PriorOneYearGpoAnnualizedPremium { get; set; }

            [JsonProperty("PRIOR_ONE_YEAR_GPO_NUMBER")]
            public string PriorOneYearGpoNumber { get; set; }

            [JsonProperty("PRIOR_TWO_YEARS_GPO_NUMBER")]
            public string PriorTwoYearsGpoNumber { get; set; }

            [JsonProperty("PRIOR_TWO_YEARS_GPO_ANNUALIZED_PREMIUM")]
            public string PriorTwoYearsGpoAnnualizedPremium { get; set; }

            [JsonProperty("REGISTER_DATE")]
            public string RegisterDate { get; set; }

            [JsonProperty("REPLACEMENT_INDICATOR")]
            public string ReplacementIndicator { get; set; }

            [JsonProperty("SHARED_CARE_IND")]
            public string SharedCareInd { get; set; }

            [JsonProperty("SPOUSE_DISCOUNT_INDICATOR")]
            public string SpouseDiscountIndicator { get; set; }

            [JsonProperty("SPOUSE_DISCOUNT_PERCENTAGE")]
            public string SpouseDiscountPercentage { get; set; }

            [JsonProperty("STATUS_DATE")]
            public string StatusDate { get; set; }

            [JsonProperty("SUITABLE_INDICATOR")]
            public string SuitableIndicator { get; set; }

            [JsonProperty("TOTAL_BASE_MODAL_PREMIUM_AMOUNT")]
            public string TotalBaseModalPremiumAmount { get; set; }

            [JsonProperty("TOTAL_GPO_MODAL_PREMIUM_AMOUNT")]
            public string TotalGpoModalPremiumAmount { get; set; }

            [JsonProperty("TPA_PD_CLM_ID")]
            public string TpaPdClmId { get; set; }

            [JsonProperty("TPA_PD_CLM_SEQ_NUM")]
            public string TpaPdClmSeqNum { get; set; }

            [JsonProperty("VALUES_CWA")]
            public string ValuesCwa { get; set; }

            [JsonProperty("YR_NUM")]
            public string YrNum { get; set; }

            [JsonProperty("LONG_TERM_CARE_POLICY_ID")]
            public string LongTermCarePolicyId { get; set; }

            [JsonProperty("ELIMINATION_PERIOD")]
            public string EliminationPeriod { get; set; }

            [JsonProperty("BENEFIT_LENGTH_YEARS")]
            public string BenefitLengthYears { get; set; }

            [JsonProperty("TAX_TYPE")]
            public string TaxType { get; set; }




            [JsonExtensionData]
            public Dictionary<string, object?>? Extra { get; init; }

        }


    }
}