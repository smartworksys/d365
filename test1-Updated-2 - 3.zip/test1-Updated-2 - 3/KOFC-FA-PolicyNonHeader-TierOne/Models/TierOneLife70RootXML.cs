﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace KOFC_FA_PolicyNonHeader_TierOne.Models
{
    public class TierOneLife70RootXML
    {


        [XmlRoot(ElementName = "Envelope", Namespace = SoapNs)]
        public class SoapEnvelope
        {
            public const string SoapNs = "http://schemas.xmlsoap.org/soap/envelope/";
            public const string Life70Ns = "http://kofc.org/life70";

            [XmlElement(ElementName = "Header", Namespace = SoapNs)]
            public SoapHeader Header { get; set; }  // optional; your sample doesn't include headers

            [XmlElement(ElementName = "Body", Namespace = SoapNs)]
            public SoapBody Body { get; set; }
        }

        public class SoapHeader
        {
            // Define header fields if your service returns them; otherwise keep empty
        }

        [XmlType(Namespace = SoapEnvelope.SoapNs)]
        public class SoapBody
        {
            // Inside <SOAP-ENV:Body>, a default namespace is declared for the payload (http://kofc.org/life70)
            [XmlElement("getPolicyValuesResponse", Namespace = SoapEnvelope.Life70Ns)]
            public GetPolicyValuesResponse GetPolicyValuesResponse { get; set; }
        }

        [XmlRoot("getPolicyValuesResponse", Namespace = SoapEnvelope.Life70Ns)]
        public class GetPolicyValuesResponse
        {
            [XmlAttribute("uuid")]
            public string Uuid { get; set; }

            [XmlElement("response")]
            public PolicyResponse Response { get; set; }
        }

        public class PolicyResponse
        {

            [XmlAttribute("policy")]
            public string Policy { get; set; }

            [XmlAttribute("country")]
            public string Country { get; set; }

            [XmlAttribute("onlineDate")]
            public string OnlineDate { get; set; }

            [XmlElement("condition")]
            public PolicyCondition Condition { get; set; }
            
            [XmlElement("qsppSurrenderAmt")]
            public string QsppSurrenderAmt { get; set; }

            [XmlElement("maxLoanAmount")]
            public string MaxLoanAmount { get; set; }

            [XmlElement("rpuFaceAmount")]
            public string RpuFaceAmount { get; set; }

            [XmlElement("qdcpLoanPayoff")]
            public string QdcpLoanPayoff { get; set; }

            [XmlElement("totalDeathBenefit")]
            public string TotalDeathBenefit { get; set; }

            [XmlElement("qsppLoanInterest")]
            public string QsppLoanInterest { get; set; }

            [XmlElement("qsppPreviousLoan")]
            public string QsppPreviousLoan { get; set; }

            [XmlElement("rate")]
            public string Rate { get; set; }

            [XmlElement("totalAmountOnDeposit")]
            public string TotalAmountOnDeposit { get; set; }

            [XmlElement("totalPUAFaceAmount")]
            public string TotalPUAFaceAmount { get; set; }

            [XmlElement("anniversaryCashValue")]
            public string AnniversaryCashValue { get; set; }

            [XmlElement("increaseInCashValue")]
            public string IncreaseInCashValue { get; set; }

            [XmlElement("netDiffCashValue")]
            public string NetDiffCashValue { get; set; }

            [XmlElement("currentDividend")]
            public string CurrentDividend { get; set; }

            [XmlElement("guaranteedInterestRate")]
            public string GuaranteedInterestRate { get; set; }

            [XmlElement("qsppPhases")]
            public QsppPhases QsppPhases { get; set; }

            [XmlElement("qsppDividends")]
            public QsppDividends QsppDividends { get; set; }


        }

        public class PolicyCondition
        {
            [XmlAttribute("completion")]
            public string Completion { get; set; }

            [XmlAttribute("transactions")]
            public string Transactions { get; set; }

            [XmlAttribute("elapsedTime")]
            public string ElapsedTime { get; set; }

            [XmlElement("message")]
            public ConditionMessage Message { get; set; }
        }

        public class ConditionMessage
        {
            [XmlAttribute("num")]
            public string Num { get; set; }

            [XmlAttribute("text")]
            public string Text { get; set; }
        }

        public class QsppPhases
        {
            [XmlAttribute("count")]
            public string Count { get; set; }

            [XmlAttribute("totalSurrenderValue")]
            public decimal TotalSurrenderValue { get; set; }

            [XmlAttribute("totalSurrenderCharge")]
            public string TotalSurrenderCharge { get; set; }

            [XmlAttribute("totalCVPUASurrender")]
            public string TotalCVPUASurrender { get; set; }

            [XmlAttribute("totalInterpolatedValue")]
            public string TotalInterpolatedValue { get; set; }
        }

        public class QsppDividends
        {
            [XmlAttribute("count")]
            public string Count { get; set; }

            [XmlAttribute("totalPUA")]
            public string TotalPUA { get; set; }

          
        }

    }
}
