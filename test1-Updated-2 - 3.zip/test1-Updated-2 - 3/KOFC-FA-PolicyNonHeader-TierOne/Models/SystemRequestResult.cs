﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KOFC_FA_PolicyNonHeader_TierOne.Models
{
    public class SystemRequestResult
    {
        public string SystemRequestId { get; set; }
        public string CurrentDate { get; set; }
        public string DateAndTimeStamp { get; set; }
    }
}
