﻿using Azure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Xml.Serialization;

namespace KOFC_FA_PolicyNonHeader_TierOne.Models
{
    public class TierOneL70ResponseJson
    {

        public string PolicyNumber { get; set; }     
        public string Country { get; set; }     
        public string OnlineDate { get; set; }
        public string TotalDeathBenefit { get; set; }
        public string QsppPUACashValue { get; set; }
        public string RpuFaceAmount { get; set; }
        public string QdcpLoanPayoff { get; set; }
        public string MaxLoanAmount { get; set; }

        public string QsppSurrenderAmt { get; set; }
        public string QsppAnnCashValue { get; set; }
        public string IimgDivDb { get; set; }
        public string QsppLoanInterest { get; set; }
        public string QsppLoanPrincipal { get; set; }
        public string QsppTotalSurrenderChargeAmt { get; set; }
        public string IIMGTotalPuaDbAmt { get; set; }
        public string QsppAnnAccumVal { get; set; }
        public string QsppPuaCashDividend { get; set; }
        public string IIMGDbByPua { get; set; }


    }
}
