﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel.Channels;
using System.ServiceModel.Security;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace KOFC_FA_PolicyNonHeader_TierOne.Models
{
    public class TierOneINGRootXml
    {
        [JsonProperty("base:callFlowResponse")]
        public Data DATA { get; set; }
    }

    public class Data
    {
        //[JsonProperty("Messages")]
        //public Messages Messages { get; set; }
        [JsonProperty("MIR-POL-ID-BASE")]
        public string POL_ID_BASE { get; set; }

        [JsonProperty("MIR-POL-ID-SFX")]
        public string POL_ID_SFX { get; set; }

        [JsonProperty("MIR-DV-EFF-DT")]
        public string DV_EFF_DT { get; set; }

        [JsonProperty("MIR-TOT-DEATH-BENE-AMT")]
        public string TOT_DEATH_BENE_AMT { get; set; }

        [JsonProperty("MIR-DV-VALU-PUA-AMT")]
        public string DV_VALUE_PUA_AMT { get; set; }

        [JsonProperty("MIR-POL-DOD-ACUM-AMT")]
        public string POL_DOD_ACUM_AMT { get; set; }

        [JsonProperty("MIR-RPU-CVG-SUM-INS-AMT")]
        public string RPU_CVG_SUM_INS_AMT { get; set; }

        [JsonProperty("MIR-CURR-ANNV-DT")]
        public string CURR_ANNV_DT { get; set; }

        [JsonProperty("MIR-CURR-ANNV-CV-AMT")]
        public string CURR_ANNV_CV_AMT { get; set; }

        [JsonProperty("MIR-PREV-ANNV-DT")]
        public string PREV_ANNV_DT { get; set; }

        [JsonProperty("MIR-PREV-ANNV-CV-AMT")]
        public string PREV_ANNV_CV_AMT { get; set; }

        [JsonProperty("MIR-DV-MCV-CSV-AMT")]
        public string DV_MCV_CSV_AMT { get; set; }

        [JsonProperty("MIR-DV-LOAN-REPAY-AMT")]
        public string DV_LOAN_REPAY_AMT { get; set; }

        [JsonProperty("MIR-DV-MAX-LOAN-AMT")]
        public string DV_MAX_LOAN_AMT { get; set; }

        [JsonProperty("MIR-LOAN-INT-AMT")]
        public string LOAN_INT_AMT { get; set; }

        [JsonProperty("MIR-LOAN-BAL-AMT")]
        public string LOAN_BAL_AMT { get; set; }

        [JsonProperty("MIR-DV-POL-CSV-AMT")]
        public string DV_POL_CSV_AMT { get; set; }

        [JsonProperty("MIR-ANNV-UL-SURR-CHRG-AMT")]
        public string ANNV_UL_SURR_CHRG_AMT { get; set; }

        [JsonProperty("MIR-ANNV-SURR-AMT")]
        public string ANNV_SURR_AMT { get; set; }

        [JsonProperty("MIR-INFC-PUA-DTH-AMT")]
        public string INFC_PUA_DTH_AMT { get; set; }

        [JsonProperty("MIR-CFN-ACB-AMT")]
        public string CFN_ACB_AMT { get; set; }

        [JsonProperty("MIR-ANNV-ACCUM-VAL-AMT")]
        public string ANNV_ACCUM_VAL_AMT { get; set; }

        [JsonProperty("MIR-PUA-CV-DIV-AMT")]
        public string PUA_CV_DIV_AMT { get; set; }

        [JsonProperty("MIR-DB-PURC-PUA-AMT")]
        public string DB_PURC_PUA_AMT { get; set; }

        [JsonProperty("LSIR-RETURN-CD")]
        public string LsirReturnCode { get; set; }

        [JsonProperty("ING-RETURN-CD")]
        public string IngeniumReturnCode { get; set; }

        [JsonProperty("Page")]
        public string PAGE { get; set; }
    }

    public class Messages
    {
        [JsonProperty("Message")]
        public List<MessageDetail> MESSAGE { get; set; }
        [JsonProperty("More")]
        public string MORE { get; set; }
    }

    public class MessageDetail
    {
        [JsonProperty("Id")]
        public string ID { get; set; }
        [JsonProperty("Severity")]
        public string SEVERITY { get; set; }
        [JsonProperty("Content")]
        public string CONTENT { get; set; }
    }
}
