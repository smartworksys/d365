﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static KOFC_FA_PolicyNonHeader_TierOne.Models.TierOneLife70RootXML;
using static KOFC_FA_PolicyNonHeader_TierOne.Helpers.SystemRequestGenerator;

namespace KOFC_FA_PolicyNonHeader_TierOne.Models
{
    public static class TierOneLife70ResponseMapper
    {

        public static TierOneResponseJson Map(PolicyResponse source)
        {
            return new TierOneResponseJson
            {

                 ONLINE_DATE = FormatDate(source.OnlineDate, "MM/dd/yyyy"),               
                 DEATH_BENEFIT = source.TotalDeathBenefit,
                 PUA_CASH_VALUE = source.QsppDividends.TotalPUA,
                 REDUCED_PAIDUP_FACE_AMOUNT = source.RpuFaceAmount,
                 LOAN_PAYOFF_AMOUNT = source.QdcpLoanPayoff,
                 MAX_LOAN_AMOUNT_AVAILABLE = source.MaxLoanAmount,
                 CASH_SURRENDER_VALUE = source.QsppSurrenderAmt,
                 CASH_LOAN_INTEREST_RATE = source.Rate,
                 DIV_DEATH_BENEFIT = source.TotalAmountOnDeposit,
                 LOAN_INTEREST = source.QsppLoanInterest,
                 LOAN_PRINCIPLE = source.QsppPreviousLoan,
                 SURRENDER_CHARGE = source.QsppPhases.TotalSurrenderCharge,
                 TOTAL_INFORCE_PUA_DEATH_BENEFIT_FACE_AMOUNT = source.TotalPUAFaceAmount,
                 ANNUITY_ACCUMULATIVE_VALUE = source.QsppPhases.TotalInterpolatedValue,
                 PUA_CASH_VALUE_FROM_DIV = source.QsppDividends.TotalPUA,
                 DB_PURCHASE_BY_PUA = source.QsppDividends.TotalPUA,
                 ANNIVERSARY_CASH_VALUE = source.AnniversaryCashValue,
                NET_CHANGE_FOR_THE_YEAR_EQUALS = source.NetDiffCashValue,
                INCREASE_IN_CASH_VALUE = source.IncreaseInCashValue,
                GUARANTEED_INTEREST_RATE = source.GuaranteedInterestRate,
                CURRENT_DIVIDEND = source.CurrentDividend

            };
    }

    }
}
