﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static KOFC_FA_PolicyNonHeader_TierOne.Models.TierOneResponseJson;

namespace KOFC_FA_PolicyNonHeader_TierOne.Models
{
    public class TierOneResponseJson
    {
        public string DEATH_BENEFIT { get; set; }
        public string PUA_CASH_VALUE { get; set; }
        public string DIV_DEATH_BENEFIT { get; set; }
        public string REDUCED_PAIDUP_FACE_AMOUNT { get; set; }
        public string ANNIVERSARY_DATE { get; set; } //check later
        public string ANNIVERSARY_CASH_VALUE { get; set; }
        public string LAST_ANNIVERSARY_DATE { get; set; } //check later
        public string VALUE_AS_OF_LAST_ANNIVERSARY { get; set; }
        public string INCREASE_IN_CASH_VALUE { get; set; }
        public string LOAN_PAYOFF_AMOUNT { get; set; }
        public string MAX_LOAN_AMOUNT_AVAILABLE { get; set; }
        public string LOAN_INTEREST { get; set; }
        public string LOAN_PRINCIPLE { get; set; }
        public string CASH_SURRENDER_VALUE { get; set; }
        public string SURRENDER_CHARGE { get; set; }
        public string DIVIDENT_VALUE { get; set; }
        public string ANNUITY_SURRENDER_VALUE { get; set; }
        public string TOTAL_INFORCE_PUA_DEATH_BENEFIT_FACE_AMOUNT { get; set; }
        public string NET_CHANGE_FOR_THE_YEAR_EQUALS { get; set; }
        public string ANNUITY_ACCUMULATIVE_VALUE { get; set; }
        public string PUA_CASH_VALUE_FROM_DIV { get; set; }
        public string DB_PURCHASE_BY_PUA { get; set; }
        public string CASH_LOAN_INTEREST_RATE { get; set; }
        public string ONLINE_DATE { get; set; }

        public string GUARANTEED_INTEREST_RATE { get; set; }

        public String CURRENT_DIVIDEND { get; set; }

      
    };
};