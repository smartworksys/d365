﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KOFC_FA_PolicyNonHeader_TierOne.Models
{
    public static class TierOneINGResponseMapper
    {
        public static TierOneResponseJson Map(Data source)
        {
            return new TierOneResponseJson
            {
                DEATH_BENEFIT = source.TOT_DEATH_BENE_AMT,
                PUA_CASH_VALUE = source.DV_VALUE_PUA_AMT,
                DIV_DEATH_BENEFIT = source.POL_DOD_ACUM_AMT,
                REDUCED_PAIDUP_FACE_AMOUNT = source.RPU_CVG_SUM_INS_AMT,
                ANNIVERSARY_DATE = FormatDate(source.CURR_ANNV_DT),//CHECK LATER
                ANNIVERSARY_CASH_VALUE = source.CURR_ANNV_CV_AMT,
                LAST_ANNIVERSARY_DATE = FormatDate(source.PREV_ANNV_DT),//CHECK LATER
                VALUE_AS_OF_LAST_ANNIVERSARY = source.DV_MCV_CSV_AMT,
                INCREASE_IN_CASH_VALUE = source.DV_MCV_CSV_AMT,
                LOAN_PAYOFF_AMOUNT = source.DV_LOAN_REPAY_AMT,
                MAX_LOAN_AMOUNT_AVAILABLE = source.DV_MAX_LOAN_AMT,
                LOAN_INTEREST = source.LOAN_INT_AMT,
                LOAN_PRINCIPLE = source.LOAN_BAL_AMT,
                CASH_SURRENDER_VALUE = source.DV_POL_CSV_AMT,
                SURRENDER_CHARGE = source.ANNV_UL_SURR_CHRG_AMT,
                ANNUITY_SURRENDER_VALUE = source.ANNV_SURR_AMT,
                TOTAL_INFORCE_PUA_DEATH_BENEFIT_FACE_AMOUNT = source.INFC_PUA_DTH_AMT,
                NET_CHANGE_FOR_THE_YEAR_EQUALS = source.CFN_ACB_AMT,
                ANNUITY_ACCUMULATIVE_VALUE = source.ANNV_ACCUM_VAL_AMT,
                PUA_CASH_VALUE_FROM_DIV = source.PUA_CV_DIV_AMT,
                DB_PURCHASE_BY_PUA = source.DB_PURC_PUA_AMT,
            };
        }

        private static string FormatDate(string inputDate)
        {
            if (string.IsNullOrEmpty(inputDate)) return null;

            if (DateTime.TryParseExact(inputDate, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var parseDate))
            {
                return parseDate.ToString("MM-dd-yyyy");
            }
            return inputDate;
        }

    }
}
