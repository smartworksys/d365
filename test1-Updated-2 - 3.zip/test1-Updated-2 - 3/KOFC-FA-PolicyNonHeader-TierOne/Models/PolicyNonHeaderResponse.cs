﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KOFC_FA_PolicyNonHeader_TierOne.Models
{
    public class PolicyNonHeaderResponse
    {
        [JsonProperty("PolicyNumber")]
        public string PolicyNumber { get; set; }
        public string InsuranceSubType { get; set; }
        public string IllustrationSystem { get; set; }
        public string AdminSystem { get; set; }
        public string InforceCode { get; set; }
        public string IssueCountry { get; set; }
        public string LastAnniversaryDate { get; set; }
        //public string NetChangeForTheYear { get; set; }
        public string NonForfeitureOption { get; set; }
        public string MiscPremiumOnDeposit { get; set; }
        public string MiscPremiumOnDepositInterestRate { get; set; }
        public string DiscountedPremiumsOnDeposit { get; set; }
        public string DiscountedPremiumsYearsLeft { get; set; }
        public string OccClass { get; set; }
        public string PuaEligiblity { get; set; }
        public string PuaLifetimeDepositAmount { get; set; }
        public string PuaLifeToDateDepositAmount { get; set; }
        public string PuaYearToDatePremiumPaid { get; set; }
        public string PuaPriorYearPremiumPaid { get; set; }
        public string AdpuaPriorYearFaceAmount { get; set; }
        public string AdpuaCurrentYearFaceAmount { get; set; }
        public string AdpuaAnnualIncreaseAmount { get; set; }
        public string ApbCurrentDeathBenefitAmount { get; set; }
        public string LprIndicator { get; set; }
        public string Policy7PayStartDate { get; set; }
        public string Policy7PayAnnualPremium { get; set; }
        public string Policy7PayPremiumPaid { get; set; }
        public string CvoaLastMatChange { get; set; }
        public string Policy1035ExchangeAmount { get; set; }
        public string DbPurchaseByPua { get; set; }
        public string AdppuaDb { get; set; }
        public string SdppuaDb { get; set; }
        public string MadpuaDb { get; set; }
        public string ApbpuaDb { get; set; }
        public string SlipuaDb { get; set; }
        public string AddtlAmtIncrOrConv { get; set; }
        public string AmountAvailConv { get; set; }
        //  public string AnnuityAccumulativeValue { get; set; }
        public string AnnuityPayoutAmountYtd { get; set; }
        public string AnnuityWithdrawalsYtd { get; set; }
        public string AnnuityCost { get; set; }
        public string AnnualIncome { get; set; }
        public string SowEligibilityIndicator { get; set; }
        public string CombinedIndicator { get; set; }
        public string PercentageIndicator { get; set; }
        public string IopoIndicator { get; set; }
        public string PaymentCeaseDate { get; set; }
        public string PremiumLoanIndicator { get; set; }
        // public string LoanInterestRate { get; set; }
        public string LoanPrincipalAtAnniversary { get; set; }
        public string PuaCashValueFromDividend { get; set; }
        public string IssueClass { get; set; }
        public string ApplicationReceivedDate { get; set; }
        public string ApplicationSignDate { get; set; }
        public string CatastrophicDisabilityRiderIndicator { get; set; }
        public string ClientFraternalStatusCode { get; set; }
        public string ColaIndicator { get; set; }
        public string DiPolicyClientEligibilityCode { get; set; }
        public string DiCvgFctId { get; set; }
        public string DiFctId { get; set; }
        public string GpoDeclined1stDate { get; set; }
        public string GpoDeclined2ndDate { get; set; }
        public string GpoOptionRemainingQuantity { get; set; }
        public string GpoOptionUsedQuantity { get; set; }
        public string MaxMonthlyBenefitAmt { get; set; }
        public string MonthlyPremiumAmount { get; set; }
        public string NextGpoOptionDate { get; set; }
        public string NextRenewalDate { get; set; }
        public string OccpClasCd { get; set; }
        public string PolicyCeaseDate { get; set; }
        public string PolicyCwaAmount { get; set; }
        public string PolicyGrossAnnualPremiumAmount { get; set; }
        public string PolicyMailDate { get; set; }
        public string PolicyPriorAnniversaryDate { get; set; }
        public string PolicyQuarterlyPremiumAmount { get; set; }
        public string PolicyRiskEffectiveDate { get; set; }
        public string PolicySemiAnnualPremiumAmount { get; set; }
        public string PolicyStatusReason { get; set; }
        public string SocialInsuranceIndicator { get; set; }
        public string AccountName { get; set; }
        public string AccountNumber { get; set; }
        public string ApplicationApproveDate { get; set; }
        public string BaseInflationModalPremiumAmount { get; set; }
        public string BaseModalPremiumAmount { get; set; }
        public string BaseNonForfeitureModalPremiumAmount { get; set; }
        public string BaseRpoModalPremiumAmount { get; set; }
        public string BaseSdModalPremiumAmount { get; set; }
        public string CheckDate { get; set; }
        public string CheckPaymentAmount { get; set; }
        public string CwaAmount { get; set; }
        public string DailyBenefitAmount { get; set; }
        public string EligibilityDate { get; set; }
        public string GpoBaseModelPremiumAmount { get; set; }
        public string GpoCriticalInd { get; set; }
        public string GpoEligibilityIndicator { get; set; }
        public string GpoNonForfeitureModelPremium { get; set; }
        public string GpoNumber { get; set; }
        public string GpoOption2Date { get; set; }
        public string GpoOptionDate { get; set; }
        public string GpoRopModelPremiumAmount { get; set; }
        public string GpoSdModelPremiumAmount { get; set; }
        public string HcCurrentDailyBenefit { get; set; }
        public string HcCurrentDailyUnlimited { get; set; }
        public string HcEliminationPeriodDays { get; set; }
        public string HcMaxLifetimeBenefit { get; set; }
        public string HcMaxLifetimeUnlimited { get; set; }
        public string HcMaxMonthlyUnlimited { get; set; }
        public string InflationOption { get; set; }
        public string InflationPercentage { get; set; }
        public string LongTermCareUnderwritingRiskClass { get; set; }
        public string LtcDurationNumber { get; set; }
        public string LtcPremIncmAmt { get; set; }
        public string ModifiedDecisionInd { get; set; }
        public string NfoIndicator { get; set; }
        public string NfoPercentage { get; set; }
        public string NhCurrentDailyBenefit { get; set; }
        public string NhCurrentDailyUnlimited { get; set; }
        public string NhEliminationPeriodDays { get; set; }
        public string NhMaxLifetimeBenefit { get; set; }
        public string NhMaxLifetimeUnlimited { get; set; }
        public string NhMaxMonthlyBenefit { get; set; }
        public string NhMaxMonthlyUnlimited { get; set; }
        public string OriginalDailyBenefitAmount { get; set; }
        public string PlanVar { get; set; }
        public string PolicyIndicator { get; set; }
        public string PremiumPaymentQuantity { get; set; }
        public string PriorOneYearGpoAnnualizedPremium { get; set; }
        public string PriorOneYearGpoNumber { get; set; }
        public string PriorTwoYearsGpoNumber { get; set; }
        public string PriorTwoYearsGpoAnnualizedPremium { get; set; }
        public string RegisterDate { get; set; }
        public string ReplacementIndicator { get; set; }
        public string SharedCareInd { get; set; }
        public string SpouseDiscountIndicator { get; set; }
        public string SpouseDiscountPercentage { get; set; }
        public string StatusDate { get; set; }
        public string SuitableIndicator { get; set; }
        public string TotalBaseModalPremiumAmount { get; set; }
        public string TotalGpoModalPremiumAmount { get; set; }
        public string TpaPdClmId { get; set; }
        public string TpaPdClmSeqNum { get; set; }
        public string ValuesCwa { get; set; }
        public string YrNum { get; set; }
        public string LongTermCarePolicyId { get; set; }
        public string EliminationPeriod { get; set; }
        public string BenefitLengthYears { get; set; }
        public string TaxType { get; set; }
        public string HcMaxMonthlyBenefit { get; set; }
    }
}
