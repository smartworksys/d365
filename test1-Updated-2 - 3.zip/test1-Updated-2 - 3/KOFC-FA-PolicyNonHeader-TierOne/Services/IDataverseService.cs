using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace KOFC_FA_PolicyNonHeader_TierOne.Services;

public interface IDataverseService
{
    Guid CallerId { get; set; }

    Entity Retrieve(string entityName, Guid id, ColumnSet columnSet);

    EntityCollection RetrieveMultiple(QueryBase query);
}
