using KOFC_FA_PolicyNonHeader_TierOne.Models;

namespace KOFC_FA_PolicyNonHeader_TierOne.Services;

public interface IPolicyTierOneIngeniumData
{
    Task<TierOneResponseJson> GetPolicyTierOneIngeniumDataAsync(string policyNo, string companyCode);
}
