using KOFC_FA_PolicyNonHeader_TierOne.Models;

namespace KOFC_FA_PolicyNonHeader_TierOne.Services;

public interface IPolicyTierOneLife70Data
{
    Task<TierOneResponseJson> GetPolicyTierOneLife70Data(string policyNo, string companyCode);
}
