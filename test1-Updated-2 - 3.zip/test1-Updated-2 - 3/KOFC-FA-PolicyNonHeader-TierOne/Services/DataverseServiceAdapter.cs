using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace KOFC_FA_PolicyNonHeader_TierOne.Services;

public sealed class DataverseServiceAdapter : IDataverseService
{
    private readonly ServiceClient _serviceClient;

    public DataverseServiceAdapter(ServiceClient serviceClient)
    {
        _serviceClient = serviceClient;
    }

    public Guid CallerId
    {
        get => _serviceClient.CallerId;
        set => _serviceClient.CallerId = value;
    }

    public Entity Retrieve(string entityName, Guid id, ColumnSet columnSet) =>
        _serviceClient.Retrieve(entityName, id, columnSet);

    public EntityCollection RetrieveMultiple(QueryBase query) =>
        _serviceClient.RetrieveMultiple(query);
}
