using KOFC_FA_PolicyNonHeader_TierOne.Models;

namespace KOFC_FA_PolicyNonHeader_TierOne.Services;

public interface IPolicyNonHeaderData
{
    Task<PolicyNonHeaderResponse> GetPolicyNonHeaderDataAsyn(
        string source,
        string companyCode,
        string policyNo,
        string userName);
}
