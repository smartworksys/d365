﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using System.Net;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Net.Http;
using Azure;
using Newtonsoft.Json;
using JsonSerializer = Newtonsoft.Json.JsonSerializer;
using KOFC_FA_PolicyNonHeader_TierOne.Models;
using System.Security.Policy;
using System.Net.Http.Json;
using JsonException = Newtonsoft.Json.JsonException;
using Microsoft.Xrm.Sdk.PluginTelemetry;
using static System.Runtime.InteropServices.JavaScript.JSType;

using KOFC_FA_PolicyNonHeader_TierOne.Services;

namespace KOFC_FA_PolicyNonHeader_TierOne
{
    public class PolicyNonHeaderData : IPolicyNonHeaderData
    {
        private readonly ILogger<PolicyNonHeaderData> _logger;
        private readonly HttpClient _httpClient;

        public PolicyNonHeaderData(ILogger<PolicyNonHeaderData> logger, IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
             _httpClient = httpClientFactory.CreateClient();
        }
      
        public async Task<PolicyNonHeaderResponse> GetPolicyNonHeaderDataAsyn(string source, string companyCode, string policyNo, string userName)
        {

            try
            {

                var nonHeaderAPIURL = Environment.GetEnvironmentVariable("POLICY_NON_HEADER_API_URL");

            
                if (string.IsNullOrWhiteSpace(nonHeaderAPIURL))
                {
                    throw new InvalidOperationException("NON_HEADER_API_URL is not configured.");
                }

                var compPolicyNo = string.Concat(companyCode, policyNo);

                string updatedURL = nonHeaderAPIURL.Replace("{source}", source).Replace("{policyNo}", compPolicyNo).Replace("{userName}", userName);

                _logger.LogInformation(
                    "Calling NonHeader API. Source={Source}, PolicyNo={PolicyNo}, CompanyPolicyNo={CompanyPolicyNo}, UserName={UserName}, Url={Url}",
                    source,
                    policyNo,
                    compPolicyNo,
                    userName,
                    updatedURL);

                var nonHeaderAPIResponse = await _httpClient.GetAsync(updatedURL);
                _logger.LogInformation(
                    "NonHeader API response. StatusCode={StatusCode}, Reason={ReasonPhrase}",
                    (int)nonHeaderAPIResponse.StatusCode,
                    nonHeaderAPIResponse.ReasonPhrase);

                if (!nonHeaderAPIResponse.IsSuccessStatusCode)
                {
                    var json = await nonHeaderAPIResponse.Content.ReadAsStringAsync();
                    PolicyNonHeaderAPIError? error = null;
                    try
                    {
                        error = JsonConvert.DeserializeObject<PolicyNonHeaderAPIError>(json);
                    }
                    catch (JsonException jex)
                    {
                        // Log malformed/non-JSON response but continue with a fallback error
                        _logger.LogWarning(jex, "Failed to parse error JSON. Raw body: {Body}", json);
                    }

                    if (error != null)
                    {
                        _logger.LogInformation(
                            "NonHeader API error. Status: {Status}. Message: {Message}. Details: {Details}",
                            error.Status, error.Message, error.Details);

                        throw new Exception(
                            $"Error Status: {error.Status}\nMessage: {error.Message}\nDetails: {error.Details}");
                    }
                    else
                    {
                        // Fallback when we cannot parse the known error shape
                        _logger.LogInformation(
                            "NonHeader API error (HTTP {StatusCode}). Raw body: {Body}",
                            (int)nonHeaderAPIResponse.StatusCode, json);

                        throw new Exception(
                            $"NonHeader API error {(int)nonHeaderAPIResponse.StatusCode} ({nonHeaderAPIResponse.ReasonPhrase}). Body: {json}");
                    }

                }

                var nonHeaderAPIResponseData = await nonHeaderAPIResponse.Content.ReadAsStringAsync();
                //nonHeaderAPIResponseData = nonHeaderAPIResponseData.Replace("[]", "\"\"");

                var root = JsonConvert.DeserializeObject<PolicyNonHeaderAPIModel.Root>(nonHeaderAPIResponseData);

                if (root?.Data?.NonHeader is null)
                {

                    throw new InvalidOperationException("NonHeader is null. Check JSON shape and property names.");
                }


                var nonHeaderCRMResponse = PolicyNonHeaderResponseMapper.Map(root.Data.NonHeader);

                return nonHeaderCRMResponse;

            }
            catch (TaskCanceledException tex)
            {
                 _logger.LogError(tex, "Request to NonHeader API timed out.");
                throw new TimeoutException("Request to NonHeader API timed out.", tex);
            }
            catch (HttpRequestException hex)
            {
                _logger.LogError(hex, "HTTP request error when calling NonHeader API.");
                throw new Exception($"HTTP error when calling NonHeader API: {hex.Message}", hex);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Unexpected error when calling NonHeader API.");
                throw;
            }
        }
    }
}