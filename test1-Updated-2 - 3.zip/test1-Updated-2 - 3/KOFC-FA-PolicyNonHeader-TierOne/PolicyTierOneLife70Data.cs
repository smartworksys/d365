﻿using KOFC_FA_PolicyNonHeader_TierOne.Models;
using KOFC_FA_PolicyNonHeader_TierOne.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net;
using System.Text;
using System.Xml.Linq;
using System.Xml;
using static System.Net.WebRequestMethods;
using static KOFC_FA_PolicyNonHeader_TierOne.Models.TierOneLife70RootXML;
using System.Xml.Serialization;
using System.Security.Authentication;

namespace KOFC_FA_PolicyNonHeader_TierOne
{
    public class PolicyTierOneLife70Data : IPolicyTierOneLife70Data
    {
        private readonly ILogger<PolicyTierOneLife70Data> _logger;
        private readonly HttpClient _httpClient;

        public PolicyTierOneLife70Data(ILogger<PolicyTierOneLife70Data> logger, IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            _httpClient = httpClientFactory.CreateClient();
            _httpClient.Timeout = TimeSpan.FromMinutes(5);
        }
        
        public async Task<TierOneResponseJson> GetPolicyTierOneLife70Data(string policyNo, string companyCode)
        {
            _logger.LogInformation(
                "Calling Life70 SOAP API for policy {PolicyNo}, company {CompanyCode}.",
                policyNo,
                companyCode);

            var life70HBURL = Environment.GetEnvironmentVariable("Life70_HB_URL");
            var life70HBClientID = Environment.GetEnvironmentVariable("Life70_HB_CLIENT_ID");
            var life70HBClientSecret = Environment.GetEnvironmentVariable("Life70_HB_CLIENT_SECRET");

            var life70HBReq = BuildLife70RequestPayload(policyNo, companyCode);

            var request = new HttpRequestMessage(HttpMethod.Post, life70HBURL)
            {
                Content = new StringContent(life70HBReq, Encoding.UTF8, "text/xml")
            };

            // ---- SOAP headers----
            request.Headers.Add("Accept", "*/*");
            request.Headers.Add("Accept-Encoding", "gzip, deflate, br");
            request.Headers.Add("Cache-Control", "no-cache");
            request.Headers.Add("Connection", "keep-alive");

            var encodedLife70HBcreds = Convert.ToBase64String(Encoding.ASCII.GetBytes($"{life70HBClientID}:{life70HBClientSecret}"));
            request.Headers.Authorization =
                new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encodedLife70HBcreds);

            try
            {
                var life70HBresp = await _httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead);
                var life70XmlResp = await life70HBresp.Content.ReadAsStringAsync();


                if (!life70HBresp.IsSuccessStatusCode)
                {
                    _logger.LogError(
                        "Life70 call failed. StatusCode={StatusCode}, Reason={Reason}, Response={Response}",
                        (int)life70HBresp.StatusCode,
                        life70HBresp.ReasonPhrase,
                        life70XmlResp);

                    return null; // or throw if this should fail the Function
                }


                var life70PolicyXML = ExtractLife70PolicyDetails(life70XmlResp, _logger);
                var tierOneLife70Response = TierOneLife70ResponseMapper.Map(life70PolicyXML.Response);

                _logger.LogInformation(
                       "Life70 response received successfully: {@Life70Response}",
                       tierOneLife70Response);

                return tierOneLife70Response;


            }

            catch (HttpRequestException ex) when (ex.InnerException is AuthenticationException)
            {
                // ✅ SSL / certificate trust issue
                _logger.LogError(
                    ex,
                    "SSL certificate validation failed when calling Life70 endpoint. Url={Url}",
                    request.RequestUri);

                return null;
            }
            catch (HttpRequestException ex)
            {
                // ✅ DNS, connection, protocol, or HTTP pipeline failures
                _logger.LogError(
                    ex,
                    "HTTP request to Life70 failed. Url={Url}, Message={Message}",
                    request.RequestUri,
                    ex.Message);

                return null;
            }
            catch (TaskCanceledException ex)
            {
                // ✅ Timeout
                _logger.LogError(
                    ex,
                    "Life70 request timed out. Url={Url}",
                    request.RequestUri);

                return null;
            }
            catch (Exception ex)
            {
                // ✅ Anything unexpected
                _logger.LogError(
                    ex,
                    "Unexpected error while calling Life70 endpoint. Url={Url}",
                    request.RequestUri);

                throw; // let Azure Functions register a failure
            }

        }




        private static string BuildLife70RequestPayload(string policyNo, String companyCode)
        {
           

            return $@"<soapenv:Envelope xmlns:soapenv='http://schemas.xmlsoap.org/soap/envelope/'
                         xmlns:lif='http://kofc.org/life70'>
                        <soapenv:Header />
                        <soapenv:Body>
                        <getPolicyValuesRequest uuid='?'>
                        <request policy='{policyNo}' country='{companyCode}'/>
                        </getPolicyValuesRequest>
                        </soapenv:Body>
                        </soapenv:Envelope>";
        }


        private static GetPolicyValuesResponse ExtractLife70PolicyDetails(string xml, ILogger _logger)
        {

            var envelopeSerializer = new XmlSerializer(typeof(SoapEnvelope));

            using (var sr = new StringReader(xml))
            {
                var envelope = (SoapEnvelope)envelopeSerializer.Deserialize(sr);

                var payload = envelope?.Body?.GetPolicyValuesResponse;

                if (payload?.Response == null)
                {
                    throw new InvalidOperationException(
                        "Policy response is null after XML deserialization. Verify namespaces and element/attribute mappings.");
                }

                return payload;
            }
        }

    


}
}
