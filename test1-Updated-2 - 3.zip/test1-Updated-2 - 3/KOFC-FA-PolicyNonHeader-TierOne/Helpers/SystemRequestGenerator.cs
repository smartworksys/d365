﻿using KOFC_FA_PolicyNonHeader_TierOne.Models;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace KOFC_FA_PolicyNonHeader_TierOne.Helpers
{
    public static class SystemRequestGenerator
    {
        private const string StaticCode = "CRM";
        private const string AllowedChars = "abcdefghijklmnopqrstuvwxyz0123456789";

        public static SystemRequestResult GenerateSystemRequestNumber()
        {
            var now = DateTime.Now;

            string yyyyMMdd = now.ToString("yyyyMMdd");
            string timeStamp = now.ToString("HHmmss");

            string uniqueCode = GenerateRandomCode(16);

            string systemReqParam = $"{StaticCode}-{yyyyMMdd}-{timeStamp}-{uniqueCode}";

            return new SystemRequestResult
            {
                SystemRequestId = systemReqParam,
                CurrentDate = now.ToString("yyyy-MM-dd"),
                DateAndTimeStamp = now.ToString("yyyy-MM-dd-HH.mm.ss")
            };
        }

        private static string GenerateRandomCode(int length)
        {
            var result = new StringBuilder(length);
            var buffer = new byte[length];

            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(buffer);
            }

            for (int i = 0; i < length; i++)
            {
                var index = buffer[i] % AllowedChars.Length;
                result.Append(AllowedChars[index]);
            }

            return result.ToString();
        }


        public static string FormatDate(string inputDate, string inputDateFormat)
        {
            if (string.IsNullOrEmpty(inputDate)) return null;

            if (DateTime.TryParseExact(inputDate, inputDateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out var parseDate))
            {
                return parseDate.ToString("MM-dd-yyyy");
            }
            return inputDate;
        }

    }
}

