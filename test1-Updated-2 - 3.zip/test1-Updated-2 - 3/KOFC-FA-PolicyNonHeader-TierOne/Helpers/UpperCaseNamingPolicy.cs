﻿using System.Text.Json;

namespace KOFC_FA_PolicyNonHeader_TierOne.Helpers
{
    public class UpperCaseNamingPolicy:JsonNamingPolicy
    {
        public override string ConvertName(string name) => name.ToUpperInvariant();
    }
}
