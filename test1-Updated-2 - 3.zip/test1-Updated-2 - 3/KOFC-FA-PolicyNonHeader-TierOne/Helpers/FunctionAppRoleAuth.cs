using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace KOFC_FA_PolicyNonHeader_TierOne.Helpers;

/// <summary>
/// Validates Easy Auth tokens on inbound requests (mirrors EApp getSOReqForEappSSO).
/// Boomi calls the function with a client-credentials token whose <c>roles</c> claim
/// must include <see cref="PolicyReadRole"/>.
/// </summary>
public static class FunctionAppRoleAuth
{
    public const string PolicyReadRole = "Policy.Read";

    public static bool IsAuthenticated(HttpRequest req)
    {
        if (req.HttpContext.User.Identity?.IsAuthenticated == true)
        {
            return true;
        }

        // Easy Auth on isolated Functions often injects X-MS-CLIENT-PRINCIPAL
        // without populating HttpContext.User for app-only (client credentials) tokens.
        if (IsRunningInAzure() && req.Headers.TryGetValue("X-MS-CLIENT-PRINCIPAL", out var principalHeader))
        {
            return !string.IsNullOrWhiteSpace(principalHeader.FirstOrDefault());
        }

        // Easy Auth is configured on the function app; locally there is no platform auth.
        return !IsRunningInAzure();
    }

    public static IReadOnlyCollection<string> GetCallerRoles(HttpRequest req)
    {
        if (!IsRunningInAzure())
        {
            return new[] { PolicyReadRole };
        }

        var roles = req.HttpContext.User.Claims
            .Where(c => c.Type is "roles" or ClaimTypes.Role
                or "http://schemas.microsoft.com/ws/2008/06/identity/claims/role")
            .Select(c => c.Value)
            .ToList();

        if (roles.Count > 0)
        {
            return roles;
        }

        if (!req.Headers.TryGetValue("X-MS-CLIENT-PRINCIPAL", out var header)
            || string.IsNullOrWhiteSpace(header.FirstOrDefault()))
        {
            return Array.Empty<string>();
        }

        var json = Encoding.UTF8.GetString(Convert.FromBase64String(header.First()!));
        var principal = JsonConvert.DeserializeObject<ClientPrincipal>(json);

        return principal?.Claims?
            .Where(c => string.Equals(c.Typ, "roles", StringComparison.OrdinalIgnoreCase))
            .Select(c => c.Val)
            .ToList() ?? [];
    }

    public static bool HasAppRole(IReadOnlyCollection<string> callerRoles, string role)
    {
        return callerRoles.Contains(role, StringComparer.OrdinalIgnoreCase);
    }

    private static bool IsRunningInAzure()
    {
        return !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("WEBSITE_SITE_NAME"));
    }

    private sealed class ClientPrincipal
    {
        [JsonProperty("claims")]
        public List<ClientPrincipalClaim>? Claims { get; set; }
    }

    private sealed class ClientPrincipalClaim
    {
        [JsonProperty("typ")]
        public string Typ { get; set; } = "";

        [JsonProperty("val")]
        public string Val { get; set; } = "";
    }
}
