using KOFC_FA_PolicyNonHeader_TierOne.Helpers;
using KOFC_FA_PolicyNonHeader_TierOne.Tests.Support;
using Microsoft.AspNetCore.Http;

namespace KOFC_FA_PolicyNonHeader_TierOne.Tests;

public class FunctionAppRoleAuthTests
{
    [Fact]
    public void IsAuthenticated_AllowsLocalRequestsWhenNotRunningInAzure()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var request = HttpRequestTestHelper.CreateRequest();

        Assert.True(FunctionAppRoleAuth.IsAuthenticated(request));
    }

    [Fact]
    public void IsAuthenticated_RequiresIdentityOrPrincipalHeaderInAzure()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var unauthenticated = HttpRequestTestHelper.CreateRequest();
        Assert.False(FunctionAppRoleAuth.IsAuthenticated(unauthenticated));

        var authenticated = HttpRequestTestHelper.CreateRequest(
            principalRoleClaims: new[] { ("roles", FunctionAppRoleAuth.PolicyReadRole) });
        Assert.True(FunctionAppRoleAuth.IsAuthenticated(authenticated));
    }

    [Fact]
    public void GetCallerRoles_ReturnsPolicyReadLocally()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var request = HttpRequestTestHelper.CreateRequest();
        var roles = FunctionAppRoleAuth.GetCallerRoles(request);

        Assert.Contains(FunctionAppRoleAuth.PolicyReadRole, roles);
    }

    [Fact]
    public void GetCallerRoles_ReadsRolesFromClaimsPrincipal()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var request = HttpRequestTestHelper.CreateRequest(
            claims: new[]
            {
                new System.Security.Claims.Claim("roles", FunctionAppRoleAuth.PolicyReadRole)
            });

        var roles = FunctionAppRoleAuth.GetCallerRoles(request);

        Assert.Single(roles);
        Assert.Equal(FunctionAppRoleAuth.PolicyReadRole, roles.First());
    }

    [Fact]
    public void GetCallerRoles_ReadsRolesFromClientPrincipalHeader()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var request = HttpRequestTestHelper.CreateRequest(
            principalRoleClaims: new[]
            {
                ("roles", FunctionAppRoleAuth.PolicyReadRole)
            });

        var roles = FunctionAppRoleAuth.GetCallerRoles(request);

        Assert.Single(roles);
        Assert.Equal(FunctionAppRoleAuth.PolicyReadRole, roles.First());
    }

    [Fact]
    public void HasAppRole_IsCaseInsensitive()
    {
        IReadOnlyCollection<string> roles = new[] { "policy.read" };

        Assert.True(FunctionAppRoleAuth.HasAppRole(roles, FunctionAppRoleAuth.PolicyReadRole));
    }
}
