using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace KOFC_FA_PolicyNonHeader_TierOne.Tests.Support;

internal static class HttpRequestTestHelper
{
    internal static HttpRequest CreateRequest(
        string? queryString = null,
        string? postBody = null,
        IEnumerable<Claim>? claims = null,
        IEnumerable<(string Role, string Value)>? principalRoleClaims = null)
    {
        var context = new DefaultHttpContext();
        if (!string.IsNullOrWhiteSpace(queryString))
        {
            context.Request.QueryString = new QueryString(queryString.StartsWith('?') ? queryString : "?" + queryString);
        }

        if (postBody != null)
        {
            context.Request.Method = HttpMethods.Post;
            context.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes(postBody));
            context.Request.ContentType = "application/json";
        }

        if (claims != null)
        {
            context.User = new ClaimsPrincipal(new ClaimsIdentity(claims, authenticationType: "Test"));
        }

        if (principalRoleClaims != null)
        {
            var payload = new
            {
                claims = principalRoleClaims.Select(c => new { typ = c.Role, val = c.Value }).ToArray()
            };
            var json = JsonConvert.SerializeObject(payload);
            var encoded = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
            context.Request.Headers["X-MS-CLIENT-PRINCIPAL"] = encoded;
        }

        return context.Request;
    }
}
