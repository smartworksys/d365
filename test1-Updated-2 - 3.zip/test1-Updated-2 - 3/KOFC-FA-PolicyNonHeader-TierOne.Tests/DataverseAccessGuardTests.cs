using KOFC_FA_PolicyNonHeader_TierOne.Tests.Support;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;

namespace KOFC_FA_PolicyNonHeader_TierOne.Tests;

public class DataverseAccessGuardTests
{
    private const string PolicyEntity = "kofc_policy";
    private const string PolicyNumberField = "kofc_policynumber";
    private const string CompanyCodeField = "kofc_companycode";

    [Fact]
    public void CheckPolicyAccess_ReturnsUserNotFoundWhenUserMissing()
    {
        using var env = CreatePolicyEnvScope();
        var fake = new FakeDataverseService { UserEntities = new EntityCollection() };
        var guard = CreateGuard(fake);
        var userId = Guid.NewGuid();

        var result = guard.CheckPolicyAccess(userId, "01", "123456", null);

        Assert.Equal(PolicyAccessStatus.UserNotFound, result.Status);
        Assert.Equal(Guid.Empty, fake.CallerId);
    }

    [Fact]
    public void CheckPolicyAccess_GrantsWhenPolicyEntityNotConfigured()
    {
        using var env = new EnvironmentVariableScope(("POLICY_DATAVERSE_ENTITY", null));
        var userId = Guid.NewGuid();
        var fake = new FakeDataverseService
        {
            UserEntities = CreateUserCollection(userId, "agent@example.com")
        };
        var guard = CreateGuard(fake);

        var result = guard.CheckPolicyAccess(userId, "01", "123456", null);

        Assert.True(result.IsGranted);
        Assert.Equal("agent@example.com", result.UserName);
        Assert.Equal(Guid.Empty, fake.CallerId);
    }

    [Fact]
    public void CheckPolicyAccess_DeniesWhenPolicyRecordNotFoundByNumber()
    {
        using var env = CreatePolicyEnvScope();
        var userId = Guid.NewGuid();
        var fake = new FakeDataverseService
        {
            UserEntities = CreateUserCollection(userId, "agent@example.com"),
            PolicyEntities = new EntityCollection()
        };
        var guard = CreateGuard(fake);

        var result = guard.CheckPolicyAccess(userId, "01", "123456", null);

        Assert.Equal(PolicyAccessStatus.AccessDenied, result.Status);
        Assert.Equal(Guid.Empty, fake.CallerId);
    }

    [Fact]
    public void CheckPolicyAccess_GrantsWhenPolicyRecordFoundByNumber()
    {
        using var env = CreatePolicyEnvScope();
        var userId = Guid.NewGuid();
        var policyEntity = new Entity(PolicyEntity) { Id = Guid.NewGuid() };
        var fake = new FakeDataverseService
        {
            UserEntities = CreateUserCollection(userId, "agent@example.com"),
            PolicyEntities = new EntityCollection(new List<Entity> { policyEntity })
        };
        var guard = CreateGuard(fake);

        var result = guard.CheckPolicyAccess(userId, "01", "123456", null);

        Assert.True(result.IsGranted);
        Assert.Equal(Guid.Empty, fake.CallerId);
    }

    [Fact]
    public void CheckPolicyAccess_GrantsWhenPolicyRecordIdMatchesRequest()
    {
        using var env = CreatePolicyEnvScope();
        var userId = Guid.NewGuid();
        var policyRecordId = Guid.NewGuid();
        var policyEntity = new Entity(PolicyEntity) { Id = policyRecordId };
        policyEntity[PolicyNumberField] = "123456";
        policyEntity[CompanyCodeField] = "01";

        var fake = new FakeDataverseService
        {
            UserEntities = CreateUserCollection(userId, "agent@example.com"),
            PolicyRetrieveEntity = policyEntity
        };
        var guard = CreateGuard(fake);

        var result = guard.CheckPolicyAccess(userId, "01", "123456", policyRecordId);

        Assert.True(result.IsGranted);
        Assert.Equal(Guid.Empty, fake.CallerId);
    }

    [Fact]
    public void CheckPolicyAccess_DeniesWhenPolicyRecordIdDoesNotMatchPolicyNumber()
    {
        using var env = CreatePolicyEnvScope();
        var userId = Guid.NewGuid();
        var policyRecordId = Guid.NewGuid();
        var policyEntity = new Entity(PolicyEntity) { Id = policyRecordId };
        policyEntity[PolicyNumberField] = "999999";
        policyEntity[CompanyCodeField] = "01";

        var fake = new FakeDataverseService
        {
            UserEntities = CreateUserCollection(userId, "agent@example.com"),
            PolicyRetrieveEntity = policyEntity
        };
        var guard = CreateGuard(fake);

        var result = guard.CheckPolicyAccess(userId, "01", "123456", policyRecordId);

        Assert.Equal(PolicyAccessStatus.AccessDenied, result.Status);
        Assert.Equal(Guid.Empty, fake.CallerId);
    }

    private static DataverseAccessGuard CreateGuard(FakeDataverseService fake) =>
        new(NullLogger<DataverseAccessGuard>.Instance, fake);

    private static EnvironmentVariableScope CreatePolicyEnvScope() =>
        new(
            ("POLICY_DATAVERSE_ENTITY", PolicyEntity),
            ("POLICY_DATAVERSE_POLICYNO_FIELD", PolicyNumberField),
            ("POLICY_DATAVERSE_COMPANYCODE_FIELD", CompanyCodeField));

    private static EntityCollection CreateUserCollection(Guid userId, string userName)
    {
        var user = new Entity("systemuser") { Id = userId };
        user["domainname"] = userName;
        return new EntityCollection(new List<Entity> { user });
    }
}
