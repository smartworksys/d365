using System.Text.Json;
using KOFC_FA_PolicyNonHeader_TierOne.Tests.Support;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Xrm.Sdk;

namespace KOFC_FA_PolicyNonHeader_TierOne.Tests;

public class PolicyDataTests
{
    private const string PolicyEntity = "kofc_policy";
    private const string PolicyNumberField = "kofc_policynumber";
    private const string CompanyCodeField = "kofc_companycode";

    [Fact]
    public async Task RunAsync_ReturnsUnauthorizedWhenNotAuthenticatedInAzure()
    {
        using var azure = new AzureEnvironmentScope(simulateAzureHost: true);
        var function = CreateFunction(new FakeDataverseService());
        var request = HttpRequestTestHelper.CreateRequest("?source=di&companyCode=01&policyNo=123456&classificationCode=A&userId=" + Guid.NewGuid());

        var result = await function.RunAsync(request);

        var unauthorized = Assert.IsType<UnauthorizedObjectResult>(result);
        Assert.Equal("Authentication required.", unauthorized.Value);
    }

    [Fact]
    public async Task RunAsync_ReturnsForbiddenWhenPolicyReadRoleMissingInAzure()
    {
        using var azure = new AzureEnvironmentScope(simulateAzureHost: true);
        var function = CreateFunction(new FakeDataverseService());
        var request = HttpRequestTestHelper.CreateRequest(
            queryString: "?source=di&companyCode=01&policyNo=123456&classificationCode=A&userId=" + Guid.NewGuid(),
            principalRoleClaims: new[] { ("roles", "Other.Read") });

        var result = await function.RunAsync(request);

        var forbidden = Assert.IsType<ObjectResult>(result);
        Assert.Equal(403, forbidden.StatusCode);
    }

    [Fact]
    public async Task RunAsync_ReturnsBadRequestWhenSourceMissing()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var function = CreateFunction(new FakeDataverseService());
        var request = HttpRequestTestHelper.CreateRequest("?companyCode=01&policyNo=123456&classificationCode=A&userId=" + Guid.NewGuid());

        var result = await function.RunAsync(request);

        var badRequest = Assert.IsType<ObjectResult>(result);
        Assert.Equal(400, badRequest.StatusCode);
    }

    [Fact]
    public async Task RunAsync_ReturnsBadRequestWhenUserIdMissing()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var function = CreateFunction(new FakeDataverseService());
        var request = HttpRequestTestHelper.CreateRequest("?source=di&companyCode=01&policyNo=123456&classificationCode=A");

        var result = await function.RunAsync(request);

        var badRequest = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal("A valid userId query parameter is required.", badRequest.Value);
    }

    [Fact]
    public async Task RunAsync_ReturnsBadRequestWhenPolicyRecordIdInvalid()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var function = CreateFunction(new FakeDataverseService());
        var request = HttpRequestTestHelper.CreateRequest(
            "?source=di&companyCode=01&policyNo=123456&classificationCode=A&userId=" + Guid.NewGuid() + "&policyRecordId=not-a-guid");

        var result = await function.RunAsync(request);

        var badRequest = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal("policyRecordId must be a valid GUID when provided.", badRequest.Value);
    }

    [Fact]
    public async Task RunAsync_ReturnsBadRequestWhenPostBodyEmpty()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var function = CreateFunction(new FakeDataverseService());
        var request = HttpRequestTestHelper.CreateRequest(postBody: "   ");

        var result = await function.RunAsync(request);

        var badRequest = Assert.IsType<BadRequestObjectResult>(result);
        Assert.Equal("Request body is required for POST.", badRequest.Value);
    }

    [Fact]
    public async Task RunAsync_ReturnsForbiddenWhenAccessDenied()
    {
        using var env = new EnvironmentVariableScope(("POLICY_DATAVERSE_ENTITY", PolicyEntity));
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var userId = Guid.NewGuid();
        var fake = new FakeDataverseService
        {
            UserEntities = CreateUserCollection(userId, "agent@example.com"),
            PolicyEntities = new EntityCollection()
        };
        var function = CreateFunction(fake);
        var request = HttpRequestTestHelper.CreateRequest(
            $"?source=di&companyCode=01&policyNo=123456&classificationCode=A&userId={userId}");

        var result = await function.RunAsync(request);

        var forbidden = Assert.IsType<ObjectResult>(result);
        Assert.Equal(403, forbidden.StatusCode);
    }

    [Fact]
    public async Task RunAsync_ReturnsPolicyJsonForDiSource()
    {
        using var env = new EnvironmentVariableScope(("POLICY_DATAVERSE_ENTITY", null));
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var userId = Guid.NewGuid();
        var fake = new FakeDataverseService
        {
            UserEntities = CreateUserCollection(userId, "agent@example.com")
        };
        var function = CreateFunction(fake);
        var request = HttpRequestTestHelper.CreateRequest(
            $"?source=di&companyCode=01&policyNo=123456&classificationCode=A&userId={userId}");

        var result = await function.RunAsync(request);

        var content = Assert.IsType<ContentResult>(result);
        Assert.Equal(200, content.StatusCode);
        Assert.Contains("NonHeader", content.Content);
        Assert.Contains("123456", content.Content);
    }

    [Fact]
    public async Task RunAsync_ReturnsNoContentForUnknownSource()
    {
        using var env = new EnvironmentVariableScope(("POLICY_DATAVERSE_ENTITY", null));
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var userId = Guid.NewGuid();
        var fake = new FakeDataverseService
        {
            UserEntities = CreateUserCollection(userId, "agent@example.com")
        };
        var function = CreateFunction(fake);
        var request = HttpRequestTestHelper.CreateRequest(
            $"?source=unknown&companyCode=01&policyNo=123456&classificationCode=A&userId={userId}");

        var result = await function.RunAsync(request);

        var noContent = Assert.IsType<ObjectResult>(result);
        Assert.Equal(204, noContent.StatusCode);
    }

    [Fact]
    public async Task RunAsync_ReadsParametersFromPostBody()
    {
        using var env = new EnvironmentVariableScope(("POLICY_DATAVERSE_ENTITY", null));
        using var _ = new AzureEnvironmentScope(simulateAzureHost: false);
        var userId = Guid.NewGuid();
        var fake = new FakeDataverseService
        {
            UserEntities = CreateUserCollection(userId, "agent@example.com")
        };
        var function = CreateFunction(fake);
        var body = JsonSerializer.Serialize(new
        {
            source = "di",
            companyCode = "01",
            policyNo = "123456",
            classificationCode = "A",
            userId = userId.ToString()
        });
        var request = HttpRequestTestHelper.CreateRequest(postBody: body);

        var result = await function.RunAsync(request);

        var content = Assert.IsType<ContentResult>(result);
        Assert.Equal(200, content.StatusCode);
    }

    private static PolicyData CreateFunction(FakeDataverseService fakeDataverse)
    {
        var guard = new DataverseAccessGuard(NullLogger<DataverseAccessGuard>.Instance, fakeDataverse);
        return new PolicyData(
            NullLogger<PolicyData>.Instance,
            new FakePolicyNonHeaderData(),
            new FakePolicyTierOneIngeniumData(),
            new FakePolicyTierOneLife70Data(),
            guard);
    }

    private static EntityCollection CreateUserCollection(Guid userId, string userName)
    {
        var user = new Entity("systemuser") { Id = userId };
        user["domainname"] = userName;
        return new EntityCollection(new List<Entity> { user });
    }
}
