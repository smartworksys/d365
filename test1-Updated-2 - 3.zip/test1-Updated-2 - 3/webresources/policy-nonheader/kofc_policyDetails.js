/*
 * ============================================================================
 * kofc_policyDetails.js — Policy Details HTML web resource module
 * ============================================================================
 *
 * Namespace: PolicyDetails (IIFE)
 *
 * REQUIRED ENVIRONMENT VARIABLES (Text type in D365):
 *   kofc_PolicyTenantId   -> Entra tenant ID
 *   kofc_PolicyClientId   -> SPA client ID
 *   kofc_PolicyApiAppId   -> Policy Function API app ID (browser scope: api://<id>/access_as_user)
 *   kofc_PolicyApiKey     -> Boomi x-api-key
 *   kofc_PolicyBoomiUrl   -> Boomi REST URL for Policy Non-Header integration
 *
 * REQUIRED WEB RESOURCES (load order in kofc_policy_details.html):
 *   1. kofc_authclient.js       — KOFC.Auth (shared with EApp)
 *   2. kofc_policyClient.js     — KOFC.Policy
 *   3. kofc_msalbrowsermin      — MSAL.js
 *   4. kofc_policyDetails.js    — this module (PolicyDetails.init on page load)
 *
 * Also required (not loaded by HTML directly):
 *   kofc_authcallback.html   — MSAL redirect page (shared with EApp)
 *
 * Uses parent.Xrm for WebApi and getGlobalContext (HTML web resource in D365 iframe).
 * ============================================================================
 */

var PolicyDetails = (function () {
    "use strict";

    var AUTH_CLIENT_LIBRARY = "/WebResources/kofc_authclient.js";
    var POLICY_CLIENT_LIBRARY = "/WebResources/kofc_policyClient.js";

    var POLICY_ENV_VARS = {
        tenantId: "kofc_PolicyTenantId",
        clientId: "kofc_PolicyClientId",
        apiAppId: "kofc_PolicyApiAppId",
        apiKey: "kofc_PolicyApiKey",
        boomiUrl: "kofc_PolicyBoomiUrl"
    };

    var POLICY_STATIC_CONFIG = {
        scope: "access_as_user",
        httpMethod: "POST",
        redirectWebResource: "kofc_authcallback.html",
        msalWebResourcePath: "/WebResources/kofc_msalbrowsermin",
        allowRedirect: true,
        debug: false
    };

    function loadAuthClient() {
        return new Promise(function (resolve, reject) {
            if (window.KOFC && window.KOFC.Auth) {
                resolve();
                return;
            }
            var script = document.createElement("script");
            script.src = parent.Xrm.Utility.getGlobalContext().getClientUrl() + AUTH_CLIENT_LIBRARY;
            script.onload = function () {
                if (window.KOFC && window.KOFC.Auth) {
                    resolve();
                } else {
                    reject(new Error("Auth client loaded but KOFC.Auth is undefined."));
                }
            };
            script.onerror = function () {
                reject(new Error("Failed to load auth client: " + script.src));
            };
            document.head.appendChild(script);
        });
    }

    function loadPolicyClient() {
        return new Promise(function (resolve, reject) {
            if (window.KOFC && window.KOFC.Policy) {
                resolve();
                return;
            }
            var script = document.createElement("script");
            script.src = parent.Xrm.Utility.getGlobalContext().getClientUrl() + POLICY_CLIENT_LIBRARY;
            script.onload = function () {
                if (window.KOFC && window.KOFC.Policy) {
                    resolve();
                } else {
                    reject(new Error("Policy client loaded but KOFC.Policy is undefined."));
                }
            };
            script.onerror = function () {
                reject(new Error("Failed to load policy client: " + script.src));
            };
            document.head.appendChild(script);
        });
    }

    function getEnvironmentVariableCurrentValue(schemaName) {
        var query =
            "?$select=defaultvalue" +
            "&$filter=schemaname eq '" + schemaName + "'" +
            "&$expand=environmentvariabledefinition_environmentvariablevalue($select=value)";

        return parent.Xrm.WebApi.retrieveMultipleRecords(
            "environmentvariabledefinition",
            query
        ).then(function (result) {
            if (!result || !result.entities || result.entities.length < 1) {
                return null;
            }
            var definition = result.entities[0];
            return definition.environmentvariabledefinition_environmentvariablevalue &&
                definition.environmentvariabledefinition_environmentvariablevalue.length
                ? definition.environmentvariabledefinition_environmentvariablevalue[0].value
                : definition.defaultvalue;
        });
    }

    function getPolicyConfigFromEnvironment() {
        return Promise.all([
            getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.tenantId),
            getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.clientId),
            getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.apiAppId),
            getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.apiKey),
            getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.boomiUrl)
        ]).then(function (values) {
            var missing = [];
            if (!values[0]) { missing.push(POLICY_ENV_VARS.tenantId); }
            if (!values[1]) { missing.push(POLICY_ENV_VARS.clientId); }
            if (!values[2]) { missing.push(POLICY_ENV_VARS.apiAppId); }
            if (!values[3]) { missing.push(POLICY_ENV_VARS.apiKey); }
            if (!values[4]) { missing.push(POLICY_ENV_VARS.boomiUrl); }
            if (missing.length > 0) {
                throw new Error("Missing Policy configuration: " + missing.join(", "));
            }
            return {
                tenantId: values[0],
                clientId: values[1],
                apiAppId: values[2],
                apiKey: values[3],
                boomiUrl: values[4],
                scope: POLICY_STATIC_CONFIG.scope,
                httpMethod: POLICY_STATIC_CONFIG.httpMethod,
                redirectWebResource: POLICY_STATIC_CONFIG.redirectWebResource,
                msalWebResourcePath: POLICY_STATIC_CONFIG.msalWebResourcePath,
                allowRedirect: POLICY_STATIC_CONFIG.allowRedirect,
                debug: POLICY_STATIC_CONFIG.debug
            };
        });
    }

    function getUserId() {
        var userId = parent.Xrm.Utility.getGlobalContext().userSettings.userId;
        if (userId) {
            userId = userId.replace(/[{}]/g, "");
        }
        return userId;
    }

    function showLoader() {
        const el = document.getElementById("loader");
        if (el) el.style.display = "flex";
    }

    function hideLoader() {
        const el = document.getElementById("loader");
        if (el) el.style.display = "none";
    }

    function setLoadingMessage(message) {
        const el = document.getElementById("loadingText");
        if (el) el.innerText = message || "Loading data...";
    }

    function showError(message) {
        const banner = document.getElementById("errorBanner");
        const msg = document.getElementById("errorMessage");

        if (msg) {
            msg.innerText = message || "Failed to load policy data.";
        }

        if (banner) {
            banner.style.display = "flex";
        }
    }

    function hideError() {
        const banner = document.getElementById("errorBanner");
        if (banner) {
            banner.style.display = "none";
        }
    }

    function setPrintEnabled(enabled) {

        const btn = document.getElementById("printBtn");

        if (btn) {
            btn.disabled = !enabled;
        }
    }

    function updatePrintHeader() {

        const policyEl =
            document.getElementById("printPolicyNumber");

        const dateEl =
            document.getElementById("printGeneratedOn");

        const policyInput =
            document.getElementById("policyNumber");

        if (policyEl) {
            policyEl.innerText =
                (policyInput && policyInput.value) ||
                "";
        }

        if (dateEl) {
            dateEl.innerText =
                new Date().toLocaleString();
        }
    }

    function printReport() {

        updatePrintHeader();
        window.print();
    }

    function retry() {
        hideError();
        init();
    }

    function getContext() {
        let recordId = null;
        let entityName = "kofc_policy";

        try {
            const topParams = new URLSearchParams(window.top.location.search);

            recordId =
                topParams.get("id") ||
                topParams.get("data");

            entityName =
                topParams.get("etn") ||
                entityName;

            if (!recordId && parent?.Xrm) {
                const q = parent.Xrm.Utility
                    .getGlobalContext()
                    .getQueryStringParameters();

                recordId = q.id || q.data;
                entityName = q.etn || entityName;
            }

        } catch (e) {
            console.error("Context Error:", e);
        }

        if (recordId) {
            recordId = recordId.replace(/[{}]/g, "");
        }

        return { recordId, entityName };
    }

    async function getPolicyRecord(entityName, recordId) {

        try {

            const query =
                "?$select=" +
                [
                    "kofc_policynumber",
                    "kofc_policyclassification",
                    "kofc_sourcename",
                    "kofc_issuecountry"
                ].join(",");

            const record =
                await parent.Xrm.WebApi.retrieveRecord(
                    entityName,
                    recordId,
                    query
                );

            console.log("Policy Record:", record);

            return record;

        } catch (e) {

            console.error("Retrieve Record Error:", e);

            return null;
        }
    }

    async function validateRecord(record) {

        const missingFields = [];

        const policyNumber =
            record?.kofc_policynumber;

        const sourceSystem =
            record?.kofc_sourcename;

        const issueCountry =
            record["kofc_issuecountry@OData.Community.Display.V1.FormattedValue"];

        const policyClassification =
            record["kofc_policyclassification@OData.Community.Display.V1.FormattedValue"];

        const allowedValues = [
            "Ingenium",
            "DI",
            "LTC",
            "L70",
            "Life 70"
        ];

        if (!policyNumber) {
            missingFields.push("Policy Number");
        }

        if (!issueCountry) {
            missingFields.push("Issue Country");
        }

        if (!policyClassification) {
            missingFields.push("Policy Classification");
        }

        if (
            !sourceSystem ||
            !allowedValues.includes(sourceSystem)
        ) {
            missingFields.push("Source Name");
        }

        if (missingFields.length > 0) {

            await parent.Xrm.Navigation.openAlertDialog({
                title: "Validation Error",
                text:
                    "Below fields are either empty or invalid.\n\n" +
                    missingFields.join("\n")
            });

            return false;
        }

        return true;
    }

    function mapSource(sourceName) {

        switch ((sourceName || "").trim()) {

            case "Ingenium":
            case "ING":
                return "ING";

            case "Life 70":
            case "L70":
                return "L70";

            case "LTC":
                return "LTC";

            case "DI":
                return "DI";

            default:
                return "ING";
        }
    }

    function mapCompanyCode(issueCountry) {

        const country =
            String(issueCountry || "")
                .trim()
                .toUpperCase();

        switch (country) {

            case "US":
            case "USA":
            case "UNITED STATES":
            case "258510000":
                return "01";

            case "CANADA":
            case "258510001":
                return "50";

            default:
                return "01";
        }
    }

    function mapClassification(policyClassification) {

        if (!policyClassification) {
            return "";
        }

        return policyClassification
            .toString()
            .trim();
    }

    function mapSourceForApi(sourceName, policyClassification) {
        var classification = mapClassification(policyClassification);

        if (classification === "LTC") {
            return "ltc";
        }

        if (classification === "DI") {
            return "di";
        }

        var source = mapSource(sourceName);

        switch (source) {
            case "ING":
                return "ing";
            case "L70":
                return "l70";
            case "LTC":
                return "ltc";
            case "DI":
                return "di";
            default:
                return "ing";
        }
    }


    function toggleRow(row, visible) {

        if (!row) {
            return;
        }

        if (visible) {
            row.classList.remove("hidden");
        } else {
            row.classList.add("hidden");
        }
    }

    function toggleSection(sectionId, visible) {

        const el = document.getElementById(sectionId);

        if (!el) {
            return;
        }

        if (visible) {
            el.classList.remove("hidden");
        } else {
            el.classList.add("hidden");
        }
    }

    function getViewProfile(sourceName, policyClassification) {

        const source = mapSource(sourceName);
        const classification = mapClassification(policyClassification);

        if (classification === "LTC") {
            return "ltc";
        }

        if (classification === "DI") {
            return "di";
        }

        if (classification === "Annuity" && source === "L70") {
            return "annuityL70";
        }

        if (classification === "Annuity") {
            return "annuityIng";
        }

        if (classification === "Life" && source === "L70") {
            return "lifeL70";
        }

        if (classification === "Life") {
            return "lifeIng";
        }

        return "lifeIng";
    }

    // -------------------------------------------------------------------------
    // Field visibility — edit PROFILE_VISIBILITY to hide/show fields per profile.
    // -------------------------------------------------------------------------

    const LIFE_ANNUITY_PROFILES = {
        lifeIng: true,
        lifeL70: true,
        annuityIng: true,
        annuityL70: true
    };

    const LIFE_ANNUITY_FIELD_IDS = [
        "nonForfeitureOption",
        "miscPremiumOnDeposit",
        "miscPremiumOnDepositInterestRate",
        "discountedPremiumsOnDeposit",
        "discountedPremiumsYearsLeft",
        "puaEligibility",
        "puaLifetimeDepositAmount",
        "puaLifeToDateDepositAmount",
        "puaYearToDatePremiumPaid",
        "puaPriorYearPremiumPaid",
        "adpuaPriorYearFaceAmount",
        "adpuaCurrentYearFaceAmount",
        "adpuaAnnualIncreaseAmount",
        "apbCurrentDeathBenefitAmount",
        "lprIndicator",
        "sevenPayStartDate",
        "sevenPayAnnualPremium",
        "sevenPayPremiumPaid",
        "cvaoLastMatChange",
        "exchange1035Amount",
        "dbPurchaseByPua",
        "adpuaDb",
        "sdpuaDb",
        "madpuaDb",
        "apbPuaDb",
        "sliPuaDb",
        "additionalAmountAvailableForIncreaseOrConversion",
        "amountAvailableForConversion",
        "annuityPayoutAmountForTheYear",
        "annuityWithdrawalsForTheYear",
        "annuityCost",
        "annualIncome",
        "swoEligibilityIndicator",
        "combinedIndicator",
        "percentageIndicator",
        "iopoIndicator",
        "paymentCeaseDate",
        "premiumLoanIndicator",
        "loanPrincipleAtAnniversary",
        "puaCashValueFromDividend",
        "cwaAmount"
    ];

    const DI_FIELD_IDS = [
        "socialInsuranceIndicator",
        "catastrophicDisabilityRiderIndicator",
        "clientFraternalStatusCode",
        "colaIndicator",
        "diPolicyClientEligibilityCode",
        "diCvgFctId",
        "diFctId",
        "gpoDeclined1stDate",
        "gpoDeclined2ndDate",
        "gpoOptionRemainingQuantity",
        "gpoOptionUsedQuantity",
        "maxMonthlyBenefitAmount",
        "monthlyPremiumAmount",
        "nextGpoOptionDate",
        "nextRenewalDate",
        "policyCeaseDate",
        "cwaAmount",
        "policyCwaAmount",
        "policyGrossAnnualPremiumAmount",
        "policyPriorAnniversaryDate",
        "policyQuarterlyPremiumAmount",
        "policyRiskEffectiveDate",
        "policySemiAnnualPremiumAmount",
        "policyStatusReason"
    ];

    const LTC_FIELD_IDS = [
        "planVar",
        "policyIndicator",
        "registerDate",
        "statusDate",
        "inflationOption",
        "taxType",
        "baseInflationModalPremiumAmount",
        "baseModalPremiumAmount",
        "baseNonForfeitureModalPremiumAmount",
        "baseRopModalPremiumAmount",
        "baseSdModalPremiumAmount",
        "dailyBenefitAmount",
        "gpoBaseModelPremiumAmount",
        "gpoCriticalInd",
        "gpoEligibilityIndicator",
        "gpoNonForfeitureModelPremium",
        "gpoNumber",
        "gpoOption2Date",
        "gpoOptionDate",
        "gpoRopModelPremiumAmount",
        "gpoSdModelPremiumAmount",
        "hcCurrentDailyBenefit",
        "hcCurrentDailyUnlimited",
        "hcEliminationPeriodDays",
        "hcMaxLifetimeBenefit",
        "hcMaxLifetimeUnlimited",
        "hcMaxMonthlyBenefit",
        "hcMaxMonthlyUnlimited",
        "inflationPercentage",
        "longTermCareUnderwritingRiskClass",
        "ltcDurationNumber",
        "ltcPremIncmAmt",
        "replacementIndicator",
        "suitableIndicator",
        "modifiedDecisionIndicator",
        "nfoIndicator",
        "nfoPercentage",
        "nhCurrentDailyBenefit",
        "nhCurrentDailyUnlimited",
        "nhEliminationPeriodDays",
        "nhMaxLifetimeBenefit",
        "nhMaxLifetimeUnlimited",
        "nhMaxMonthlyBenefit",
        "nhMaxMonthlyUnlimited",
        "originalDailyBenefitAmount",
        "sharedCareInd",
        "spouseDiscountIndicator",
        "spouseDiscountPercentage",
        "totalBaseModalPremiumAmount",
        "totalGpoModalPremiumAmount",
        "valuesCwa",
        "premiumPaymentQuantity",
        "priorOneYearGpoAnnualizedPremium",
        "priorOneYearGpoNumber",
        "priorTwoYearsGpoNumber",
        "priorTwoYearsGpoAnnualizedPremium",
        "longTermCarePolicyId",
        "eliminationPeriod",
        "benefitLengthYears"
    ];

    const APPLICATION_TIMELINE_FIELD_IDS = [
        "lastAnniversaryDate",
        "applicationReceivedDate",
        "applicationSignDate",
        "applicationApproveDate",
        "policyMailDate"
    ];

    const PROFILE_VISIBILITY = {
        lifeIng: {
            hideApplicationTimeline: false,
            ltcOnlyCwa: false,
            hiddenFields: [
                "accountName", "accountNumber", "anniversaryDate", "annualIncome",
                "annuityCost", "annuityPayoutAmountForTheYear", "annuityWithdrawalsForTheYear",
                "applicationApproveDate", "combinedIndicator", "currentDividend", "cwaAmount",
                "dbPurchaseByPua", "guaranteedInterestRate", "iopoIndicator", "issueClass",
                "lastAnniversaryTier1Date", "occpClasCd", "onlineDate", "percentageIndicator",
                "policyMailDate", "puaCashValueFromDividend", "swoEligibilityIndicator","occClass", "occpClasCd"
            ]
        },
        annuityIng: {
            hideApplicationTimeline: false,
            ltcOnlyCwa: false,
            hiddenFields: [
                "accountName", "accountNumber", "additionalAmountAvailableForIncreaseOrConversion",
                "adpuaAnnualIncreaseAmount", "adpuaCurrentYearFaceAmount", "adpuaDb",
                "adpuaPriorYearFaceAmount", "amountAvailableForConversion", "anniversaryDate",
                "apbCurrentDeathBenefitAmount", "apbPuaDb", "applicationApproveDate",
                "currentDividend", "cvaoLastMatChange", "cwaAmount", "combinedIndicator","dbPurchaseByPua",
                "discountedPremiumsOnDeposit", "discountedPremiumsYearsLeft", "exchange1035Amount",
                "guaranteedInterestRate", "inforceCode", "issueClass", "iopoIndicator","lastAnniversaryTier1Date",
                "lprIndicator", "madpuaDb", "miscPremiumOnDeposit", "miscPremiumOnDepositInterestRate",
                "nonForfeitureOption", "occClass", "occpClasCd", "onlineDate", "policyMailDate",
                "puaCashValueFromDividend", "puaEligibility", "puaLifeToDateDepositAmount",
                "puaLifetimeDepositAmount", "puaPriorYearPremiumPaid", "puaYearToDatePremiumPaid","percentageIndicator",
                "sdpuaDb", "sevenPayAnnualPremium", "sevenPayPremiumPaid", "sevenPayStartDate","swoEligibilityIndicator",
                "sliPuaDb", "lastAnniversaryDate", "premiumLoanIndicator", "loanPrincipleAtAnniversary"
            ]
        },
        lifeL70: {
            hideApplicationTimeline: false,
            ltcOnlyCwa: false,
            hiddenFields: [
                "accountName", "accountNumber", "additionalAmountAvailableForIncreaseOrConversion",
                "adpuaAnnualIncreaseAmount", "adpuaCurrentYearFaceAmount", "adpuaDb",
                "adpuaPriorYearFaceAmount", "amountAvailableForConversion", "anniversaryDate",
                "annualIncome", "annuityCost", "annuityPayoutAmountForTheYear",
                "annuityWithdrawalsForTheYear", "apbCurrentDeathBenefitAmount", "apbPuaDb",
                "applicationApproveDate", "applicationReceivedDate", "applicationSignDate",
                "combinedIndicator", "currentDividend", "cvaoLastMatChange", "cwaAmount",
                "dbPurchaseByPua", "discountedPremiumsOnDeposit", "discountedPremiumsYearsLeft",
                "exchange1035Amount", "guaranteedInterestRate", "iopoIndicator", "issueClass",
                "lastAnniversaryTier1Date", "lprIndicator", "madpuaDb", "miscPremiumOnDeposit",
                "miscPremiumOnDepositInterestRate", "occClass", "occpClasCd", "onlineDate",
                "percentageIndicator", "policyMailDate", "puaEligibility", "puaLifeToDateDepositAmount",
                "puaLifetimeDepositAmount", "puaPriorYearPremiumPaid", "puaYearToDatePremiumPaid",
                "sdpuaDb", "sevenPayAnnualPremium", "sliPuaDb", "swoEligibilityIndicator","puaCashValueFromDividend"
            ]
        },
        annuityL70: {
            hideApplicationTimeline: true,
            ltcOnlyCwa: false,
            hiddenFields: [
                "accountName", "accountNumber", "additionalAmountAvailableForIncreaseOrConversion",
                "adpuaAnnualIncreaseAmount", "adpuaCurrentYearFaceAmount", "adpuaDb",
                "adpuaPriorYearFaceAmount", "amountAvailableForConversion", "anniversaryDate",
                "apbCurrentDeathBenefitAmount", "apbPuaDb", "currentDividend", "cvaoLastMatChange",
                "cwaAmount", "dbPurchaseByPua", "discountedPremiumsOnDeposit",
                "discountedPremiumsYearsLeft", "exchange1035Amount", "guaranteedInterestRate",
                "inforceCode", "issueClass", "lastAnniversaryTier1Date", "lprIndicator", "madpuaDb",
                "miscPremiumOnDeposit", "miscPremiumOnDepositInterestRate", "nonForfeitureOption",
                "occClass", "occpClasCd", "onlineDate", "puaCashValueFromDividend", "puaEligibility",
                "puaLifeToDateDepositAmount", "puaLifetimeDepositAmount", "puaPriorYearPremiumPaid",
                "puaYearToDatePremiumPaid", "sdpuaDb", "sevenPayAnnualPremium", "sevenPayPremiumPaid",
                "sevenPayStartDate", "sliPuaDb", "occClass", "occpClasCd","lastAnniversaryDate", "premiumLoanIndicator", 
                "loanPrincipleAtAnniversary"
            ]
        },
        ltc: {
            hideApplicationTimeline: false,
            ltcOnlyCwa: true,
            hiddenFields: [
                "accountName", "accountNumber", "adminSystem", "anniversaryDate", "currentDividend",
                "guaranteedInterestRate", "illustrationSystem", "inforceCode", "issueClass",
                "lastAnniversaryDate", "lastAnniversaryTier1Date", "ltcDurationNumber",
        "ltcPremIncmAmt","occClass", "occpClasCd", "onlineDate", "premiumLoanIndicator", "loanPrincipleAtAnniversary","longTermCarePolicyId","planVar",
        "deathBenefit", "puaCashValue", "divDeathBenefit", "reducedPaidUpFaceAmount", "anniversaryDate", "anniversaryCashValue", "lastAnniversaryTier1Date", "valuesAsOfLastAnniversary", 
        "increaseInCashValue", "loanPayoffAmount", "maxLoanAmountAvailable", "loanInterest", "loanPrinciple", "cashLoanInterestRate", "cashSurrenderValue", 
        "surrenderCharge", "dividendValue", "annuitySurrenderValue", "totalInforcePuaDeathBenefitFaceAmount", "netForYear", "annuityAccumulativeValue", 
        "puaCashValueFromDiv", "dbPurchaseByPuaTier1", "onlineDate", "guaranteedInterestRate", "currentDividend"
        
            ]
        },
        di: {
            hideApplicationTimeline: false,
            ltcOnlyCwa: false,
            hiddenFields: [
                "accountName", "accountNumber", "adminSystem","applicationApproveDate","currentDividend","diCvgFctId","diFctId","guaranteedInterestRate","illustrationSystem", "inforceCode",
                "issueClass",  "occClass", "occpClasCd", "onlineDate","premiumLoanIndicator", "loanPrincipleAtAnniversary",
                "deathBenefit", "puaCashValue", "divDeathBenefit", "reducedPaidUpFaceAmount", "anniversaryDate", "anniversaryCashValue", "lastAnniversaryTier1Date", "valuesAsOfLastAnniversary", 
                "increaseInCashValue", "loanPayoffAmount", "maxLoanAmountAvailable", "loanInterest", "loanPrinciple", "cashLoanInterestRate", "cashSurrenderValue", "surrenderCharge", "dividendValue", 
                "annuitySurrenderValue", "totalInforcePuaDeathBenefitFaceAmount", "netForYear", "annuityAccumulativeValue", "puaCashValueFromDiv", "dbPurchaseByPuaTier1", "onlineDate", "guaranteedInterestRate", "currentDividend"
            ]
        }
    };

    const FIELD_GROUP_LOOKUP = (function () {

        const lookup = {};

        function register(ids, groupName) {
            ids.forEach(function (fieldId) {
                lookup[fieldId] = groupName;
            });
        }

        register(LIFE_ANNUITY_FIELD_IDS, "lifeAnnuity");
        register(DI_FIELD_IDS, "di");
        register(LTC_FIELD_IDS, "ltc");

        return lookup;
    })();

    function getProfileRules(profile) {
        return PROFILE_VISIBILITY[profile] || {
            hideApplicationTimeline: false,
            ltcOnlyCwa: false,
            hiddenFields: []
        };
    }

    function isFieldHiddenForProfile(fieldId, profile) {
        const rules = getProfileRules(profile);
        return rules.hiddenFields.indexOf(fieldId) > -1;
    }

    function isFieldVisible(fieldId, profile) {

        const rules = getProfileRules(profile);
        const group = FIELD_GROUP_LOOKUP[fieldId];

        if (group === "di") {
            if (profile !== "di") {
                return false;
            }
        } else if (group === "ltc") {
            if (profile !== "ltc") {
                return false;
            }
        } else if (group === "lifeAnnuity") {
            if (profile === "ltc") {
                return rules.ltcOnlyCwa && fieldId === "cwaAmount";
            }

            if (profile === "di" || !LIFE_ANNUITY_PROFILES[profile]) {
                return false;
            }
        }

        if (
            rules.hideApplicationTimeline &&
            APPLICATION_TIMELINE_FIELD_IDS.indexOf(fieldId) > -1
        ) {
            return false;
        }

        return !isFieldHiddenForProfile(fieldId, profile);
    }

    function applyFieldVisibility(profile) {

        document
            .querySelectorAll("#reportContent .row")
            .forEach(function (row) {

                const input = row.querySelector(".d365-input");

                if (!input || !input.id) {
                    return;
                }

                toggleRow(row, isFieldVisible(input.id, profile));
            });
    }

    function sectionHasVisibleRows(sectionId) {

        const section = document.getElementById(sectionId);

        if (!section) {
            return false;
        }

        return !!section.querySelector(".row:not(.hidden)");
    }

    function updateSectionVisibility(profile) {

        const rules = getProfileRules(profile);

        toggleSection(
            "policyInfoSection",
            sectionHasVisibleRows("policyInfoSection")
        );

        toggleSection(
            "applicationTimelineSection",
            !rules.hideApplicationTimeline &&
            sectionHasVisibleRows("applicationTimelineSection")
        );

        toggleSection(
            "tier1Section",
            sectionHasVisibleRows("tier1Section")
        );

        toggleSection(
            "lifeSection",
            sectionHasVisibleRows("lifeSection")
        );
    }

    function applyViewVisibility(sourceName, policyClassification) {

        const profile = getViewProfile(
            sourceName,
            policyClassification
        );

        console.log("View profile:", profile);

        applyFieldVisibility(profile);
        updateSectionVisibility(profile);
    }


    async function fetchPolicyData(
        policyNo,
        sourceName,
        issueCountry,
        policyClassification,
        policyRecordId
    ) {
        var companyCode = mapCompanyCode(issueCountry);
        var classificationCode = mapClassification(policyClassification);
        var source = mapSourceForApi(sourceName, policyClassification);
        var userId = getUserId();

        await loadAuthClient();
        await loadPolicyClient();

        var config = await getPolicyConfigFromEnvironment();
        KOFC.Policy.configure(config);

        var result = await KOFC.Policy.getPolicyData({
            source: source,
            companyCode: companyCode,
            policyNo: String(policyNo),
            classificationCode: classificationCode,
            userId: userId,
            policyRecordId: policyRecordId
        });

        if (result && result.redirecting) {
            return { redirecting: true };
        }

        if (!result.ok) {
            var errMsg = (result.data && result.data.ERROR) ? result.data.ERROR : result.raw;
            throw new Error("Policy lookup failed (" + result.status + "): " + errMsg);
        }

        return result.data;
    }

    function setValue(id, value) {

        const el =
            document.getElementById(id);

        if (el) {
            el.value = value ?? "";
        }
    }

    function formatCurrency(value) {

        if (
            value === null ||
            value === undefined ||
            value === ""
        ) {
            return "";
        }

        const num = Number(value);

        if (isNaN(num)) {
            return value;
        }

        return "$" +
            num.toLocaleString(
                undefined,
                {
                    minimumFractionDigits: 0,
                    maximumFractionDigits: 2
                }
            );
    }

    function bind(data) {

        const nh = data?.NonHeader || {};
        const t = data?.TIERONE || {};

        setValue("policyNumber", nh.PolicyNumber);
        setValue("issueCountry", nh.IssueCountry);
        setValue("insuranceSubType", nh.InsuranceSubType);
        setValue("illustrationSystem", nh.IllustrationSystem);
        setValue("adminSystem", nh.AdminSystem);
        setValue("inforceCode", nh.InforceCode);
        setValue("occClass", nh.OccClass);
        setValue("issueClass", nh.IssueClass);
        setValue("occpClasCd", nh.OccpClasCd);
        setValue("accountName", nh.AccountName);
        setValue("accountNumber", nh.AccountNumber);

        setValue("lastAnniversaryDate", nh.LastAnniversaryDate);
        setValue("applicationReceivedDate", nh.ApplicationReceivedDate);
        setValue("applicationSignDate", nh.ApplicationSignDate);
        setValue("applicationApproveDate", nh.ApplicationApproveDate);
        setValue("policyMailDate", nh.PolicyMailDate);

        setValue("nonForfeitureOption", nh.NonForfeitureOption);
        setValue("miscPremiumOnDeposit", nh.MiscPremiumOnDeposit);
        setValue("miscPremiumOnDepositInterestRate", nh.MiscPremiumOnDepositInterestRate);
        setValue("discountedPremiumsOnDeposit", nh.DiscountedPremiumsOnDeposit);
        setValue("discountedPremiumsYearsLeft", nh.DiscountedPremiumsYearsLeft);
        setValue("puaEligibility", nh.PuaEligiblity);
        setValue("puaLifetimeDepositAmount", nh.PuaLifetimeDepositAmount);
        setValue("puaLifeToDateDepositAmount", nh.PuaLifeToDateDepositAmount);
        setValue("puaYearToDatePremiumPaid", nh.PuaYearToDatePremiumPaid);
        setValue("puaPriorYearPremiumPaid", nh.PuaPriorYearPremiumPaid);
        setValue("adpuaPriorYearFaceAmount", nh.AdpuaPriorYearFaceAmount);
        setValue("adpuaCurrentYearFaceAmount", nh.AdpuaCurrentYearFaceAmount);
        setValue("adpuaAnnualIncreaseAmount", nh.AdpuaAnnualIncreaseAmount);
        setValue("apbCurrentDeathBenefitAmount", nh.ApbCurrentDeathBenefitAmount);
        setValue("lprIndicator", nh.LprIndicator);
        setValue("sevenPayStartDate", nh.Policy7PayStartDate);
        setValue("sevenPayAnnualPremium", nh.Policy7PayAnnualPremium);
        setValue("sevenPayPremiumPaid", nh.Policy7PayPremiumPaid);
        setValue("cvaoLastMatChange", nh.CvoaLastMatChange);
        setValue("exchange1035Amount", nh.Policy1035ExchangeAmount);
        setValue("dbPurchaseByPua", nh.DbPurchaseByPua);
        setValue("adpuaDb", nh.AdppuaDb);
        setValue("sdpuaDb", nh.SdppuaDb);
        setValue("madpuaDb", nh.MadpuaDb);
        setValue("apbPuaDb", nh.ApbpuaDb);
        setValue("sliPuaDb", nh.SlipuaDb);
        setValue("additionalAmountAvailableForIncreaseOrConversion", nh.AddtlAmtIncrOrConv);
        setValue("amountAvailableForConversion", nh.AmountAvailConv);
        setValue("annuityPayoutAmountForTheYear", nh.AnnuityPayoutAmountYtd);
        setValue("annuityWithdrawalsForTheYear", nh.AnnuityWithdrawalsYtd);
        setValue("annuityCost", nh.AnnuityCost);
        setValue("annualIncome", nh.AnnualIncome);
        setValue("swoEligibilityIndicator", nh.SowEligibilityIndicator);
        setValue("combinedIndicator", nh.CombinedIndicator);
        setValue("percentageIndicator", nh.PercentageIndicator);
        setValue("iopoIndicator", nh.IopoIndicator);
        setValue("paymentCeaseDate", nh.PaymentCeaseDate);
        setValue("premiumLoanIndicator", nh.PremiumLoanIndicator);
        setValue("loanPrincipleAtAnniversary", nh.LoanPrincipalAtAnniversary);
        setValue("puaCashValueFromDividend", nh.PuaCashValueFromDividend);
        setValue("cwaAmount", nh.CwaAmount);

        setValue("socialInsuranceIndicator", nh.SocialInsuranceIndicator);
        setValue("catastrophicDisabilityRiderIndicator", nh.CatastrophicDisabilityRiderIndicator);
        setValue("clientFraternalStatusCode", nh.ClientFraternalStatusCode);
        setValue("colaIndicator", nh.ColaIndicator);
        setValue("diPolicyClientEligibilityCode", nh.DiPolicyClientEligibilityCode);
        setValue("diCvgFctId", nh.DiCvgFctId);
        setValue("diFctId", nh.DiFctId);
        setValue("gpoDeclined1stDate", nh.GpoDeclined1stDate);
        setValue("gpoDeclined2ndDate", nh.GpoDeclined2ndDate);
        setValue("gpoOptionRemainingQuantity", nh.GpoOptionRemainingQuantity);
        setValue("gpoOptionUsedQuantity", nh.GpoOptionUsedQuantity);
        setValue("maxMonthlyBenefitAmount", nh.MaxMonthlyBenefitAmt);
        setValue("monthlyPremiumAmount", nh.MonthlyPremiumAmount);
        setValue("nextGpoOptionDate", nh.NextGpoOptionDate);
        setValue("nextRenewalDate", nh.NextRenewalDate);
        setValue("policyCeaseDate", nh.PolicyCeaseDate);
        setValue("policyCwaAmount", nh.PolicyCwaAmount);
        setValue("policyGrossAnnualPremiumAmount", nh.PolicyGrossAnnualPremiumAmount);
        setValue("policyPriorAnniversaryDate", nh.PolicyPriorAnniversaryDate);
        setValue("policyQuarterlyPremiumAmount", nh.PolicyQuarterlyPremiumAmount);
        setValue("policyRiskEffectiveDate", nh.PolicyRiskEffectiveDate);
        setValue("policySemiAnnualPremiumAmount", nh.PolicySemiAnnualPremiumAmount);
        setValue("policyStatusReason", nh.PolicyStatusReason);

        setValue("planVar", nh.PlanVar);
        setValue("policyIndicator", nh.PolicyIndicator);
        setValue("registerDate", nh.RegisterDate);
        setValue("statusDate", nh.StatusDate);
        setValue("baseInflationModalPremiumAmount", nh.BaseInflationModalPremiumAmount);
        setValue("baseModalPremiumAmount", nh.BaseModalPremiumAmount);
        setValue("baseNonForfeitureModalPremiumAmount", nh.BaseNonForfeitureModalPremiumAmount);
        setValue("baseRopModalPremiumAmount", nh.BaseRpoModalPremiumAmount);
        setValue("baseSdModalPremiumAmount", nh.BaseSdModalPremiumAmount);
        setValue("dailyBenefitAmount", nh.DailyBenefitAmount);
        setValue("gpoBaseModelPremiumAmount", nh.GpoBaseModelPremiumAmount);
        setValue("gpoCriticalInd", nh.GpoCriticalInd);
        setValue("gpoEligibilityIndicator", nh.GpoEligibilityIndicator);
        setValue("gpoNonForfeitureModelPremium", nh.GpoNonForfeitureModelPremium);
        setValue("gpoNumber", nh.GpoNumber);
        setValue("gpoOption2Date", nh.GpoOption2Date);
        setValue("gpoOptionDate", nh.GpoOptionDate);
        setValue("gpoRopModelPremiumAmount", nh.GpoRopModelPremiumAmount);
        setValue("gpoSdModelPremiumAmount", nh.GpoSdModelPremiumAmount);
        setValue("hcCurrentDailyBenefit", nh.HcCurrentDailyBenefit);
        setValue("hcCurrentDailyUnlimited", nh.HcCurrentDailyUnlimited);
        setValue("hcEliminationPeriodDays", nh.HcEliminationPeriodDays);
        setValue("hcMaxLifetimeBenefit", nh.HcMaxLifetimeBenefit);
        setValue("hcMaxLifetimeUnlimited", nh.HcMaxLifetimeUnlimited);
        setValue("hcMaxMonthlyBenefit", nh.HcMaxMonthlyBenefit);
        setValue("hcMaxMonthlyUnlimited", nh.HcMaxMonthlyUnlimited);
        setValue("inflationOption", nh.InflationOption);
        setValue("inflationPercentage", nh.InflationPercentage);
        setValue("longTermCareUnderwritingRiskClass", nh.LongTermCareUnderwritingRiskClass);
        setValue("ltcDurationNumber", nh.LtcDurationNumber);
        setValue("ltcPremIncmAmt", nh.LtcPremIncmAmt);
        setValue("replacementIndicator", nh.ReplacementIndicator);
        setValue("suitableIndicator", nh.SuitableIndicator);
        setValue("modifiedDecisionIndicator", nh.ModifiedDecisionInd);
        setValue("nfoIndicator", nh.NfoIndicator);
        setValue("nfoPercentage", nh.NfoPercentage);
        setValue("nhCurrentDailyBenefit", nh.NhCurrentDailyBenefit);
        setValue("nhCurrentDailyUnlimited", nh.NhCurrentDailyUnlimited);
        setValue("nhEliminationPeriodDays", nh.NhEliminationPeriodDays);
        setValue("nhMaxLifetimeBenefit", nh.NhMaxLifetimeBenefit);
        setValue("nhMaxLifetimeUnlimited", nh.NhMaxLifetimeUnlimited);
        setValue("nhMaxMonthlyBenefit", nh.NhMaxMonthlyBenefit);
        setValue("nhMaxMonthlyUnlimited", nh.NhMaxMonthlyUnlimited);
        setValue("originalDailyBenefitAmount", nh.OriginalDailyBenefitAmount);
        setValue("sharedCareInd", nh.SharedCareInd);
        setValue("spouseDiscountIndicator", nh.SpouseDiscountIndicator);
        setValue("spouseDiscountPercentage", nh.SpouseDiscountPercentage);
        setValue("totalBaseModalPremiumAmount", nh.TotalBaseModalPremiumAmount);
        setValue("totalGpoModalPremiumAmount", nh.TotalGpoModalPremiumAmount);
        setValue("valuesCwa", nh.ValuesCwa);
        setValue("premiumPaymentQuantity", nh.PremiumPaymentQuantity);
        setValue("priorOneYearGpoAnnualizedPremium", nh.PriorOneYearGpoAnnualizedPremium);
        setValue("priorOneYearGpoNumber", nh.PriorOneYearGpoNumber);
        setValue("priorTwoYearsGpoNumber", nh.PriorTwoYearsGpoNumber);
        setValue("priorTwoYearsGpoAnnualizedPremium", nh.PriorTwoYearsGpoAnnualizedPremium);
        setValue("longTermCarePolicyId", nh.LongTermCarePolicyId);
        setValue("eliminationPeriod", nh.EliminationPeriod);
        setValue("benefitLengthYears", nh.BenefitLengthYears);
        setValue("taxType", nh.TaxType);

        setValue("deathBenefit", formatCurrency(t.DEATH_BENEFIT));
        setValue("puaCashValue", formatCurrency(t.PUA_CASH_VALUE));
        setValue("divDeathBenefit", t.DIV_DEATH_BENEFIT);
        setValue("reducedPaidUpFaceAmount", t.REDUCED_PAIDUP_FACE_AMOUNT);
        setValue("anniversaryDate", t.ANNIVERSARY_DATE);
        setValue("anniversaryCashValue", formatCurrency(t.ANNIVERSARY_CASH_VALUE));
        setValue("lastAnniversaryTier1Date", t.LAST_ANNIVERSARY_DATE);
        setValue("valuesAsOfLastAnniversary", formatCurrency(t.VALUE_AS_OF_LAST_ANNIVERSARY));
        setValue("increaseInCashValue", formatCurrency(t.INCREASE_IN_CASH_VALUE));
        setValue("loanPayoffAmount", formatCurrency(t.LOAN_PAYOFF_AMOUNT));
        setValue("maxLoanAmountAvailable", formatCurrency(t.MAX_LOAN_AMOUNT_AVAILABLE));
        setValue("loanInterest", formatCurrency(t.LOAN_INTEREST));
        setValue("loanPrinciple", formatCurrency(t.LOAN_PRINCIPLE));
        setValue("cashSurrenderValue", formatCurrency(t.CASH_SURRENDER_VALUE));
        setValue("surrenderCharge", t.SURRENDER_CHARGE);
        setValue("dividendValue", t.DIVIDENT_VALUE);
        setValue("annuitySurrenderValue", t.ANNUITY_SURRENDER_VALUE);
        setValue("totalInforcePuaDeathBenefitFaceAmount", formatCurrency(t.TOTAL_INFORCE_PUA_DEATH_BENEFIT_FACE_AMOUNT));
        setValue("netForYear", formatCurrency(t.NET_CHANGE_FOR_THE_YEAR_EQUALS));
        setValue("annuityAccumulativeValue", t.ANNUITY_ACCUMULATIVE_VALUE);
        setValue("puaCashValueFromDiv", formatCurrency(t.PUA_CASH_VALUE_FROM_DIV));
        setValue("dbPurchaseByPuaTier1", formatCurrency(t.DB_PURCHASE_BY_PUA));
        setValue("cashLoanInterestRate", t.CASH_LOAN_INTEREST_RATE);
        setValue("onlineDate", t.ONLINE_DATE);
        setValue("guaranteedInterestRate", t.GUARANTEED_INTEREST_RATE);
        setValue("currentDividend", t.CURRENT_DIVIDEND);
    }

    async function init() {
        try {
            hideError();
            setPrintEnabled(false);
            showLoader();
            setLoadingMessage("Loading policy context...");

            var ctx = getContext();
            console.log("Context:", ctx);

            if (!ctx.recordId) {
                throw new Error("Record Id missing");
            }

            await loadPolicyClient();

            var pending = KOFC.Policy.consumePendingResult();

            setLoadingMessage("Retrieving policy record...");

            var record = await getPolicyRecord(ctx.entityName, ctx.recordId);

            if (!record) {
                throw new Error("Unable to retrieve policy record");
            }

            var isValid = await validateRecord(record);

            if (!isValid) {
                hideLoader();
                return;
            }

            var policyNo = record.kofc_policynumber;
            var sourceName = record.kofc_sourcename;
            var issueCountry =
                record["kofc_issuecountry@OData.Community.Display.V1.FormattedValue"];
            var policyClassification =
                record["kofc_policyclassification@OData.Community.Display.V1.FormattedValue"];

            applyViewVisibility(sourceName, policyClassification);

            console.log("Policy Number:", policyNo);
            console.log("Source:", sourceName);
            console.log("Issue Country:", issueCountry);
            console.log("Policy Classification:", policyClassification);

            var data;

            if (pending) {
                if (!pending.ok) {
                    var pendingErr = (pending.data && pending.data.ERROR) ? pending.data.ERROR : pending.raw;
                    throw new Error("Policy lookup failed (" + pending.status + "): " + pendingErr);
                }
                data = pending.data;
            } else {
                setLoadingMessage("Calling Policy Non-Header API service...");

                data = await fetchPolicyData(
                    policyNo,
                    sourceName,
                    issueCountry,
                    policyClassification,
                    ctx.recordId
                );

                if (data && data.redirecting) {
                    hideLoader();
                    return;
                }
            }

            if (!data) {
                throw new Error("No data returned from API");
            }

            if (data.ERROR) {
                throw new Error(String(data.ERROR));
            }

            if (!data.NonHeader || !data.NonHeader.PolicyNumber) {
                throw new Error("Response contained no data.");
            }

            setLoadingMessage("Rendering data...");
            bind(data);
            applyViewVisibility(sourceName, policyClassification);
            updatePrintHeader();
            setPrintEnabled(true);

        } catch (e) {
            console.error("Init Error:", e);
            setPrintEnabled(false);
            showError(e.message || "Failed to load policy data.");
        } finally {
            setTimeout(function () {
                hideLoader();
            }, 300);
        }
    }

    return {
        init: init,
        retry: retry,
        print: printReport
    };

})();