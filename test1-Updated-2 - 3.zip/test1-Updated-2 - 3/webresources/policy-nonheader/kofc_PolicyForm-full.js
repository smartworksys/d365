/*
 * ============================================================================
 * kofc_PolicyForm-full.js — Policy form script (Boomi + Non-Header integration)
 * ============================================================================
 *
 * Upload as a Dynamics 365 form script web resource on the Policy entity.
 *
 * BOOMI / MSAL (Policy Non-Header Tier One):
 *   Uses userId + policyRecordId (not userName) when opening the details HTML page
 *   or when calling KOFC.Policy directly. Env vars: kofc_PolicyTenantId, ClientId,
 *   ApiAppId, ApiKey, PolicyBoomiUrl (see kofc_PolicyForm-snippet.js).
 *
 * HTML web resource kofc_policy_details.html should load:
 *   kofc_authclient.js, kofc_policyClient.js, kofc_msalbrowsermin, kofc_policyDetails.js
 * ============================================================================
 */

var AUTH_CLIENT_LIBRARY = "/WebResources/kofc_authclient.js";
var POLICY_CLIENT_LIBRARY = "/WebResources/kofc_policyClient.js";
var POLICY_DETAILS_HTML = "kofc_policy_details.html";

var POLICY_ENV_VARS = {
    tenantId: "kofc_PolicyTenantId",
    clientId: "kofc_PolicyClientId",
    apiAppId: "kofc_PolicyApiAppId",
    apiKey: "kofc_PolicyApiKey",
    boomiUrl: "kofc_PolicyBoomiUrl"
};

var POLICY_STATIC_CONFIG = {
    scope: "access_as_user",
    httpMethod: "POST",
    redirectWebResource: "kofc_authcallback.html",
    msalWebResourcePath: "/WebResources/kofc_msalbrowsermin",
    allowRedirect: true,
    debug: false
};

function loadAuthClient() {
    return new Promise(function (resolve, reject) {
        if (window.KOFC && window.KOFC.Auth) {
            resolve();
            return;
        }
        var script = document.createElement("script");
        script.src = Xrm.Utility.getGlobalContext().getClientUrl() + AUTH_CLIENT_LIBRARY;
        script.onload = function () {
            if (window.KOFC && window.KOFC.Auth) {
                resolve();
            } else {
                reject(new Error("Auth client loaded but KOFC.Auth is undefined."));
            }
        };
        script.onerror = function () {
            reject(new Error("Failed to load auth client: " + script.src));
        };
        document.head.appendChild(script);
    });
}

function loadPolicyClient() {
    return new Promise(function (resolve, reject) {
        if (window.KOFC && window.KOFC.Policy) {
            resolve();
            return;
        }
        var script = document.createElement("script");
        script.src = Xrm.Utility.getGlobalContext().getClientUrl() + POLICY_CLIENT_LIBRARY;
        script.onload = function () {
            if (window.KOFC && window.KOFC.Policy) {
                resolve();
            } else {
                reject(new Error("Policy client loaded but KOFC.Policy is undefined."));
            }
        };
        script.onerror = function () {
            reject(new Error("Failed to load policy client: " + script.src));
        };
        document.head.appendChild(script);
    });
}

async function getPolicyConfigFromEnvironment() {
    var values = await Promise.all([
        getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.tenantId),
        getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.clientId),
        getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.apiAppId),
        getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.apiKey),
        getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.boomiUrl)
    ]);
    var missing = [];
    if (!values[0]) { missing.push(POLICY_ENV_VARS.tenantId); }
    if (!values[1]) { missing.push(POLICY_ENV_VARS.clientId); }
    if (!values[2]) { missing.push(POLICY_ENV_VARS.apiAppId); }
    if (!values[3]) { missing.push(POLICY_ENV_VARS.apiKey); }
    if (!values[4]) { missing.push(POLICY_ENV_VARS.boomiUrl); }
    if (missing.length > 0) {
        throw new Error("Missing Policy configuration: " + missing.join(", "));
    }
    return {
        tenantId: values[0],
        clientId: values[1],
        apiAppId: values[2],
        apiKey: values[3],
        boomiUrl: values[4],
        scope: POLICY_STATIC_CONFIG.scope,
        httpMethod: POLICY_STATIC_CONFIG.httpMethod,
        redirectWebResource: POLICY_STATIC_CONFIG.redirectWebResource,
        msalWebResourcePath: POLICY_STATIC_CONFIG.msalWebResourcePath,
        allowRedirect: POLICY_STATIC_CONFIG.allowRedirect,
        debug: POLICY_STATIC_CONFIG.debug
    };
}

/**
 * Form OnLoad — completes policy lookup after MSAL redirect (Policy HTML page or form).
 */
async function onPolicyFormLoad(executionContext) {
    try {
        await loadPolicyClient();
        var pending = KOFC.Policy.consumePendingResult();
        if (!pending) {
            return;
        }
        if (pending.ok) {
            console.log("Policy data (from redirect)", pending.data);
        } else {
            var errMsg = (pending.data && pending.data.ERROR) ? pending.data.ERROR : pending.raw;
            Xrm.Navigation.openAlertDialog({
                text: "Policy lookup failed (" + pending.status + "): " + errMsg
            });
        }
    } catch (ex) {
        console.warn("onPolicyFormLoad:", ex);
    }
}

function mapSource(sourceName) {
    switch ((sourceName || "").trim()) {
        case "Ingenium":
        case "ING":
            return "ING";
        case "Life 70":
        case "L70":
            return "L70";
        case "LTC":
            return "LTC";
        case "DI":
            return "DI";
        default:
            return "ING";
    }
}

function mapSourceForApi(sourceName) {
    switch (mapSource(sourceName)) {
        case "ING": return "ing";
        case "L70": return "l70";
        case "LTC": return "ltc";
        case "DI": return "di";
        default: return "ing";
    }
}

function mapCompanyCodeFromForm(formContext) {
    var issueCountryAttr = formContext.getAttribute("kofc_issuecountry");
    if (!issueCountryAttr) {
        return null;
    }
    var text = issueCountryAttr.getText();
    var country = String(text || "").trim().toUpperCase();
    switch (country) {
        case "US":
        case "USA":
        case "UNITED STATES":
            return "01";
        case "CANADA":
            return "50";
        default:
            return "01";
    }
}

function mapClassificationFromForm(formContext) {
    var classAttr = formContext.getAttribute("kofc_policyclassification");
    if (!classAttr) {
        return "";
    }
    try {
        return (classAttr.getText() || "").trim();
    } catch (e) {
        return "";
    }
}

/**
 * Opens Policy Non-Header HTML page (uses kofc_policyDetails.js + Boomi inside the page).
 */
async function ShowNonHeaderDetails(executionContext) {
    var formContext = executionContext;

    var policyNumber = formContext.getAttribute("kofc_policynumber")?.getValue();
    var policyClassification = formContext.getAttribute("kofc_policyclassification")?.getValue();
    var sourceSystem = formContext.getAttribute("kofc_sourcename")?.getValue();
    var issueCountry = formContext.getAttribute("kofc_issuecountry")?.getValue();

    var allowedValues = ["Ingenium", "DI", "LTC", "L70"];
    var missingFields = [];

    if (!policyNumber || String(policyNumber).trim() === "") {
        missingFields.push("Policy Number");
    }
    if (issueCountry === null || issueCountry === undefined) {
        missingFields.push("Issue Country");
    }
    if (policyClassification === null || policyClassification === undefined) {
        missingFields.push("Policy Classification");
    }
    if (!sourceSystem || String(sourceSystem).trim() === "" || allowedValues.indexOf(String(sourceSystem).trim()) < 0) {
        missingFields.push("Source Name (Allowed values - Ingenium, LTC, DI, L70)");
    }

    if (missingFields.length > 0) {
        await Xrm.Navigation.openAlertDialog({
            confirmButtonLabel: "OK",
            text: "Below fields are either empty or Invalid. Please contact system administrator.\n\n" + missingFields.join("\n"),
            title: "Validation Error"
        });
        return;
    }

    var entityLogicalName = formContext.data.entity.getEntityName();
    var recordId = formContext.data.entity.getId().replace(/[{}]/g, "");

    await openPolicyDetailsHtmlPage({
        entityLogicalName: entityLogicalName,
        recordId: recordId
    });
}

async function openPolicyDetailsHtmlPage(options) {
    try {
        var gc = Xrm.Utility.getGlobalContext();
        var clientUrl = gc.getClientUrl();
        var appProps = await gc.getCurrentAppProperties();

        var url = clientUrl + "/main.aspx?appid=" + encodeURIComponent(appProps.appId)
            + "&pagetype=webresource"
            + "&webresourceName=" + encodeURIComponent(POLICY_DETAILS_HTML)
            + "&etn=" + encodeURIComponent(options.entityLogicalName)
            + "&id=" + encodeURIComponent(options.recordId);

        window.open(url, "_blank");
    } catch (e) {
        Xrm.Navigation.openAlertDialog({
            text: "Failed to open policy details page. " + (e.message || e)
        });
    }
}

/**
 * Optional: call Boomi directly from the form (no HTML page) using KOFC.Policy.
 */
async function callPolicyFunctionFromForm(executionContext, sourceApiValue) {
    Xrm.Utility.showProgressIndicator("Loading policy data...");

    try {
        var formContext = executionContext.getFormContext
            ? executionContext.getFormContext()
            : executionContext;

        var policyNo = formContext.getAttribute("kofc_policynumber")?.getValue();
        var companyCode = mapCompanyCodeFromForm(formContext);
        var classificationCode = mapClassificationFromForm(formContext);
        var sourceAttr = formContext.getAttribute("kofc_sourcename");
        var sourceName = sourceAttr ? sourceAttr.getValue() : null;
        var source = sourceApiValue || mapSourceForApi(sourceName);

        if (!policyNo || !companyCode || !classificationCode) {
            Xrm.Navigation.openAlertDialog({
                text: "Policy number, issue country, and classification are required."
            });
            return;
        }

        var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
        var policyRecordId = formContext.data.entity.getId();

        await loadAuthClient();
        await loadPolicyClient();

        var config = await getPolicyConfigFromEnvironment();
        KOFC.Policy.configure(config);

        var result = await KOFC.Policy.getPolicyData({
            source: source,
            companyCode: String(companyCode),
            policyNo: String(policyNo),
            classificationCode: String(classificationCode),
            userId: userId,
            policyRecordId: policyRecordId
        });

        if (result && result.redirecting) {
            return;
        }

        if (!result.ok) {
            var errMsg = (result.data && result.data.ERROR) ? result.data.ERROR : result.raw;
            Xrm.Navigation.openAlertDialog({
                text: "Policy lookup failed (" + result.status + "): " + errMsg
            });
            return;
        }

        console.log("Policy data", result.data);
        Xrm.Navigation.openAlertDialog({ text: "Policy data retrieved successfully." });
    } catch (ex) {
        Xrm.Navigation.openAlertDialog({ text: "Error: " + (ex.message || ex) });
    } finally {
        Xrm.Utility.closeProgressIndicator();
    }
}

// --- Existing form helpers (unchanged behavior) ---

function OnLoad(executionContext) {
    "use strict";
    try {
        var formContext = executionContext.getFormContext();
        FilterPolicySubgrid(formContext);
        HideSecondaryFieldsIfPolicyisnotDual(formContext);
    } catch (error) {
        Xrm.Navigation.openAlertDialog("Error in onLoad: " + (error.description || error.message));
    }
}

function HideSecondaryFieldsIfPolicyisnotDual(formContext) {
    "use strict";
    try {
        var insurancesubtype = formContext.getAttribute("kofc_insurancesubtype").getValue();
        var productName = formContext.getAttribute("kofc_productname").getValue();
        var show = (insurancesubtype != null && (insurancesubtype === 258510011 || insurancesubtype === 258510012))
            || (productName != null && (productName.includes("940") || productName.includes("840")));

        var fields = [
            "kofc_secondaryinsuredname", "kofc_secondarypolicyownername", "kofc_secondarypayorname",
            "kofc_secondaryinsuredissueage", "kofc_secondaryinsuredtobaccoindicator_os"
        ];
        fields.forEach(function (name) {
            var ctrl = formContext.getControl(name);
            if (ctrl) {
                ctrl.setVisible(show);
            }
        });
    } catch (error) {
        Xrm.Navigation.openAlertDialog("Error in HideSecondaryFieldsIfPolicyisnotDual: " + (error.description || error.message));
    }
}

function OnChangeClientId(executionContext) {
    "use strict";
    try {
        FilterPolicySubgrid(executionContext.getFormContext());
    } catch (error) {
        Xrm.Navigation.openAlertDialog("Error in OnChangeClientId: " + (error.description || error.message));
    }
}

function FilterPolicySubgrid(formContext) {
    "use strict";
    try {
        var clientIdGuid = "{00000000-0000-0000-0000-000000000000}";
        var relationshipPartiesGridControl = formContext.getControl("subgrid_relationshipinterestedparties");

        if (relationshipPartiesGridControl !== null) {
            if (formContext.getAttribute("kofc_clientid") !== null) {
                var clientIdValue = formContext.getAttribute("kofc_clientid").getValue();
                if (clientIdValue !== null && clientIdValue !== undefined && clientIdValue[0].entityType === "contact") {
                    clientIdGuid = clientIdValue[0].id;
                }
            }

            var fetchConnections = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                "<entity name='connection'>" +
                "<attribute name='record2id' />" +
                "<attribute name='record2roleid' />" +
                "<attribute name='description' />" +
                "<attribute name='name' />" +
                "<attribute name='connectionid' />" +
                "<order attribute='name' descending='false' />" +
                "<filter type='and'>" +
                "<filter type='and'>" +
                "<condition attribute='statecode' operator='eq' value='0' />" +
                "<condition attribute='record1id' operator='eq' value='" + clientIdGuid + "' />" +
                "</filter>" +
                "</filter>" +
                "<link-entity name='connectionrole' from='connectionroleid' to='record2roleid' link-type='inner' alias='af'>" +
                "<filter type='and'>" +
                "<condition attribute='category' operator='eq' value='2' />" +
                "</filter>" +
                "</link-entity>" +
                "</entity>" +
                "</fetch>";
            relationshipPartiesGridControl.setFilterXml(fetchConnections);
            relationshipPartiesGridControl.refresh();
        }
    } catch (error) {
        Xrm.Navigation.openAlertDialog("Error in FilterPolicySubgrid: " + (error.description || error.message));
    }
}

async function getEnvironmentVariableCurrentValue(schemaName) {
    "use strict";

    var query =
        "?$select=defaultvalue" +
        "&$filter=schemaname eq '" + schemaName + "'" +
        "&$expand=environmentvariabledefinition_environmentvariablevalue($select=value)";

    var result = await Xrm.WebApi.retrieveMultipleRecords(
        "environmentvariabledefinition",
        query
    );

    if (!result || !result.entities || result.entities.length < 1) {
        return null;
    }

    var definition = result.entities[0];
    return definition.environmentvariabledefinition_environmentvariablevalue?.length
        ? definition.environmentvariabledefinition_environmentvariablevalue[0].value
        : definition.defaultvalue;
}
