/*
 * ============================================================================
 * kofc_PolicyForm-snippet.js — Form script integration (Boomi + MSAL, like EApp)
 * ============================================================================
 *
 * Copy the sections below into your Dynamics 365 form script.
 * Uses environment variables for auth + Boomi — nothing sensitive hard-coded.
 *
 * REQUIRED ENVIRONMENT VARIABLES (Text type in D365):
 *   kofc_PolicyTenantId   -> Entra tenant ID
 *   kofc_PolicyClientId   -> SPA client ID
 *   kofc_PolicyApiAppId   -> Policy Function API app ID (browser scope: api://<id>/access_as_user)
 *   kofc_PolicyApiKey     -> Boomi x-api-key
 *   kofc_PolicyBoomiUrl   -> Boomi REST URL for Policy Non-Header integration
 *
 * NOTE: Boomi calls the Function with a client-credentials token that must carry
 * the Policy.Read app role (same two-token model as EApp Contact.Read).
 *
 * REQUIRED WEB RESOURCES:
 *   kofc_authclient.js       — KOFC.Auth (shared with EApp)
 *   kofc_policyClient.js     — KOFC.Policy
 *   kofc_authcallback.html   — MSAL redirect page (shared with EApp)
 *   kofc_msalbrowsermin      — MSAL.js
 *
 * HOW TO APPLY:
 *   1) ADD the helpers below (libraries, env vars, loaders, config builder).
 *   2) ADD onPolicyFormLoad to form OnLoad event (completes flow after redirect).
 *   3) Wire callPolicyFunction("ing") from your button OnClick handler.
 * ============================================================================
 */

var AUTH_CLIENT_LIBRARY = "/WebResources/kofc_authclient.js";
var POLICY_CLIENT_LIBRARY = "/WebResources/kofc_policyClient.js";

var POLICY_ENV_VARS = {
    tenantId: "kofc_PolicyTenantId",
    clientId: "kofc_PolicyClientId",
    apiAppId: "kofc_PolicyApiAppId",
    apiKey: "kofc_PolicyApiKey",
    boomiUrl: "kofc_PolicyBoomiUrl"
};

var POLICY_STATIC_CONFIG = {
    scope: "access_as_user",
    httpMethod: "POST",
    redirectWebResource: "kofc_authcallback.html",
    msalWebResourcePath: "/WebResources/kofc_msalbrowsermin",
    allowRedirect: true,
    debug: false
};

function loadAuthClient() {
    return new Promise(function (resolve, reject) {
        if (window.KOFC && window.KOFC.Auth) {
            resolve();
            return;
        }
        var script = document.createElement("script");
        script.src = Xrm.Utility.getGlobalContext().getClientUrl() + AUTH_CLIENT_LIBRARY;
        script.onload = function () {
            if (window.KOFC && window.KOFC.Auth) {
                resolve();
            } else {
                reject(new Error("Auth client loaded but KOFC.Auth is undefined."));
            }
        };
        script.onerror = function () {
            reject(new Error("Failed to load auth client: " + script.src));
        };
        document.head.appendChild(script);
    });
}

function loadPolicyClient() {
    return new Promise(function (resolve, reject) {
        if (window.KOFC && window.KOFC.Policy) {
            resolve();
            return;
        }
        var script = document.createElement("script");
        script.src = Xrm.Utility.getGlobalContext().getClientUrl() + POLICY_CLIENT_LIBRARY;
        script.onload = function () {
            if (window.KOFC && window.KOFC.Policy) {
                resolve();
            } else {
                reject(new Error("Policy client loaded but KOFC.Policy is undefined."));
            }
        };
        script.onerror = function () {
            reject(new Error("Failed to load policy client: " + script.src));
        };
        document.head.appendChild(script);
    });
}

function getPolicyConfigFromEnvironment() {
    return Promise.all([
        getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.tenantId),
        getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.clientId),
        getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.apiAppId),
        getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.apiKey),
        getEnvironmentVariableCurrentValue(POLICY_ENV_VARS.boomiUrl)
    ]).then(function (values) {
        var missing = [];
        if (!values[0]) { missing.push(POLICY_ENV_VARS.tenantId); }
        if (!values[1]) { missing.push(POLICY_ENV_VARS.clientId); }
        if (!values[2]) { missing.push(POLICY_ENV_VARS.apiAppId); }
        if (!values[3]) { missing.push(POLICY_ENV_VARS.apiKey); }
        if (!values[4]) { missing.push(POLICY_ENV_VARS.boomiUrl); }
        if (missing.length > 0) {
            throw new Error("Missing Policy configuration: " + missing.join(", "));
        }
        return {
            tenantId: values[0],
            clientId: values[1],
            apiAppId: values[2],
            apiKey: values[3],
            boomiUrl: values[4],
            scope: POLICY_STATIC_CONFIG.scope,
            httpMethod: POLICY_STATIC_CONFIG.httpMethod,
            redirectWebResource: POLICY_STATIC_CONFIG.redirectWebResource,
            msalWebResourcePath: POLICY_STATIC_CONFIG.msalWebResourcePath,
            allowRedirect: POLICY_STATIC_CONFIG.allowRedirect,
            debug: POLICY_STATIC_CONFIG.debug
        };
    });
}

/**
 * Form OnLoad — finishes policy lookup after MSAL redirect (no second click).
 */
async function onPolicyFormLoad(executionContext) {
    try {
        await loadPolicyClient();
        var pending = KOFC.Policy.consumePendingResult();
        if (!pending) {
            return;
        }
        if (pending.ok) {
            console.log("Policy data (from redirect)", pending.data);
            Xrm.Navigation.openAlertDialog({ text: "Policy data retrieved successfully." });
            // TODO: map pending.data.NonHeader / pending.data.TIERONE to form fields
        } else {
            var errMsg = (pending.data && pending.data.ERROR) ? pending.data.ERROR : pending.raw;
            Xrm.Navigation.openAlertDialog({
                text: "Policy lookup failed (" + pending.status + "): " + errMsg
            });
        }
    } catch (ex) {
        // Non-fatal on load
        console.warn("onPolicyFormLoad:", ex);
    }
}

/**
 * Button handler — adapt attribute logical names to your form.
 * @param {string} source - ing | l70 | di | ltc
 */
async function callPolicyFunction(source) {
    Xrm.Utility.showProgressIndicator("Loading policy data...");

    try {
        var formContext = typeof executionContext !== "undefined"
            ? executionContext.getFormContext()
            : null;

        if (!formContext) {
            throw new Error("Form context is not available.");
        }

        var companyAttr = formContext.getAttribute("kofc_companycode");
        var policyAttr = formContext.getAttribute("kofc_policynumber");
        var classAttr = formContext.getAttribute("kofc_classificationcode");
        var companyCode = companyAttr ? companyAttr.getValue() : null;
        var policyNo = policyAttr ? policyAttr.getValue() : null;
        var classificationCode = classAttr ? classAttr.getValue() : null;

        if (!companyCode || !policyNo || !classificationCode) {
            Xrm.Navigation.openAlertDialog({
                text: "Company code, policy number, and classification code are required."
            });
            return;
        }

        var userId = Xrm.Utility.getGlobalContext().userSettings.userId;
        var policyRecordId = formContext.data.entity.getId();

        await loadAuthClient();
        await loadPolicyClient();

        var config = await getPolicyConfigFromEnvironment();
        KOFC.Policy.configure(config);

        var result = await KOFC.Policy.getPolicyData({
            source: source,
            companyCode: String(companyCode),
            policyNo: String(policyNo),
            classificationCode: String(classificationCode),
            userId: userId,
            policyRecordId: policyRecordId
        });

        if (result && result.redirecting) {
            Xrm.Utility.closeProgressIndicator();
            return;
        }

        if (!result.ok) {
            var errMsg = (result.data && result.data.ERROR) ? result.data.ERROR : result.raw;
            Xrm.Navigation.openAlertDialog({
                text: "Policy lookup failed (" + result.status + "): " + errMsg
            });
            return;
        }

        console.log("Policy data", result.data);
        Xrm.Navigation.openAlertDialog({ text: "Policy data retrieved successfully." });
        // TODO: map result.data.NonHeader / result.data.TIERONE to form fields
    } catch (ex) {
        Xrm.Navigation.openAlertDialog({ text: "Error: " + (ex.message || ex) });
    } finally {
        Xrm.Utility.closeProgressIndicator();
    }
}
