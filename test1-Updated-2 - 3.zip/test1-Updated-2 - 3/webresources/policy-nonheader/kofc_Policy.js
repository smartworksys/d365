/*
 * ============================================================================
 * kofc_Policy.js — Policy entity form script (merged from TEST3JS.txt)
 * ============================================================================
 *
 * FORM EVENT WIRING:
 *   Form OnLoad                        -> OnLoad
 *   kofc_clientid OnChange             -> OnChangeClientId
 *   kofc_policyclassification OnChange -> ShowHideFieldsForLineOfBusiness (if wired)
 *   Illustrator ribbon                 -> CallNavEnvVar
 *   Policy XML ribbon                  -> CallSnowflakeEnvVar
 *   Policy XML enable rule             -> EnablePolicyXMLButton
 *   Non-Header button                  -> ShowNonHeaderDetails
 *
 * NON-HEADER (updated): opens kofc_policy_details.html; Boomi/MSAL run in that page.
 * Web resources: kofc_policy_details.html, kofc_policyDetails.js, kofc_policyClient.js,
 *   kofc_authclient.js, kofc_msalbrowsermin, kofc_authcallback.html
 * Env vars (HTML page): kofc_PolicyTenantId, ClientId, ApiAppId, ApiKey, PolicyBoomiUrl
 * ============================================================================
 */

function oneMember() {
    "use strict";
    window.open("https://kofctest.stoneriver.com/testQA/LifePortraits.aspx?externalLogin=true", Navigator)
}
///*
//Author: Dipti Mishra
//#US - 5141
//created OnLoad, OnChangeClientId, FilterPolicySubgrid
//Date: 12/04/2023
//*

function OnLoad(executionContext) {
    "use strict";
    try {

        var formContext = executionContext.getFormContext();
        FilterPolicySubgrid(formContext);
        HideSecondaryFieldsIfPolicyisnotDual(formContext);
    }
    catch (error) {
        Xrm.Navigation.openAlertDialog('Error in onLoad: ' + (error.description || error.message));
    }
}
///*
//Author: Surbhi Garg
//#US - 44285
//created OnLoad
//Date: 12/10/2025
//*
function HideSecondaryFieldsIfPolicyisnotDual(formContext) {
    "use strict";
    try {
        var insurancesubtype = formContext.getAttribute("kofc_insurancesubtype").getValue();
        var productName = formContext.getAttribute("kofc_productname").getValue();

        if ((insurancesubtype != null && (insurancesubtype == 258510011 || insurancesubtype == 258510012)) || (productName != null && ((productName.includes('940') || productName.includes('840'))))) {
            formContext.getControl("kofc_secondaryinsuredname").setVisible(true);
            formContext.getControl("kofc_secondarypolicyownername").setVisible(true);
            formContext.getControl("kofc_secondarypayorname").setVisible(true);

            formContext.getControl("kofc_secondaryinsuredissueage").setVisible(true);
            formContext.getControl("kofc_secondaryinsuredtobaccoindicator_os").setVisible(true);

        }
        else {
            formContext.getControl("kofc_secondaryinsuredname").setVisible(false);
            formContext.getControl("kofc_secondarypolicyownername").setVisible(false);
            formContext.getControl("kofc_secondarypayorname").setVisible(false);

            formContext.getControl("kofc_secondaryinsuredissueage").setVisible(false);
            formContext.getControl("kofc_secondaryinsuredtobaccoindicator_os").setVisible(false);
        }
    }
    catch (error) {
        Xrm.Navigation.openAlertDialog('Error in OnChangeClientId: ' + (error.description || error.message));
    }
}
function OnChangeClientId(executionContext) {
    "use strict";
    try {
        var formContext = executionContext.getFormContext();
        FilterPolicySubgrid(formContext);
    }
    catch (error) {
        Xrm.Navigation.openAlertDialog('Error in OnChangeClientId: ' + (error.description || error.message));
    }
}

function FilterPolicySubgrid(formContext) {
    "use strict";
    try {
        var clientIdGuid = '{00000000-0000-0000-0000-000000000000}';
        var relationshipPartiesGridControl = formContext.getControl("subgrid_relationshipinterestedparties");

        if (relationshipPartiesGridControl !== null) {
            if (formContext.getAttribute('kofc_clientid') !== null) {
                var clientIdValue = formContext.getAttribute('kofc_clientid').getValue();
                if (clientIdValue !== null && clientIdValue !== undefined && clientIdValue[0].entityType === 'contact') {
                    clientIdGuid = clientIdValue[0].id;
                }
            }

            var fetchConnections = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
                "<entity name='connection'>" +
                "<attribute name='record2id' />" +
                "<attribute name='record2roleid' />" +
                "<attribute name='description' />" +
                "<attribute name='name' />" +
                "<attribute name='connectionid' />" +
                "<order attribute='name' descending='false' />" +
                "<filter type='and'>" +
                "<filter type='and'>" +
                "<condition attribute='statecode' operator='eq' value='0' />" +
                "<condition attribute='record1id' operator='eq' value='" + clientIdGuid + "' />" +
                "</filter>" +
                "</filter>" +
                "<link-entity name='connectionrole' from='connectionroleid' to='record2roleid' link-type='inner' alias='af'>" +
                "<filter type='and'>" +
                "<condition attribute='category' operator='eq' value='2' />" +
                "</filter>" +
                "</link-entity>" +
                "</entity>" +
                "</fetch>";
            relationshipPartiesGridControl.setFilterXml(fetchConnections);
            relationshipPartiesGridControl.refresh();

        }
    }
    catch (error) {
        Xrm.Navigation.openAlertDialog('Error in FilterPolicySubgrid: ' + (error.description || error.message));
    }
}


//Author:Susmitha THokala
//Created On:5/25/2024
//US:15980
//Function to call Navigator
function CallNavEnvVar(PrimaryControl) {
    "use strict";
    GetEnvironmentVariableValueForNavigator("kofc_NavigatorIntfunctionURL", PrimaryControl);
}

// ADO 51210 | Veera Kolan | 03/18/2026
// Refactored to use getEnvironmentVariableCurrentValue() for env var resolution.

async function GetEnvironmentVariableValueForNavigator(name, PrimaryControl) {
    "use strict";

    const navFunctionAppURL = await getEnvironmentVariableCurrentValue(name);
    if (navFunctionAppURL) {
        GetEnvironmentVariableValueByName(
            navFunctionAppURL,
            "kofc_navigatorURL",
            PrimaryControl
        );
    }
}

// ADO 51210 | Veera Kolan | 03/18/2026
// Refactored to use getEnvironmentVariableCurrentValue() for env var resolution.

async function GetEnvironmentVariableValueByName(navFunctionAppURL, name, PrimaryControl) {
    "use strict";

    const navigatorUrl = await getEnvironmentVariableCurrentValue(name);
    if (navigatorUrl) {
        onIllustratorButtonClick(
            navigatorUrl,
            PrimaryControl,
            navFunctionAppURL
        );
    }
}

function navigateToNavigator(navigatorURL, content) {

    var transTrackingID = content;
    transTrackingID = transTrackingID.replace('"', '').replace('"', '');

    let navParams = "&CurrentPage=Illustration&GatewayServicePayloadId=" + transTrackingID;
    let navURL = navigatorURL + navParams;

    Xrm.Utility.closeProgressIndicator();
    const newWindow = window.open(navURL, "_blank");

    window.addEventListener('load', function () {
        if (newWindow) {

            console.log("new window loaded");

        }
        else {
            console.error('The new window is not accessible.');
            Xrm.Utility.closeProgressIndicator();
        }
    });
}



//Author:Sai Mukka
//Created On:08/14/2024  #US-20940


//Function to illustrate TKIS/Navigator/DNI policy data
function onIllustratorButtonClick(navigatorURL, PrimaryControl, navFunctionAppURL) {
    Xrm.Utility.showProgressIndicator("Processing Request... Please Wait.");

    var formContext = PrimaryControl;
    //getting Policy Number and Country Code
    let policyNumber = formContext.getAttribute("kofc_policynumber")?.getValue();
    let countryCode = formContext.getAttribute("kofc_issuecountry")?.getText();
    let sourceSystem = formContext.getAttribute("kofc_sourcename")?.getValue();

    //display pop up if country code not found
    if (!countryCode) {
        Xrm.Utility.closeProgressIndicator();
        Xrm.Navigation.openAlertDialog("Issue Country is empty.\n Please assign a Policy Issue Country and try again!");
        return;
    }
    
    if (!sourceSystem) {
        Xrm.Utility.closeProgressIndicator();
        Xrm.Navigation.openAlertDialog("Source System is missing.\n Please assign a Source Issue System and try again!");
        return;
    }
    
     const source = mapSource(sourceSystem);

    //append Country code to policy nummber
    let reqPolicyNumber = policyNumber;
    if (countryCode === "US") {
        reqPolicyNumber = '01' + policyNumber;
    } else if (countryCode === "Canada") {
        reqPolicyNumber = '50' + policyNumber;
    } else {
        Xrm.Utility.closeProgressIndicator();
        Xrm.Navigation.openAlertDialog("Invalid Country Code!\n Please assign valid country code and try again!");
        return;
    }

    //generate requestURL
    var reqUrl = `${navFunctionAppURL}&type=policy&policyNo=${reqPolicyNumber}&sourceSystem=${source}`;

    var requestOptions = {
        method: "GET",
        headers: {
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
        }
    };

    fetch(reqUrl, requestOptions)
        .then(response => {
            if (!response.ok) {
                if (response.status === 404) {
                    Xrm.Utility.closeProgressIndicator();
                    Xrm.Navigation.openAlertDialog("Policy Not Found.");
                    throw new Error(": Policy Not Found");
                }
                Xrm.Utility.closeProgressIndicator();
                Xrm.Navigation.openAlertDialog(" Failed to fetch response!");
                throw new Error(" Failed to fetch response!");
            }
            return response.json();
        })
        .then(responseData => {
            if (!responseData) {
                Xrm.Utility.closeProgressIndicator();
                Xrm.Navigation.openAlertDialog(`No response from API`);
                return;
            }

            const indicator = responseData.indicator;
            const Content = responseData.data;

            if (!indicator && !Content) {
                //to be integrated with Nav
                Xrm.Utility.closeProgressIndicator();
                Xrm.Navigation.openAlertDialog("Illustration System : NAVIGATOR\n  This functionality is not yet available. Build in progress !!");
                return;
            } else {
                switch (indicator) {
                    case "TKIS":
                        showIllustrateDownloadDialog(Content);
                        break;
                    case "Navigator":
                        navigateToNavigator(navigatorURL, Content);
                        break;
                    case "DO NOT ILLUSTRATE":
                        if (HasHomeOfficeUserRole()) {
                            Xrm.Utility.closeProgressIndicator();
                            Xrm.Navigation.openAlertDialog("Policy cannot be illustrated.");
                            break;
                        } else {
                            Xrm.Utility.closeProgressIndicator();
                            Xrm.Navigation.openAlertDialog("Policy cannot be illustrated.");
                            break;
                        }
                    default:
                        Xrm.Utility.closeProgressIndicator();
                        Xrm.Navigation.openAlertDialog(`Unknown illustrate type found: ${policyIndicator}, Expected types : 'TKIS/Navigator/DNI'.`);
                        break;
                }
            }
        })
        .catch(error => {
            Xrm.Utility.closeProgressIndicator();
            throw new Error(`: Failed to fetch response! ${error.message}`);
        });
};



function showIllustrateDownloadDialog(iniContent) {
    var confirmStrings = {
        text: "Please make sure to 'save as' kofcill.ini and choose C:\\KofCAppData for folder destination.",
        title: "Download Instructions!",
        confirmButtonLabel: "Download",
        cancelButtonLabel: "Cancel"
    };
    var confirmationOptions = { height: 150, width: 450 };

    Xrm.Utility.closeProgressIndicator();
    Xrm.Navigation.openConfirmDialog(confirmStrings, confirmationOptions).then(
        function (choice) {
            if (choice.confirmed) {
                downloadIniFile(iniContent);
            }
        });
}


function downloadIniFile(iniContent) {
    try {
        const blob = new Blob([iniContent], { type: "text/plain;charset=utf-8" });

        const fileLink = document.createElement("a");
        const url = URL.createObjectURL(blob);

        fileLink.href = url;
        fileLink.download = "KofCill.ini";

        setTimeout(() => {
            fileLink.click();
            URL.revokeObjectURL(url);
        }, 0);
    } catch (error) {
        Xrm.Navigation.openAlertDialog(`An error occured while downloading the INI doc.\n  error : ${error.message}`)
    }
}

//function to check user's roles
function HasHomeOfficeUserRole() {
    "use strict";
    var userRoles = Xrm.Utility.getGlobalContext().userSettings.roles;
    var hasHomeOfficeRoleFlag = false;
    if (userRoles !== null && userRoles !== undefined) {
        userRoles.forEach(function (item) {
            if (item.name.toLowerCase() === "home office navigator role") {
                hasHomeOfficeRoleFlag = true;
                return hasHomeOfficeRoleFlag;
            }
        });
    }
    return hasHomeOfficeRoleFlag;
}



var optionSetValues = {
    Life: 258510000,
    Annuity: 258510001,
    LTC: 258510002,
    DI: 258510003
};
function ShowHideFieldsForLineOfBusiness(executionContext) {
    "use strict";
    try {
        var formContext = executionContext.getFormContext();
        //formContext.ui.process.setVisible(false);
        //FilterLeadSubTypeMobile(executionContext);
        if (formContext.getAttribute("kofc_policyclassification").getValue() !== null && formContext.getAttribute("kofc_policyclassification").getValue() !== undefined) {
            var PolicyClassification = formContext.getAttribute("kofc_policyclassification").getValue();
            if (PolicyClassification === optionSetValues.Life) {
                formContext.ui.tabs.get("AdditionalPolicyDetails").sections.get("Section_Annuity").setVisible(false);
                formContext.getControl("kofc_annutant") != null ? formContext.getControl("kofc_annutant").setVisible(false) : "";//annuitant Name
                formContext.getControl("kofc_depositamount") != null ? formContext.getControl("kofc_depositamount").setVisible(false) : "";
                formContext.getControl("kofc_costbasis") != null ? formContext.getControl("kofc_costbasis").setVisible(false) : "";
                formContext.getControl("kofc_annuitybasecashvalue") != null ? formContext.getControl("kofc_annuitybasecashvalue").setVisible(false) : "";
                formContext.getControl("kofc_annuitypaymentfrequency_os") != null ? formContext.getControl("kofc_annuitypaymentfrequency_os").setVisible(false) : "";
                formContext.getControl("kofc_purchaseprice") != null ? formContext.getControl("kofc_purchaseprice").setVisible(false) : "";
                formContext.getControl("kofc_periodicincome") != null ? formContext.getControl("kofc_periodicincome").setVisible(false) : "";
                formContext.getControl("kofc_numberofyears") != null ? formContext.getControl("kofc_numberofyears").setVisible(false) : "";
                formContext.getControl("kofc_incomestartdate") != null ? formContext.getControl("kofc_incomestartdate").setVisible(false) : "";
                formContext.getControl("kofc_paymentstartdate") != null ? formContext.getControl("kofc_paymentstartdate").setVisible(false) : "";
                formContext.getControl("kofc_nextpaymentdate") != null ? formContext.getControl("kofc_nextpaymentdate").setVisible(false) : "";
                formContext.getControl("kofc_rrifdistributionoption_os") != null ? formContext.getControl("kofc_rrifdistributionoption_os").setVisible(false) : "";
                formContext.getControl("kofc_amountofannuitytobepaid") != null ? formContext.getControl("kofc_amountofannuitytobepaid").setVisible(false) : "";
                formContext.getControl("kofc_minimumpayment") != null ? formContext.getControl("kofc_minimumpayment").setVisible(false) : "";
                formContext.getControl("kofc_maximumpayment") != null ? formContext.getControl("kofc_maximumpayment").setVisible(false) : "";
                formContext.getControl("kofc_federaltaxwithholdingrequestamount") != null ? formContext.getControl("kofc_federaltaxwithholdingrequestamount").setVisible(false) : "";
                formContext.getControl("kofc_federaltaxwithholdingrequestpercent") != null ? formContext.getControl("kofc_federaltaxwithholdingrequestpercent").setVisible(false) : "";
                formContext.getControl("kofc_locationtaxwithholdingrequestamount") != null ? formContext.getControl("kofc_locationtaxwithholdingrequestamount").setVisible(false) : "";
                formContext.getControl("kofc_locationtaxwithholdingrequestpercent") != null ? formContext.getControl("kofc_locationtaxwithholdingrequestpercent").setVisible(false) : "";
                formContext.getControl("kofc_taxqualificationcode_os") != null ? formContext.getControl("kofc_taxqualificationcode_os").setVisible(false) : "";
                formContext.getControl("kofc_autormdelection") != null ? formContext.getControl("kofc_autormdelection").setVisible(false) : "";
                formContext.getControl("kofc_autormdfedwithholdingamount") != null ? formContext.getControl("kofc_autormdfedwithholdingamount").setVisible(false) : "";
                formContext.getControl("kofc_autormdfedwithholdingpercentage") != null ? formContext.getControl("kofc_autormdfedwithholdingpercentage").setVisible(false) : "";
                formContext.getControl("kofc_autormdstatewithholdingamount") != null ? formContext.getControl("kofc_autormdstatewithholdingamount").setVisible(false) : "";
                formContext.getControl("kofc_autormdstatewithholdingpercentage") != null ? formContext.getControl("kofc_autormdstatewithholdingpercentage").setVisible(false) : "";
                formContext.getControl("kofc_autormdmode_os") != null ? formContext.getControl("kofc_autormdmode_os").setVisible(false) : "";
                formContext.getControl("kofc_rmddate") != null ? formContext.getControl("kofc_rmddate").setVisible(false) : "";
                formContext.getControl("kofc_rmdyearendbalance") != null ? formContext.getControl("kofc_rmdyearendbalance").setVisible(false) : "";
                formContext.getControl("kofc_rmdamountrequiredminimumdistributionamount") != null ? formContext.getControl("kofc_rmdamountrequiredminimumdistributionamount").setVisible(false) : "";
                formContext.getControl("kofc_annuityplans") != null ? formContext.getControl("kofc_annuityplans").setVisible(false) : "";
                formContext.getControl("kofc_viewofsettlementoptionforjoint_os") != null ? formContext.getControl("kofc_viewofsettlementoptionforjoint_os").setVisible(false) : "";
                formContext.getControl("kofc_paymentfrequency") != null ? formContext.getControl("kofc_paymentfrequency").setVisible(false) : "";


            }
            else if (PolicyClassification === optionSetValues.Annuity) {
                formContext.ui.tabs.get("AdditionalPolicyDetails").sections.get("Section_Annuity").setVisible(true)
                formContext.getControl("kofc_contact") != null ? formContext.getControl("kofc_contact").setVisible(false) : "";//Insured Name     
                formContext.getControl("kofc_contingentownername_os") != null ? formContext.getControl("kofc_contingentownername_os").setVisible(false) : "";// Contingent Owner Name
                formContext.getControl("kofc_paidtodate") != null ? formContext.getControl("kofc_paidtodate").setVisible(false) : "";
                formContext.getControl("kofc_modifiedendowmentcontractindicator_os") != null ? formContext.getControl("kofc_modifiedendowmentcontractindicator_os").setVisible(false) : "";
                formContext.getControl("kofc_loanpayoffamount") != null ? formContext.getControl("kofc_loanpayoffamount").setVisible(false) : "";
                formContext.getControl("kofc_maxloanamountavailable") != null ? formContext.getControl("kofc_maxloanamountavailable").setVisible(false) : "";
                formContext.getControl("kofc_loaninterest") != null ? formContext.getControl("kofc_loaninterest").setVisible(false) : "";
                formContext.getControl("kofc_loanprinciple") != null ? formContext.getControl("kofc_loanprinciple").setVisible(false) : "";
                formContext.getControl("kofc_restrictcode") != null ? formContext.getControl("kofc_restrictcode").setVisible(false) : "";
                formContext.getControl("kofc_restricteffectivedate") != null ? formContext.getControl("kofc_restricteffectivedate").setVisible(false) : "";
                formContext.getControl("kofc_restrictenddate") != null ? formContext.getControl("kofc_restrictenddate").setVisible(false) : "";
                formContext.getControl("kofc_surrendervalue") != null ? formContext.getControl("kofc_surrendervalue").setVisible(false) : "";
                formContext.getControl("kofc_cashsurrendervalue") != null ? formContext.getControl("kofc_cashsurrendervalue").setVisible(false) : "";
                formContext.getControl("kofc_surrendercharge") != null ? formContext.getControl("kofc_surrendercharge").setVisible(false) : "";
                formContext.getControl("kofc_deathbenefitasof") != null ? formContext.getControl("kofc_deathbenefitasof").setVisible(false) : "";
                formContext.getControl("kofc_extendedtermdate") != null ? formContext.getControl("kofc_extendedtermdate").setVisible(false) : "";
                formContext.getControl("kofc_nonexemptstatus_os") != null ? formContext.getControl("kofc_nonexemptstatus_os").setVisible(false) : "";
                formContext.getControl("kofc_puacashvalue") != null ? formContext.getControl("kofc_puacashvalue").setVisible(false) : "";
                formContext.getControl("kofc_dividendaccumulations") != null ? formContext.getControl("kofc_dividendaccumulations").setVisible(false) : "";
                formContext.getControl("kofc_divdeathbenefit") != null ? formContext.getControl("kofc_divdeathbenefit").setVisible(false) : "";
                formContext.getControl("kofc_dividendoption_os") != null ? formContext.getControl("kofc_dividendoption_os").setVisible(false) : "";
                formContext.getControl("kofc_dividendvalue") != null ? formContext.getControl("kofc_dividendvalue").setVisible(false) : "";
                formContext.getControl("kofc_ffb_os") != null ? formContext.getControl("kofc_ffb_os").setVisible(false) : "";
                formContext.getControl("kofc_gpocriticalind") != null ? formContext.getControl("kofc_gpocriticalind").setVisible(false) : "";
                formContext.getControl("kofc_gpooptiondate") != null ? formContext.getControl("kofc_gpooptiondate").setVisible(false) : "";
                formContext.getControl("kofc_nextgpooptiondate") != null ? formContext.getControl("kofc_nextgpooptiondate").setVisible(false) : "";
                formContext.getControl("kofc_increaseincashvalue") != null ? formContext.getControl("kofc_increaseincashvalue").setVisible(false) : "";
                formContext.getControl("kofc_lastannivdividend") != null ? formContext.getControl("kofc_lastannivdividend").setVisible(false) : "";
                formContext.getControl("kofc_addldeathbenefit") != null ? formContext.getControl("kofc_addldeathbenefit").setVisible(false) : "";
                formContext.getControl("kofc_anniversarycashvalue") != null ? formContext.getControl("kofc_anniversarycashvalue").setVisible(false) : "";
                formContext.getControl("kofc_currpaidupadditions") != null ? formContext.getControl("kofc_currpaidupadditions").setVisible(false) : "";
                formContext.getControl("kofc_currentdividend") != null ? formContext.getControl("kofc_currentdividend").setVisible(false) : "";
                formContext.getControl("kofc_res117") != null ? formContext.getControl("kofc_res117").setVisible(false) : "";
                formContext.getControl("kofc_res149") != null ? formContext.getControl("kofc_res149").setVisible(false) : "";
                formContext.getControl("kofc_polaplind") != null ? formContext.getControl("kofc_polaplind").setVisible(false) : "";
                formContext.getControl("kofc_tobaccoindicator_os") != null ? formContext.getControl("kofc_tobaccoindicator_os").setVisible(false) : "";
                formContext.getControl("kofc_valuesasoflastanniversary") != null ? formContext.getControl("kofc_valuesasoflastanniversary").setVisible(false) : "";
            }
            else if (PolicyClassification === optionSetValues.LTC || PolicyClassification === optionSetValues.DI) {
                formContext.ui.tabs.get("AdditionalPolicyDetails").sections.get("Section_Annuity").setVisible(false);
                formContext.getControl("kofc_annutant") != null ? formContext.getControl("kofc_annutant").setVisible(false) : "";//annuitant Name
                formContext.getControl("kofc_contingentownername_os") != null ? formContext.getControl("kofc_contingentownername_os").setVisible(false) : "";// Contingent Owner Name
                formContext.getControl("kofc_depositamount") != null ? formContext.getControl("kofc_depositamount").setVisible(false) : "";
                formContext.getControl("kofc_costbasis") != null ? formContext.getControl("kofc_costbasis").setVisible(false) : "";
                formContext.getControl("kofc_modifiedendowmentcontractindicator_os") != null ? formContext.getControl("kofc_modifiedendowmentcontractindicator_os").setVisible(false) : "";
                formContext.getControl("kofc_loanpayoffamount") != null ? formContext.getControl("kofc_loanpayoffamount").setVisible(false) : "";
                formContext.getControl("kofc_maxloanamountavailable") != null ? formContext.getControl("kofc_maxloanamountavailable").setVisible(false) : "";
                formContext.getControl("kofc_loaninterest") != null ? formContext.getControl("kofc_loaninterest").setVisible(false) : "";
                formContext.getControl("kofc_loanprinciple") != null ? formContext.getControl("kofc_loanprinciple").setVisible(false) : "";
                formContext.getControl("kofc_restrictcode") != null ? formContext.getControl("kofc_restrictcode").setVisible(false) : "";
                formContext.getControl("kofc_restricteffectivedate") != null ? formContext.getControl("kofc_restricteffectivedate").setVisible(false) : "";
                formContext.getControl("kofc_restrictenddate") != null ? formContext.getControl("kofc_restrictenddate").setVisible(false) : "";
                formContext.getControl("kofc_annuitybasecashvalue") != null ? formContext.getControl("kofc_annuitybasecashvalue").setVisible(false) : "";
                formContext.getControl("kofc_annuitypaymentfrequency_os") != null ? formContext.getControl("kofc_annuitypaymentfrequency_os").setVisible(false) : "";
                formContext.getControl("kofc_purchaseprice") != null ? formContext.getControl("kofc_purchaseprice").setVisible(false) : "";
                formContext.getControl("kofc_periodicincome") != null ? formContext.getControl("kofc_periodicincome").setVisible(false) : "";
                formContext.getControl("kofc_numberofyears") != null ? formContext.getControl("kofc_numberofyears").setVisible(false) : "";
                formContext.getControl("kofc_incomestartdate") != null ? formContext.getControl("kofc_incomestartdate").setVisible(false) : "";
                formContext.getControl("kofc_paymentstartdate") != null ? formContext.getControl("kofc_paymentstartdate").setVisible(false) : "";
                formContext.getControl("kofc_nextpaymentdate") != null ? formContext.getControl("kofc_nextpaymentdate").setVisible(false) : "";
                formContext.getControl("kofc_rrifdistributionoption_os") != null ? formContext.getControl("kofc_rrifdistributionoption_os").setVisible(false) : "";
                formContext.getControl("kofc_amountofannuitytobepaid") != null ? formContext.getControl("kofc_amountofannuitytobepaid").setVisible(false) : "";
                formContext.getControl("kofc_minimumpayment") != null ? formContext.getControl("kofc_minimumpayment").setVisible(false) : "";
                formContext.getControl("kofc_maximumpayment") != null ? formContext.getControl("kofc_maximumpayment").setVisible(false) : "";
                formContext.getControl("kofc_surrendervalue") != null ? formContext.getControl("kofc_surrendervalue").setVisible(false) : "";
                formContext.getControl("kofc_cashsurrendervalue") != null ? formContext.getControl("kofc_cashsurrendervalue").setVisible(false) : "";
                formContext.getControl("kofc_surrendercharge") != null ? formContext.getControl("kofc_surrendercharge").setVisible(false) : "";
                formContext.getControl("kofc_deathbenefitasof") != null ? formContext.getControl("kofc_deathbenefitasof").setVisible(false) : "";
                formContext.getControl("kofc_extendedtermdate") != null ? formContext.getControl("kofc_extendedtermdate").setVisible(false) : "";
                formContext.getControl("kofc_federaltaxwithholdingrequestamount") != null ? formContext.getControl("kofc_federaltaxwithholdingrequestamount").setVisible(false) : "";
                formContext.getControl("kofc_federaltaxwithholdingrequestpercent") != null ? formContext.getControl("kofc_federaltaxwithholdingrequestpercent").setVisible(false) : "";
                formContext.getControl("kofc_locationtaxwithholdingrequestamount") != null ? formContext.getControl("kofc_locationtaxwithholdingrequestamount").setVisible(false) : "";
                formContext.getControl("kofc_locationtaxwithholdingrequestpercent") != null ? formContext.getControl("kofc_locationtaxwithholdingrequestpercent").setVisible(false) : "";
                formContext.getControl("kofc_incomestartdate") != null ? formContext.getControl("kofc_incomestartdate").setVisible(false) : "";

                formContext.getControl("kofc_lockedinindicator") != null ? formContext.getControl("kofc_lockedinindicator").setVisible(false) : "";
                formContext.getControl("kofc_taxqualificationcode_os") != null ? formContext.getControl("kofc_taxqualificationcode_os").setVisible(false) : "";
                formContext.getControl("kofc_nonexemptstatus_os") != null ? formContext.getControl("kofc_nonexemptstatus_os").setVisible(false) : "";
                formContext.getControl("kofc_puacashvalue") != null ? formContext.getControl("kofc_puacashvalue").setVisible(false) : "";
                formContext.getControl("kofc_autormdelection") != null ? formContext.getControl("kofc_autormdelection").setVisible(false) : "";
                formContext.getControl("kofc_autormdfedwithholdingamount") != null ? formContext.getControl("kofc_autormdfedwithholdingamount").setVisible(false) : "";
                formContext.getControl("kofc_autormdfedwithholdingpercentage") != null ? formContext.getControl("kofc_autormdfedwithholdingpercentage").setVisible(false) : "";
                formContext.getControl("kofc_autormdstatewithholdingamount") != null ? formContext.getControl("kofc_autormdstatewithholdingamount").setVisible(false) : "";
                formContext.getControl("kofc_autormdstatewithholdingpercentage") != null ? formContext.getControl("kofc_autormdstatewithholdingpercentage").setVisible(false) : "";
                formContext.getControl("kofc_autormdmode_os") != null ? formContext.getControl("kofc_autormdmode_os").setVisible(false) : "";
                formContext.getControl("kofc_rmddate") != null ? formContext.getControl("kofc_rmddate").setVisible(false) : "";
                formContext.getControl("kofc_rmdyearendbalance") != null ? formContext.getControl("kofc_rmdyearendbalance").setVisible(false) : "";
                formContext.getControl("kofc_rmdamountrequiredminimumdistributionamount") != null ? formContext.getControl("kofc_rmdamountrequiredminimumdistributionamount").setVisible(false) : "";
                formContext.getControl("kofc_dividendaccumulations") != null ? formContext.getControl("kofc_dividendaccumulations").setVisible(false) : "";
                formContext.getControl("kofc_divdeathbenefit") != null ? formContext.getControl("kofc_divdeathbenefit").setVisible(false) : "";
                formContext.getControl("kofc_dividendvalue") != null ? formContext.getControl("kofc_dividendvalue").setVisible(false) : "";
                formContext.getControl("kofc_ffb_os") != null ? formContext.getControl("kofc_ffb_os").setVisible(false) : "";
                formContext.getControl("kofc_increaseincashvalue") != null ? formContext.getControl("kofc_increaseincashvalue").setVisible(false) : "";
                formContext.getControl("kofc_lastannivdividend") != null ? formContext.getControl("kofc_lastannivdividend").setVisible(false) : "";
                formContext.getControl("kofc_addldeathbenefit") != null ? formContext.getControl("kofc_addldeathbenefit").setVisible(false) : "";
                formContext.getControl("kofc_anniversarycashvalue") != null ? formContext.getControl("kofc_anniversarycashvalue").setVisible(false) : "";

                formContext.getControl("kofc_currpaidupadditions") != null ? formContext.getControl("kofc_currpaidupadditions").setVisible(false) : "";
                formContext.getControl("kofc_currentdividend") != null ? formContext.getControl("kofc_currentdividend").setVisible(false) : "";
                formContext.getControl("kofc_annuityplans") != null ? formContext.getControl("kofc_annuityplans").setVisible(false) : "";
                formContext.getControl("kofc_viewofsettlementoptionforjoint_os") != null ? formContext.getControl("kofc_viewofsettlementoptionforjoint_os").setVisible(false) : "";
                formContext.getControl("kofc_paymentfrequency") != null ? formContext.getControl("kofc_paymentfrequency").setVisible(false) : "";
                formContext.getControl("kofc_res117") != null ? formContext.getControl("kofc_res117").setVisible(false) : "";
                formContext.getControl("kofc_res149") != null ? formContext.getControl("kofc_res149").setVisible(false) : "";
                formContext.getControl("kofc_polaplind") != null ? formContext.getControl("kofc_polaplind").setVisible(false) : "";
                formContext.getControl("kofc_tobaccoindicator_os") != null ? formContext.getControl("kofc_tobaccoindicator_os").setVisible(false) : "";

                formContext.getControl("kofc_valuesasoflastanniversary") != null ? formContext.getControl("kofc_valuesasoflastanniversary").setVisible(false) : "";
                formContext.getControl("kofc_netcostamount") != null ? formContext.getControl("kofc_netcostamount").setVisible(false) : "";
                formContext.getControl("kofc_netforyear") != null ? formContext.getControl("kofc_netforyear").setVisible(false) : "";
                formContext.getControl("kofc_principalamount") != null ? formContext.getControl("kofc_principalamount").setVisible(false) : "";
            }

        }
    }
    catch (error) {
        Xrm.Navigation.openAlertDialog('Error in ShowHideFieldsForLineOfBusiness: ' + (error.description || error.message));
    }
}

//Function to Show Hide Policy XML button based on the Role US#19991
//Author: Susmitha Thokala on 8/21/2024
//updated: Sai Mukka, 10/15/2024 US#25051

async function EnablePolicyXMLButton(PrimaryControl) {
    "use strict";
    return new Promise(function (resolve, reject) {
        var userId = Xrm.Utility.getGlobalContext().userSettings.userId.replace(/[{}]/g, "");
        var hasRole = false;
        //get home office navigator role code from user
        Xrm.WebApi.online.retrieveRecord("systemuser", userId, "?$select=kofc_homeofficenavigatorrole").then(

            function success(result) {
                var hoNavRole = result.kofc_homeofficenavigatorrole;
                // Check if user has 'kc60' role code with optionSet value
                if (hoNavRole !== null && hoNavRole !== undefined && hoNavRole === 258510000) {
                    var roles = Xrm.Utility.getGlobalContext().userSettings.roles;
                    if (roles !== null && roles !== undefined) {
                        // Check if the current user has the home office navigator role
                        roles.forEach(function (item) {
                            if (item.name && item.name.toLowerCase() === "home office navigator role") {
                                hasRole = true;
                            }
                        });
                    }
                    return resolve(hasRole);
                }
                else {
                    return resolve(hasRole);
                }
            },

            function (error) {
                console.error('Error retrieving user information: ', error.message);
                return reject(hasRole);
            });
    }
    );
}



//Function to download xml/ini files on click US#18037
//Author: Sai Mukka on 09/18/2024

function CallSnowflakeEnvVar(PrimaryControl) {
    "use strict";
    GetEnvironmentVariableValueForPolicyXML("kofc_NavigatorIntfunctionURL", PrimaryControl);
}

//Function to get the environment variable value for agent portal API by environment
async function GetEnvironmentVariableValueForPolicyXML(name, PrimaryControl) {
    "use strict";
    let results = await Xrm.WebApi.retrieveMultipleRecords("environmentvariabledefinition", "?$select=defaultvalue&$filter=schemaname eq '" + name + "'");
    if (!results || !results.entities || results.entities.length < 1) return null;
    let url = results.entities[0]['defaultvalue'];
    if (url) {

        onPolicyXMLButtonClick(PrimaryControl, url);
    }
}


function onPolicyXMLButtonClick(PrimaryControl, url) {
    Xrm.Utility.showProgressIndicator("Processing Request... Please Wait.");

    let formContext = Xrm.Page.data.entity;
    //getting Policy Number and Country Code
    let policyNumber = formContext.attributes.get("kofc_policynumber")?.getValue();
    let countryCode = formContext.attributes.get("kofc_issuecountry")?.getText();
     let sourceSystem = formContext.attributes.get("kofc_sourcename")?.getValue();

    //display pop up if country code not found
    if (!countryCode) {
        Xrm.Utility.closeProgressIndicator();
        Xrm.Navigation.openAlertDialog("Issue Country is empty.\n Please assign a Policy Issue Country and try again!");
        return;
    }
    
    if (!sourceSystem) {
        Xrm.Utility.closeProgressIndicator();
        Xrm.Navigation.openAlertDialog("Source System is missing.\n Please assign a Source Issue System and try again!");
        return;
    }
    
     const source = mapSource(sourceSystem);


    //append Country code to policy nummber
    let reqPolicyNumber = policyNumber;
    if (countryCode === "US") {
        reqPolicyNumber = '01' + policyNumber;
    } else if (countryCode === "Canada") {
        reqPolicyNumber = '50' + policyNumber;
    } else {
        Xrm.Utility.closeProgressIndicator();
        Xrm.Navigation.openAlertDialog("Invalid Country Code!\n Please assign valid country code and try again!");
        return;
    }

    //append request type and policy number to generate requestURL
    var reqUrl = `${url}&type=policy&policyNo=${reqPolicyNumber}&sourceSystem=${source}`;


    var requestOptions = {
        method: "GET",
        headers: {
            "Content-Type": "application/json; charset=utf-8",
            "Accept": "application/json",
        }
    };

    fetch(reqUrl, requestOptions)
        .then(response => {
            if (!response.ok) {
                if (response.status === 404) {
                    Xrm.Utility.closeProgressIndicator();
                    Xrm.Navigation.openAlertDialog("Policy Not Found.");
                    throw new Error(": Policy Not Found");
                }
                Xrm.Utility.closeProgressIndicator();
                Xrm.Navigation.openAlertDialog(": Failed to fetch response!");
                throw new Error(": Failed to fetch response!");
            }
            return response.json();
        })
        .then(responseData => {
            if (!responseData) {
                Xrm.Utility.closeProgressIndicator();
                Xrm.Navigation.openAlertDialog(`No response from API.`);
                return;
            }

            const indicator = responseData.indicator;
            const Content = responseData.data;

            if (!indicator && !Content) {
                //to be integrated with Nav XML file download
                Xrm.Utility.closeProgressIndicator();
                Xrm.Navigation.openAlertDialog("Illustration System : NAVIGATOR\n  This functionality is not yet available. Build in progress !!");
                return;
            } else {
                switch (indicator) {
                    case "TKIS":
                        showPolicyXMLDownloadDialogBox(Content);
                        break;

                    case "Navigator":
                        reqUrl += "&operation=inforceXML";

                        fetch(reqUrl, requestOptions)
                            .then(navResponse => {
                                if (!navResponse.ok) {
                                    Xrm.Utility.closeProgressIndicator();
                                    Xrm.Navigation.openAlertDialog("Failed to fetch Navigator XML.");
                                    throw new Error("Failed to fetch Navigator XML");
                                }
                                return navResponse.text(); // Get XML as text
                            })
                            .then(xmlContent => {
                                showPolicyXMLDownloadDialogBox(xmlContent, policyNumber); // Pass XML content to download dialog
                            })
                            .catch(error => {
                                Xrm.Utility.closeProgressIndicator();
                                console.error("Error fetching Navigator XML:", error);
                            });
                        break;

                    case "DO NOT ILLUSTRATE":
                        Xrm.Utility.closeProgressIndicator();
                        Xrm.Navigation.openAlertDialog("Policy cannot be illustrated.");
                        break;
                    default:
                        Xrm.Utility.closeProgressIndicator();
                        Xrm.Navigation.openAlertDialog(`Unknown illustrate type found: ${policyIndicator}, Expected types : 'TKIS/Navigator/DNI'.`);
                        break;
                }
            }
        })
        .catch(error => {
            Xrm.Utility.closeProgressIndicator();
            throw new Error(`: Failed to fetch response! ${error.message}`);
        });
};



function showPolicyXMLDownloadDialogBox(iniContent) {
    var confirmStrings = {
        text: "Please click to download TKIS policy illustration file!",
        title: "Download Instructions!",
        confirmButtonLabel: "Download",
        cancelButtonLabel: "Cancel"
    };
    var confirmationOptions = { height: 100, width: 350 };

    Xrm.Utility.closeProgressIndicator();
    Xrm.Navigation.openConfirmDialog(confirmStrings, confirmationOptions).then(
        function (choice) {
            if (choice.confirmed) {
                downloadIniFile(iniContent);
            }
        });
}

//Function to download xml file on click US#17361
//Author: Rejoy Jacob on 11/04/24

// Dialog Box for .xml files
function showPolicyXMLDownloadDialogBox(xmlContent, policyNumber) {
    var confirmStrings = {
        text: "Please click to download the policy XML file!",
        title: "Download Policy XML",
        confirmButtonLabel: "Download XML",
        cancelButtonLabel: "Cancel"
    };
    var confirmationOptions = { height: 100, width: 350 };

    Xrm.Utility.closeProgressIndicator();
    Xrm.Navigation.openConfirmDialog(confirmStrings, confirmationOptions).then(
        function (choice) {
            if (choice.confirmed) {
                downloadPolicyXMLFile(xmlContent, policyNumber);
            }
        }
    );
}

// Function to handle the download of the .xml file

function downloadPolicyXMLFile(content, policyNumber) {

    const cleanedContent = content.replace(/\\n/g, "").replace(/\\r/g, "").replace(/^"|"$/g, "");
    const blob = new Blob([cleanedContent], { type: "application/xml" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${policyNumber}.xml`;
    a.click();
    window.URL.revokeObjectURL(url);
}


var POLICY_DETAILS_HTML = "kofc_policy_details.html";

/**
 * Non-Header button — validate fields, open HTML details page (Boomi inside page).
 * Second argument (isBoomi) kept for ribbon backward compatibility; ignored.
 */
async function ShowNonHeaderDetails(executionContext, isBoomi) {
    var formContext = executionContext;

    var policyNumber = formContext.getAttribute("kofc_policynumber")?.getValue();
    var policyClassification = formContext.getAttribute("kofc_policyclassification")?.getValue();
    var sourceSystem = formContext.getAttribute("kofc_sourcename")?.getValue();
    var issueCountry = formContext.getAttribute("kofc_issuecountry")?.getValue();

    var allowedValues = ["Ingenium", "DI", "LTC", "L70"];
    var missingFields = [];

    if (!policyNumber || String(policyNumber).trim() === "") {
        missingFields.push("Policy Number");
    }
    if (issueCountry === null || issueCountry === undefined) {
        missingFields.push("Issue Country");
    }
    if (policyClassification === null || policyClassification === undefined) {
        missingFields.push("Policy Classification");
    }
    if (!sourceSystem || String(sourceSystem).trim() === "" || allowedValues.indexOf(String(sourceSystem).trim()) < 0) {
        missingFields.push("Source Name (Allowed values - Ingenium, LTC, DI, L70)");
    }

    if (missingFields.length > 0) {
        await Xrm.Navigation.openAlertDialog({
            confirmButtonLabel: "OK",
            text: "Below fields are either empty or Invalid. Please contact system administrator.\n\n" + missingFields.join("\n"),
            title: "Validation Error"
        });
        return;
    }

    var entityLogicalName = formContext.data.entity.getEntityName();
    var recordId = formContext.data.entity.getId().replace(/[{}]/g, "");

    await openPolicyDetailsHtmlPage({
        entityLogicalName: entityLogicalName,
        recordId: recordId
    });
}

async function openPolicyDetailsHtmlPage(options) {
    try {
        var gc = Xrm.Utility.getGlobalContext();
        var clientUrl = gc.getClientUrl();
        var appProps = await gc.getCurrentAppProperties();

        var url = clientUrl + "/main.aspx?appid=" + encodeURIComponent(appProps.appId)
            + "&pagetype=webresource"
            + "&webresourceName=" + encodeURIComponent(POLICY_DETAILS_HTML)
            + "&etn=" + encodeURIComponent(options.entityLogicalName)
            + "&id=" + encodeURIComponent(options.recordId);

        window.open(url, "_blank");
    } catch (e) {
        Xrm.Navigation.openAlertDialog({
            text: "Failed to open policy details page. " + (e.message || e)
        });
    }
}


// ADO Item: 51210
// Author: Veera Kolan
// Date: 03/30/2026
// Description: Updated environment variable handling to use a centralized,
// reusable helper method that resolves Current Value first with Default Value fallback
// to ensure consistent behavior across environments.

async function getEnvironmentVariableCurrentValue(schemaName) {
    "use strict";

    const query =
        "?$select=defaultvalue" +
        "&$filter=schemaname eq '" + schemaName + "'" +
        "&$expand=environmentvariabledefinition_environmentvariablevalue($select=value)";

    const result = await Xrm.WebApi.retrieveMultipleRecords(
        "environmentvariabledefinition",
        query
    );

    if (!result || !result.entities || result.entities.length < 1) {
        return null;
    }

    const definition = result.entities[0];

    // Prefer current value, fallback to default
    return definition.environmentvariabledefinition_environmentvariablevalue?.length
        ? definition.environmentvariabledefinition_environmentvariablevalue[0].value
        : definition.defaultvalue;
}


//Susmitha Thokala
 function mapSource(sourceName) {

        switch ((sourceName || "").trim()) {

            case "Ingenium":
            case "ING":
                return "ING";

            case "Life 70":
            case "L70":
                return "L70";

            case "LTC":
                return "LTC";

            case "DI":
                return "DI";

            default:
                return "ING";
        }
    }