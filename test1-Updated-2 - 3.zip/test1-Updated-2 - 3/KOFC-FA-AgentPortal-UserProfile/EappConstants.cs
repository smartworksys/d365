﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KOFC_FA_AgentPortal_UserProfile
{
    public class EappConstants
    {
        public static Dictionary<string, string> userRoleCode = new Dictionary<string, string>
         {
                 { "Insurance-Field Agent",   "KC20" },
                 { "Insurance-General Agent",  "KC10" },
                 { "Insurance-Assistant General Agent",  "KC30" },
                 { "Insurance-Agency Admin",  "KC40" },
                 { "Insurance-Field Agent Assistant", "KC50" },
                 { "Insurance-AgencyAdmin", "KC60" },
                 //{ "Basic User", "KC20" },
    };

        public static Dictionary<string, string> userRoleType = new Dictionary<string, string>
         {
                 { "KC20",   "isFieldAgent" },
                 { "KC10",  "isGeneralAgent" },
                 { "KC30",  "isAssistantGeneralAgent" },
                 { "KC40",  "isFieldAssistant" },
                 { "KC50", "isFieldAssistant" },
                 { "KC60", "isAdmin" },
    };

    }
}
