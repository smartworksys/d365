using Microsoft.PowerPlatform.Dataverse.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace KOFC_FA_AgentPortal_UserProfile.Services;

public sealed class DataverseServiceAdapter : IDataverseService
{
    private readonly ServiceClient _serviceClient;

    public DataverseServiceAdapter(ServiceClient serviceClient)
    {
        _serviceClient = serviceClient;
    }

    public Guid CallerId
    {
        get => _serviceClient.CallerId;
        set => _serviceClient.CallerId = value;
    }

    public EntityCollection RetrieveMultiple(QueryBase query) =>
        _serviceClient.RetrieveMultiple(query);

    public OrganizationResponse Execute(OrganizationRequest request) =>
        _serviceClient.Execute(request);
}
