using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace KOFC_FA_AgentPortal_UserProfile.Services;

public interface IDataverseService
{
    Guid CallerId { get; set; }

    EntityCollection RetrieveMultiple(QueryBase query);

    OrganizationResponse Execute(OrganizationRequest request);
}
