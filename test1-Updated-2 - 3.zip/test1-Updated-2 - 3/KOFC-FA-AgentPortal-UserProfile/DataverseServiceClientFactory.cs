using Azure.Core;
using Azure.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;

namespace KOFC_FA_AgentPortal_UserProfile;

public static class DataverseServiceClientFactory
{
    public static ServiceClient Create(ILogger logger)
    {
        var crmUrl = Environment.GetEnvironmentVariable("CRM_URL")
            ?? throw new InvalidOperationException("CRM_URL is not configured.");

        var dataverseUri = new Uri(crmUrl);
        var credential = new DefaultAzureCredential();
        var scope = $"{dataverseUri.GetLeftPart(UriPartial.Authority)}/.default";

        var serviceClient = new ServiceClient(
            dataverseUri,
            async _ =>
            {
                var token = await credential.GetTokenAsync(
                    new TokenRequestContext(new[] { scope }),
                    CancellationToken.None);
                return token.Token;
            },
            useUniqueInstance: true);

        if (!serviceClient.IsReady)
        {
            logger.LogError("Failed to connect to CRM: {Error}", serviceClient.LastError);
            throw new InvalidOperationException($"Failed to connect to CRM: {serviceClient.LastError}");
        }

        return serviceClient;
    }
}
