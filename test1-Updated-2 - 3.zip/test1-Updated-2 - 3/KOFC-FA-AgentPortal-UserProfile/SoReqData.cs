﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KOFC_FA_AgentPortal_UserProfile
{
    public class SoReqData
    {
        public string reqAction { get; set; } = string.Empty;
        public string gmtStamp { get; set; } = string.Empty;
        public string agentId { get; set; } = string.Empty;

        public string loginUserID { get; set; } = string.Empty;

        public string clientId { get; set; } = string.Empty;
        public string clientDob { get; set; } = string.Empty;
        public bool isAdmin { get; set; }
        public bool isSysAdmin { get; set; }
        public bool isGeneralAgent { get; set; }
        public bool isGeneralAssistant { get; set; }
        public bool isAssistantGeneralAgent { get; set; }
        public bool isFieldAgent { get; set; }
        public bool isFieldAssistant { get; set; }
    }
}
