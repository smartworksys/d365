namespace KOFC_FA_AgentPortal_UserProfile.Helpers;

/// <summary>
/// Maps Dataverse insurance role labels/codes to EApp SoReq role flags.
/// </summary>
public static class EappRoleMapper
{
    public static string ResolveRoleType(string? roleLabelOrCode)
    {
        var roleCodeKey = roleLabelOrCode ?? string.Empty;
        if (EappConstants.userRoleCode.TryGetValue(roleCodeKey, out var mappedCode))
        {
            roleCodeKey = mappedCode;
        }

        return EappConstants.userRoleType.TryGetValue(roleCodeKey, out var roleType)
            ? roleType
            : string.Empty;
    }

    public static void ApplyRoleFlags(SoReqData soReq, string roleType)
    {
        switch (roleType)
        {
            case "isFieldAgent":
                soReq.isFieldAgent = true;
                break;
            case "isGeneralAgent":
                soReq.isGeneralAgent = true;
                break;
            case "isAssistantGeneralAgent":
                soReq.isAssistantGeneralAgent = true;
                break;
            case "isFieldAssistant":
                soReq.isFieldAssistant = true;
                break;
            case "isAdmin":
                soReq.isAdmin = true;
                break;
        }
    }
}
