using System.Linq;
using KOFC_FA_AgentPortal_UserProfile;
using KOFC_FA_AgentPortal_UserProfile.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;

var host = new HostBuilder()
    .ConfigureFunctionsWebApplication()
    .ConfigureServices(services =>
    {
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();
        // Scoped so CallerId impersonation is isolated per function invocation.
        services.AddScoped<ServiceClient>(sp =>
            DataverseServiceClientFactory.Create(
                sp.GetRequiredService<ILogger<ServiceClient>>()));
        services.AddScoped<IDataverseService, DataverseServiceAdapter>();
    })
    .ConfigureLogging(logging =>
    {
        // In the .NET isolated worker, the Application Insights logger provider ships with a
        // default filter that only forwards Warning+ to App Insights, so LogInformation calls
        // appear in Log Stream/Live Metrics but not in the 'traces' table. Remove that rule so
        // Information logs are exported. (host.json still governs the host-side log levels.)
        logging.Services.Configure<LoggerFilterOptions>(options =>
        {
            var defaultRule = options.Rules.FirstOrDefault(rule =>
                rule.ProviderName == "Microsoft.Extensions.Logging.ApplicationInsights.ApplicationInsightsLoggerProvider");
            if (defaultRule is not null)
            {
                options.Rules.Remove(defaultRule);
            }
        });
    })
    .Build();

host.Run();
