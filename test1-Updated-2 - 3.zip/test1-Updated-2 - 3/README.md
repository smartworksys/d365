# KOFC CRM Integrations

Dynamics 365 integrations for **EApp SSO** (Opportunity form) and **Policy Non-Header Tier One** (Policy form), brokered through **Boomi** and **Azure Functions**.

Both flows use the same **two-token model**: the browser sends a **delegated MSAL token** to Boomi; Boomi calls the Function with a **client-credentials token** (app roles). User identity for Dataverse impersonation is passed as **`userId`** (Dataverse `systemuserid` GUID), not by forwarding the user's Bearer token to the Function.

## Documentation

| Document | Format | Description |
|----------|--------|-------------|
| [KOFC-EApp-SSO-Architecture.wiki.md](docs/KOFC-EApp-SSO-Architecture.wiki.md) | Markdown | EApp SSO Function App architecture, MSAL/Boomi flow, env vars, deployment |
| [KOFC-EApp-SSO-Architecture.docx](docs/KOFC-EApp-SSO-Architecture.docx) | Word | Generated from the EApp wiki |
| [KOFC-EApp-SSO-FunctionApp-Design.docx](docs/KOFC-EApp-SSO-FunctionApp-Design.docx) | Word | End-to-end EApp design document |
| [KOFC-PolicyNonHeader-TierOne-Architecture.wiki.md](docs/KOFC-PolicyNonHeader-TierOne-Architecture.wiki.md) | Markdown | Policy Non-Header Function App, HTML details page, `userId` / `policyRecordId` API |
| [KOFC-PolicyNonHeader-TierOne-Architecture.docx](docs/KOFC-PolicyNonHeader-TierOne-Architecture.docx) | Word | Generated from the Policy wiki |
| [Postman collection](docs/postman/KOFC-PolicyNonHeader-TierOne.postman_collection.json) | Postman | `getPolicyData` requests (client-credentials auth) |
| [Postman environment](docs/postman/KOFC-PolicyNonHeader-TierOne.postman_environment.json) | Postman | DEV template (`userId`, `policyRecordId`, etc.) |

Regenerate Word files from markdown:

```powershell
python docs\_build_docx.py
python docs\_build_policy_docx.py
python docs\generate_design_doc.py
```

## Repository layout

| Path | Purpose |
|------|---------|
| `KOFC-FA-AgentPortal-UserProfile/` | EApp SSO Azure Function (`getSOReqForEappSSO`) |
| `KOFC-FA-PolicyNonHeader-TierOne/` | Policy Non-Header Azure Function (`getPolicyData`) |
| `webresources/eapp-boomi-button/` | Shared auth client, callback page, Opportunity form updates |
| `webresources/policy-nonheader/` | Policy form script, HTML details page, `KOFC.Policy` client |

## D365 environment variables

**EApp:** `kofc_EappTenantId`, `kofc_EappClientId`, `kofc_EappApiAppId`, `kofc_EappApiKey`, `kofc_EappIntfunctionURL`, `kofc_EappURL`

**Policy Non-Header:** `kofc_PolicyTenantId`, `kofc_PolicyClientId`, `kofc_PolicyApiAppId`, `kofc_PolicyApiKey`, `kofc_PolicyBoomiUrl`
