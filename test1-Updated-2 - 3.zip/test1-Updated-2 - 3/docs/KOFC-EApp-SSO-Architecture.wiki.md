# KOFC Agent Portal – EApp SSO Function App Architecture

> **Solution:** `KOFC-FA-AgentPortal-UserProfile`
> **Function:** `getSOReqForEappSSO`
> **Runtime:** .NET 8 (Isolated), Azure Functions v4
> **Last updated:** 2026-07-22 (release **1.2.0**)

[[_TOC_]]

---

## 1. Overview

The EApp SSO Function App exposes a secure HTTP API that returns an agent's profile, role, and (optionally) linked client/opportunity data from **Microsoft Dataverse**. It is triggered from a **Dynamics 365** command-bar button, brokered through **Boomi**, and enforces **per-user Dataverse security** via impersonation.

**Key characteristics**

- **User sign-in (browser):** the Opportunity form dynamically loads **`kofc_authclient.js`** (`KOFC.Auth`), reads auth settings from **environment variables**, acquires a **delegated user token** via MSAL.js (scope `api://<FUNCTION_API_APP_ID>/access_as_user`), and sends it — plus `x-api-key`, `userId`, `oppID` — to Boomi. On first sign-in, a full-page redirect through **`kofc_authcallback.html`** auto-completes the Boomi call and opens EApp.
- **Inbound auth (to Function):** Azure App Service **Easy Auth** validates the OAuth bearer token. In production, Boomi calls the Function with its **own client-credentials token** carrying the app roles.
- **App-role authorization:** the Function requires the **`Contact.Read`** app role on every call and **`Opportunity.Read`** when `oppID` is supplied.
- **Outbound auth:** **Managed Identity** + `DefaultAzureCredential` acquires the Dataverse token (no secrets in code).
- **Per-user security:** `ServiceClient.CallerId` impersonation applies the calling user's CRM privileges.
- **Concurrency-safe:** `ServiceClient` is registered **Scoped** (per invocation) to isolate impersonation.
- **Response:** Base64-encoded JSON for downstream EApp consumption.

> **Two-token model.** The browser's delegated token (`scp = access_as_user`) authenticates the *user* to Boomi. Boomi then calls the Function using a **client-credentials** token whose **`roles`** claim satisfies the Function's app-role check. The user's identity flows onward as the **`userId`** parameter (a Dataverse `systemuserid`) used for impersonation.

---

## 2. Identities & App Registrations

There are **three Entra ID app registrations** plus the **Function App Managed Identity**.

| # | Identity | Type | Secret? | Purpose |
|---|----------|------|---------|---------|
| 1 | **SPA (D365 button)** | App registration (public client / SPA) | No | Browser sign-in via MSAL.js; acquires the **delegated user token** (`access_as_user`) |
| 2 | **Boomi client** | App registration (confidential client) | **Yes** (or cert) | Boomi uses **client credentials** to get a token **to call** the Function; token carries the app **roles** |
| 3 | **Function App API** | App registration (resource) | No | Defines the `access_as_user` scope + the `Contact.Read` / `Opportunity.Read` **app roles**; Easy Auth validates tokens issued **for** this API |
| 4 | **Function App Managed Identity** | System-assigned MI | No | Function App acquires a token **to call Dataverse** |

> Easy Auth is **not** a separate app registration — it is middleware on the Function App configured to trust app registration **#3**.

### 2.1 App roles (on the Function API registration)

| App role (value) | Required when | Present in which token |
|------------------|---------------|------------------------|
| `Contact.Read` | Every call | Boomi client-credentials token (`roles`) |
| `Opportunity.Read` | `oppID` is provided | Boomi client-credentials token (`roles`) |

> App roles appear in the **`roles`** claim. A **delegated** SPA token contains **`scp`** (e.g. `access_as_user`), **not** `roles` — which is why the browser token is not used to call the Function directly. If app roles are assigned to **users** (member type Users/Groups), a delegated token *can* carry `roles`, but the production design uses the Boomi client-credentials token.

### 2.2 SPA redirect URIs (Entra → Authentication → Single-page application)

| Consumer | Redirect URI |
|----------|--------------|
| Production button | `https://<org>.crm.dynamics.com/WebResources/kofc_authcallback.html` |

---

## 3. High-Level Architecture

::: mermaid
flowchart LR
    subgraph D365["Dynamics 365"]
        BTN["Command-bar button<br/>kofc_authclient.js<br/>(MSAL.js)"]
        CB["kofc_authcallback.html<br/>(redirect URI)"]
    end

    subgraph BOOMI["Boomi Integration"]
        PROC["Process<br/>OAuth client credentials<br/>client ID + secret"]
    end

    subgraph AZURE["Azure"]
        EA["Easy Auth<br/>(validates token)"]
        FA["Function App<br/>getSOReqForEappSSO"]
        MI["Managed Identity"]
    end

    DV[("Microsoft<br/>Dataverse")]
    AAD["Microsoft Entra ID"]

    BTN -->|MSAL: access_as_user| AAD
    AAD -->|delegated user token| CB
    CB -.->|token| BTN
    BTN -->|Bearer user token + x-api-key<br/>userId, oppID| PROC
    PROC -->|client credentials| AAD
    AAD -->|app token<br/>roles = Contact.Read...| PROC
    PROC -->|request:<br/>Bearer app token + params| EA
    EA --> FA
    FA -->|role check: Contact.Read / Opportunity.Read| FA
    FA -->|GetToken| MI
    MI -->|token request| AAD
    AAD -->|access token| MI
    FA -->|CallerId = userId<br/>RetrieveMultiple| DV
    DV -->|user / opp / contact| FA
    FA -.->|response:<br/>Base64 JSON| PROC
    PROC -.->|response| BTN
:::

> **Two tokens, one inbound path.** The browser acquires a **delegated** token to authenticate the user to Boomi; Boomi swaps it for a **client-credentials** app token (carrying `roles`) to call the Function via Easy Auth. Dashed arrows are responses, not additional auth routes.

---

## 4. Authentication Layers

The solution uses **two independent auth layers**. They are **not** linked by token exchange.

| Layer | Direction | Mechanism | Identity | Purpose |
|-------|-----------|-----------|----------|---------|
| Inbound | Boomi → Function | Easy Auth + `ClaimsPrincipal` | Boomi app registration | Authorize API access |
| Outbound | Function → Dataverse | `DefaultAzureCredential` | Function App Managed Identity | Acquire Dataverse token |
| Impersonation | Function → Dataverse | `ServiceClient.CallerId` | Dataverse `systemuser` (`userId`) | Enforce per-user CRM security |

::: mermaid
flowchart TB
    T1["Boomi OAuth token<br/>client credentials<br/><i>audience = Function App API</i>"] --> Q1{"Is caller<br/>allowed to hit<br/>the API?"}
    Q1 -->|Easy Auth| OK1["ClaimsPrincipal.IsAuthenticated"]

    T2["Managed Identity token<br/><i>audience = Dataverse</i>"] --> Q2{"Is the app<br/>allowed to reach<br/>Dataverse?"}
    Q2 -->|DefaultAzureCredential| OK2["ServiceClient connected"]

    OK2 --> IMP["CallerId = userId"]
    IMP --> Q3{"Does THIS user<br/>have access to<br/>the record?"}
    Q3 -->|Privilege intersection| OK3["Data returned or 403/empty"]
:::

---

## 5. End-to-End Sequence

::: mermaid
sequenceDiagram
    autonumber
    participant U as D365 User (button)
    participant JS as JS Web Resource
    participant B as Boomi
    participant EA as Easy Auth
    participant FA as Function App
    participant AAD as Entra ID
    participant DV as Dataverse

    U->>JS: Click button
    JS->>AAD: MSAL acquire token<br/>(scope access_as_user)
    AAD-->>JS: Delegated user token (scp)
    JS->>B: Bearer user token + x-api-key<br/>userId, oppID
    B->>AAD: Client credentials<br/>(client ID + secret)
    AAD-->>B: App token (aud = Function API, roles)
    B->>EA: request: GET/POST + Bearer app token + params
    EA->>EA: Validate token (sig, exp, aud, iss)
    EA->>FA: Forward request + ClaimsPrincipal
    FA->>FA: IsAuthenticated() check
    FA->>FA: Require Contact.Read (roles)
    FA->>FA: Validate userId (GUID), oppID (GUID)
    FA->>FA: If oppID: require Opportunity.Read
    FA->>FA: CallerId = userId
    FA->>AAD: GetToken (Managed Identity)
    AAD-->>FA: Dataverse access token
    FA->>DV: RetrieveMultiple systemuser (impersonated)
    DV-->>FA: Agent profile + role
    opt oppID provided
        FA->>DV: RetrieveMultiple opportunity + contact
        DV-->>FA: clientId, clientDob (if permitted)
    end
    FA->>FA: Serialize -> Base64
    FA-->>B: response: Base64 JSON
    B-->>JS: Response
    JS-->>U: EApp SSO continues
:::

---

## 6. Request Processing Logic

::: mermaid
flowchart TD
    START([Request received]) --> AUTH{IsAuthenticated?}
    AUTH -->|No| E401[401 Unauthorized]
    AUTH -->|Yes| RC{Has Contact.Read role?}
    RC -->|No| E403a[403 Forbidden]
    RC -->|Yes| VUSER{Valid userId GUID?}
    VUSER -->|No| E400a[400 Bad Request]
    VUSER -->|Yes| VOPP{oppID valid or absent?}
    VOPP -->|No| E400b[400 Bad Request]
    VOPP -->|Yes| ROPP{oppID set and<br/>Opportunity.Read?}
    ROPP -->|Missing role| E403b[403 Forbidden]
    ROPP -->|OK| IMP[Set CallerId = userId]
    IMP --> QUSER[Query systemuser]
    QUSER --> FOUND{User found?}
    FOUND -->|No| E404[404 Not Found]
    FOUND -->|Yes| ROLE{Has insurance role?}
    ROLE -->|No| E400c[400 Bad Request]
    ROLE -->|Yes| MAP[Map role -> EApp flags]
    MAP --> HASOPP{oppID provided?}
    HASOPP -->|No| BUILD[Build SoReqData]
    HASOPP -->|Yes| QOPP[Query opportunity + contact]
    QOPP --> BUILD
    BUILD --> ENC[Base64 encode JSON]
    ENC --> OK200[200 OK]
    QUSER -.privilege fault.-> E403[403 Forbidden]
    QOPP -.privilege fault.-> E403
    IMP -.finally.-> RESET[CallerId = Guid.Empty]
:::

---

## 7. Component Model

| Source File | Component | Responsibility |
|-------------|-----------|----------------|
| `Program.cs` | DI Host | Registers **scoped** `ServiceClient` per invocation |
| `DataverseServiceClientFactory.cs` | CRM Client Factory | Creates `ServiceClient` with MI token callback |
| `EappSSO.cs` | HTTP Function | Auth check, **app-role check**, impersonation, FetchXML queries, response encoding |
| `EappConstants.cs` | Role Mapping | Maps insurance role codes to EApp role flags |
| `SoReqData.cs` | Response DTO | JSON structure returned to caller |
| `functionapp.json` | ARM Template | Provisions Function App with system-assigned MI |

### 7.1 Client web resources (Dynamics 365)

| Web resource | Folder | Responsibility |
|--------------|--------|----------------|
| `kofc_authclient.js` | `webresources/eapp-boomi-button/` | Reusable MSAL client: acquires token, calls Boomi with `Bearer` + `x-api-key` + `userId`/`oppID` (`KOFC.Auth.callBoomi` / `KOFC.Auth.openEapp`) |
| `kofc_authcallback.html` | `webresources/eapp-boomi-button/` | Reusable MSAL **redirect URI** page: completes redirect sign-in, calls the API, and opens the target URL |
| `kofc_msalbrowsermin` | `webresources/` | MSAL.js library (org-hosted; no file extension in D365 Name) |

---

## 8. API Specification

### 8.1 Endpoint

| Property | Value |
|----------|-------|
| Function name | `getSOReqForEappSSO` |
| Methods | `GET`, `POST` |
| Authorization level | `Anonymous` (platform auth via Easy Auth) |
| Response content type | `text/plain` (Base64-encoded JSON) |

### 8.2 Parameters

| Parameter | Required | Type | Description |
|-----------|----------|------|-------------|
| `userId` | Yes | GUID | Dataverse `systemuserid` to impersonate |
| `oppID` | No | GUID | Opportunity ID; returns linked contact data |

> Parameters are read from the **query string** (`req.Query`). If sent via POST, keep them on the query string — the request **body is not parsed**.

### 8.2.1 Required app roles

| Condition | Required role (`roles` claim) |
|-----------|-------------------------------|
| Every call | `Contact.Read` |
| `oppID` provided | `Opportunity.Read` (in addition) |

### 8.2.2 Request headers (Boomi front door)

| Header | Set by | Purpose |
|--------|--------|---------|
| `Authorization: Bearer <token>` | Caller | User token (SPA→Boomi) or app token (Boomi→Function) |
| `x-api-key` | D365 button | Boomi API gateway authentication |

### 8.3 Response fields (decoded JSON)

| Field | Type | Source |
|-------|------|--------|
| `reqAction` | string | Constant `"EAPP"` |
| `gmtStamp` | string | Generated timestamp |
| `agentId` | string | `systemuser.kofc_agentid` |
| `loginUserID` | string | `systemuser.kofc_user_ldap_id` |
| `clientId` | string | `contact.kofc_clientid` |
| `clientDob` | string | `contact.kofc_birthdate` |
| `isFieldAgent` / `isGeneralAgent` / `isAssistantGeneralAgent` / `isFieldAssistant` / `isAdmin` | bool | Role mapping |

### 8.4 Status codes

| Status | Condition |
|--------|-----------|
| `200 OK` | Success (Base64 JSON) |
| `400 Bad Request` | Invalid/missing `userId`, invalid `oppID`, or missing insurance role |
| `401 Unauthorized` | Easy Auth: caller not authenticated |
| `403 Forbidden` | Missing app role (`Contact.Read` / `Opportunity.Read`) **or** Dataverse privilege denied for impersonated user |
| `404 Not Found` | `systemuser` not found / not visible |

---

## 9. Role Code Mapping

| Role Label | Code | EApp Flag |
|------------|------|-----------|
| Insurance-Field Agent | KC20 | `isFieldAgent` |
| Insurance-General Agent | KC10 | `isGeneralAgent` |
| Insurance-Assistant General Agent | KC30 | `isAssistantGeneralAgent` |
| Insurance-Agency Admin | KC40 | `isFieldAssistant` |
| Insurance-Field Agent Assistant | KC50 | `isFieldAssistant` |
| Insurance-AgencyAdmin | KC60 | `isAdmin` |

---

## 9a. Dynamics 365 Command-Bar Button (Reusable Auth Client)

The EApp button on the Opportunity form uses a **reusable, modular auth client** (`kofc_authclient.js`, namespace **`KOFC.Auth`**) that is loaded **on demand** from the form script — it is **not** registered as a form library. Configuration is supplied at runtime via **`KOFC.Auth.configure({...})`**, with sensitive values read from **Dataverse environment variables**.

### 9a.1 Web resources

| Name (D365 web resource) | Display name (example) | Type | Purpose |
|--------------------------|------------------------|------|---------|
| `kofc_authclient.js` | KOFC Auth Client | Script (JScript) | Reusable MSAL + Boomi library (`KOFC.Auth`) |
| `kofc_authcallback.html` | KOFC Auth Callback | HTML | Generic MSAL redirect URI page; completes sign-in and auto-finishes pending actions |
| `kofc_msalbrowsermin` | MSAL Browser Library | Script (JScript) | MSAL.js (org-hosted; satisfies D365 CSP) |
| `kofc_Opportunity` (form script) | Opportunity Form Script | Script (JScript) | Button chain + env-var config + dynamic loader |

Reference snippet (copy into form script): `webresources/eapp-boomi-button/kofc_Opportunity-eapp-updates.js`

### 9a.2 Environment variables

Auth settings are stored as **Text** environment variables and read via the existing `getEnvironmentVariableCurrentValue(schemaName)` helper (ADO 51210).

| Schema name | Purpose |
|-------------|---------|
| `kofc_EappURL` | EApp base URL (already used; appended with `?soreq=<base64>`) |
| `kofc_EappIntfunctionURL` | Boomi REST endpoint — read as `boomiUrl` in `getAuthConfigFromEnvironment()` (`AUTH_ENV_VARS.boomiUrl`) |
| `kofc_EappTenantId` | Entra tenant (directory) ID |
| `kofc_EappClientId` | SPA app registration client ID |
| `kofc_EappApiAppId` | Function API app ID (builds scope `api://<id>/access_as_user`) |
| `kofc_EappApiKey` | Boomi `x-api-key` for the API gateway |

Static, non-secret settings remain in the form script (`AUTH_STATIC_CONFIG`): `scope`, `httpMethod`, `redirectWebResource`, `msalWebResourcePath`, `allowRedirect`, `debug`.

### 9a.3 Public API (`KOFC.Auth`)

| Method | Description |
|--------|-------------|
| `configure(options)` | Set/override config at runtime (required before use) |
| `openEapp(userId, oppId, eappUrl)` | Token → Boomi → open `eappUrl + "?soreq=<base64>"` in new tab |
| `callBoomiRaw(userId, oppId)` | Token → Boomi → returns raw Base64 response body |
| `getAccessToken()` | Returns delegated user access token only |
| `callBoomi(primaryControl)` | Ribbon entry point (alerts on success/failure) |
| `clearCache()` | Clears MSAL + pending localStorage (re-test first-time flow) |
| `getLogs()` / `dumpLogs()` / `clearLogs()` | Structured diagnostics (`CONFIG.debug = true`) |

### 9a.4 Token acquisition strategy

::: mermaid
flowchart TD
    CLICK([User clicks EApp button]) --> LOAD[loadAuthClient + configure from env vars]
    LOAD --> SILENT{Cached MSAL account?}
    SILENT -->|Yes| AT1[acquireTokenSilent]
    AT1 -->|OK| BOOMI[Call Boomi + open EApp]
    AT1 -->|Fail| SSO{Account or loginHint?}
    SILENT -->|No| SSO
    SSO -->|Yes| AT2[ssoSilent hidden iframe]
    SSO -->|No| REDIR[Skip ssoSilent]
    AT2 -->|OK| BOOMI
    AT2 -->|Fail| REDIR
    REDIR --> AT3[acquireTokenRedirect full page]
    AT3 --> CB[kofc_authcallback.html]
    CB --> HANDLE[handleRedirectPromise reads code]
    HANDLE --> PENDING{Pending action in localStorage?}
    PENDING -->|Yes| BOOMI2[Call Boomi + open EApp + return to form]
    PENDING -->|No| BACK[Return to Dynamics form]
    BOOMI --> DONE([EApp opens in new tab])
    BOOMI2 --> DONE
:::

1. **`acquireTokenSilent`** — MSAL cache (works after first sign-in; refresh token renews silently for ~24h).
2. **`ssoSilent`** — hidden iframe (only attempted when a cached account **or** `loginHint` is available; skipped otherwise to avoid `timed_out`).
3. **`acquireTokenRedirect`** — full-page redirect to Microsoft (when `allowRedirect: true`; default). The callback page (`kofc_authcallback.html`) reads the auth code, caches the token, calls Boomi, and opens EApp — **no second button click**.

> **First-time / daily renewal:** user sees a brief redirect through `kofc_authcallback.html` (Fluent UI spinner). **Subsequent clicks same day:** fully silent; EApp opens in a new tab.

### 9a.5 Opportunity form integration

Button chain (unchanged):

`OnClickEAppButton` → `CallEappEnvVar` → `GetEnvironmentVariableValueForEapp` → `GetEnvironmentVariableValueForEappIntFunctionApp` → `navigateToEapp` → **`callEappFunctionAPP`**

Updated `callEappFunctionAPP` (at bottom of form script):

```javascript
async function callEappFunctionAPP(userId, opportunityId, eappUrl, boomiIntegrationUrl) {
    await loadAuthClient();
    var authConfig = await getAuthConfigFromEnvironment(boomiIntegrationUrl);
    KOFC.Auth.configure(authConfig);
    await KOFC.Auth.openEapp(userId, opportunityId, eappUrl);
}
```

The library is injected dynamically:

```javascript
var AUTH_CLIENT_LIBRARY = "/WebResources/kofc_authclient.js";
// loadAuthClient() appends <script src=".../kofc_authclient.js">
```

> **Do not** register `kofc_authclient.js` as a form library unless you want eager loading. Dynamic loading keeps the form lightweight and allows reuse from other entities.

### 9a.6 Entra redirect URI

Register under the **SPA** app registration (`kofc_EappClientId`), character-for-character (case-sensitive):

```
https://<org>.crm.dynamics.com/WebResources/kofc_authcallback.html
```

The same callback page is reusable for any integration that uses `KOFC.Auth` with the same SPA client ID.

### 9a.7 Values sent to Boomi

`Authorization: Bearer <user token>`, `x-api-key: <key>`, and `?userId=<systemuserid>&oppID=<guid>` (POST also mirrors these in a JSON body).

Response: Base64-encoded JSON → appended to EApp URL as `?soreq=<base64>` → opened in new tab.

### 9a.8 Clear cache (re-test first-time flow)

From the form iframe console (select the form frame, not `top`):

```javascript
KOFC.Auth.clearCache()
```

Or open Dynamics in **InPrivate/Incognito**. To force the full Microsoft redirect again, also clear cookies for `login.microsoftonline.com`.

---

## 10. Security Design

### 10.1 Inbound (Boomi → Function)

- Easy Auth configured manually on the Function App (Entra ID provider).
- Boomi obtains an OAuth token (client credentials: client ID + secret, scope `api://<FUNCTION_API_APP_ID>/.default`) — the token's **`roles`** claim carries the granted app roles (admin-consented).
- The Function then enforces **app-role authorization**: `Contact.Read` on every call, `Opportunity.Read` when `oppID` is present.
- Function runtime auth level is `Anonymous`; platform enforces authentication.
- Local dev bypasses auth when `WEBSITE_SITE_NAME` is unset (and `GetCallerRoles` returns both roles).

### 10.1a Boomi gateway validation (browser → Boomi)

Before Boomi calls the Function, the **D365 browser** sends a **delegated user token** to Boomi. Boomi validates at the API gateway:

| Layer | What Boomi checks | What it proves |
|-------|-------------------|----------------|
| **`x-api-key`** | Header matches configured gateway key | Request is from the D365 integration |
| **`Authorization: Bearer`** | Entra JWT signature, issuer, audience, expiry, **`scp`** includes `access_as_user` | A signed-in user obtained a delegated token for the Function API app |

Boomi does **not** forward the user token to the Function. It swaps to a **client-credentials** token with **`Contact.Read`** / **`Opportunity.Read`** app roles and passes **`userId`** (and optional **`oppID`**) as query/body parameters for Dataverse impersonation.

The Opportunity form reads the Boomi URL from environment variable **`kofc_EappIntfunctionURL`** via `AUTH_ENV_VARS.boomiUrl` in `getAuthConfigFromEnvironment()` (see `kofc_Opportunity-eapp-updates.js`). The legacy `boomiIntegrationUrl` function parameter is used only as a fallback when the env var is empty.

### 10.2 Outbound (Function → Dataverse)

- System-assigned Managed Identity on the Function App.
- MI registered as an **Application User** in Power Platform.
- **Custom least-privilege role** recommended.
- **Act on Behalf of Another User** (`prvActOnBehalfOfAnotherUser`) assigned **directly** (not via team).

### 10.3 Recommended Dataverse role

| Privilege | Area | Level |
|-----------|------|-------|
| Act on Behalf of Another User | Business Management | Organization |
| Read | User (`systemuser`) | Appropriate depth |
| Read | Opportunity | As needed |
| Read | Contact | As needed |

> **Privilege intersection:** with `CallerId` set, effective access = **app user privileges ∩ impersonated user privileges**. Both must permit the action.

### 10.4 What is NOT used

| Mechanism | Reason |
|-----------|--------|
| Azure AD `user_impersonation` (delegated) | For OBO/user-token flows, not MI + `CallerId` |
| Boomi token pass-through to Dataverse | Token audience is Function App API, not Dataverse |
| `CRM_CLIENT_ID` / `CRM_CLIENT_SECRET` | Replaced by Managed Identity in code (legacy settings) |

### 10.5 Trust boundary & `userId`

The Function **does not correlate** the authenticated caller with the `userId` parameter — it trusts whoever passes the app-role check to specify any `systemuserid`. This is correct for the **trusted-subsystem** model (the app-only Boomi token has no user; identity is carried as the `userId` value established at SPA sign-in). Its safety depends on:

1. Only **Boomi** being able to reach the Function (network restriction), and
2. Boomi sending the **correct `systemuserid`** for the signed-in user.

> Note: the token user id (`oid`, an Entra object id) is **not** the Dataverse `systemuserid`. They are linked via `systemuser.azureactivedirectoryobjectid`. `CallerId` requires the `systemuserid`.

### 10.6 Recommended hardening

| # | Control | Effort | Priority |
|---|---------|--------|----------|
| 1 | **Network-restrict** the Function to Boomi only (Access Restrictions IP allow-list, or Private Endpoint / VNet). | Config | High |
| 2 | **Protect the Boomi credential** — prefer a certificate over a shared secret; store securely; set expiry + rotation. | Config | High |
| 3 | Keep layered auth (Easy Auth **and** a function/host key or `x-api-key`) so both network and token must pass. | Config | Medium |
| 4 | *(Optional, defense-in-depth)* On the delegated path only, derive `systemuserid` from the token `oid` (`azureactivedirectoryobjectid` lookup) instead of trusting the param. Not required if #1 holds. | Code | Low |

> **Client-side configuration:** auth settings (`tenantId`, `clientId`, `apiAppId`, `apiKey`) are stored in **Dataverse environment variables** and passed to `KOFC.Auth.configure()` at runtime. The `x-api-key` is still visible to form users in browser memory during the call — treat it as low-sensitivity, rotate it, and prefer having Boomi authorize on the bearer token when possible.

---

## 11. Infrastructure

| Resource | Value (dev example) |
|----------|---------------------|
| Function App | `KOFC-Dev-FA-Eapp-Integration` |
| Runtime | `dotnet-isolated`, Functions v4, .NET 8 |
| Identity | System-assigned Managed Identity |
| App Service Plan | `KOC-EUS-Premium-ASP` |
| Application Insights | `KOC-CRM-INTDEV-APPINS` |
| Key Vault | `KOC-CRM-KOCAZINTDEV1-KV` |
| Storage Account | `koccrmdevsa` |
| Resource Group | `KOC-CRM-DEV` |
| Location | East US |

**Key app settings:** `CRM_URL`, `APPLICATIONINSIGHTS_CONNECTION_STRING`, `AzureWebJobsStorage`, `FUNCTIONS_WORKER_RUNTIME=dotnet-isolated`, `FUNCTIONS_EXTENSION_VERSION=~4`.

---

## 12. Deployment Checklist

### 12.1 Azure Function App

1. Deploy Function App via ARM template / Azure DevOps pipeline.
2. Enable Managed Identity and note the Object (principal) ID.
3. Create the Application User in Dataverse linked to the MI.
4. Assign a security role with **Act on Behalf Of** + entity read privileges.
5. Configure Easy Auth on the Function App for the Boomi app registration.
6. Grant the Boomi app registration permission to call the Function App API.
7. Store `CRM_URL` in Key Vault and reference from app settings.
8. Validate connectivity and impersonation with test `userId` values.

### 12.2 Dynamics 365 web resources

1. Upload and publish **`kofc_authclient.js`** (Name must include `.js`).
2. Upload and publish **`kofc_authcallback.html`** (Name must include `.html`).
3. Confirm **`kofc_msalbrowsermin`** exists and loads at `/WebResources/kofc_msalbrowsermin`.
4. Update **`kofc_Opportunity`** form script with changes from `kofc_Opportunity-eapp-updates.js`.
5. **Do not** register `kofc_authclient.js` as a form library (loaded dynamically).

### 12.3 Environment variables (Dataverse)

Create Text environment variables (set Current Value per environment):

| Schema name | Example purpose |
|-------------|-----------------|
| `kofc_EappURL` | EApp base URL |
| `kofc_EappIntfunctionURL` | Boomi REST endpoint |
| `kofc_EappTenantId` | Entra tenant ID |
| `kofc_EappClientId` | SPA client ID |
| `kofc_EappApiAppId` | Function API app ID |
| `kofc_EappApiKey` | Boomi x-api-key |

### 12.4 Entra ID (SPA app registration)

1. Add SPA redirect URI: `https://<org>.crm.dynamics.com/WebResources/kofc_authcallback.html` (**case-sensitive**).
2. Expose scope `access_as_user` on the Function API registration; grant admin consent to the SPA app.
3. Remove legacy redirect URI `kofc_eappauthcallback.html` after cutover (if present).

### 12.5 Smoke test

1. Open Opportunity form → click EApp button.
2. **First time:** redirect → callback spinner → EApp opens in new tab; Dynamics returns to form.
3. **Second click:** silent → EApp opens directly (no redirect).
4. Console: filter `[KOFC.Auth]` (set `debug: true` in `AUTH_STATIC_CONFIG` while testing).
5. Re-test first-time: `KOFC.Auth.clearCache()` in form iframe console, or InPrivate window.

---

## 13. Error Handling

| Scenario | Behavior | Status |
|----------|----------|--------|
| Unauthenticated caller | `UnauthorizedObjectResult` | 401 |
| Invalid `userId` / `oppID` | `BadRequestObjectResult` | 400 |
| User not found / not visible | `NotFoundObjectResult` | 404 |
| Missing `kofc_insurancerole` | `BadRequestObjectResult` | 400 |
| Dataverse privilege fault (`0x80048303`) | Logged warning, forbidden | 403 |
| CRM connection failure at startup | `InvalidOperationException` | 500 |
| Opportunity/contact not accessible | Empty client fields | 200 |

---

## 14. Test Scenarios

| # | Scenario | Expected |
|---|----------|----------|
| 1 | Valid token + valid `userId` | 200 + role flags |
| 2 | + `oppID` (user has access) | 200 + `clientId`, `clientDob` |
| 3 | + `oppID` (no contact access) | 200 + empty client fields |
| 4 | Missing/invalid token (Azure) | 401 |
| 5 | Token without `Contact.Read` role | 403 |
| 6 | `oppID` provided, token without `Opportunity.Read` | 403 |
| 7 | Missing `userId` | 400 |
| 8 | Invalid `oppID` format | 400 |
| 9 | `userId` not found | 404 |
| 10 | App user missing Act on Behalf Of | 403 |
| 11 | Local dev (no `WEBSITE_SITE_NAME`) | Auth bypassed, both roles granted |
| 12 | Delegated SPA token (`scp` only) hits Function directly | 403 (no `roles`) |

---

## 15. Dependencies

| Package | Version |
|---------|---------|
| `Microsoft.Azure.Functions.Worker` | 1.21.0 |
| `Azure.Identity` | 1.13.2 |
| `Microsoft.PowerPlatform.Dataverse.Client` | 1.1.32 |
| `Newtonsoft.Json` | 13.0.3 |

---

## 16. References

- `docs/KOFC-PolicyNonHeader-TierOne-Architecture.wiki.md` — Policy Non-Header integration (same MSAL + Boomi pattern)
- Microsoft Learn — *Impersonate another user (Dataverse)*
- Microsoft Learn — *DefaultAzureCredential class*
- Microsoft Learn — *Build web applications using Server-to-Server (S2S) authentication*
- Microsoft Learn — *Application users and security roles (Power Platform)*
