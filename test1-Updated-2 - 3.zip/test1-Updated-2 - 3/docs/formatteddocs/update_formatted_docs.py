"""Update KOFC formatted architecture docx content without rebuilding from markdown."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path

from docx import Document
from docx.oxml.ns import qn
from docx.table import Table
from docx.text.paragraph import Paragraph


DOCS_DIR = Path(__file__).parent
DOC_VERSION = "2.1"
LAST_UPDATED = "23 July 2026"
REVISION_SUMMARY = (
    "Release 1.2.0 alignment: userId and policyRecordId API contract, "
    "Policy HTML details page flow, Boomi gateway validation, "
    "kofc_EappIntfunctionURL boomiUrl mapping, and related deployment updates."
)


def replace_text_in_element(element, old: str, new: str) -> int:
    """Replace substring in paragraphs and table cells; preserve paragraph style."""
    count = 0

    def replace_in_paragraph(paragraph: Paragraph) -> None:
        nonlocal count
        if old not in paragraph.text:
            return
        if paragraph.text == old:
            paragraph.text = new
            count += 1
            return
        if old in paragraph.text:
            inline = paragraph.runs
            if inline:
                combined = "".join(run.text for run in inline)
                if old in combined:
                    combined = combined.replace(old, new)
                    inline[0].text = combined
                    for run in inline[1:]:
                        run.text = ""
                    count += 1
            else:
                paragraph.text = paragraph.text.replace(old, new)
                count += 1

    if isinstance(element, Paragraph):
        replace_in_paragraph(element)
    elif isinstance(element, Table):
        for row in element.rows:
            for cell in row.cells:
                for paragraph in cell.paragraphs:
                    replace_in_paragraph(paragraph)
    else:
        doc = element
        for paragraph in doc.paragraphs:
            replace_in_paragraph(paragraph)
        for table in doc.tables:
            for row in table.rows:
                for cell in row.cells:
                    for paragraph in cell.paragraphs:
                        replace_in_paragraph(paragraph)

    return count


def set_paragraph_text(paragraph: Paragraph, new_text: str) -> None:
    if paragraph.runs:
        paragraph.runs[0].text = new_text
        for run in paragraph.runs[1:]:
            run.text = ""
    else:
        paragraph.text = new_text


def find_paragraph(doc: Document, exact: str) -> Paragraph | None:
    for paragraph in doc.paragraphs:
        if paragraph.text.strip() == exact.strip():
            return paragraph
    return None


def insert_paragraph_after(paragraph: Paragraph, text: str, style_name: str | None = None) -> Paragraph:
    new_p = deepcopy(paragraph._element)
    paragraph._element.addnext(new_p)
    new_para = Paragraph(new_p, paragraph._parent)
    set_paragraph_text(new_para, text)
    if style_name:
        new_para.style = style_name
    return new_para


def insert_table_after(paragraph: Paragraph, headers: list[str], rows: list[list[str]]) -> Table:
    parent = paragraph._parent
    table = parent.add_table(rows=1 + len(rows), cols=len(headers))
    table.style = "Table Grid"
    for idx, header in enumerate(headers):
        table.rows[0].cells[idx].text = header
    for row_idx, row in enumerate(rows, start=1):
        for col_idx, value in enumerate(row):
            table.rows[row_idx].cells[col_idx].text = value
    paragraph._element.addnext(table._element)
    return table


def add_revision_row(doc: Document, version: str, date: str, summary: str) -> None:
    for table in doc.tables:
        if table.rows and table.rows[0].cells[0].text.strip() == "Version":
            if any(row.cells[0].text.strip() == version for row in table.rows[1:]):
                return
            row = table.add_row()
            row.cells[0].text = version
            row.cells[1].text = date
            row.cells[2].text = "Solution Architecture"
            row.cells[3].text = summary
            return


def update_document_control(doc: Document) -> None:
    for table in doc.tables:
        if len(table.rows) >= 6 and table.rows[0].cells[0].text.strip() == "Solution":
            for row in table.rows:
                label = row.cells[0].text.strip()
                if label == "Document version":
                    row.cells[1].text = DOC_VERSION
                elif label == "Last updated":
                    row.cells[1].text = LAST_UPDATED
            return


def apply_replacements(doc: Document, replacements: list[tuple[str, str]]) -> None:
    for old, new in replacements:
        replace_text_in_element(doc, old, new)


def update_policy_doc(path: Path) -> None:
    doc = Document(str(path))

    replacements = [
        (
            "Before any upstream system is called, the function performs a Dataverse access check that mirrors the pattern established by the EApp SSO solution. It connects to Dataverse using its Managed Identity, resolves the inbound userName to a Dataverse system user, impersonates that user by setting CallerId, and verifies that the user is permitted to read the requested policy record.",
            "Before any upstream system is called, the function performs a Dataverse access check that mirrors the pattern established by the EApp SSO solution. It connects to Dataverse using its Managed Identity, resolves the inbound userId (Dataverse systemuserid GUID) to a system user, impersonates that user by setting CallerId, and verifies that the user is permitted to read the requested policy record (by policyRecordId when supplied, otherwise by policy number query).",
        ),
        (
            "The DataverseAccessGuard impersonates the supplied userName and confirms access to the policy record.",
            "Inbound userId is validated as a required GUID; optional policyRecordId must be a valid GUID when supplied. The DataverseAccessGuard resolves userId, impersonates that user, and confirms access to the policy record.",
        ),
        (
            "Resolve the inbound userName to a systemuserid using a QueryExpression against the systemuser entity, restricted to enabled users.",
            "Resolve inbound userId (GUID) to a systemuser record, restricted to enabled users.",
        ),
        (
            "Set ServiceClient.CallerId to the resolved user.",
            "Derive userName (UPN/login) from the resolved user for upstream {userName} URL substitution, then set ServiceClient.CallerId to that systemuserid.",
        ),
        (
            "If POLICY_DATAVERSE_ENTITY is configured, query the policy entity by policy number and, where configured, company code.",
            "If POLICY_DATAVERSE_ENTITY is configured: when policyRecordId is supplied, Retrieve that record and cross-check policy number (and optional company code); otherwise query by policy number.",
        ),
        (
            "https://<function-app>.azurewebsites.net/api/getPolicyData /     ?source=ing /     &companyCode=01 /     &policyNo=123456 /     &classificationCode=ABC /     &userName=user@domain.com",
            "https://<function-app>.azurewebsites.net/api/getPolicyData /     ?source=ing /     &companyCode=01 /     &policyNo=123456 /     &classificationCode=ABC /     &userId=<systemuserid-guid> /     &policyRecordId=<policy-record-guid>",
        ),
        (
            "userName || Yes || Caller login or UPN. Matched to a Dataverse system user for the access check.",
            "userId || Yes || Dataverse systemuserid GUID. Resolved server-side for impersonation and upstream {userName} substitution.",
        ),
        (
            "Column on systemuser matched against the inbound userName.",
            "Column on systemuser used as upstream {userName} after userId resolve.",
        ),
        (
            "Dynamics 365 form script || Collects policy parameters, acquires a delegated user token through KOFC.Auth, and calls the Boomi endpoint.",
            "Policy form (kofc_Policy.js) || Validates fields and opens kofc_policy_details.html; Boomi/MSAL run inside the HTML page.",
        ),
        (
            "The form persists the pending policy parameters to kofc_policy_pending before the MSAL redirect.",
            "kofc_policyDetails.js persists pending policy parameters to kofc_policy_pending before the MSAL redirect.",
        ),
        (
            "The form OnLoad handler calls KOFC.Policy.consumePendingResult(), so no second button click is required.",
            "kofc_policy_details.html init() calls KOFC.Policy.consumePendingResult(), so no second button click is required.",
        ),
        (
            "The Function does not correlate the authenticated caller with the userName parameter. Any principal that satisfies the Policy.Read app-role check may nominate any user name for impersonation.",
            "The Function does not correlate the authenticated caller with the userId parameter. Any principal that satisfies the Policy.Read app-role check may nominate any systemuserid for impersonation.",
        ),
        (
            "Boomi always forwards the user name of the genuinely signed-in user, taken from the validated delegated token.",
            "Boomi always forwards the correct systemuserid for the genuinely signed-in user, established at SPA sign-in.",
        ),
        (
            "Upload kofc_policyClient.js as a JScript web resource.",
            "Upload kofc_policyClient.js, kofc_policy_details.html and kofc_policyDetails.js.",
        ),
        (
            "Add the form script from kofc_PolicyForm-snippet.js and wire the OnLoad event to onPolicyFormLoad.",
            "Update kofc_Policy.js with ShowNonHeaderDetails / openPolicyDetailsHtmlPage (see kofc_PolicyForm-snippet.js).",
        ),
        (
            "Open the policy form in Dynamics 365 with the integrated form script.",
            "Open a Policy record and click Non-Header Details (or equivalent ribbon command).",
        ),
        (
            "Trigger a policy data request using valid parameters.",
            "Confirm the HTML details page loads, calls Boomi, and renders policy data.",
        ),
        (
            "userName not resolvable in Dataverse || Guard returns UserNotFound. || 403",
            "userId not resolvable in Dataverse || Guard returns UserNotFound. || 403",
        ),
        (
            "Missing userName || 400 Bad Request",
            "Missing or invalid userId || 400 Bad Request",
        ),
        (
            "userName not present in Dataverse || 403 — user not found",
            "userId not present in Dataverse || 403 — user not found",
        ),
        (
            "derive the system user from the validated token where a delegated path is available, rather than trusting the userName parameter.",
            "derive the systemuserid from the validated token where a delegated path is available, rather than trusting the userId parameter.",
        ),
        (
            "Query or body || source, companyCode, policyNo, classificationCode, userName",
            "Query or body || source, companyCode, policyNo, classificationCode, userId, optional policyRecordId",
        ),
        (
            "    userName:           \"user@domain.com\"",
            "    userId:             \"<systemuserid-guid>\", /     policyRecordId:     \"<policy-record-guid>\"",
        ),
        (
            "// The form OnLoad handler calls KOFC.Policy.consumePendingResult().",
            "// kofc_policy_details.html init() calls KOFC.Policy.consumePendingResult().",
        ),
        (
            "Solid arrows are requests; the dashed arrow is the response path returned to the Dynamics 365 form.",
            "Solid arrows are requests; the dashed arrow is the response path returned to the kofc_policy_details.html page.",
        ),
        (
            "Forward the request to getPolicyData with that bearer token.",
            "Forward the request to getPolicyData with that client-credentials bearer token (no function key).",
        ),
        (
            "webresources/policy-nonheader/kofc_policyClient.js || KOFC.Policy client library.",
            "webresources/policy-nonheader/kofc_policyClient.js || KOFC.Policy client library.",
        ),
    ]
    apply_replacements(doc, replacements)

    # Add policyRecordId parameter row if missing
    for table in doc.tables:
        if len(table.rows) >= 2 and table.rows[0].cells[0].text.strip() == "Parameter":
            has_policy_record = any("policyRecordId" in row.cells[0].text for row in table.rows)
            if not has_policy_record:
                row = table.add_row()
                row.cells[0].text = "policyRecordId"
                row.cells[1].text = "No"
                row.cells[2].text = (
                    "Dataverse policy record GUID. When supplied, the guard performs a direct Retrieve "
                    "and cross-checks policy number and company code."
                )

    # Extend web resources table
    for table in doc.tables:
        if len(table.rows) >= 2 and table.rows[0].cells[0].text.strip() == "Web resource":
            names = {row.cells[0].text.strip() for row in table.rows[1:]}
            extras = [
                ("kofc_policy_details.html", "HTML shell opened from the Policy form; renders the Non-Header report."),
                ("kofc_policyDetails.js", "Page logic: env vars, Dataverse record read, Boomi call, visibility profiles."),
                ("kofc_Policy.js", "Policy form script — ShowNonHeaderDetails opens the HTML page (Boomi not on the form)."),
            ]
            for name, purpose in extras:
                if name not in names:
                    row = table.add_row()
                    row.cells[0].text = name
                    row.cells[1].text = purpose

    # Extend related documents table
    for table in doc.tables:
        if len(table.rows) >= 2 and table.rows[0].cells[0].text.strip() == "Reference":
            refs = {row.cells[0].text.strip() for row in table.rows[1:]}
            extras = [
                ("webresources/policy-nonheader/kofc_policyDetails.js", "HTML page orchestration for Policy Non-Header."),
                ("webresources/policy-nonheader/kofc_policy_details.html", "Policy Non-Header details HTML web resource."),
            ]
            for ref, desc in extras:
                if ref not in refs:
                    row = table.add_row()
                    row.cells[0].text = ref
                    row.cells[1].text = desc

    anchor = find_paragraph(doc, "Boomi obtains a client-credentials token using the scope shown below. The resulting token carries Policy.Read in its roles claim.")
    if anchor is not None:
        insert_paragraph_after(
            anchor,
            "Before calling the Function, Boomi validates the browser request at the API gateway using x-api-key and the delegated user token (scp = access_as_user). The user token is not forwarded to the Function; Boomi swaps to a client-credentials token whose roles claim includes Policy.Read.",
            anchor.style.name if anchor.style else None,
        )

    update_document_control(doc)
    add_revision_row(doc, DOC_VERSION, "23 Jul 2026", REVISION_SUMMARY)
    doc.save(str(path))
    print(f"Updated {path.name}")


def update_eapp_doc(path: Path) -> None:
    doc = Document(str(path))

    replacements = [
        (
            "kofc_EappIntfunctionURL || Boomi REST endpoint, passed as boomiIntegrationUrl.",
            "kofc_EappIntfunctionURL || Boomi REST endpoint — mapped to KOFC.Auth boomiUrl in getAuthConfigFromEnvironment() (AUTH_ENV_VARS.boomiUrl).",
        ),
        (
            "kofc_EappIntfunctionURL || Boomi REST endpoint.",
            "kofc_EappIntfunctionURL || Boomi REST endpoint — mapped to KOFC.Auth boomiUrl in getAuthConfigFromEnvironment().",
        ),
        (
            "var authConfig = await getAuthConfigFromEnvironment(boomiIntegrationUrl);",
            "var authConfig = await getAuthConfigFromEnvironment(boomiIntegrationUrl); // boomiUrl from kofc_EappIntfunctionURL unless legacy param supplied",
        ),
    ]
    apply_replacements(doc, replacements)

    anchor = find_paragraph(
        doc,
        "Local development bypasses authentication when WEBSITE_SITE_NAME is unset, in which case GetCallerRoles returns both roles.",
    )
    if anchor is not None:
        insert_paragraph_after(
            anchor,
            "Boomi gateway validation (browser to Boomi): before calling the Function, Boomi validates x-api-key and the delegated user token (scp = access_as_user). Boomi does not forward the user token to the Function; it uses a client-credentials token with Contact.Read / Opportunity.Read and passes userId (and optional oppID) as parameters.",
            "List Paragraph",
        )

    update_document_control(doc)
    add_revision_row(doc, DOC_VERSION, "23 Jul 2026", REVISION_SUMMARY)
    doc.save(str(path))
    print(f"Updated {path.name}")


def main() -> None:
    update_policy_doc(DOCS_DIR / "KOFC-Policy-NonHeader-TierOne-Architecture.docx")
    update_eapp_doc(DOCS_DIR / "KOFC-EApp-SSO-Architecture.docx")


if __name__ == "__main__":
    main()
