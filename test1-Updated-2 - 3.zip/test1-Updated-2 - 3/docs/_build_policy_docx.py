"""Convert KOFC-PolicyNonHeader-TierOne-Architecture.wiki.md to Word (.docx)."""
import os
import sys

# Reuse the EApp markdown-to-docx converter.
sys.path.insert(0, os.path.dirname(__file__))
import _build_docx as builder

builder.SRC = os.path.join(os.path.dirname(__file__), "KOFC-PolicyNonHeader-TierOne-Architecture.wiki.md")
builder.OUT = os.path.join(os.path.dirname(__file__), "KOFC-PolicyNonHeader-TierOne-Architecture.docx")

if __name__ == "__main__":
    builder.main()
