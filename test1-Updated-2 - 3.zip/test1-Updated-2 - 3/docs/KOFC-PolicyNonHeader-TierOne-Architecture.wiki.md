# KOFC Policy Non-Header Tier One — Function App Architecture

> **Solution:** `KOFC-FA-PolicyNonHeader-TierOne`
> **Function:** `getPolicyData`
> **Runtime:** .NET 8 (Isolated), Azure Functions v4
> **Last updated:** 2026-07-22 (release **1.2.0**)

[[_TOC_]]

---

## 1. Overview

The Policy Non-Header Tier One Function App exposes an HTTP API that aggregates policy data from **multiple upstream systems** (Policy Non-Header REST API, Ingenium, Life70) and returns a merged JSON payload to Dynamics 365 or integration callers.

Before calling upstream APIs, the function performs a **Dataverse access check** (mirroring the EApp pattern): it connects via **Managed Identity**, resolves the inbound **`userId`** (Dataverse `systemuserid` GUID) to a user, impersonates that user via `CallerId`, and verifies they can read the requested policy record (by **`policyRecordId`** when supplied, otherwise by policy number query).

**Key characteristics**

- **D365 client path:** MSAL delegated token (`access_as_user`) → **Boomi** → Function (client-credentials token with **`Policy.Read`** app role).
- **Function inbound auth:** **Easy Auth** + **`Policy.Read`** app role check (same pattern as EApp `Contact.Read` / `Opportunity.Read`). No function key from browser.
- **Dataverse auth:** Function App **Managed Identity** + `DefaultAzureCredential` (no CRM client secret in code).
- **Per-user security:** `DataverseAccessGuard` sets `ServiceClient.CallerId` and lets Dataverse enforce record-level access before upstream calls.
- **Upstream systems:** Policy Non-Header REST API, Ingenium (PING + Headlessflow), Life70 SOAP (Basic auth).
- **Response:** JSON — `NonHeader` only, or merged `NonHeader` + `TIERONE` depending on `source`.

---

## 2. High-Level Architecture

::: mermaid
flowchart LR
    subgraph D365["Dynamics 365"]
        FORM["Policy form<br/>kofc_Policy.js"]
        HTML["kofc_policy_details.html<br/>kofc_policyDetails.js"]
        AUTH["kofc_authclient.js<br/>KOFC.Auth / MSAL"]
    end

    subgraph BOOMI["Boomi"]
        BP["Policy REST process<br/>OAuth client credentials"]
    end

    subgraph AZURE["Azure Function App"]
        EA["Easy Auth<br/>(validates token)"]
        FA["getPolicyData"]
        GUARD["DataverseAccessGuard"]
        MI["Managed Identity"]
    end

    subgraph UPSTREAM["Upstream policy systems"]
        NH["Policy Non-Header API"]
        ING["Ingenium"]
        L70["Life70 SOAP"]
    end

    DV[("Dataverse")]
    AAD["Microsoft Entra ID"]

    FORM -->|Non-Header button| HTML
    HTML --> AUTH
    AUTH -->|MSAL: access_as_user| AAD
    AAD -->|delegated user token| AUTH
    AUTH -->|Bearer user token| BP
    HTML -->|x-api-key + userId + policyRecordId| BP
    BP -->|client credentials| AAD
    AAD -->|app token<br/>roles = Policy.Read| BP
    BP -->|Bearer app token + params| EA
    EA --> FA
    FA -->|role check: Policy.Read| FA
    FA --> GUARD
    GUARD --> MI
    MI --> DV
    FA --> NH
    FA --> ING
    FA --> L70
    FA -.->|policy JSON| BP
    BP -.->|JSON| HTML
:::

---

## 3. Request Flow

::: mermaid
flowchart TD
    START([Request received]) --> VALID{Required params present?}
    VALID -->|No| E400[400 Bad Request]
    VALID -->|Yes| DVCHK[DataverseAccessGuard.CheckPolicyAccess]
    DVCHK -->|User not found| E403a[403 Forbidden]
    DVCHK -->|Access denied| E403b[403 Forbidden]
    DVCHK -->|Granted| SRC{source value}
    SRC -->|ing| MERGE1[NonHeader + Ingenium]
    SRC -->|l70| MERGE2[NonHeader + Life70]
    SRC -->|di / ltc| NHONLY[NonHeader only]
    SRC -->|other| E204[204 No Content]
    MERGE1 --> OK[200 JSON]
    MERGE2 --> OK
    NHONLY --> OK
:::

---

## 4. Authentication (EApp-aligned two-token model)

| Layer | Who | Token type | Claim checked |
|-------|-----|------------|---------------|
| Browser → Boomi | D365 user (MSAL) | Delegated user token | `scp` = `access_as_user` (Boomi validates) |
| Boomi → Function | Boomi service principal | Client credentials | `roles` contains **`Policy.Read`** |
| Function → Dataverse | Function MI + CallerId | Managed Identity | Dataverse privileges for impersonated user |

### 4.1 Entra app registration (Function API)

On the **Policy Function API** app registration (same pattern as EApp):

| Item | Value |
|------|-------|
| Exposed scope (delegated) | `access_as_user` — used by the D365 SPA when calling Boomi |
| App role (application) | **`Policy.Read`** — assigned to the Boomi app registration |
| Easy Auth | Enable on Function App; validate JWT issued for this API |

Boomi obtains a client-credentials token (`scope = api://<POLICY_API_APP_ID>/.default`) whose **`roles`** claim includes `Policy.Read` (admin-consented).

### 4.3 Boomi gateway validation (browser → Boomi)

The browser does **not** pass its user token through to the Function. Boomi validates the caller at the API gateway in two layers:

| Layer | What Boomi checks | What it proves |
|-------|-------------------|----------------|
| **`x-api-key`** | Header matches configured gateway key | Request is from the D365 integration (not anonymous internet traffic) |
| **`Authorization: Bearer`** | Entra JWT signature, issuer, audience, expiry, **`scp`** includes `access_as_user` | A real signed-in Entra user obtained a delegated token for the Policy API app |

After validation, Boomi calls the Function with its **own** client-credentials token (`roles` = **`Policy.Read`**) and forwards business parameters (`userId`, optional `policyRecordId`, policy fields). The user's identity for Dataverse impersonation is the **`userId`** parameter, not the Bearer token on the Function call.

### 4.2 Function enforcement

`PolicyData.cs` uses `AuthorizationLevel.Anonymous` (Easy Auth at the platform layer) and checks:

1. Caller is authenticated (`HttpContext.User` or `X-MS-CLIENT-PRINCIPAL`)
2. Caller has app role **`Policy.Read`** (`FunctionAppRoleAuth.cs`)
3. Inbound **`userId`** is a valid GUID (required)
4. Optional **`policyRecordId`** must be a valid GUID when supplied
5. `DataverseAccessGuard` resolves **`userId`** → impersonates user → verifies policy access (direct **Retrieve** when `policyRecordId` is set; otherwise query by policy number)

Locally (no `WEBSITE_SITE_NAME`), auth checks are bypassed and `Policy.Read` is assumed — same as EApp local dev.

---

## 5. API Specification

### 5.1 Endpoint

| Property | Value |
|----------|-------|
| Function name | `getPolicyData` |
| Methods | `GET`, `POST` |
| Authorization | **Easy Auth** + app role **`Policy.Read`** (Boomi client-credentials token) |
| Response content type | `application/json` |

**Example URL (called by Boomi, not browser):**

```
https://<function-app>.azurewebsites.net/api/getPolicyData?source=ing&companyCode=01&policyNo=123456&classificationCode=ABC&userId=<systemuserid-guid>&policyRecordId=<policy-record-guid>
```

Request must include `Authorization: Bearer <token>` where the token's `roles` claim contains `Policy.Read`.

### 5.2 Parameters

| Parameter | Required | Description |
|-----------|----------|-------------|
| `source` | Yes | Policy source system: `ing`, `l70`, `di`, or `ltc` |
| `companyCode` | Yes | Company code (prepended to policy number for Non-Header API) |
| `policyNo` | Yes | Policy number |
| `classificationCode` | Yes | Classification code (validated; passed through) |
| `userId` | Yes | Dataverse `systemuserid` GUID — resolved server-side for impersonation and upstream `{userName}` substitution |
| `policyRecordId` | No | Dataverse policy record GUID — when supplied, guard performs a direct **Retrieve** and cross-checks policy number/company code |

POST body may also supply these fields as JSON properties (merged with query string).

> **Internal resolution:** the Function resolves `userId` → `systemuser.domainname` (or `DATAVERSE_USERNAME_FIELD`) and passes that UPN/login as `{userName}` to the upstream Non-Header API URL template. Callers send **`userId`**, not `userName`.

### 5.3 Source routing

| `source` | Upstream calls | Response shape |
|----------|----------------|----------------|
| `ing` | Non-Header API + Ingenium Tier One | `{"NonHeader":{...},"TIERONE":{...}}` |
| `l70` | Non-Header API + Life70 SOAP | `{"NonHeader":{...},"TIERONE":{...}}` |
| `di` | Non-Header API only | `{"NonHeader":{...}}` |
| `ltc` | Non-Header API only | `{"NonHeader":{...}}` |
| other | — | 204 with error JSON |

### 5.4 HTTP status codes

| Status | Condition |
|--------|-----------|
| `200 OK` | Success (JSON body) |
| `400 Bad Request` | Missing required parameter |
| `401 Unauthorized` | Missing or invalid Bearer token (Easy Auth) |
| `403 Forbidden` | Token lacks **`Policy.Read`** app role, or Dataverse access denied |
| `204 No Content` | Unknown `source` value |
| `500` | Upstream API failure (wrapped in ERROR JSON when built internally) |

---

## 6. Dataverse Access Guard

Mirrors the EApp impersonation pattern (`DataverseServiceClientFactory` + `CallerId`).

### 6.1 Steps

1. Resolve inbound **`userId`** (GUID) → `systemuser` via Retrieve/Query (enabled users only).
2. Derive **`userName`** (UPN/login) from the resolved user for upstream API URL substitution.
3. Set `ServiceClient.CallerId` to that user's `systemuserid`.
4. If `POLICY_DATAVERSE_ENTITY` is configured:
   - When **`policyRecordId`** is supplied: **Retrieve** that record and verify policy number (+ optional company code) match the request.
   - Otherwise: query the policy entity by policy number (+ optional company code).
5. Return `Granted`, `UserNotFound`, or `AccessDenied`.
6. Reset `CallerId = Guid.Empty` in `finally`.

### 6.2 App settings (Dataverse check)

| Setting | Default | Purpose |
|---------|---------|---------|
| `CRM_URL` | *(required)* | Dataverse organization URL |
| `DATAVERSE_USERNAME_FIELD` | `domainname` | Column on `systemuser` used as upstream `{userName}` after `userId` resolve |
| `POLICY_DATAVERSE_ENTITY` | *(optional)* | Entity logical name for record-level check |
| `POLICY_DATAVERSE_POLICYNO_FIELD` | `kofc_policynumber` | Policy number column on policy entity |
| `POLICY_DATAVERSE_COMPANYCODE_FIELD` | *(optional)* | Company code column on policy entity |

> If `POLICY_DATAVERSE_ENTITY` is not set, the guard grants access when the user resolves successfully (user-existence only). If `policyRecordId` is supplied without `POLICY_DATAVERSE_ENTITY`, the record id is logged and ignored.

---

## 7. Upstream Systems & App Settings

| Setting | Used by | Purpose |
|---------|---------|---------|
| `POLICY_NON_HEADER_API_URL` | `PolicyNonHeaderData` | REST URL template with `{source}`, `{policyNo}`, `{userName}` |
| `INGENIUM_URL` | `PolicyTierOneIngeniumData` | Ingenium production PING URL |
| `INGENIUM_CLONE_URL` | `PolicyTierOneIngeniumData` | Ingenium clone/fallback PING URL |
| `Life70_HB_URL` | `PolicyTierOneLife70Data` | Life70 SOAP endpoint |
| `Life70_HB_CLIENT_ID` | `PolicyTierOneLife70Data` | Basic auth username |
| `Life70_HB_CLIENT_SECRET` | `PolicyTierOneLife70Data` | Basic auth password |

> **Note:** Dataverse uses **Managed Identity**. Life70 uses **Basic auth** (client ID + secret in app settings). Policy Non-Header and Ingenium URLs are configured per environment.

---

## 8. Component Model

| Source file | Responsibility |
|-------------|----------------|
| `Program.cs` | DI host; registers scoped `ServiceClient`, `DataverseAccessGuard`, upstream data services |
| `PolicyData.cs` | HTTP trigger `getPolicyData`; Easy Auth + **Policy.Read** role check, access guard, source routing |
| `Helpers/FunctionAppRoleAuth.cs` | Easy Auth + **`Policy.Read`** app role validation (mirrors EApp `Contact.Read`) |
| `DataverseServiceClientFactory.cs` | MI + `DefaultAzureCredential` Dataverse connection |
| `DataverseAccessGuard.cs` | User resolve + impersonation + policy record access check |
| `PolicyNonHeaderData.cs` | Calls Policy Non-Header REST API |
| `PolicyTierOneIngeniumData.cs` | Ingenium PING + Headlessflow |
| `PolicyTierOneLife70Data.cs` | Life70 SOAP call |

---

## 9. Client Web Resources (Dynamics 365)

Same **MSAL → Boomi → Function** pattern as EApp. Reuses `kofc_authclient.js` and `kofc_authcallback.html` (shared redirect page; Policy uses pending key `kofc_policy_pending` / `kofc_policy_result`).

| Web resource | Purpose |
|--------------|---------|
| `kofc_authclient.js` | Shared `KOFC.Auth` — MSAL token acquisition |
| `kofc_authcallback.html` | Shared MSAL redirect page (completes Policy pending after sign-in via `callPolicyApi()`) |
| `kofc_msalbrowsermin` | MSAL.js library |
| `kofc_policyClient.js` | `KOFC.Policy` — configure + `getPolicyData()` via Boomi |
| `kofc_policy_details.html` | HTML shell opened from Policy form; loads scripts and renders Non-Header report |
| `kofc_policyDetails.js` | Page logic: env vars, Dataverse record read, Boomi call, visibility profiles |
| `kofc_Policy.js` | Policy form script — `ShowNonHeaderDetails` opens HTML page (Boomi **not** on form) |
| `kofc_PolicyForm-snippet.js` | Copy-paste Non-Header section only (optional alternative to full form merge) |

### 9.1 Public API (`KOFC.Policy`)

```javascript
await loadAuthClient();
await loadPolicyClient();

KOFC.Policy.configure({
    tenantId: "...",
    clientId: "...",
    apiAppId: "...",
    apiKey: "...",          // Boomi x-api-key
    boomiUrl: "https://.../ws/rest/PolicyNonHeader",
    allowRedirect: true
});

var result = await KOFC.Policy.getPolicyData({
    source: "ing",
    companyCode: "01",
    policyNo: "123456",
    classificationCode: "ABC",
    userId: "<systemuserid-guid>",
    policyRecordId: "<policy-record-guid>"   // optional but recommended from form/HTML page
});
// result.redirecting === true when a sign-in redirect is in progress;
// kofc_authcallback.html finishes the Boomi call and stores the result.
// kofc_policyDetails.html init() calls KOFC.Policy.consumePendingResult().
```

### 9.2 Boomi request (from browser)

| Header / param | Value |
|----------------|-------|
| `Authorization` | `Bearer <MSAL access token>` (delegated; validated at Boomi gateway) |
| `x-api-key` | Boomi API key (from env var `kofc_PolicyApiKey`) |
| Query / body | `source`, `companyCode`, `policyNo`, `classificationCode`, **`userId`**, optional **`policyRecordId`** |

Boomi forwards to `getPolicyData` with a **client-credentials Bearer token** (`Policy.Read` role) — not the user's token and not an Azure function key.

### 9.3 Environment variables (D365)

Read by `kofc_policyDetails.js` in the HTML page (via parent Xrm context):

| Schema name | Purpose |
|-------------|---------|
| `kofc_PolicyTenantId` | Entra tenant ID |
| `kofc_PolicyClientId` | SPA client ID |
| `kofc_PolicyApiAppId` | Function API app ID (scope `api://<id>/access_as_user`) |
| `kofc_PolicyApiKey` | Boomi x-api-key |
| `kofc_PolicyBoomiUrl` | Boomi REST URL for Policy integration |

> If Policy and EApp share the same Entra app and Boomi host, you may reuse the EApp env vars — but separate Policy vars keep deployments independent.

### 9.4 Redirect auto-complete (like EApp)

1. `kofc_policyDetails.js` persists pending policy params to `kofc_policy_pending` before MSAL redirect.
2. `kofc_authcallback.html` reads the token, calls Boomi (`callPolicyApi()`), stores JSON in `kofc_policy_result`.
3. User returns to **`kofc_policy_details.html`** — **`init()`** calls `KOFC.Policy.consumePendingResult()` and renders without a second button click.

### 9.5 Policy form integration

Ribbon/command: **`ShowNonHeaderDetails`** (optional 2nd arg `isBoomi` kept for backward compatibility; ignored).

1. Form validates policy fields.
2. Opens `kofc_policy_details.html` in a new tab with `etn` + `id` query params.
3. HTML page reads the policy record from Dataverse, calls Boomi with **`userId`** (from `userSettings.userId`) and **`policyRecordId`** (from URL record id).

---

## 10. Deployment Checklist

### 10.1 Azure Function App

1. Deploy `KOFC-FA-PolicyNonHeader-TierOne` (Zip Deploy or pipeline).
2. Enable **system-assigned Managed Identity**.
3. Create **Application User** in Dataverse linked to the MI.
4. Assign security role with **Act on Behalf Of** + read on policy entity (if record check enabled).
5. Enable **Easy Auth** on the Function App (validate JWT for the Policy API app registration).
6. Expose app role **`Policy.Read`** on the API registration; assign it to the Boomi service principal (admin consent).
7. Configure app settings: `CRM_URL`, upstream API URLs, Life70 credentials, optional `POLICY_DATAVERSE_*` settings.

### 10.2 Dynamics 365 web resources

1. Upload `kofc_authclient.js`, `kofc_authcallback.html`, `kofc_msalbrowsermin` (shared with EApp if already deployed).
2. Upload `kofc_policyClient.js`, `kofc_policy_details.html`, `kofc_policyDetails.js` (Script/HTML as appropriate).
3. Update **`kofc_Policy.js`** — replace legacy Non-Header custom page with `ShowNonHeaderDetails` / `openPolicyDetailsHtmlPage` (see `kofc_PolicyForm-snippet.js`).
4. Register `kofc_authcallback.html` in Entra as SPA redirect URI (if not already).
5. Create environment variables: `kofc_PolicyTenantId`, `kofc_PolicyClientId`, `kofc_PolicyApiAppId`, `kofc_PolicyApiKey`, `kofc_PolicyBoomiUrl`.

### 10.3 Boomi process

1. Expose REST endpoint matching `kofc_PolicyBoomiUrl`.
2. Accept `Authorization: Bearer` (user delegated token) + `x-api-key` + policy query/body params from D365 (`userId`, optional `policyRecordId`).
3. Obtain client-credentials token for the Policy API (`api://<POLICY_API_APP_ID>/.default`) with **`Policy.Read`** role.
4. Forward to Azure Function `getPolicyData` with that Bearer token (no function key).
5. Return Function JSON response to the browser.

### 10.4 Smoke test

1. Open a Policy record → click **Non-Header Details** (or equivalent ribbon command).
2. Confirm HTML page loads, calls Boomi, and renders policy data.
3. Confirm **200** JSON or expected **403** when user lacks Dataverse access.
4. First load may redirect to sign-in; callback should auto-complete without a second click.

---

## 11. Test Scenarios

| # | Scenario | Expected |
|---|----------|----------|
| 1 | Valid params + user with policy access, `source=ing` | 200 merged JSON |
| 2 | Valid params + user with policy access, `source=di` | 200 NonHeader only |
| 3 | Missing or invalid `userId` | 400 |
| 4 | Unknown `userId` in Dataverse | 403 User not found |
| 5 | User cannot read policy record (or `policyRecordId` mismatch) | 403 Access denied |
| 6 | Unknown `source` | 204 |
| 7 | Boomi token missing **Policy.Read** role | 403 Missing required app role |
| 8 | Invalid/missing Boomi x-api-key | 401/403 from Boomi |
| 9 | First-time user (no MSAL cache) | Redirect → callback auto-completes policy call |

---

## 12. Dependencies

| Package | Version |
|---------|---------|
| `Microsoft.Azure.Functions.Worker` | 2.51.0 |
| `Azure.Identity` | 1.17.1 |
| `Microsoft.PowerPlatform.Dataverse.Client` | 1.2.10 |
| `Newtonsoft.Json` | (via models) |

---

## 13. Related documentation

- `docs/KOFC-EApp-SSO-Architecture.wiki.md` — EApp SSO (same MSAL + Boomi client pattern)
- `webresources/eapp-boomi-button/kofc_authclient.js` — shared KOFC.Auth library
- `webresources/eapp-boomi-button/kofc_authcallback.html` — shared MSAL callback (`callPolicyApi` + EApp `callApi`)
- `webresources/policy-nonheader/kofc_policyClient.js` — KOFC.Policy library
- `webresources/policy-nonheader/kofc_policyDetails.js` — HTML page orchestration
- `webresources/policy-nonheader/kofc_Policy.js` — Policy form Non-Header button
