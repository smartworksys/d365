"""Convert the EApp SSO architecture markdown to a Word (.docx) document.

Handles: ATX headings, pipe tables, fenced code blocks (``` and ::: mermaid),
blockquotes, bullet/numbered lists, horizontal rules, and inline **bold** / `code`.
"""
import os
import re

from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

SRC = os.path.join(os.path.dirname(__file__), "KOFC-EApp-SSO-Architecture.wiki.md")
OUT = os.path.join(os.path.dirname(__file__), "KOFC-EApp-SSO-Architecture.docx")

MONO = "Consolas"


def add_inline(paragraph, text):
    """Render **bold** and `code` runs; everything else plain."""
    # Split on bold or inline-code tokens, keeping delimiters.
    parts = re.split(r"(\*\*[^*]+\*\*|`[^`]+`)", text)
    for part in parts:
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            run = paragraph.add_run(part[2:-2])
            run.bold = True
        elif part.startswith("`") and part.endswith("`"):
            run = paragraph.add_run(part[1:-1])
            run.font.name = MONO
            run.font.size = Pt(9.5)
        else:
            paragraph.add_run(part)


def strip_inline(text):
    """Plain text for table cells (still keep bold/code readable)."""
    return text


def flush_code(doc, lines, label=None):
    if label:
        p = doc.add_paragraph()
        r = p.add_run(label)
        r.italic = True
        r.font.size = Pt(9)
        r.font.color.rgb = RGBColor(0x66, 0x66, 0x66)
    for ln in lines:
        p = doc.add_paragraph()
        r = p.add_run(ln if ln else " ")
        r.font.name = MONO
        r.font.size = Pt(9)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.space_before = Pt(0)


def parse_table(block):
    rows = []
    for line in block:
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        rows.append(cells)
    # rows[1] is the separator (---)
    header = rows[0]
    body = rows[2:] if len(rows) > 2 else []
    return header, body


def add_table(doc, header, body):
    ncols = len(header)
    table = doc.add_table(rows=1, cols=ncols)
    table.style = "Light Grid Accent 1"
    hdr = table.rows[0].cells
    for i, h in enumerate(header):
        hdr[i].paragraphs[0].text = ""
        add_inline(hdr[i].paragraphs[0], h)
        for run in hdr[i].paragraphs[0].runs:
            run.bold = True
    for row in body:
        cells = table.add_row().cells
        for i in range(ncols):
            val = row[i] if i < len(row) else ""
            cells[i].paragraphs[0].text = ""
            add_inline(cells[i].paragraphs[0], val)
    doc.add_paragraph()


def main():
    with open(SRC, "r", encoding="utf-8") as f:
        lines = f.read().split("\n")

    doc = Document()
    doc.styles["Normal"].font.name = "Calibri"
    doc.styles["Normal"].font.size = Pt(10.5)

    i = 0
    n = len(lines)
    while i < n:
        line = lines[i]
        stripped = line.strip()

        # Skip TOC macro
        if stripped == "[[_TOC_]]":
            i += 1
            continue

        # Horizontal rule
        if stripped == "---":
            i += 1
            continue

        # Fenced code (backticks)
        if stripped.startswith("```"):
            i += 1
            buf = []
            while i < n and not lines[i].strip().startswith("```"):
                buf.append(lines[i])
                i += 1
            i += 1  # closing fence
            flush_code(doc, buf, label="code")
            continue

        # Mermaid / fenced block (::: mermaid ... :::)
        if stripped.startswith("::: mermaid") or stripped == ":::":
            if stripped.startswith("::: mermaid"):
                i += 1
                buf = []
                while i < n and lines[i].strip() != ":::":
                    buf.append(lines[i])
                    i += 1
                i += 1  # closing :::
                flush_code(doc, buf, label="Diagram (mermaid)")
            else:
                i += 1
            continue

        # Table (consecutive lines starting with |)
        if stripped.startswith("|"):
            buf = []
            while i < n and lines[i].strip().startswith("|"):
                buf.append(lines[i])
                i += 1
            if len(buf) >= 2:
                header, body = parse_table(buf)
                add_table(doc, header, body)
            continue

        # Headings
        m = re.match(r"^(#{1,6})\s+(.*)$", stripped)
        if m:
            level = len(m.group(1))
            text = m.group(2)
            # Strip trailing anchors
            doc.add_heading(re.sub(r"[`*]", "", text), level=min(level, 4))
            i += 1
            continue

        # Blockquote
        if stripped.startswith(">"):
            buf = []
            while i < n and lines[i].strip().startswith(">"):
                buf.append(lines[i].strip().lstrip(">").strip())
                i += 1
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Pt(18)
            add_inline(p, " ".join(buf))
            for run in p.runs:
                run.italic = True
            continue

        # Bullet list
        mb = re.match(r"^[-*]\s+(.*)$", stripped)
        if mb:
            p = doc.add_paragraph(style="List Bullet")
            add_inline(p, mb.group(1))
            i += 1
            continue

        # Numbered list
        mn = re.match(r"^\d+\.\s+(.*)$", stripped)
        if mn:
            p = doc.add_paragraph(style="List Number")
            add_inline(p, mn.group(1))
            i += 1
            continue

        # Blank line
        if stripped == "":
            i += 1
            continue

        # Plain paragraph
        p = doc.add_paragraph()
        add_inline(p, stripped)
        i += 1

    doc.save(OUT)
    print("Wrote", OUT)


if __name__ == "__main__":
    main()
