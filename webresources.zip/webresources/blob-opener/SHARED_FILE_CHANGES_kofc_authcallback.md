# Shared File Changes — `kofc_authcallback.html` (Blob Integration)

**File:** `webresources/eapp-boomi-button/kofc_authcallback.html`  
**Change type:** Modified (blob flow added alongside existing EApp and Policy flows)  
**Used by:** EApp button, Policy Non-Header, **Blob opener** (`kofc_blob_open.html`)

---

## Summary

The shared MSAL redirect page gained a **third pending-action flow** for SaaS blob access. After sign-in, if `kofc_blob_pending` is in localStorage, the callback calls Boomi with the user's SPA token and opens the returned SAS URL.

EApp and Policy behavior is **unchanged**.

---

## New localStorage keys

| Key | Written by | Read by | Purpose |
|-----|------------|---------|---------|
| `kofc_blob_pending` | `kofc_blobClient.js` | `kofc_authcallback.html` | Blob request to finish after redirect sign-in |
| `kofc_blob_result` | `kofc_authcallback.html` | `kofc_blobClient.js` (`consumePendingResult`) | Result passed back when callback completes |

**Existing keys (unchanged):**

| Key | Flow |
|-----|------|
| `kofc_eapp_msal_cfg` | Shared MSAL config (all flows) |
| `kofc_eapp_pending` | EApp |
| `kofc_policy_pending` / `kofc_policy_result` | Policy |

---

## Code added — constants (lines 136–138)

```javascript
var BLOB_PENDING_KEY = "kofc_blob_pending";
var BLOB_RESULT_KEY = "kofc_blob_result";
```

---

## Code added — `callBlobApi()` function

New helper that mirrors `callPolicyApi()` but for blob parameters.

**Request to Boomi:**

```http
GET {boomiUrl}?path={path}&contactId={contactId}&format=json
Authorization: Bearer {SPA token}
x-api-key: {apiKey}
Accept: application/json
```

**POST body (when httpMethod is not GET):**

```json
{
  "path": "...",
  "contactId": "...",
  "format": "json"
}
```

**Notes:**

- Browser sends **only** `path` and `contactId` — **not** `userId`
- Boomi extracts `oid` from the token and forwards `userId` to the Function
- Expects Function/Boomi to return JSON with `sasUrl`

---

## Code added — blob pending shape

Written by `kofc_blobClient.js` before redirect:

```javascript
{
  action: "blob",
  path: "<windows file path>",
  contactId: "<contact guid>",
  boomiUrl: "<Boomi REST URL>",
  apiKey: "<x-api-key>",
  httpMethod: "GET",
  apiScopes: ["api://<apiAppId>/access_as_user"],
  returnUrl: "<D365 page URL>"
}
```

---

## Code modified — silent token scope resolution (lines 363–365)

**Before (EApp + Policy only):**

```javascript
var scopesForSilent = (pending && pending.apiScopes)
    || (policyPending && policyPending.apiScopes);
```

**After:**

```javascript
var scopesForSilent = (pending && pending.apiScopes)
    || (policyPending && policyPending.apiScopes)
    || (blobPending && blobPending.apiScopes);
```

Allows silent token acquisition for blob when redirect returns.

---

## Code added — blob flow handler (runs before Policy and EApp)

**Trigger condition:**

```javascript
if (token && blobPending && blobPending.action === "blob" && blobPending.boomiUrl)
```

**Success path:**

1. Show message: `"Sign-in complete. Opening file..."`
2. Call `callBlobApi(blobPending, token)`
3. Parse response JSON → `{ sasUrl: "..." }`
4. Write `kofc_blob_result`:

   ```javascript
   {
     ok: true,
     status: <http status>,
     data: { sasUrl: "..." },
     raw: "<response body>"
   }
   ```

5. Remove `kofc_blob_pending`
6. Navigate to `blobParsed.sasUrl` (opens the file)
7. Fallback: `returnUrl` or static success message

**Error path:**

1. Write `kofc_blob_result` with `ok: false`
2. Remove `kofc_blob_pending`
3. Show error: `"Blob request failed: ..."`

**Flow order after sign-in:**

```text
1. Blob   (if kofc_blob_pending)
2. Policy (if kofc_policy_pending)
3. EApp   (if kofc_eapp_pending)
4. Default return to Dynamics
```

Blob is checked **first** so a blob pending action is not skipped.

---

## What was NOT changed

| Area | Status |
|------|--------|
| HTML / CSS UI | Unchanged |
| `callApi()` (EApp) | Unchanged |
| `callPolicyApi()` | Unchanged |
| `finishAction()` | Unchanged |
| MSAL initialization | Unchanged |
| ssoSilent iframe early exit | Unchanged |
| Entra redirect URI | Same URL — no new registration needed |

---

## End-to-end redirect flow (blob)

```text
kofc_blob_open.html
  → KOFC.Blob.openSaasBlob({ path, contactId })
  → persist kofc_blob_pending
  → KOFC.Auth.getAccessToken() → redirect to Microsoft
  → kofc_authcallback.html (this file)
  → handleRedirectPromise()
  → callBlobApi() → Boomi → Function → { sasUrl }
  → window.location.href = sasUrl
```

If token is already cached, `kofc_blobClient.js` calls Boomi directly and skips this callback (except when redirect is required).

---

## Testing checklist

- [ ] First-time sign-in from timeline link opens file via callback
- [ ] Second click uses silent token (no full redirect)
- [ ] EApp button still works after blob changes
- [ ] Policy button still works after blob changes
- [ ] Blob error shows message and writes `kofc_blob_result` with `ok: false`
