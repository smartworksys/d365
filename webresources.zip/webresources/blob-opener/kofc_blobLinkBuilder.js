/*
 * KOFC.BlobLinkBuilder — build timeline-safe links to kofc_blob_open.html
 *
 * Usage (browser):
 *   var url = KOFC.BlobLink.buildOpenerUrl({ filePath: "D:\\...", contactId: "{guid}" });
 *
 * Usage (ADF / server — copy the URL pattern from BOOMI_INTEGRATION.md):
 *   {OrgUrl}/main.aspx?pagetype=webresource&webresourceName=kofc_blob_open.html&data=...
 */
(function (global) {
    "use strict";

    var DEFAULT_WEB_RESOURCE = "kofc_blob_open.html";

    function stripBraces(value) {
        return String(value || "").replace(/[{}]/g, "");
    }

    function buildDataParam(filePath, contactId) {
        return "path=" + encodeURIComponent(filePath) + "&contactId=" + stripBraces(contactId);
    }

    function buildOpenerUrl(options) {
        if (!options || !options.filePath || !options.contactId) {
            throw new Error("buildOpenerUrl requires filePath and contactId.");
        }

        var orgUrl = options.orgUrl;
        if (!orgUrl && typeof Xrm !== "undefined" && Xrm.Utility) {
            orgUrl = Xrm.Utility.getGlobalContext().getClientUrl();
        }
        if (!orgUrl) {
            throw new Error("buildOpenerUrl requires orgUrl when not running inside Dynamics.");
        }

        var webResource = options.webResourceName || DEFAULT_WEB_RESOURCE;
        var data = buildDataParam(options.filePath, options.contactId);
        return orgUrl.replace(/\/$/, "") +
            "/main.aspx?pagetype=webresource" +
            "&webresourceName=" + encodeURIComponent(webResource) +
            "&data=" + encodeURIComponent(data);
    }

    function buildAnchorHtml(options) {
        var label = options.label || "View file";
        return '<a href="' + buildOpenerUrl(options) + '" target="_blank" rel="noopener noreferrer">' +
            label + "</a>";
    }

    global.KOFC = global.KOFC || {};
    global.KOFC.BlobLink = {
        buildOpenerUrl: buildOpenerUrl,
        buildAnchorHtml: buildAnchorHtml,
        buildDataParam: buildDataParam
    };
})(typeof window !== "undefined" ? window : this);
