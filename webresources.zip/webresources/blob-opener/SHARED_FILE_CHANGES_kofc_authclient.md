# Shared File Changes — `kofc_authclient.js` (Blob Integration)

**File:** `webresources/eapp-boomi-button/kofc_authclient.js`  
**Change type:** **No code changes** — reused as-is by the blob opener  
**Consumer:** `webresources/blob-opener/kofc_blobClient.js`

---

## Summary

`kofc_authclient.js` (`KOFC.Auth`) was **not modified** for blob integration. The blob client loads this shared library dynamically and uses only a subset of its public API for MSAL token acquisition.

Blob-specific Boomi calls and SAS handling live in **`kofc_blobClient.js`** and **`kofc_authcallback.html`**.

---

## How blob uses `KOFC.Auth`

| KOFC.Auth API | Used by blob? | Purpose |
|---------------|---------------|---------|
| `configure(options)` | **Yes** | Pass blob env vars (tenant, client, Boomi URL, etc.) |
| `getAccessToken()` | **Yes** | Acquire delegated SPA token (silent or redirect) |
| `openEapp()` | No | EApp only |
| `callBoomiRaw()` | No | EApp only |
| `callBoomi()` | No | EApp ribbon only |
| `clearCache()` | Optional | Clears EApp pending keys only (see gap below) |

**Load pattern in `kofc_blobClient.js`:**

```javascript
// Lazy-load shared auth library
script.src = clientUrl() + "/WebResources/kofc_authclient.js";

// Then configure and get token
global.KOFC.Auth.configure({ tenantId, clientId, apiAppId, ... });
return global.KOFC.Auth.getAccessToken();
```

---

## Shared infrastructure reused (no changes required)

### MSAL config key — `kofc_eapp_msal_cfg`

Both EApp and blob write/read the same key via `KOFC.Auth.persistMsalConfig()`:

```javascript
{
  clientId, tenantId, redirectUri, returnUrl
}
```

The callback page reads this key for all flows.

### Redirect page — `kofc_authcallback.html`

Blob sets:

```javascript
redirectWebResource: "kofc_authcallback.html"
```

Same Entra SPA redirect URI as EApp and Policy — **no new app registration redirect needed**.

### MSAL web resource — `kofc_msalbrowsermin`

Same MSAL bundle path as EApp:

```javascript
msalWebResourcePath: "/WebResources/kofc_msalbrowsermin"
```

---

## Blob vs EApp — what differs (in blob client, not auth client)

| Concern | EApp (`KOFC.Auth`) | Blob (`KOFC.Blob`) |
|---------|-------------------|-------------------|
| Pending localStorage key | `kofc_eapp_pending` | `kofc_blob_pending` |
| Boomi parameters | `userId`, `oppID` | `path`, `contactId`, `format=json` |
| Boomi response | Base64 string → EApp URL | JSON `{ sasUrl }` → open file |
| Callback completion | `callApi()` in callback | `callBlobApi()` in callback |
| Default HTTP method | `POST` | `GET` |
| Accept header | `text/plain` | `application/json` |

---

## Configuration passed from blob to shared auth client

`kofc_blobClient.js` → `applyAuthConfig()`:

```javascript
KOFC.Auth.configure({
    tenantId: CONFIG.tenantId,           // kofc_BlobTenantId
    clientId: CONFIG.clientId,           // kofc_BlobClientId
    apiAppId: CONFIG.apiAppId,           // kofc_BlobApiAppId
    apiKey: CONFIG.apiKey,               // kofc_BlobApiKey
    boomiUrl: CONFIG.boomiUrl,           // kofc_BlobBoomiUrl
    scope: "access_as_user",
    httpMethod: "GET",
    redirectWebResource: "kofc_authcallback.html",
    msalWebResourcePath: "/WebResources/kofc_msalbrowsermin",
    allowRedirect: true,
    debug: false
});
```

**Important:** `boomiUrl` and `apiKey` are configured on `KOFC.Auth` but blob does **not** use `KOFC.Auth.callBoomiApi()`. Those values are copied into `kofc_blob_pending` for the callback page. The in-page blob flow uses `KOFC.Blob.callBlobBoomi()` instead.

---

## Known gap — `clearCache()` and blob keys

`KOFC.Auth.clearCache()` removes:

- `kofc_eapp_msal_cfg`
- `kofc_eapp_pending`
- Keys starting with `msal.`

It does **not** remove:

- `kofc_blob_pending`
- `kofc_blob_result`
- `kofc_policy_pending` / `kofc_policy_result`

To fully reset blob state during testing, clear those keys manually in DevTools → Local Storage, or call:

```javascript
localStorage.removeItem("kofc_blob_pending");
localStorage.removeItem("kofc_blob_result");
```

No change was made to `kofc_authclient.js` to avoid affecting EApp behavior.

---

## Why auth client was left unchanged

1. **Separation of concerns** — blob Boomi contract differs from EApp (path/contactId vs userId/oppID).
2. **Backward compatibility** — EApp ribbon and forms depend on current `KOFC.Auth` behavior.
3. **Callback extension** — redirect completion for blob was added to the shared callback page instead.
4. **Thin reuse** — blob only needs token acquisition from the shared MSAL stack.

---

## Files in the blob feature (not shared)

| File | Role |
|------|------|
| `kofc_blobClient.js` | Blob-specific MSAL orchestration + Boomi call |
| `kofc_blob_open.html` | Timeline landing page |
| `kofc_blobLinkBuilder.js` | ADF/form link builder |
| `SHARED_FILE_CHANGES_kofc_authcallback.md` | Exact callback changes for blob |

For Function App changes, see `proxyBlobFunction/FUNCTION_CHANGES.md`.  
For full deployment steps, see `proxyBlobFunction/BOOMI_INTEGRATION.md`.
