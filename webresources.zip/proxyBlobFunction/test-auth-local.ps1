# PowerShell script to test authentication locally
# Usage: .\test-auth-local.ps1 -Path "D:\test\file.txt" -ContactId "12345678-1234-1234-1234-123456789012"

param(
    [Parameter(Mandatory=$false)]
    [string]$Path = "D:\KOFCExt Extractions\test\file.txt",
    
    [Parameter(Mandatory=$false)]
    [string]$ContactId = "12345678-1234-1234-1234-123456789012",
    
    [Parameter(Mandatory=$false)]
    [string]$UserName = "test@example.com",
    
    [Parameter(Mandatory=$false)]
    [string]$Oid = "12345678-1234-1234-1234-123456789012",
    
    [Parameter(Mandatory=$false)]
    [string]$AccessToken = "",
    
    [Parameter(Mandatory=$false)]
    [string]$Endpoint = "http://localhost:7071/api/GetSaasBlobUrl",
    
    [Parameter(Mandatory=$false)]
    [switch]$GetRealToken
)

Write-Host "🧪 Testing Authentication Locally" -ForegroundColor Cyan
Write-Host "===================================" -ForegroundColor Cyan
Write-Host ""

# Generate Base64 principal
Write-Host "📝 Generating test principal..." -ForegroundColor Yellow
$principal = @{
    auth_typ = "aad"
    claims = @(
        @{ typ = "name"; val = $UserName },
        @{ typ = "oid"; val = $Oid },
        @{ typ = "email"; val = $UserName },
        @{ typ = "preferred_username"; val = $UserName }
    )
} | ConvertTo-Json -Depth 10 -Compress

$bytes = [System.Text.Encoding]::UTF8.GetBytes($principal)
$base64Principal = [Convert]::ToBase64String($bytes)

Write-Host "✅ Principal generated" -ForegroundColor Green
Write-Host ""

# Get real token if requested
if ($GetRealToken) {
    Write-Host "🔑 Getting real Azure AD token..." -ForegroundColor Yellow
    try {
        $realToken = az account get-access-token --resource "https://yourorg.crm.dynamics.com" --query accessToken -o tsv 2>$null
        if ($realToken) {
            $AccessToken = $realToken
            Write-Host "✅ Real token obtained" -ForegroundColor Green
        } else {
            Write-Host "⚠️  Could not get real token, using test token" -ForegroundColor Yellow
            $AccessToken = "test-access-token-for-local-development"
        }
    } catch {
        Write-Host "⚠️  Could not get real token, using test token" -ForegroundColor Yellow
        $AccessToken = "test-access-token-for-local-development"
    }
} else {
    if ([string]::IsNullOrWhiteSpace($AccessToken)) {
        $AccessToken = "test-access-token-for-local-development"
        Write-Host "ℹ️  Using test token (use -GetRealToken for real token)" -ForegroundColor Gray
    }
}

Write-Host ""

# URL encode the path
Add-Type -AssemblyName System.Web
$encodedPath = [System.Web.HttpUtility]::UrlEncode($Path)
$fullUrl = "$Endpoint?path=$encodedPath&contactId=$ContactId"

Write-Host "📡 Request Details:" -ForegroundColor Green
Write-Host "  URL: $fullUrl" -ForegroundColor White
Write-Host "  Principal: $base64Principal" -ForegroundColor Gray
Write-Host ""

# Create headers
$headers = @{
    "X-MS-TOKEN-AAD-ACCESS-TOKEN" = $AccessToken
    "X-MS-CLIENT-PRINCIPAL" = $base64Principal
    "X-MS-CLIENT-PRINCIPAL-NAME" = $UserName
    "X-MS-CLIENT-PRINCIPAL-ID" = $Oid
}

Write-Host "🚀 Sending request with authentication headers..." -ForegroundColor Yellow
Write-Host ""

try {
    $response = Invoke-WebRequest -Uri $fullUrl -Method Get -Headers $headers -MaximumRedirection 0 -ErrorAction SilentlyContinue
    
    if ($response.StatusCode -eq 302) {
        $sasUrl = $response.Headers.Location
        Write-Host "✅ Success! Authentication worked!" -ForegroundColor Green
        Write-Host "  Status: 302 Redirect" -ForegroundColor White
        Write-Host "  SAS URL: $sasUrl" -ForegroundColor Cyan
        Write-Host ""
        
        $openNow = Read-Host "Open blob URL in browser? (y/n)"
        if ($openNow -eq 'y') {
            Start-Process $sasUrl
        }
    } else {
        Write-Host "⚠️  Unexpected status code: $($response.StatusCode)" -ForegroundColor Yellow
        Write-Host "  Response: $($response.Content)" -ForegroundColor White
    }
}
catch {
    if ($_.Exception.Response.StatusCode -eq 302) {
        $sasUrl = $_.Exception.Response.Headers.Location
        Write-Host "✅ Success! Authentication worked!" -ForegroundColor Green
        Write-Host "  Status: 302 Redirect" -ForegroundColor White
        Write-Host "  SAS URL: $sasUrl" -ForegroundColor Cyan
        Write-Host ""
        
        $openNow = Read-Host "Open blob URL in browser? (y/n)"
        if ($openNow -eq 'y') {
            Start-Process $sasUrl
        }
    }
    elseif ($_.Exception.Response.StatusCode -eq 401) {
        Write-Host "❌ Unauthorized (401)" -ForegroundColor Red
        Write-Host "  Headers may not be properly formatted" -ForegroundColor Yellow
        Write-Host "  Check function logs for details" -ForegroundColor Yellow
    }
    elseif ($_.Exception.Response.StatusCode -eq 403) {
        Write-Host "❌ Forbidden (403)" -ForegroundColor Red
        Write-Host "  Authentication worked, but Dataverse access denied" -ForegroundColor Yellow
        Write-Host "  Check if token is valid and user has access to contact" -ForegroundColor Yellow
    }
    else {
        Write-Host "❌ Error: $($_.Exception.Message)" -ForegroundColor Red
        if ($_.Exception.Response) {
            $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
            $responseBody = $reader.ReadToEnd()
            Write-Host "  Response: $responseBody" -ForegroundColor Red
        }
    }
}

Write-Host ""
Write-Host "💡 Tips:" -ForegroundColor Cyan
Write-Host "  - Use -GetRealToken to get a real Azure AD token" -ForegroundColor Gray
Write-Host "  - Real tokens expire quickly - get fresh token before testing" -ForegroundColor Gray
Write-Host "  - Check function logs for detailed authentication flow" -ForegroundColor Gray
Write-Host "  - Use GetSaasBlobUrlLocal endpoint to test without auth" -ForegroundColor Gray
Write-Host ""

