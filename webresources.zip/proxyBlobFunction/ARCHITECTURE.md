# Architecture Diagram - GetSaasBlobUrl Azure Function App

## System Architecture Overview

```mermaid
graph TB
    subgraph "Client Layer"
        User[👤 Dynamics 365 User]
        Browser[🌐 Web Browser]
    end
    
    subgraph "Azure AD / Authentication"
        EasyAuth[Azure AD Easy Auth<br/>App Service Authentication]
        AzureAD[Azure Active Directory]
        TokenService[Token Service]
    end
    
    subgraph "Azure Function App"
        Function[GetSaasBlobUrl Function<br/>.NET 8 Isolated]
        PrincipalService[Principal Service<br/>Decode User Principal]
        DataverseService[Dataverse Service<br/>Validate Contact Access]
        BlobService[Blob Service<br/>Generate SAS URL]
    end
    
    subgraph "Dynamics 365 / Dataverse"
        DataverseAPI[Dataverse Web API<br/>v9.2]
        ContactRecord[Contact Record<br/>Security Validation]
    end
    
    subgraph "Azure Storage"
        BlobStorage[Azure Blob Storage<br/>Container: smart-office]
        SASURL[SAS URL<br/>15-min Read-Only]
    end
    
    subgraph "Monitoring"
        AppInsights[Application Insights<br/>Logging & Telemetry]
    end
    
    User -->|1. Clicks Link| Browser
    Browser -->|2. HTTP GET Request| EasyAuth
    EasyAuth -->|3. Authenticate| AzureAD
    AzureAD -->|4. Return Token| TokenService
    TokenService -->|5. Inject Headers| Function
    
    Function -->|6. Decode Principal| PrincipalService
    Function -->|7. Validate Access| DataverseService
    DataverseService -->|8. API Call| DataverseAPI
    DataverseAPI -->|9. Check Permissions| ContactRecord
    ContactRecord -->|10. Access Granted/Denied| DataverseService
    
    Function -->|11. Normalize Path| BlobService
    BlobService -->|12. Generate SAS| BlobStorage
    BlobStorage -->|13. Return SAS URL| BlobService
    Function -->|14. HTTP 302 Redirect| Browser
    Browser -->|15. Open File| SASURL
    
    Function -.->|Logging| AppInsights
    DataverseService -.->|Telemetry| AppInsights
    BlobService -.->|Metrics| AppInsights
    
    style User fill:#e1f5ff
    style Function fill:#90EE90
    style EasyAuth fill:#FFD700
    style DataverseAPI fill:#87CEEB
    style BlobStorage fill:#DDA0DD
    style AppInsights fill:#FFA07A
```

---

## Detailed Component Architecture

```mermaid
graph LR
    subgraph "Function App Components"
        A[HTTP Trigger<br/>GetSaasBlobUrl] --> B[Auth Validator]
        B --> C[Principal Service]
        B --> D[Dataverse Service]
        D --> E[Blob Service]
        E --> F[Path Normalizer]
        F --> G[SAS Generator]
    end
    
    subgraph "External Services"
        H[Azure AD]
        I[Dataverse API]
        J[Blob Storage]
    end
    
    B -.->|Extract Headers| H
    D -.->|Validate Access| I
    G -.->|Generate URL| J
    
    style A fill:#4CAF50
    style C fill:#2196F3
    style D fill:#FF9800
    style E fill:#9C27B0
```

---

## Data Flow Diagram

```mermaid
sequenceDiagram
    participant U as User
    participant B as Browser
    participant EA as Easy Auth
    participant F as Function App
    participant DS as Dataverse Service
    participant D as Dataverse API
    participant BS as Blob Service
    participant ST as Blob Storage
    participant AI as App Insights
    
    U->>B: Click Link in D365
    B->>EA: GET /api/GetSaasBlobUrl?path=...&contactId=...
    EA->>EA: Check Auth Status
    alt Not Authenticated
        EA->>B: Redirect to Azure AD Login
        B->>EA: Login Complete
    end
    EA->>F: Request + Auth Headers
    
    F->>AI: Log Request Start
    F->>F: Extract Headers (Token, Principal)
    F->>F: Decode User Principal
    F->>DS: Validate Contact Access
    DS->>D: GET /api/data/v9.2/contacts(id)
    D->>D: Check User Permissions
    alt Access Denied
        D->>DS: 403 Forbidden
        DS->>F: Return False
        F->>B: 403 Forbidden
        B->>U: Error Message
    else Access Granted
        D->>DS: 200 OK
        DS->>F: Return True
        F->>BS: Normalize Path
        F->>BS: Generate SAS URL
        BS->>ST: Check Blob Exists
        alt Blob Not Found
            ST->>BS: Not Found
            BS->>F: Throw Exception
            F->>B: 404 Not Found
            B->>U: Error Message
        else Blob Found
            ST->>BS: Return Blob Info
            BS->>BS: Generate SAS (15-min, Read)
            BS->>F: Return SAS URL
            F->>AI: Log Success
            F->>B: 302 Redirect to SAS URL
            B->>ST: GET Blob via SAS URL
            ST->>B: Return File
            B->>U: Display File
        end
    end
```

---

## Security Architecture

```mermaid
graph TB
    subgraph "Security Layers"
        L1[Layer 1: Network Security<br/>HTTPS/TLS]
        L2[Layer 2: Authentication<br/>Azure AD Easy Auth]
        L3[Layer 3: Authorization<br/>Dataverse Security Roles]
        L4[Layer 4: Access Control<br/>SAS Token Permissions]
        L5[Layer 5: Time Limits<br/>15-min Expiration]
    end
    
    Request[Incoming Request] --> L1
    L1 --> L2
    L2 --> L3
    L3 --> L4
    L4 --> L5
    L5 --> BlobAccess[Blob Access]
    
    style L1 fill:#FF6B6B
    style L2 fill:#4ECDC4
    style L3 fill:#45B7D1
    style L4 fill:#FFA07A
    style L5 fill:#98D8C8
```

---

## Deployment Architecture

```mermaid
graph TB
    subgraph "Development"
        DevCode[Source Code<br/>Visual Studio]
        DevTests[Unit Tests<br/>xUnit]
    end
    
    subgraph "CI/CD Pipeline"
        Build[Build & Test<br/>dotnet build/test]
        Package[Package<br/>dotnet publish]
        Deploy[Deploy<br/>func azure deploy]
    end
    
    subgraph "Azure Production"
        FuncApp[Function App<br/>Consumption Plan]
        Storage[Storage Account<br/>Blob Container]
        AppInsights[Application Insights<br/>Monitoring]
    end
    
    subgraph "Configuration"
        AppSettings[Application Settings<br/>Connection Strings]
        KeyVault[Azure Key Vault<br/>Secrets]
    end
    
    DevCode --> Build
    DevTests --> Build
    Build --> Package
    Package --> Deploy
    Deploy --> FuncApp
    
    FuncApp --> Storage
    FuncApp --> AppInsights
    FuncApp --> AppSettings
    AppSettings --> KeyVault
    
    style DevCode fill:#E8F5E9
    style FuncApp fill:#C8E6C9
    style Storage fill:#BBDEFB
    style AppInsights fill:#FFE0B2
```

---

## Infrastructure Components

### Azure Resources

```
┌─────────────────────────────────────────────────────────────┐
│                    Azure Subscription                        │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Function App (Consumption Plan)                │  │
│  │  ┌──────────────────────────────────────────────────┐ │  │
│  │  │  GetSaasBlobUrl Function (.NET 8 Isolated)       │ │  │
│  │  │  - HTTP Trigger                                   │ │  │
│  │  │  - Easy Auth Enabled                              │ │  │
│  │  └──────────────────────────────────────────────────┘ │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Storage Account                               │  │
│  │  ┌──────────────────────────────────────────────────┐ │  │
│  │  │  Blob Container: smart-office                      │ │  │
│  │  │  - Files stored with normalized paths             │ │  │
│  │  │  - SAS URLs generated on-demand                   │ │  │
│  │  └──────────────────────────────────────────────────┘ │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Application Insights                          │  │
│  │  - Request telemetry                                  │  │
│  │  - Exception tracking                                 │  │
│  │  - Performance metrics                                │  │
│  │  - Dependency tracking                                │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Azure AD                                      │  │
│  │  - User authentication                               │  │
│  │  - Token generation                                  │  │
│  │  - Easy Auth integration                             │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐  │
│  │         Dynamics 365 / Dataverse                     │  │
│  │  - Contact records                                   │  │
│  │  - Security roles                                    │  │
│  │  - Web API v9.2                                      │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

---

## Request/Response Flow

### Request Flow

```
1. User Action
   └─> Click link in Dynamics 365 Timeline

2. Browser Request
   └─> GET https://functionapp.azurewebsites.net/api/GetSaasBlobUrl?path=...&contactId=...

3. Azure Easy Auth
   └─> Authenticate user (if needed)
   └─> Inject headers:
       ├─ X-MS-TOKEN-AAD-ACCESS-TOKEN
       ├─ X-MS-CLIENT-PRINCIPAL
       ├─ X-MS-CLIENT-PRINCIPAL-NAME
       └─ X-MS-CLIENT-PRINCIPAL-ID

4. Function Processing
   ├─> Extract & decode principal
   ├─> Validate contact access (Dataverse)
   ├─> Normalize file path
   └─> Generate SAS URL

5. Response
   └─> HTTP 302 Redirect to SAS URL

6. Browser Follow Redirect
   └─> GET blob via SAS URL

7. File Display
   └─> Browser displays file
```

### Response Codes

```
200 OK          → Never returned (always 302)
302 Found       → Success - Redirect to SAS URL
400 Bad Request → Missing/invalid parameters
401 Unauthorized → Missing/invalid auth headers
403 Forbidden   → No Dataverse access to contact
404 Not Found   → Blob doesn't exist
500 Server Error → Internal error (logged)
```

---

## Security Model

```
┌─────────────────────────────────────────┐
│         Security Layers                  │
├─────────────────────────────────────────┤
│                                         │
│  1. Network Security                    │
│     • HTTPS/TLS encryption              │
│     • Azure network security            │
│                                         │
│  2. Authentication                      │
│     • Azure AD Easy Auth                │
│     • SSO support                       │
│     • MFA compatible                    │
│                                         │
│  3. Authorization                       │
│     • Dataverse security roles          │
│     • Contact-level access control      │
│     • Per-request validation            │
│                                         │
│  4. Access Control                      │
│     • SAS token (read-only)             │
│     • Time-limited (15 minutes)         │
│     • Single-use per generation         │
│                                         │
│  5. Audit & Compliance                  │
│     • Application Insights logging      │
│     • User action tracking              │
│     • Access attempt monitoring         │
│                                         │
└─────────────────────────────────────────┘
```

---

## Technology Stack

```
┌─────────────────────────────────────────────────┐
│           Technology Stack                       │
├─────────────────────────────────────────────────┤
│                                                 │
│  Runtime:                                        │
│  • .NET 8.0                                      │
│  • Azure Functions v4 (Isolated Process)        │
│                                                 │
│  Authentication:                                 │
│  • Azure AD Easy Auth                            │
│  • Microsoft Identity Platform                   │
│                                                 │
│  Storage:                                        │
│  • Azure Blob Storage                            │
│  • Azure.Storage.Blobs SDK v12.19.1              │
│                                                 │
│  Integration:                                    │
│  • Dynamics 365 Dataverse Web API v9.2           │
│  • HttpClient for API calls                      │
│                                                 │
│  Monitoring:                                     │
│  • Application Insights                          │
│  • Structured logging (ILogger)                  │
│                                                 │
│  Testing:                                        │
│  • xUnit                                         │
│  • Moq (mocking)                                 │
│                                                 │
│  Development:                                    │
│  • Visual Studio / VS Code                       │
│  • Azure Functions Core Tools                    │
│  • Azure CLI                                     │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## Scalability & Performance

### Consumption Plan Benefits

```
┌──────────────────────────────────────────────┐
│         Auto-Scaling Model                    │
├──────────────────────────────────────────────┤
│                                              │
│  • Automatic scaling based on demand         │
│  • Pay only for execution time                │
│  • No server management required              │
│  • Handles traffic spikes automatically      │
│  • Cold start: ~1-2 seconds                  │
│  • Warm execution: <500ms                    │
│                                              │
└──────────────────────────────────────────────┘
```

### Performance Targets

```
Operation                 Target    Notes
─────────────────────────────────────────────────
Total Request Time        < 2s      End-to-end
Authentication            < 500ms   Azure AD
Dataverse Validation      < 500ms   API call
Path Normalization        < 50ms    In-memory
SAS Generation            < 200ms    Storage API
Blob Access (via SAS)     Variable  Storage speed
```

---

## Monitoring & Observability

```
┌─────────────────────────────────────────────────┐
│         Application Insights                    │
├─────────────────────────────────────────────────┤
│                                                 │
│  Metrics Tracked:                                │
│  • Request count & duration                      │
│  • Success/failure rates                        │
│  • Authentication failures                      │
│  • Dataverse API latency                         │
│  • Blob access patterns                         │
│                                                 │
│  Logs Captured:                                  │
│  • User identity (principal, OID)                │
│  • Request parameters (path, contactId)          │
│  • Access decisions (granted/denied)             │
│  • Errors and exceptions                         │
│  • Normalized paths                              │
│                                                 │
│  Alerts Configured:                              │
│  • High error rate (>5% failures)               │
│  • Authentication failures (>10 failures/hour)    │
│  • Slow response times (>3 seconds)              │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## High-Level Architecture Summary

### Component Responsibilities

| Component | Responsibility | Technology |
|-----------|---------------|------------|
| **Function App** | HTTP endpoint, orchestration | .NET 8 Isolated |
| **Principal Service** | Decode Easy Auth headers | C# / System.Text.Json |
| **Dataverse Service** | Validate user access | HttpClient / REST API |
| **Blob Service** | Path normalization, SAS generation | Azure.Storage.Blobs |
| **Easy Auth** | Authentication middleware | Azure App Service |
| **Azure AD** | Identity provider | Microsoft Identity Platform |
| **Dataverse** | Authorization source | Dynamics 365 API |
| **Blob Storage** | File storage | Azure Blob Storage |
| **App Insights** | Monitoring & logging | Application Insights |

---

## Integration Points

```
┌─────────────────────────────────────────────────────────┐
│              External Integrations                      │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  1. Dynamics 365 Timeline                                │
│     • Custom link format                                │
│     • Context-aware (contactId)                          │
│                                                          │
│  2. Azure AD Easy Auth                                   │
│     • Header injection                                   │
│     • Token provisioning                                 │
│                                                          │
│  3. Dataverse Web API                                    │
│     • Contact record access                             │
│     • Security role validation                           │
│                                                          │
│  4. Azure Blob Storage                                   │
│     • Container: smart-office                            │
│     • SAS token generation                               │
│                                                          │
│  5. Application Insights                                 │
│     • Telemetry ingestion                               │
│     • Log aggregation                                    │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

---

## Deployment Architecture

### Deployment Pipeline

```
┌──────────────┐     ┌──────────┐     ┌─────────────┐     ┌──────────────┐
│ Source Code  │ --> │  Build   │ --> │   Test     │ --> │   Deploy     │
│ (GitHub/ADO) │     │ (.NET)   │     │ (xUnit)    │     │ (Azure)      │
└──────────────┘     └──────────┘     └─────────────┘     └──────────────┘
                                                                    │
                                                                    ▼
                                                           ┌──────────────┐
                                                           │ Function App │
                                                           │   (Azure)    │
                                                           └──────────────┘
```

---

## Data Flow Summary

```
User Request
    │
    ├─> Authentication (Azure AD Easy Auth)
    │
    ├─> Authorization (Dataverse API)
    │
    ├─> Path Processing (Normalization)
    │
    ├─> Blob Access (SAS URL Generation)
    │
    └─> File Delivery (302 Redirect)
```

---

## Security Flow

```
Unauthenticated Request
    │
    ├─> Azure AD Login
    │
    └─> Authenticated Request
            │
            ├─> Extract Token & Principal
            │
            ├─> Validate Dataverse Access
            │
            ├─> Generate Time-Limited SAS
            │
            └─> Return Secure URL
```

---

## Key Design Decisions

1. **Isolated Process Model**
   - Better performance and compatibility
   - Full .NET 8 features available

2. **Consumption Plan**
   - Auto-scaling
   - Cost-effective for variable traffic

3. **Easy Auth vs Custom Auth**
   - Easier to implement
   - Built-in SSO support
   - Less code to maintain

4. **Dataverse API Validation**
   - Leverages existing security model
   - No duplicate authorization logic

5. **15-Minute SAS Expiration**
   - Balance between usability and security
   - Prevents long-lived access tokens

6. **302 Redirect vs Direct Return**
   - Browser handles file properly
   - Better user experience

---

## Architecture Principles

✅ **Security First** - Multiple layers of security  
✅ **Separation of Concerns** - Service-based architecture  
✅ **Scalability** - Consumption plan auto-scaling  
✅ **Observability** - Comprehensive logging  
✅ **Reliability** - Error handling and retries  
✅ **Maintainability** - Clean code, dependency injection  
✅ **Performance** - Optimized for speed  

---

See `USER_STORIES.md` for detailed user stories and requirements.

