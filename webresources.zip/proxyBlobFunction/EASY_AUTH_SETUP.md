# Azure AD Easy Auth Setup Guide

## ✅ What You Need for the Current Implementation

The current implementation uses **Azure AD Easy Auth** with **user delegation**. Here's what you need:

---

## 🎯 Quick Answer

You **DO NOT need** a client secret for the basic setup!

**What you need:**
1. ✅ Azure AD App Registration (created automatically by Easy Auth)
2. ✅ API permissions for Dynamics CRM
3. ❌ **No client secret required**

The user's identity is passed through to Dataverse automatically.

---

## 📋 Step-by-Step Setup

### Step 1: Configure Easy Auth (Azure Portal)

1. **Navigate to your Function App**
   - Azure Portal → Function Apps → Your Function App

2. **Settings → Authentication**
   - Click **Add identity provider**
   - Select **Microsoft**

3. **Configure Authentication Settings:**
   ```
   App registration type: Create new app registration
   Name: [your-function-app-name]-auth
   Supported account types: Current tenant - Single tenant
   Restrict access: Require authentication
   Unauthenticated requests: HTTP 302 Found redirect
   Token store: ✅ Enabled
   ```

4. **Click Add**

✅ **An app registration is created automatically!**

---

### Step 2: Get Your Client ID (Information Only)

The Client ID was created automatically, but you can find it:

**Azure Portal:**
1. Function App → Authentication
2. Click on the Microsoft provider
3. You'll see **Client ID** (also called Application ID)

**Or via Azure CLI:**
```bash
# Get the client ID
az functionapp auth show \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --query identityProviders.azureActiveDirectory.registration.clientId -o tsv
```

📝 **Note:** The `ClientId` setting in `local.settings.json` is **optional** and only needed if you're using Managed Identity for storage access (advanced scenario).

---

### Step 3: Configure API Permissions for Dynamics 365

The app registration needs permission to access Dynamics 365 on behalf of the user.

**Azure Portal Method:**

1. **Go to Azure AD → App registrations**
   - Search for `[your-function-app-name]-auth`
   - Click on it

2. **API permissions → Add a permission**
   - Click **APIs my organization uses**
   - Search for **Dynamics CRM** (or **Common Data Service**)
   - Click it

3. **Select Delegated permissions**
   - ✅ Check `user_impersonation`
   - Click **Add permissions**

4. **Grant admin consent**
   - Click **Grant admin consent for [Your Tenant]**
   - Click **Yes**

**Azure CLI Method:**

```bash
# Get the app registration ID
APP_ID=$(az functionapp auth show \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --query identityProviders.azureActiveDirectory.registration.clientId -o tsv)

echo "App ID: $APP_ID"

# Get Dynamics CRM API ID (this is a well-known ID)
DYNAMICS_API="00000007-0000-0000-c000-000000000000"

# Add user_impersonation permission
az ad app permission add \
  --id $APP_ID \
  --api $DYNAMICS_API \
  --api-permissions 78ce3f0f-a1ce-49c2-8cde-64b5c0896db4=Scope

# Grant admin consent
az ad app permission admin-consent --id $APP_ID
```

✅ **That's it! No secrets needed!**

---

### Step 4: Configure Function App Settings

**Required Settings:**

| Setting | Value | Where to Set |
|---------|-------|-------------|
| `AzureWebJobsStorage` | Storage connection string | App Settings |
| `DataverseUrl` | `https://yourorg.crm.dynamics.com` | App Settings |
| `BlobContainerName` | `kofcext-extractions` | App Settings |

**Optional Settings:**

| Setting | Value | When Needed |
|---------|-------|-------------|
| `ClientId` | From Step 2 | Only for Managed Identity scenarios |

**Azure Portal:**
```
Function App → Configuration → Application settings → New application setting
```

**Azure CLI:**
```bash
az functionapp config appsettings set \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --settings \
    "DataverseUrl=https://yourorg.crm.dynamics.com" \
    "BlobContainerName=kofcext-extractions"
```

---

## 🔐 How Authentication Works

```
User → Function URL → Easy Auth → Azure AD Login
                           ↓
                    Token Generated
                           ↓
            Headers Added to Request:
            - X-MS-TOKEN-AAD-ACCESS-TOKEN (for Dataverse)
            - X-MS-CLIENT-PRINCIPAL (user info)
                           ↓
                  Your Function Code
                           ↓
              Uses token to call Dataverse
                  (as the user!)
```

**Key Point:** The function acts **on behalf of the user**, using **their permissions**.

---

## ✅ Verify Setup

### Test Authentication:

1. **Open Function URL in browser:**
   ```
   https://YOUR-FUNCTION-APP.azurewebsites.net/api/GetSaasBlobUrl?path=D:\test\file.txt&contactId=...
   ```

2. **Expected:** Redirected to Microsoft login

3. **After login:** Function should process request

### Check Headers (for debugging):

Add this to your function temporarily:

```csharp
var accessToken = GetHeaderValue(req, "X-MS-TOKEN-AAD-ACCESS-TOKEN");
var principal = GetHeaderValue(req, "X-MS-CLIENT-PRINCIPAL");

_logger.LogInformation("Has access token: {HasToken}", !string.IsNullOrEmpty(accessToken));
_logger.LogInformation("Has principal: {HasPrincipal}", !string.IsNullOrEmpty(principal));
```

If these are empty, Easy Auth is not configured correctly.

---

## 🆚 Client ID vs Client Secret

### Client ID (Application ID)
- ✅ **Public identifier**
- ✅ **Safe to log**
- ✅ **Automatically created by Easy Auth**
- ✅ **You have this already!**

### Client Secret (NOT NEEDED for user delegation)
- ❌ **Sensitive credential**
- ❌ **Not needed for user delegation**
- ❌ **Only needed for service-to-service auth**
- ⚠️ **Don't create unless you need service principal auth**

---

## 🔧 Troubleshooting

### Issue: "Headers not found" (401 error)

**Check:**
```bash
# Verify Easy Auth is enabled
az functionapp auth show \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --query enabled -o tsv
```

Should return: `true`

**Fix:**
```bash
# Enable authentication
az functionapp auth update \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --enabled true \
  --action LoginWithAzureActiveDirectory
```

---

### Issue: "User consent required"

**Symptom:** Users see consent screen on first login

**This is normal!** But if you want to pre-consent:

```bash
# Grant admin consent (from Step 3)
az ad app permission admin-consent --id $APP_ID
```

---

### Issue: "Access denied to Dataverse" (403 error)

**Cause:** User doesn't have permission to the contact record in Dynamics 365

**Fix:** Grant appropriate security role in Dynamics 365

---

### Issue: "The reply URL... does not match"

**Cause:** Redirect URI not configured

**Fix:** Azure automatically configures this, but verify:

```
Azure AD → App registrations → Your app → Authentication
Should have:
  https://YOUR-FUNCTION-APP.azurewebsites.net/.auth/login/aad/callback
```

---

## 📝 Summary: What You Actually Need

### ✅ Created Automatically by Easy Auth:
1. App Registration in Azure AD
2. Client ID (Application ID)
3. Redirect URIs

### ✅ You Must Configure Manually:
1. API permissions for Dynamics CRM
2. Admin consent
3. Function App settings (DataverseUrl, etc.)

### ❌ You Do NOT Need:
1. Client Secret
2. Certificate
3. Service Principal
4. Application User in Dynamics 365

---

## 🎯 Quick Reference Commands

```bash
# Get your app's client ID
az functionapp auth show \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --query identityProviders.azureActiveDirectory.registration.clientId

# Add Dynamics CRM permission
APP_ID="your-app-id"
az ad app permission add \
  --id $APP_ID \
  --api 00000007-0000-0000-c000-000000000000 \
  --api-permissions 78ce3f0f-a1ce-49c2-8cde-64b5c0896db4=Scope

# Grant admin consent
az ad app permission admin-consent --id $APP_ID

# Configure function settings
az functionapp config appsettings set \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --settings "DataverseUrl=https://yourorg.crm.dynamics.com"
```

---

## 🚀 Next Steps

1. ✅ Easy Auth configured
2. ✅ API permissions granted
3. ✅ Settings configured
4. 🧪 Test the function!

See **AZURE_SETUP_GUIDE.md** for complete deployment instructions.

---

## 📚 When You WOULD Need Client Secret

Only needed for **service principal authentication** (service-to-service, no user context):

- Background jobs
- Timer triggers
- Service accounts

See **DYNAMICS_365_AUTH_SETUP.md** for that advanced scenario.

For **this project**, stick with user delegation! ✅

