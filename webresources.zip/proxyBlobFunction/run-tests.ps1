# PowerShell script to run all tests with detailed output

param(
    [Parameter(Mandatory=$false)]
    [switch]$Watch,
    
    [Parameter(Mandatory=$false)]
    [switch]$Coverage,
    
    [Parameter(Mandatory=$false)]
    [string]$Filter = ""
)

Write-Host "🧪 Running Azure Function Tests" -ForegroundColor Cyan
Write-Host "================================" -ForegroundColor Cyan
Write-Host ""

# Navigate to test project
Push-Location "KOFC.Azure.Functions.GetSaasBlobUrl.Tests"

try {
    # Build command
    $testCommand = "dotnet test"
    
    if ($Watch) {
        $testCommand += " --watch"
        Write-Host "👀 Running in watch mode..." -ForegroundColor Yellow
    }
    
    if ($Coverage) {
        $testCommand += ' --collect:"XPlat Code Coverage"'
        Write-Host "📊 Collecting code coverage..." -ForegroundColor Yellow
    }
    
    if ($Filter) {
        $testCommand += " --filter `"$Filter`""
        Write-Host "🔍 Filter: $Filter" -ForegroundColor Yellow
    }
    
    $testCommand += " --logger `"console;verbosity=detailed`""
    
    Write-Host "🏃 Running: $testCommand" -ForegroundColor Gray
    Write-Host ""
    Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
    Write-Host ""
    
    # Run tests
    Invoke-Expression $testCommand
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
        Write-Host "✅ All tests passed!" -ForegroundColor Green
        
        if ($Coverage) {
            Write-Host ""
            Write-Host "📊 Coverage report generated in TestResults/" -ForegroundColor Cyan
            Write-Host "   To view, install: dotnet tool install -g dotnet-reportgenerator-globaltool" -ForegroundColor Gray
            Write-Host "   Then run: reportgenerator -reports:TestResults/**/coverage.cobertura.xml -targetdir:coveragereport" -ForegroundColor Gray
        }
    } else {
        Write-Host ""
        Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
        Write-Host "❌ Some tests failed!" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "❌ Error running tests: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
} finally {
    Pop-Location
}

Write-Host ""
Write-Host "💡 Tips:" -ForegroundColor Cyan
Write-Host "  .\run-tests.ps1 -Watch              # Watch mode for TDD" -ForegroundColor Gray
Write-Host "  .\run-tests.ps1 -Coverage           # Generate coverage report" -ForegroundColor Gray
Write-Host '  .\run-tests.ps1 -Filter "BlobService"  # Run specific tests' -ForegroundColor Gray
Write-Host ""

