# Quick Start Guide

Get the Azure Function App running in under 10 minutes.

## Prerequisites Checklist

- [ ] .NET 8.0 SDK installed
- [ ] Azure CLI installed
- [ ] Azure subscription access
- [ ] Dynamics 365 environment
- [ ] Storage account created

## Local Development (5 minutes)

### 1. Configure Local Settings

Edit `MIS.Azure.Functions.GetSaasBlobUrl/local.settings.json`:

```json
{
  "IsEncrypted": false,
  "Values": {
    "AzureWebJobsStorage": "DefaultEndpointsProtocol=https;AccountName=YOUR_STORAGE;AccountKey=YOUR_KEY;EndpointSuffix=core.windows.net",
    "FUNCTIONS_WORKER_RUNTIME": "dotnet-isolated",
    "DataverseUrl": "https://yourorg.crm.dynamics.com",
    "BlobContainerName": "kofcext-extractions"
  }
}
```

### 2. Build and Run

```bash
cd MIS.Azure.Functions.GetSaasBlobUrl
dotnet restore
dotnet build
func start
```

Function will be available at: `http://localhost:7071/api/GetSaasBlobUrl`

### 3. Test Locally

```bash
# Note: Easy Auth headers won't be available locally
# You'll get 401 responses unless you modify the function for local testing
```

## Azure Deployment (5 minutes)

### Option 1: Quick Deploy via CLI

```bash
# Login to Azure
az login

# Deploy (replace with your function app name)
cd MIS.Azure.Functions.GetSaasBlobUrl
func azure functionapp publish YOUR-FUNCTION-APP-NAME
```

### Option 2: Visual Studio

1. Right-click project → **Publish**
2. Select **Azure Function App**
3. Choose existing or create new
4. Click **Publish**

### Option 3: VS Code

1. Install Azure Functions extension
2. Click Azure icon in sidebar
3. Deploy to Function App

## Configure Easy Auth (Azure Portal)

### 1-Minute Setup

1. Open your Function App in Azure Portal
2. **Settings** → **Authentication** → **Add identity provider**
3. Select **Microsoft**
4. Accept defaults
5. Click **Add**

### Add Dataverse Permissions

1. Click the app registration link
2. **API permissions** → **Add a permission**
3. Select **Dynamics CRM**
4. Check **user_impersonation**
5. **Grant admin consent**

## Test the Deployment

### Test URL Format

```
https://YOUR-FUNCTION-APP.azurewebsites.net/api/GetSaasBlobUrl?path=D:\KOFCExt%20Extractions\09272024\000554\document.xlsx&contactId=12345678-1234-1234-1234-123456789012
```

### Expected Flow

1. Browser redirects to Microsoft login
2. User authenticates
3. Function validates Dataverse access
4. Browser redirects to blob with SAS token
5. File downloads or displays

## Run Tests

```bash
cd MIS.Azure.Functions.GetSaasBlobUrl.Tests
dotnet test
```

Expected output:
```
Passed!  - Failed:     0, Passed:    XX, Skipped:     0, Total:    XX
```

## Essential Configuration Settings

| Setting | Where to Set | Value |
|---------|-------------|-------|
| `AzureWebJobsStorage` | App Settings | Storage connection string |
| `DataverseUrl` | App Settings | `https://yourorg.crm.dynamics.com` |
| `BlobContainerName` | App Settings | `kofcext-extractions` |
| Easy Auth | Authentication blade | Microsoft Identity Platform |
| API Permissions | App Registration | Dynamics CRM - user_impersonation |

## Common First-Time Issues

### Issue: "Cannot find module"

```bash
# Solution: Restore packages
dotnet restore
```

### Issue: "Function not found"

```bash
# Solution: Rebuild project
dotnet clean
dotnet build
```

### Issue: "401 Unauthorized"

**Cause**: Easy Auth not configured

**Solution**: Follow "Configure Easy Auth" section above

### Issue: "403 Forbidden"

**Cause**: User doesn't have Dataverse access

**Solution**: 
- Grant user appropriate security role in Dynamics 365
- Verify API permissions are granted

### Issue: "404 Not Found"

**Cause**: Blob doesn't exist

**Solution**:
- Check blob exists in storage
- Verify container name is correct
- Check path normalization in logs

## Next Steps

1. ✅ Function deployed and running
2. ✅ Easy Auth configured
3. ✅ First successful request
4. 📊 Set up monitoring (see AZURE_SETUP_GUIDE.md)
5. 🔒 Configure additional security (Key Vault, Managed Identity)
6. 🎯 Set up CI/CD pipeline (see README.md)

## Useful Commands

### View Logs

```bash
func azure functionapp logstream YOUR-FUNCTION-APP-NAME
```

### Get Function Keys

```bash
func azure functionapp list-functions YOUR-FUNCTION-APP-NAME --show-keys
```

### Restart Function App

```bash
az functionapp restart --name YOUR-FUNCTION-APP-NAME --resource-group YOUR-RESOURCE-GROUP
```

### Check Function Status

```bash
az functionapp show --name YOUR-FUNCTION-APP-NAME --resource-group YOUR-RESOURCE-GROUP --query state
```

## Documentation Index

- **README.md** - Complete project documentation
- **AZURE_SETUP_GUIDE.md** - Detailed Azure configuration
- **QUICK_START.md** - This file (quick reference)

## Support

- 📖 Check README.md for detailed documentation
- 🔧 See AZURE_SETUP_GUIDE.md for troubleshooting
- 📊 Review Application Insights for errors
- 🎯 Check Azure Portal for configuration

---

**Tip**: Bookmark this guide for quick reference during development and deployment!

