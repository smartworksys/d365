# PowerShell script to deploy Azure Function App (assumes resources already exist)
# Usage: .\deploy-only.ps1

param(
    [Parameter(Mandatory=$false)]
    [string]$FunctionAppName = "ProxyBlobAccess",
    
    [Parameter(Mandatory=$false)]
    [string]$ResourceGroupName = "ProxyBlobAccess_group"
)

$ErrorActionPreference = "Stop"

Write-Host "🚀 Deploying Azure Function App" -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Cyan
Write-Host ""

# Navigate to project directory
$projectPath = "KOFC.Azure.Functions.GetSaasBlobUrl"

if (-not (Test-Path $projectPath)) {
    Write-Host "❌ Project path not found: $projectPath" -ForegroundColor Red
    exit 1
}

Push-Location $projectPath

try {
    # Clean
    Write-Host "🧹 Cleaning project..." -ForegroundColor Yellow
    dotnet clean -c Release | Out-Null
    
    # Build
    Write-Host "🔨 Building project..." -ForegroundColor Yellow
    dotnet build -c Release
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ Build failed!" -ForegroundColor Red
        exit 1
    }
    
    # Publish
    Write-Host "📦 Publishing project..." -ForegroundColor Yellow
    dotnet publish -c Release -o ./publish
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ Publish failed!" -ForegroundColor Red
        exit 1
    }
    
    # Deploy
    Write-Host "🚀 Deploying to Azure..." -ForegroundColor Yellow
    func azure functionapp publish $FunctionAppName --dotnet-isolated
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ Deployment failed!" -ForegroundColor Red
        exit 1
    }
    
    Write-Host ""
    Write-Host "✅ Deployment successful!" -ForegroundColor Green
    Write-Host ""
    
    # Get function URL
    Write-Host "🔗 Getting function URL..." -ForegroundColor Yellow
    $functionUrl = az functionapp function show `
        --name $FunctionAppName `
        --resource-group $ResourceGroupName `
        --function-name GetSaasBlobUrl `
        --query invokeUrlTemplate `
        -o tsv 2>&1
    
    if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace($functionUrl)) {
        Write-Host "✅ Function URL: $functionUrl" -ForegroundColor Cyan
    }
    
} catch {
    Write-Host "❌ Error: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
} finally {
    Pop-Location
}

Write-Host ""

