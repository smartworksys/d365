# PowerShell script to test the Azure Function locally
# Usage: .\test-local.ps1 -Path "D:\test\file.txt" -ContactId "12345678-1234-1234-1234-123456789012"

param(
    [Parameter(Mandatory=$false)]
    [string]$Path = "D:\KOFCExt Extractions\09272024\000554\test.xlsx",
    
    [Parameter(Mandatory=$false)]
    [string]$ContactId = "12345678-1234-1234-1234-123456789012",
    
    [Parameter(Mandatory=$false)]
    [string]$Endpoint = "http://localhost:7071/api/GetSaasBlobUrlLocal",
    
    [Parameter(Mandatory=$false)]
    [switch]$OpenInBrowser
)

Write-Host "🧪 Testing Azure Function Locally" -ForegroundColor Cyan
Write-Host "=================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Path: $Path" -ForegroundColor Yellow
Write-Host "ContactId: $ContactId" -ForegroundColor Yellow
Write-Host "Endpoint: $Endpoint" -ForegroundColor Yellow
Write-Host ""

# URL encode the path
Add-Type -AssemblyName System.Web
$encodedPath = [System.Web.HttpUtility]::UrlEncode($Path)
$fullUrl = "$Endpoint?path=$encodedPath&contactId=$ContactId"

Write-Host "📡 Full URL:" -ForegroundColor Green
Write-Host $fullUrl
Write-Host ""

if ($OpenInBrowser) {
    Write-Host "🌐 Opening in browser..." -ForegroundColor Magenta
    Start-Process $fullUrl
} else {
    Write-Host "📥 Sending HTTP request..." -ForegroundColor Magenta
    try {
        $response = Invoke-WebRequest -Uri $fullUrl -Method Get -MaximumRedirection 0 -ErrorAction SilentlyContinue
        
        if ($response.StatusCode -eq 302) {
            $sasUrl = $response.Headers.Location
            Write-Host "✅ Success! Got SAS URL:" -ForegroundColor Green
            Write-Host $sasUrl -ForegroundColor White
            Write-Host ""
            Write-Host "🌐 Opening blob in browser..." -ForegroundColor Magenta
            Start-Process $sasUrl
        } else {
            Write-Host "⚠️  Unexpected status code: $($response.StatusCode)" -ForegroundColor Yellow
            Write-Host $response.Content
        }
    }
    catch {
        if ($_.Exception.Response.StatusCode -eq 302) {
            $sasUrl = $_.Exception.Response.Headers.Location
            Write-Host "✅ Success! Got SAS URL:" -ForegroundColor Green
            Write-Host $sasUrl -ForegroundColor White
            Write-Host ""
            $openNow = Read-Host "Open in browser? (y/n)"
            if ($openNow -eq 'y') {
                Start-Process $sasUrl
            }
        } else {
            Write-Host "❌ Error: $($_.Exception.Message)" -ForegroundColor Red
            if ($_.Exception.Response) {
                $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
                $responseBody = $reader.ReadToEnd()
                Write-Host "Response: $responseBody" -ForegroundColor Red
            }
        }
    }
}

Write-Host ""
Write-Host "💡 Tips:" -ForegroundColor Cyan
Write-Host "  - Make sure the function is running: func start" -ForegroundColor Gray
Write-Host "  - Use -OpenInBrowser to open URL directly in browser" -ForegroundColor Gray
Write-Host "  - The local endpoint skips authentication for testing" -ForegroundColor Gray
Write-Host ""
Write-Host "Examples:" -ForegroundColor Cyan
Write-Host '  .\test-local.ps1 -Path "D:\test\file.txt"' -ForegroundColor Gray
Write-Host '  .\test-local.ps1 -Path "D:\test\file.txt" -OpenInBrowser' -ForegroundColor Gray

