# 🚀 Quick Local Testing (3 Steps)

## The Simplest Way to Test Locally

### Step 1: Configure Storage (30 seconds)

Edit `MIS.Azure.Functions.GetSaasBlobUrl\local.settings.json`:

```json
{
  "IsEncrypted": false,
  "Values": {
    "AzureWebJobsStorage": "YOUR_STORAGE_CONNECTION_STRING_HERE",
    "FUNCTIONS_WORKER_RUNTIME": "dotnet-isolated",
    "DataverseUrl": "https://yourorg.crm.dynamics.com",
    "BlobContainerName": "kofcext-extractions"
  }
}
```

**Where to get your storage connection string:**
- Azure Portal → Your Storage Account → Access Keys → Connection String

**Or use local emulator:**
```json
"AzureWebJobsStorage": "UseDevelopmentStorage=true"
```

---

### Step 2: Start the Function (1 command)

**Option A: Using PowerShell script (Recommended)**
```powershell
.\start-local.ps1
```

**Option B: Manual**
```powershell
cd MIS.Azure.Functions.GetSaasBlobUrl
dotnet build
func start
```

You should see:
```
Functions:
        GetSaasBlobUrl: [GET] http://localhost:7071/api/GetSaasBlobUrl
        GetSaasBlobUrlLocal: [GET] http://localhost:7071/api/GetSaasBlobUrlLocal
```

---

### Step 3: Test It (1 command or open browser)

**Option A: Using test script (Easiest)**
```powershell
.\test-local.ps1 -Path "D:\test\file.txt" -ContactId "12345678-1234-1234-1234-123456789012"
```

**Option B: Open in browser**
```
http://localhost:7071/api/GetSaasBlobUrlLocal?path=D:\test\file.txt&contactId=12345678-1234-1234-1234-123456789012
```

**Option C: PowerShell one-liner**
```powershell
$url = "http://localhost:7071/api/GetSaasBlobUrlLocal?path=D:\test\file.txt&contactId=12345678-1234-1234-1234-123456789012"
Start-Process $url
```

---

## ✅ Expected Results

### Success (File Exists):
- **Status**: 302 Redirect
- **Redirects to**: `https://yourstorage.blob.core.windows.net/container/path/file.txt?sv=2021...`
- **Browser**: Opens the file directly

### File Not Found:
- **Status**: 404 Not Found
- **Message**: "Not Found: The requested file does not exist"

### Invalid Parameters:
- **Status**: 400 Bad Request
- **Message**: "Bad Request: Missing 'path' parameter"

---

## 🎯 Which Endpoint to Use?

| Endpoint | Authentication | Dataverse | Use Case |
|----------|---------------|-----------|----------|
| **GetSaasBlobUrlLocal** | ❌ None | ❌ Skipped | **Local testing** |
| **GetSaasBlobUrl** | ✅ Required | ✅ Validated | **Production only** |

### For Local Development:
👉 **Use `GetSaasBlobUrlLocal`** - No auth required, works immediately

### Testing Full Auth Flow:
👉 **Deploy to Azure Dev environment** - See AZURE_SETUP_GUIDE.md

---

## 🧪 Test Scenarios

### Test 1: Path Normalization
```powershell
# Input: Windows path with drive letter
.\test-local.ps1 -Path "D:\KOFCExt Extractions\09272024\000554\document.xlsx"

# Expected normalized path in logs: 09272024/000554/document.xlsx
```

### Test 2: Special Characters
```powershell
.\test-local.ps1 -Path "D:\folder with spaces\file-name_v2.pdf"
```

### Test 3: Missing File (404)
```powershell
.\test-local.ps1 -Path "D:\nonexistent\file.txt"
# Expected: 404 Not Found
```

### Test 4: Invalid Parameters (400)
```powershell
# Missing path
Invoke-WebRequest "http://localhost:7071/api/GetSaasBlobUrlLocal?contactId=123"
# Expected: 400 Bad Request
```

---

## 📊 Run Unit Tests

### All Tests:
```powershell
.\run-tests.ps1
```

### Watch Mode (for development):
```powershell
.\run-tests.ps1 -Watch
```

### Specific Tests:
```powershell
# Test path normalization only
.\run-tests.ps1 -Filter "BlobServiceTests"

# Test Dataverse validation
.\run-tests.ps1 -Filter "DataverseServiceTests"
```

### With Coverage:
```powershell
.\run-tests.ps1 -Coverage
```

---

## 🔍 View Logs

While the function is running, you'll see detailed logs:

```
[2024-11-02 10:30:15] ⚠️ USING LOCAL TESTING ENDPOINT - NO AUTH VALIDATION ⚠️
[2024-11-02 10:30:15] Request parameters - Path: D:\test\file.txt, ContactId: 12345678-1234-1234-1234-123456789012
[2024-11-02 10:30:15] Normalized path from 'D:\test\file.txt' to 'test/file.txt'
[2024-11-02 10:30:16] Generated SAS URL for blob 'test/file.txt' in container 'kofcext-extractions'
[2024-11-02 10:30:16] Successfully generated SAS URL for blob test/file.txt
```

---

## ⚠️ Troubleshooting

### Problem: "Storage account not found"
```
❌ Error: The remote name could not be resolved: 'yourstorage.blob.core.windows.net'
```

**Solution**: Check your storage connection string in `local.settings.json`

---

### Problem: "Blob not found"
```
❌ 404 Not Found: The requested file does not exist
```

**Solution**: 
1. Verify the blob exists in your storage account
2. Check the container name is correct
3. View the normalized path in logs to see what it's looking for

**Create test blob:**
```bash
# Azure CLI
az storage blob upload \
  --account-name yourstorage \
  --container-name kofcext-extractions \
  --name "test/file.txt" \
  --file "C:\local\testfile.txt"
```

---

### Problem: "Function host not starting"
```
❌ The listener for function 'GetSaasBlobUrl' was unable to start
```

**Solution**:
```powershell
# Clean and rebuild
cd MIS.Azure.Functions.GetSaasBlobUrl
dotnet clean
dotnet build
func start --verbose
```

---

### Problem: "Port already in use"
```
❌ Failed to bind to address http://127.0.0.1:7071
```

**Solution**: Change the port
```powershell
func start --port 7072
```

Then update test script:
```powershell
.\test-local.ps1 -Endpoint "http://localhost:7072/api/GetSaasBlobUrlLocal"
```

---

## 🎓 Understanding the Difference

### Production Endpoint (`GetSaasBlobUrl`):
```
Browser → Azure AD Login → Easy Auth Headers → Function → Dataverse Check → Blob SAS
          ✅ User authenticated     ↓                    ↓
                                Headers:           Validates access
                                X-MS-TOKEN-AAD-ACCESS-TOKEN
                                X-MS-CLIENT-PRINCIPAL
```

### Local Endpoint (`GetSaasBlobUrlLocal`):
```
Browser → Function → Blob SAS
          ⚠️ NO AUTH   ⚠️ NO DATAVERSE
```

**Why?** Easy Auth headers are ONLY available in Azure App Service, not in local Functions runtime.

---

## 🚀 Next Steps

1. ✅ Tested locally with `GetSaasBlobUrlLocal`
2. ✅ All unit tests passing
3. 📦 Ready to deploy to Azure
4. 🔒 Configure Easy Auth for full security
5. 🧪 Test production endpoint with real authentication

---

## 📚 More Information

- **Full documentation**: See `README.md`
- **Azure setup**: See `AZURE_SETUP_GUIDE.md`
- **Detailed local testing**: See `LOCAL_TESTING_GUIDE.md`

---

## 💡 Pro Tips

1. **Use watch mode for unit tests** while developing:
   ```powershell
   .\run-tests.ps1 -Watch
   ```

2. **Keep function running** in one terminal, test in another:
   ```powershell
   # Terminal 1
   .\start-local.ps1

   # Terminal 2
   .\test-local.ps1 -Path "D:\different\file.txt"
   ```

3. **Check normalized paths** in logs to debug path issues

4. **Use Azurite** for completely local testing (no Azure required):
   ```bash
   npm install -g azurite
   azurite --silent
   ```
   Then set: `"AzureWebJobsStorage": "UseDevelopmentStorage=true"`

---

**That's it! 🎉 You're ready to test locally!**

