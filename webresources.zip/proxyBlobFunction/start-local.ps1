# PowerShell script to start the Azure Function locally with checks

Write-Host "🚀 Starting Azure Function App Locally" -ForegroundColor Cyan
Write-Host "======================================" -ForegroundColor Cyan
Write-Host ""

# Check if .NET is installed
Write-Host "🔍 Checking prerequisites..." -ForegroundColor Yellow
try {
    $dotnetVersion = dotnet --version
    Write-Host "✅ .NET SDK: $dotnetVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ .NET SDK not found! Please install .NET 8.0 SDK" -ForegroundColor Red
    exit 1
}

# Check if Azure Functions Core Tools is installed
try {
    $funcVersion = func --version
    Write-Host "✅ Azure Functions Core Tools: $funcVersion" -ForegroundColor Green
} catch {
    Write-Host "❌ Azure Functions Core Tools not found!" -ForegroundColor Red
    Write-Host "   Install from: https://docs.microsoft.com/en-us/azure/azure-functions/functions-run-local" -ForegroundColor Yellow
    exit 1
}

Write-Host ""

# Check if local.settings.json exists
$settingsPath = "KOFC.Azure.Functions.GetSaasBlobUrl\local.settings.json"
if (-not (Test-Path $settingsPath)) {
    Write-Host "❌ local.settings.json not found!" -ForegroundColor Red
    Write-Host "   Please configure your settings first" -ForegroundColor Yellow
    exit 1
}

# Read and validate settings
Write-Host "🔧 Validating configuration..." -ForegroundColor Yellow
try {
    $settings = Get-Content $settingsPath | ConvertFrom-Json
    $storageConnection = $settings.Values.AzureWebJobsStorage
    
    if ($storageConnection -eq "UseDevelopmentStorage=true") {
        Write-Host "⚠️  Using Azurite (local storage emulator)" -ForegroundColor Yellow
        Write-Host "   Make sure Azurite is running: azurite" -ForegroundColor Gray
    } elseif ($storageConnection -like "DefaultEndpointsProtocol*") {
        Write-Host "✅ Using Azure Storage Account" -ForegroundColor Green
    } else {
        Write-Host "❌ Invalid AzureWebJobsStorage configuration" -ForegroundColor Red
        exit 1
    }
    
    $dataverseUrl = $settings.Values.DataverseUrl
    if ($dataverseUrl) {
        Write-Host "✅ Dataverse URL: $dataverseUrl" -ForegroundColor Green
    } else {
        Write-Host "⚠️  Dataverse URL not configured" -ForegroundColor Yellow
    }
} catch {
    Write-Host "❌ Error reading local.settings.json: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

Write-Host ""

# Build the project
Write-Host "🔨 Building project..." -ForegroundColor Yellow
Push-Location "KOFC.Azure.Functions.GetSaasBlobUrl"
try {
    $buildOutput = dotnet build 2>&1
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ Build successful!" -ForegroundColor Green
    } else {
        Write-Host "❌ Build failed!" -ForegroundColor Red
        Write-Host $buildOutput -ForegroundColor Red
        Pop-Location
        exit 1
    }
} catch {
    Write-Host "❌ Build error: $($_.Exception.Message)" -ForegroundColor Red
    Pop-Location
    exit 1
}

Write-Host ""
Write-Host "🎯 Available endpoints:" -ForegroundColor Cyan
Write-Host "  • GetSaasBlobUrl (production - requires auth headers)" -ForegroundColor White
Write-Host "    http://localhost:7071/api/GetSaasBlobUrl" -ForegroundColor Gray
Write-Host ""
Write-Host "  • GetSaasBlobUrlLocal (development - no auth)" -ForegroundColor White
Write-Host "    http://localhost:7071/api/GetSaasBlobUrlLocal" -ForegroundColor Gray
Write-Host ""

Write-Host "🏃 Starting function host..." -ForegroundColor Yellow
Write-Host ""
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
Write-Host ""

# Start the function
func start

Pop-Location

