# Alternative: Service Principal Authentication

⚠️ **Note**: The current implementation uses **user delegation**. Only use service principal authentication if you need background/service-to-service access.

## When to Use This

- Background jobs without user context
- Timer-triggered functions
- Service accounts with fixed permissions

## Setup Steps

### Step 1: Create App Registration

```bash
# Create app registration
az ad app create \
  --display-name "SaaSBlob-Service-Principal" \
  --sign-in-audience AzureADMyOrg

# Get the App ID
APP_ID=$(az ad app list --display-name "SaaSBlob-Service-Principal" --query "[0].appId" -o tsv)
echo "Client ID: $APP_ID"

# Create a client secret
az ad app credential reset \
  --id $APP_ID \
  --append \
  --credential-description "SaaSBlob Function Secret"
```

**Save the output:**
```json
{
  "appId": "12345678-1234-1234-1234-123456789012",  // Client ID
  "password": "secret-value-here",                   // Client Secret
  "tenant": "87654321-4321-4321-4321-210987654321"  // Tenant ID
}
```

---

### Step 2: Add API Permissions

```bash
# Get Dynamics CRM API ID
DYNAMICS_API=$(az ad sp list --display-name "Dynamics CRM" --query "[0].appId" -o tsv)

# Add permission
az ad app permission add \
  --id $APP_ID \
  --api $DYNAMICS_API \
  --api-permissions 78ce3f0f-a1ce-49c2-8cde-64b5c0896db4=Scope

# Grant admin consent
az ad app permission admin-consent --id $APP_ID
```

---

### Step 3: Create Application User in Dynamics 365

The service principal needs to be registered in Dynamics 365:

1. **Go to Power Platform Admin Center**
   - https://admin.powerplatform.microsoft.com/

2. **Select your environment** → **Settings** → **Users + permissions** → **Application users**

3. **New app user**:
   ```
   App: Select your app registration
   Business unit: Select appropriate unit
   Security roles: Assign appropriate roles (e.g., System Administrator for testing)
   ```

**Or via PowerShell:**
```powershell
# Install module
Install-Module Microsoft.Xrm.Data.PowerShell -Scope CurrentUser

# Connect
Connect-CrmOnline -ServerUrl "https://yourorg.crm.dynamics.com"

# Create application user
$appId = "YOUR-CLIENT-ID"
New-CrmRecord -EntityLogicalName systemuser -Fields @{
    "applicationid" = $appId
    "firstname" = "SaaSBlob"
    "lastname" = "Service Principal"
}
```

---

### Step 4: Update Function Code

Create a new service for service principal auth:

```csharp
// Services/IAuthService.cs
public interface IAuthService
{
    Task<string> GetAccessTokenAsync();
}

// Services/ServicePrincipalAuthService.cs
public class ServicePrincipalAuthService : IAuthService
{
    private readonly IConfiguration _configuration;
    private readonly HttpClient _httpClient;
    
    public ServicePrincipalAuthService(IConfiguration configuration, HttpClient httpClient)
    {
        _configuration = configuration;
        _httpClient = httpClient;
    }
    
    public async Task<string> GetAccessTokenAsync()
    {
        var tenantId = _configuration["TenantId"];
        var clientId = _configuration["ClientId"];
        var clientSecret = _configuration["ClientSecret"];
        var dataverseUrl = _configuration["DataverseUrl"];
        
        var tokenEndpoint = $"https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token";
        var resource = new Uri(dataverseUrl).GetLeftPart(UriPartial.Authority);
        
        var requestBody = new FormUrlEncodedContent(new[]
        {
            new KeyValuePair<string, string>("grant_type", "client_credentials"),
            new KeyValuePair<string, string>("client_id", clientId),
            new KeyValuePair<string, string>("client_secret", clientSecret),
            new KeyValuePair<string, string>("scope", $"{resource}/.default")
        });
        
        var response = await _httpClient.PostAsync(tokenEndpoint, requestBody);
        response.EnsureSuccessStatusCode();
        
        var responseContent = await response.Content.ReadAsStringAsync();
        var tokenResponse = JsonSerializer.Deserialize<TokenResponse>(responseContent);
        
        return tokenResponse.AccessToken;
    }
}

public class TokenResponse
{
    [JsonPropertyName("access_token")]
    public string AccessToken { get; set; }
}
```

---

### Step 5: Configure Function Settings

**Azure Portal or local.settings.json:**

```json
{
  "Values": {
    "AzureWebJobsStorage": "...",
    "DataverseUrl": "https://yourorg.crm.dynamics.com",
    "TenantId": "87654321-4321-4321-4321-210987654321",
    "ClientId": "12345678-1234-1234-1234-123456789012",
    "ClientSecret": "your-secret-here"
  }
}
```

⚠️ **Security**: Use Azure Key Vault for secrets in production:

```bash
# Store secret in Key Vault
az keyvault secret set \
  --vault-name your-keyvault \
  --name "DataverseClientSecret" \
  --value "your-secret-here"

# Reference in Function App
az functionapp config appsettings set \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --settings \
    "ClientSecret=@Microsoft.KeyVault(SecretUri=https://your-keyvault.vault.azure.net/secrets/DataverseClientSecret/)"
```

---

### Step 6: Update DataverseService

Modify to use service principal token:

```csharp
public class DataverseService : IDataverseService
{
    private readonly ILogger<DataverseService> _logger;
    private readonly HttpClient _httpClient;
    private readonly IAuthService _authService;
    
    public DataverseService(
        ILogger<DataverseService> logger, 
        HttpClient httpClient,
        IAuthService authService)
    {
        _logger = logger;
        _httpClient = httpClient;
        _authService = authService;
    }
    
    public async Task<bool> ValidateContactAccessAsync(
        string contactId, 
        string accessToken,  // Can be null if using service principal
        string dataverseUrl)
    {
        // Get token from service principal if not provided
        if (string.IsNullOrWhiteSpace(accessToken))
        {
            accessToken = await _authService.GetAccessTokenAsync();
        }
        
        // Rest of implementation...
    }
}
```

---

## Security Best Practices

### 1. Store Secrets in Key Vault

**Never** commit client secrets to source control!

```bash
# Store all secrets
az keyvault secret set --vault-name your-kv --name "TenantId" --value "..."
az keyvault secret set --vault-name your-kv --name "ClientId" --value "..."
az keyvault secret set --vault-name your-kv --name "ClientSecret" --value "..."
```

### 2. Use Managed Identity (Even Better)

Enable Managed Identity instead of client secret:

```bash
# Enable managed identity
az functionapp identity assign \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP

# Get the identity
IDENTITY=$(az functionapp identity show \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --query principalId -o tsv)

# Grant Key Vault access
az keyvault set-policy \
  --name your-keyvault \
  --object-id $IDENTITY \
  --secret-permissions get list
```

### 3. Rotate Secrets Regularly

```bash
# Create new secret
az ad app credential reset \
  --id $APP_ID \
  --append

# Update in Key Vault
az keyvault secret set \
  --vault-name your-kv \
  --name "DataverseClientSecret" \
  --value "new-secret"

# Remove old secret after testing
az ad app credential delete \
  --id $APP_ID \
  --key-id OLD-KEY-ID
```

### 4. Principle of Least Privilege

Assign only necessary security roles in Dynamics 365:

```
❌ DON'T: System Administrator
✅ DO: Custom role with only required permissions
```

---

## Comparison: User Delegation vs Service Principal

| Aspect | User Delegation (Current) | Service Principal |
|--------|--------------------------|-------------------|
| **Audit Trail** | ✅ Shows actual user | ❌ Shows service account |
| **Permissions** | ✅ User's own permissions | ❌ Fixed permissions |
| **Secrets** | ✅ No secrets needed | ❌ Must manage secrets |
| **Use Case** | ✅ User-initiated actions | ✅ Background jobs |
| **Security** | ✅ More secure | ⚠️ Requires secret management |

---

## Recommendation for This Project

**Stick with User Delegation** ✅

The current implementation is correct for this use case because:

1. Actions are user-initiated (click from Dynamics 365)
2. Users should only access their own data
3. Audit trail should show actual user
4. No secrets to manage

Only switch to service principal if requirements change!

---

## Troubleshooting

### Error: "AADSTS65001: The user or administrator has not consented"

**Solution**: Grant admin consent in Azure AD → App registrations → API permissions

### Error: "Principal user is missing"

**Solution**: Create application user in Dynamics 365 (Step 3)

### Error: "401 Unauthorized"

**Solution**: Check client secret is correct and not expired

### Error: "403 Forbidden"

**Solution**: Check security roles assigned to application user

---

## Additional Resources

- [Authenticate with Dataverse web services](https://docs.microsoft.com/en-us/power-apps/developer/data-platform/authentication)
- [Use service principal authentication](https://docs.microsoft.com/en-us/power-apps/developer/data-platform/use-single-tenant-server-server-authentication)
- [Application users in Power Platform](https://docs.microsoft.com/en-us/power-platform/admin/manage-application-users)

