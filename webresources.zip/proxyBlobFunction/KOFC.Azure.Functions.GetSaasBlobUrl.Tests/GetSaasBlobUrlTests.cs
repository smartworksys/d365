using System.Net;
using System.Text;
using System.Text.Json;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using KOFC.Azure.Functions.GetSaasBlobUrl.Models;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using Moq;
using Xunit;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests;

internal sealed class AzureEnvironmentScope : IDisposable
{
    private readonly string? _originalSiteName;

    public AzureEnvironmentScope(bool simulateAzureHost)
    {
        _originalSiteName = Environment.GetEnvironmentVariable("WEBSITE_SITE_NAME");
        Environment.SetEnvironmentVariable(
            "WEBSITE_SITE_NAME",
            simulateAzureHost ? "unit-test-app" : null);
    }

    public void Dispose()
    {
        Environment.SetEnvironmentVariable("WEBSITE_SITE_NAME", _originalSiteName);
    }
}

public class GetSaasBlobUrlTests
{
    private readonly Mock<ILogger<GetSaasBlobUrl>> _mockLogger;
    private readonly Mock<IPrincipalService> _mockPrincipalService;
    private readonly Mock<IDataverseService> _mockDataverseService;
    private readonly Mock<IContactAccessGuard> _mockContactAccessGuard;
    private readonly Mock<IBlobService> _mockBlobService;
    private readonly Mock<IConfiguration> _mockConfiguration;

    public GetSaasBlobUrlTests()
    {
        _mockLogger = new Mock<ILogger<GetSaasBlobUrl>>();
        _mockPrincipalService = new Mock<IPrincipalService>();
        _mockDataverseService = new Mock<IDataverseService>();
        _mockContactAccessGuard = new Mock<IContactAccessGuard>();
        _mockBlobService = new Mock<IBlobService>();
        _mockConfiguration = new Mock<IConfiguration>();

        // Setup default configuration values
        _mockConfiguration.Setup(c => c["DataverseUrl"]).Returns("https://test.crm.dynamics.com");
        _mockConfiguration.Setup(c => c["BlobContainerName"]).Returns("test-container");
    }

    private const string DefaultQuery =
        "?path=D%3A%5Ctest%5Cfile.txt&contactId=12345678-1234-1234-1234-123456789012";

    [Fact]
    public async Task Run_MissingAccessToken_ReturnsUnauthorized()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockContactAccessGuard.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(DefaultQuery);
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Run_MissingPrincipalHeader_ReturnsUnauthorized()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockContactAccessGuard.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(DefaultQuery);
        AddHeader(mockRequest, "X-MS-TOKEN-AAD-ACCESS-TOKEN", "test-token");

        var response = await function.Run(mockRequest.Object);

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Run_InvalidUserPrincipal_ReturnsUnauthorized()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockContactAccessGuard.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(DefaultQuery);
        AddHeader(mockRequest, "X-MS-TOKEN-AAD-ACCESS-TOKEN", "test-token");
        AddHeader(mockRequest, "X-MS-CLIENT-PRINCIPAL", "invalid-principal");

        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns((UserPrincipal?)null);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Run_MissingPathParameter_ReturnsBadRequest()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockContactAccessGuard.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData("?contactId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Run_MissingContactIdParameter_ReturnsBadRequest()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockContactAccessGuard.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData("?path=D:\\test\\file.txt");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Run_UserHasNoAccess_ReturnsForbidden()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockContactAccessGuard.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(
            "?path=D:\\test\\file.txt&contactId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        _mockDataverseService.Setup(s => s.ValidateContactAccessAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(false);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }

    [Fact]
    public async Task Run_BlobNotFound_ReturnsNotFound()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockContactAccessGuard.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(
            "?path=D:\\test\\file.txt&contactId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        _mockDataverseService.Setup(s => s.ValidateContactAccessAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns("test/file.txt");

        _mockBlobService.Setup(s => s.GenerateSasUrlAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ThrowsAsync(new InvalidOperationException("Blob not found"));

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    [Fact]
    public async Task Run_SuccessfulRequest_ReturnsRedirect()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockContactAccessGuard.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(
            "?path=D:\\KOFCExt%20Extractions\\test\\file.txt&contactId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        _mockDataverseService.Setup(s => s.ValidateContactAccessAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns("test/file.txt");

        var expectedSasUrl = "https://storage.blob.core.windows.net/container/test/file.txt?sv=2021-06-08&sig=...";
        _mockBlobService.Setup(s => s.GenerateSasUrlAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(expectedSasUrl);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.Redirect, response.StatusCode);
        Assert.True(response.Headers.TryGetValues("Location", out var locationValues));
        Assert.Equal(expectedSasUrl, locationValues.FirstOrDefault());
    }

    [Fact]
    public async Task Run_NormalizedPathIsEmpty_ReturnsBadRequest()
    {
        // Arrange
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockContactAccessGuard.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(
            "?path=D:\\&contactId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        _mockDataverseService.Setup(s => s.ValidateContactAccessAsync(
                It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(true);

        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns(string.Empty);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
    }

    [Fact]
    public async Task Run_DataverseUrlMissing_ReturnsInternalServerError()
    {
        // Arrange
        _mockConfiguration.Setup(c => c["DataverseUrl"]).Returns((string?)null);

        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockContactAccessGuard.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(
            "?path=D:\\test\\file.txt&contactId=12345678-1234-1234-1234-123456789012");
        SetupAuthHeaders(mockRequest);

        var userPrincipal = CreateTestUserPrincipal();
        _mockPrincipalService.Setup(s => s.DecodeUserPrincipal(It.IsAny<string>()))
            .Returns(userPrincipal);

        // Act
        var response = await function.Run(mockRequest.Object);

        // Assert
        Assert.Equal(HttpStatusCode.InternalServerError, response.StatusCode);
    }

    [Fact]
    public async Task Run_BoomiCaller_ReturnsJsonSasUrl()
    {
        using var _ = new AzureEnvironmentScope(simulateAzureHost: true);
        var function = new GetSaasBlobUrl(
            _mockLogger.Object,
            _mockPrincipalService.Object,
            _mockDataverseService.Object,
            _mockContactAccessGuard.Object,
            _mockBlobService.Object,
            _mockConfiguration.Object);

        var mockRequest = CreateMockHttpRequestData(
            "?path=D:\\test\\file.txt&contactId=12345678-1234-1234-1234-123456789012&userId=aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa&format=json");
        SetupBoomiAuthHeaders(mockRequest);

        _mockContactAccessGuard.Setup(g => g.CheckContactAccess(
                It.IsAny<Guid>(),
                It.IsAny<Guid>()))
            .Returns(ContactAccessResult.Granted(Guid.Parse("aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa")));

        _mockBlobService.Setup(s => s.NormalizePathToBlob(It.IsAny<string>()))
            .Returns("test/file.txt");

        var expectedSasUrl = "https://storage.blob.core.windows.net/container/test/file.txt?sv=2021-06-08&sig=...";
        _mockBlobService.Setup(s => s.GenerateSasUrlAsync(It.IsAny<string>(), It.IsAny<string>()))
            .ReturnsAsync(expectedSasUrl);

        var response = await function.Run(mockRequest.Object);

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        response.Body.Position = 0;
        using var reader = new StreamReader(response.Body);
        var body = await reader.ReadToEndAsync();
        using var document = JsonDocument.Parse(body);
        Assert.Equal(expectedSasUrl, document.RootElement.GetProperty("sasUrl").GetString());
    }

    // Helper methods
    private Mock<HttpRequestData> CreateMockHttpRequestData(string queryString = "")
    {
        var mockRequest = new Mock<HttpRequestData>(MockBehavior.Strict, Mock.Of<FunctionContext>());
        
        mockRequest.Setup(r => r.Url).Returns(new Uri($"https://localhost:7071/api/GetSaasBlobUrl{queryString}"));
        mockRequest.Setup(r => r.Headers).Returns(new HttpHeadersCollection());
        mockRequest.Setup(r => r.Method).Returns("GET");
        
        var mockResponse = new Mock<HttpResponseData>(MockBehavior.Loose, Mock.Of<FunctionContext>());
        mockResponse.SetupProperty(r => r.StatusCode);
        mockResponse.SetupProperty(r => r.Headers, new HttpHeadersCollection());
        mockResponse.Setup(r => r.Body).Returns(new MemoryStream());

        mockRequest.Setup(r => r.CreateResponse()).Returns(mockResponse.Object);

        return mockRequest;
    }

    private void AddHeader(Mock<HttpRequestData> mockRequest, string name, string value)
    {
        mockRequest.Object.Headers.Add(name, new[] { value });
    }

    private void SetupAuthHeaders(Mock<HttpRequestData> mockRequest)
    {
        AddHeader(mockRequest, "X-MS-TOKEN-AAD-ACCESS-TOKEN", "test-access-token");
        
        var principal = CreateTestUserPrincipal();
        var json = JsonSerializer.Serialize(principal);
        var base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
        
        AddHeader(mockRequest, "X-MS-CLIENT-PRINCIPAL", base64);
        AddHeader(mockRequest, "X-MS-CLIENT-PRINCIPAL-NAME", "test@example.com");
        AddHeader(mockRequest, "X-MS-CLIENT-PRINCIPAL-ID", "12345678-1234-1234-1234-123456789012");
    }

    private void SetupBoomiAuthHeaders(Mock<HttpRequestData> mockRequest)
    {
        var principal = CreateBoomiPrincipal();
        var json = JsonSerializer.Serialize(principal);
        var base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
        AddHeader(mockRequest, "X-MS-CLIENT-PRINCIPAL", base64);
    }

    private UserPrincipal CreateBoomiPrincipal()
    {
        return new UserPrincipal
        {
            AuthType = "aad",
            Claims = new List<Claim>
            {
                new Claim { Type = "roles", Value = "Blob.Read" },
                new Claim { Type = "appid", Value = "boomi-service-principal" }
            }
        };
    }

    private UserPrincipal CreateTestUserPrincipal()
    {
        return new UserPrincipal
        {
            AuthType = "aad",
            Claims = new List<Claim>
            {
                new Claim { Type = "name", Value = "Test User" },
                new Claim { Type = "oid", Value = "12345678-1234-1234-1234-123456789012" }
            }
        };
    }
}

