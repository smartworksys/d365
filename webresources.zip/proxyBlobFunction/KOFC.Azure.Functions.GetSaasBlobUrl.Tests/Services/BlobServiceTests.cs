using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Tests.Services;

public class BlobServiceTests
{
    private static BlobService CreateBlobService()
    {
        var mockLogger = new Mock<ILogger<BlobService>>();
        var mockBlobServiceClient = new Mock<global::Azure.Storage.Blobs.BlobServiceClient>();
        var mockConfiguration = new Mock<IConfiguration>();
        mockConfiguration.Setup(c => c["BlobStorageAccountName"]).Returns((string?)null);
        return new BlobService(mockLogger.Object, mockBlobServiceClient.Object, mockConfiguration.Object);
    }

    [Theory]
    [InlineData("D:\\KOFCExt Extractions\\09272024\\000554\\test.xlsx", "09272024/000554/test.xlsx")]
    [InlineData("D:\\KOFCExt Extractions\\file.pdf", "file.pdf")]
    [InlineData("C:\\KOFCExt Extractions\\folder\\document.docx", "folder/document.docx")]
    [InlineData("E:\\Test\\subfolder\\file.txt", "Test/subfolder/file.txt")]
    [InlineData("D:\\KOFCExt Extractions\\", "")]
    public void NormalizePathToBlob_ValidWindowsPath_ReturnsNormalizedPath(string input, string expected)
    {
        // Arrange
        var blobService = CreateBlobService();

        // Act
        var result = blobService.NormalizePathToBlob(input);

        // Assert
        Assert.Equal(expected, result);
    }

    [Fact]
    public void NormalizePathToBlob_NullPath_ReturnsEmpty()
    {
        // Arrange
        var blobService = CreateBlobService();

        // Act
        var result = blobService.NormalizePathToBlob(null!);

        // Assert
        Assert.Equal(string.Empty, result);
    }

    [Fact]
    public void NormalizePathToBlob_EmptyPath_ReturnsEmpty()
    {
        // Arrange
        var blobService = CreateBlobService();

        // Act
        var result = blobService.NormalizePathToBlob("");

        // Assert
        Assert.Equal(string.Empty, result);
    }

    [Fact]
    public void NormalizePathToBlob_WhitespacePath_ReturnsEmpty()
    {
        // Arrange
        var blobService = CreateBlobService();

        // Act
        var result = blobService.NormalizePathToBlob("   ");

        // Assert
        Assert.Equal(string.Empty, result);
    }

    [Theory]
    [InlineData("D:\\KOFCEXT EXTRACTIONS\\file.txt", "file.txt")]
    [InlineData("D:\\kofcext extractions\\file.txt", "file.txt")]
    [InlineData("D:\\KoFcExT eXtRaCtIoNs\\file.txt", "file.txt")]
    public void NormalizePathToBlob_CaseInsensitiveRemoval_RemovesPrefix(string input, string expected)
    {
        // Arrange
        var blobService = CreateBlobService();

        // Act
        var result = blobService.NormalizePathToBlob(input);

        // Assert
        Assert.Equal(expected, result);
    }

    [Fact]
    public async Task GenerateSasUrlAsync_NullContainerName_ThrowsArgumentException()
    {
        // Arrange
        var blobService = CreateBlobService();

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentException>(async () =>
            await blobService.GenerateSasUrlAsync(null!, "test.txt"));
    }

    [Fact]
    public async Task GenerateSasUrlAsync_EmptyContainerName_ThrowsArgumentException()
    {
        // Arrange
        var blobService = CreateBlobService();

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentException>(async () =>
            await blobService.GenerateSasUrlAsync("", "test.txt"));
    }

    [Fact]
    public async Task GenerateSasUrlAsync_NullBlobPath_ThrowsArgumentException()
    {
        // Arrange
        var blobService = CreateBlobService();

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentException>(async () =>
            await blobService.GenerateSasUrlAsync("container", null!));
    }

    [Fact]
    public async Task GenerateSasUrlAsync_EmptyBlobPath_ThrowsArgumentException()
    {
        // Arrange
        var blobService = CreateBlobService();

        // Act & Assert
        await Assert.ThrowsAsync<ArgumentException>(async () =>
            await blobService.GenerateSasUrlAsync("container", ""));
    }
}

