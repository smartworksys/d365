# Functions Not Visible After Deployment - Troubleshooting Guide

## Common Causes and Solutions

### 1. Local Testing Function Deployed to Production

**Problem:** `GetSaasBlobUrlLocal` is deployed, but you only want the production function.

**Solution:** Exclude the local function file from production builds.

**Option A: Use conditional compilation** (Recommended)

Modify `GetSaasBlobUrl.Local.cs`:

```csharp
#if DEBUG
using System.Net;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
// ... rest of file
#endif
```

**Option B: Exclude from project file**

Add to `.csproj`:

```xml
<ItemGroup Condition="'$(Configuration)' == 'Release'">
  <Compile Remove="GetSaasBlobUrl.Local.cs" />
</ItemGroup>
```

---

### 2. Missing Route Configuration

**Problem:** Functions may need explicit routes.

**Solution:** Routes are configured correctly, but verify in Azure Portal:

```
Function App → Functions → GetSaasBlobUrl → Integration
```

Should show:
- **Trigger:** HTTP (GET)
- **Route:** `api/GetSaasBlobUrl` (default)

---

### 3. Authorization Level Issues

**Problem:** `AuthorizationLevel.Anonymous` might be blocked by Easy Auth.

**Current:** `[HttpTrigger(AuthorizationLevel.Anonymous, "get")]`

**Solution:** Keep `Anonymous` - Easy Auth handles authentication before the function.

If needed, you can check the route in the function:
```csharp
[HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "GetSaasBlobUrl")]
```

---

### 4. Deployment Issues

**Check deployment logs:**

```bash
# Azure CLI
az functionapp deployment list \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP

# View latest deployment
az functionapp deployment show \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --deployment-id LATEST
```

**Verify deployment succeeded:**
```bash
az functionapp show \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --query state
```

---

### 5. Check Function App Logs

**View streaming logs:**
```bash
az webapp log tail \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP
```

**Check Kudu/SCM:**
```
https://YOUR-FUNCTION-APP.scm.azurewebsites.net
```

Navigate to: `Debug Console` → `CMD` → `site` → `wwwroot`

Verify files are deployed:
- `GetSaasBlobUrl.dll`
- `host.json`
- Function metadata files

---

### 6. Application Settings Not Configured

**Verify required settings:**
```bash
az functionapp config appsettings list \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --query "[?name=='BLOB_CONNECTION_STRING' || name=='DataverseUrl' || name=='BlobContainerName']"
```

**Required settings:**
- `BLOB_CONNECTION_STRING` (or `AzureWebJobsStorage`)
- `DataverseUrl`
- `BlobContainerName`
- `FUNCTIONS_WORKER_RUNTIME=dotnet-isolated`

---

### 7. Function Discovery Issues

**Clear function metadata cache:**

1. Go to Azure Portal → Function App
2. **Configuration** → **General settings**
3. Restart the function app

Or via CLI:
```bash
az functionapp restart \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP
```

---

### 8. Check Function Host Logs

**In Azure Portal:**
1. Function App → **Log stream**
2. Look for errors during startup
3. Check for function registration messages

**Common errors:**
- Missing dependencies
- Configuration errors
- BlobServiceClient initialization failures

---

### 9. Verify Runtime Version

**Check .NET version:**
```bash
az functionapp config show \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --query linuxFxVersion
```

Should be: `DOTNET-ISOLATED|8.0` (for Linux) or similar for Windows

**Set if incorrect:**
```bash
az functionapp config set \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --net-framework-version v8.0
```

---

### 10. Test Function Endpoint Directly

**Get function URL:**
```bash
az functionapp function show \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --function-name GetSaasBlobUrl \
  --query invokeUrlTemplate -o tsv
```

**Test with curl:**
```bash
curl -v "https://YOUR-FUNCTION-APP.azurewebsites.net/api/GetSaasBlobUrl?path=test&contactId=test"
```

---

## Quick Diagnostic Checklist

- [ ] Function app is running (state = "Running")
- [ ] Deployment succeeded (check deployment history)
- [ ] Application settings are configured
- [ ] Functions are listed in Azure Portal (Function App → Functions)
- [ ] No errors in Log stream
- [ ] Runtime version is correct (.NET 8 isolated)
- [ ] Files deployed to wwwroot
- [ ] No compilation errors in deployment logs

---

## Step-by-Step Recovery

### Step 1: Verify Deployment

```bash
# Check deployment status
func azure functionapp list-functions YOUR-FUNCTION-APP
```

### Step 2: Check Function App Status

```bash
# Check app state
az functionapp show \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --query "{state:state, defaultHostName:defaultHostName}"
```

### Step 3: View Recent Errors

```bash
# Application Insights queries
az monitor app-insights query \
  --app YOUR-APP-INSIGHTS \
  --resource-group YOUR-RESOURCE-GROUP \
  --analytics-query "exceptions | where timestamp > ago(1h) | order by timestamp desc | take 10"
```

### Step 4: Redeploy

```bash
# Clean build and redeploy
cd MIS.Azure.Functions.GetSaasBlobUrl
dotnet clean
dotnet publish -c Release -o ./publish
func azure functionapp publish YOUR-FUNCTION-APP
```

---

## Common Error Messages

### "No functions found"

**Cause:** Functions not registered properly

**Solution:**
1. Verify `[Function]` attributes are correct
2. Check function names match exactly
3. Restart function app
4. Check deployment package contains all DLLs

---

### "Function host is not running"

**Cause:** Function app stopped or crashed

**Solution:**
```bash
az functionapp start \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP
```

---

### "The function runtime is unable to start"

**Cause:** Configuration or dependency issue

**Solution:**
1. Check `BLOB_CONNECTION_STRING` is valid
2. Verify all required packages are deployed
3. Check function app logs for specific errors
4. Ensure `FUNCTIONS_WORKER_RUNTIME=dotnet-isolated`

---

## Verify Functions Are Visible

**Azure Portal:**
1. Navigate to Function App
2. Click **Functions** in left menu
3. Should see `GetSaasBlobUrl` listed

**Azure CLI:**
```bash
az functionapp function list \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP
```

Should return:
```json
[
  {
    "name": "GetSaasBlobUrl",
    "scriptRootPathHref": "...",
    "scriptHref": "...",
    "configHref": "...",
    "href": "..."
  }
]
```

---

## If Still Not Working

1. **Check Application Insights** for detailed errors
2. **Review Kudu logs** at `https://YOUR-FUNCTION-APP.scm.azurewebsites.net`
3. **Enable verbose logging** in `host.json`:
   ```json
   {
     "logging": {
       "logLevel": {
         "default": "Trace"
       }
     }
   }
   ```
4. **Contact support** with:
   - Function app name
   - Resource group
   - Deployment ID
   - Error logs

