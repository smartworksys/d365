# PowerShell script to create and deploy Azure Function App
# Usage: .\deploy-function.ps1

param(
    [Parameter(Mandatory=$false)]
    [string]$FunctionAppName = "ProxyBlobAccess",
    
    [Parameter(Mandatory=$false)]
    [string]$ResourceGroupName = "ProxyBlobAccess_group",
    
    [Parameter(Mandatory=$false)]
    [string]$Location = "eastus",
    
    [Parameter(Mandatory=$false)]
    [string]$StorageAccountName = "",
    
    [Parameter(Mandatory=$false)]
    [string]$AppServicePlanName = "",
    
    [Parameter(Mandatory=$false)]
    [string]$SubscriptionId = "",
    
    [Parameter(Mandatory=$false)]
    [string]$DataverseUrl = "https://orgbf3a235c.crm.dynamics.com",
    
    [Parameter(Mandatory=$false)]
    [string]$BlobContainerName = "smart-office",
    
    [Parameter(Mandatory=$false)]
    [string]$BlobConnectionString = "",
    
    [Parameter(Mandatory=$false)]
    [switch]$SkipBuild,
    
    [Parameter(Mandatory=$false)]
    [switch]$SkipDeploy
)

$ErrorActionPreference = "Stop"

Write-Host "🚀 Azure Function App Deployment Script" -ForegroundColor Cyan
Write-Host "======================================" -ForegroundColor Cyan
Write-Host ""

# Generate storage account name if not provided
if ([string]::IsNullOrWhiteSpace($StorageAccountName)) {
    $StorageAccountName = ($FunctionAppName -replace '[^a-z0-9]', '').ToLower() + "storage" + (Get-Random -Maximum 9999)
    Write-Host "📝 Generated storage account name: $StorageAccountName" -ForegroundColor Yellow
}

# Generate App Service Plan name if not provided
if ([string]::IsNullOrWhiteSpace($AppServicePlanName)) {
    $AppServicePlanName = "$FunctionAppName-plan"
}

Write-Host "📋 Configuration:" -ForegroundColor Green
Write-Host "  Function App Name: $FunctionAppName" -ForegroundColor White
Write-Host "  Resource Group: $ResourceGroupName" -ForegroundColor White
Write-Host "  Location: $Location" -ForegroundColor White
Write-Host "  Storage Account: $StorageAccountName" -ForegroundColor White
Write-Host "  App Service Plan: $AppServicePlanName" -ForegroundColor White
Write-Host ""

# Step 1: Login check
Write-Host "🔐 Step 1: Checking Azure login..." -ForegroundColor Yellow
try {
    $account = az account show 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Host "❌ Not logged in to Azure. Please run: az login" -ForegroundColor Red
        exit 1
    }
    Write-Host "✅ Already logged in to Azure" -ForegroundColor Green
    
    if (-not [string]::IsNullOrWhiteSpace($SubscriptionId)) {
        Write-Host "📝 Setting subscription: $SubscriptionId" -ForegroundColor Yellow
        az account set --subscription $SubscriptionId
    }
} catch {
    Write-Host "❌ Error checking Azure login: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
Write-Host ""

# Step 2: Create Resource Group
Write-Host "📦 Step 2: Creating Resource Group..." -ForegroundColor Yellow
$rgExists = az group exists --name $ResourceGroupName 2>&1
if ($rgExists -eq "false") {
    Write-Host "Creating resource group: $ResourceGroupName" -ForegroundColor Gray
    az group create --name $ResourceGroupName --location $Location
    Write-Host "✅ Resource group created" -ForegroundColor Green
} else {
    Write-Host "✅ Resource group already exists" -ForegroundColor Green
}
Write-Host ""

# Step 3: Create Storage Account
Write-Host "💾 Step 3: Creating Storage Account..." -ForegroundColor Yellow
$ErrorActionPreference = "SilentlyContinue"
$checkResult = az storage account show --name $StorageAccountName --resource-group $ResourceGroupName 2>$null
$storageExists = $LASTEXITCODE -eq 0
$ErrorActionPreference = "Stop"

if (-not $storageExists) {
    Write-Host "Creating storage account: $StorageAccountName" -ForegroundColor Gray
    az storage account create `
        --name $StorageAccountName `
        --resource-group $ResourceGroupName `
        --location $Location `
        --sku Standard_LRS `
        --kind StorageV2
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ Storage account created" -ForegroundColor Green
    } else {
        Write-Host "❌ Failed to create storage account" -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "✅ Storage account already exists" -ForegroundColor Green
}
Write-Host ""

# Step 4: Get Storage Connection String
Write-Host "🔑 Step 4: Getting Storage Connection String..." -ForegroundColor Yellow
if ([string]::IsNullOrWhiteSpace($BlobConnectionString)) {
    $BlobConnectionString = az storage account show-connection-string `
        --name $StorageAccountName `
        --resource-group $ResourceGroupName `
        --query connectionString `
        -o tsv
    Write-Host "✅ Retrieved storage connection string" -ForegroundColor Green
} else {
    Write-Host "✅ Using provided connection string" -ForegroundColor Green
}
Write-Host ""

# Step 5: Skip App Service Plan for Consumption (created automatically with Function App)
Write-Host "📋 Step 5: App Service Plan..." -ForegroundColor Yellow
Write-Host "ℹ️  Using Consumption plan - will be created automatically with Function App" -ForegroundColor Gray
Write-Host ""

# Step 6: Create Function App
Write-Host "⚡ Step 6: Creating Function App..." -ForegroundColor Yellow
$ErrorActionPreference = "SilentlyContinue"
$checkResult = az functionapp show --name $FunctionAppName --resource-group $ResourceGroupName 2>$null
$appExists = $LASTEXITCODE -eq 0
$ErrorActionPreference = "Stop"

if (-not $appExists) {
    Write-Host "Creating Function App: $FunctionAppName" -ForegroundColor Gray
    az functionapp create `
        --name $FunctionAppName `
        --resource-group $ResourceGroupName `
        --consumption-plan-location $Location `
        --storage-account $StorageAccountName `
        --runtime dotnet-isolated `
        --runtime-version 8 `
        --functions-version 4 `
        --os-type Windows
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✅ Function App created" -ForegroundColor Green
    } else {
        Write-Host "❌ Failed to create Function App" -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "✅ Function App already exists" -ForegroundColor Green
    Write-Host "Updating runtime version..." -ForegroundColor Gray
    az functionapp config set `
        --name $FunctionAppName `
        --resource-group $ResourceGroupName `
        --net-framework-version v8.0 | Out-Null
}
Write-Host ""

# Step 7: Remove incompatible settings
Write-Host "🧹 Step 7: Cleaning up incompatible settings..." -ForegroundColor Yellow
$settingsToRemove = @("WEBSITE_RUN_FROM_PACKAGE", "WEBSITE_CONTENTAZUREFILECONNECTIONSTRING", "WEBSITE_CONTENTSHARE")
foreach ($setting in $settingsToRemove) {
    $exists = az functionapp config appsettings list `
        --name $FunctionAppName `
        --resource-group $ResourceGroupName `
        --query "[?name=='$setting']" `
        -o json | ConvertFrom-Json
    if ($exists.Count -gt 0) {
        Write-Host "Removing setting: $setting" -ForegroundColor Gray
        az functionapp config appsettings delete `
            --name $FunctionAppName `
            --resource-group $ResourceGroupName `
            --setting-names $setting
    }
}
Write-Host "✅ Cleanup complete" -ForegroundColor Green
Write-Host ""

# Step 8: Configure Application Settings
Write-Host "⚙️ Step 8: Configuring Application Settings..." -ForegroundColor Yellow
Write-Host "Setting application settings..." -ForegroundColor Gray
az functionapp config appsettings set `
    --name $FunctionAppName `
    --resource-group $ResourceGroupName `
    --settings `
        "FUNCTIONS_WORKER_RUNTIME=dotnet-isolated" `
        "BLOB_CONNECTION_STRING=$BlobConnectionString" `
        "DataverseUrl=$DataverseUrl" `
        "BlobContainerName=$BlobContainerName" `
    | Out-Null
Write-Host "✅ Application settings configured" -ForegroundColor Green
Write-Host ""

# Step 9: Build Project
if (-not $SkipBuild) {
    Write-Host "🔨 Step 9: Building Project..." -ForegroundColor Yellow
    $projectPath = "KOFC.Azure.Functions.GetSaasBlobUrl"
    
    if (-not (Test-Path $projectPath)) {
        Write-Host "❌ Project path not found: $projectPath" -ForegroundColor Red
        exit 1
    }
    
    Push-Location $projectPath
    
    try {
        Write-Host "Cleaning project..." -ForegroundColor Gray
        dotnet clean -c Release | Out-Null
        
        Write-Host "Building project..." -ForegroundColor Gray
        dotnet build -c Release
        
        if ($LASTEXITCODE -ne 0) {
            Write-Host "❌ Build failed!" -ForegroundColor Red
            Pop-Location
            exit 1
        }
        
        Write-Host "Publishing project..." -ForegroundColor Gray
        dotnet publish -c Release -o ./publish
        
        if ($LASTEXITCODE -ne 0) {
            Write-Host "❌ Publish failed!" -ForegroundColor Red
            Pop-Location
            exit 1
        }
        
        Write-Host "✅ Build and publish successful" -ForegroundColor Green
    } catch {
        Write-Host "❌ Build error: $($_.Exception.Message)" -ForegroundColor Red
        Pop-Location
        exit 1
    } finally {
        Pop-Location
    }
    Write-Host ""
} else {
    Write-Host "⏭️  Skipping build (using --SkipBuild)" -ForegroundColor Yellow
    Write-Host ""
}

# Step 10: Deploy Function App
if (-not $SkipDeploy) {
    Write-Host "🚀 Step 10: Deploying Function App..." -ForegroundColor Yellow
    $projectPath = "KOFC.Azure.Functions.GetSaasBlobUrl"
    
    Push-Location $projectPath
    
    try {
        Write-Host "Deploying to Azure..." -ForegroundColor Gray
        func azure functionapp publish $FunctionAppName --dotnet-isolated
        
        if ($LASTEXITCODE -ne 0) {
            Write-Host "❌ Deployment failed!" -ForegroundColor Red
            Pop-Location
            exit 1
        }
        
        Write-Host "✅ Deployment successful!" -ForegroundColor Green
    } catch {
        Write-Host "❌ Deployment error: $($_.Exception.Message)" -ForegroundColor Red
        Pop-Location
        exit 1
    } finally {
        Pop-Location
    }
    Write-Host ""
} else {
    Write-Host "⏭️  Skipping deployment (using --SkipDeploy)" -ForegroundColor Yellow
    Write-Host ""
}

# Step 11: Verify Deployment
Write-Host "✅ Step 11: Verifying Deployment..." -ForegroundColor Yellow
Start-Sleep -Seconds 5

$functions = az functionapp function list `
    --name $FunctionAppName `
    --resource-group $ResourceGroupName `
    -o json | ConvertFrom-Json

if ($functions.Count -gt 0) {
    Write-Host "✅ Functions found:" -ForegroundColor Green
    foreach ($func in $functions) {
        Write-Host "  - $($func.name)" -ForegroundColor White
    }
} else {
    Write-Host "⚠️  No functions found yet. They may still be deploying..." -ForegroundColor Yellow
}

Write-Host ""

# Step 12: Get Function URLs
Write-Host "🔗 Step 12: Function URLs..." -ForegroundColor Yellow
$functionUrl = az functionapp function show `
    --name $FunctionAppName `
    --resource-group $ResourceGroupName `
    --function-name GetSaasBlobUrl `
    --query invokeUrlTemplate `
    -o tsv 2>&1

if ($LASTEXITCODE -eq 0 -and -not [string]::IsNullOrWhiteSpace($functionUrl)) {
    Write-Host "✅ Function URL:" -ForegroundColor Green
    Write-Host "  $functionUrl" -ForegroundColor Cyan
} else {
    Write-Host "⚠️  Function URL not available yet" -ForegroundColor Yellow
}

Write-Host ""

# Summary
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
Write-Host "✅ Deployment Complete!" -ForegroundColor Green
Write-Host ""
Write-Host "📋 Summary:" -ForegroundColor Cyan
Write-Host "  Function App: https://$FunctionAppName.azurewebsites.net" -ForegroundColor White
Write-Host "  Resource Group: $ResourceGroupName" -ForegroundColor White
Write-Host "  Storage Account: $StorageAccountName" -ForegroundColor White
Write-Host ""
Write-Host "🔧 Next Steps:" -ForegroundColor Cyan
Write-Host "  1. Configure Azure AD Easy Auth (see EASY_AUTH_SETUP.md)" -ForegroundColor White
Write-Host "  2. Test the function endpoint" -ForegroundColor White
Write-Host "  3. Configure Application Insights (optional)" -ForegroundColor White
Write-Host ""
Write-Host "📚 Documentation:" -ForegroundColor Cyan
Write-Host "  - EASY_AUTH_SETUP.md - Configure authentication" -ForegroundColor Gray
Write-Host "  - AZURE_SETUP_GUIDE.md - Complete setup guide" -ForegroundColor Gray
Write-Host ""

