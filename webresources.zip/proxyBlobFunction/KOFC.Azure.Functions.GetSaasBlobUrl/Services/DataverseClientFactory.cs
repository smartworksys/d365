using Azure.Core;
using Azure.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public static class DataverseClientFactory
{
    public static ServiceClient Create(ILogger logger)
    {
        var crmUrl = Environment.GetEnvironmentVariable("DataverseUrl")
            ?? Environment.GetEnvironmentVariable("CRM_URL")
            ?? throw new InvalidOperationException("DataverseUrl or CRM_URL is not configured.");

        var dataverseUri = new Uri(crmUrl);
        var credential = new DefaultAzureCredential();
        var scope = $"{dataverseUri.GetLeftPart(UriPartial.Authority)}/.default";

        var serviceClient = new ServiceClient(
            dataverseUri,
            async _ =>
            {
                var token = await credential.GetTokenAsync(
                    new TokenRequestContext(new[] { scope }),
                    CancellationToken.None);
                return token.Token;
            },
            useUniqueInstance: true);

        if (!serviceClient.IsReady)
        {
            logger.LogError("Failed to connect to Dataverse: {Error}", serviceClient.LastError);
            throw new InvalidOperationException($"Failed to connect to Dataverse: {serviceClient.LastError}");
        }

        return serviceClient;
    }
}
