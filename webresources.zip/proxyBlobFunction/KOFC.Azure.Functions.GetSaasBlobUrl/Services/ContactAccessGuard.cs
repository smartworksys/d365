using System.ServiceModel;
using Microsoft.Extensions.Logging;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public enum ContactAccessStatus
{
    Granted,
    UserNotFound,
    AccessDenied
}

public sealed class ContactAccessResult
{
    public ContactAccessStatus Status { get; init; }
    public string Message { get; init; } = string.Empty;
    public bool IsGranted => Status == ContactAccessStatus.Granted;
    public Guid? UserId { get; init; }

    public static ContactAccessResult Granted(Guid userId) =>
        new() { Status = ContactAccessStatus.Granted, Message = "Access granted.", UserId = userId };

    public static ContactAccessResult UserNotFound(string message) =>
        new() { Status = ContactAccessStatus.UserNotFound, Message = message };

    public static ContactAccessResult AccessDenied(Guid userId, string message) =>
        new() { Status = ContactAccessStatus.AccessDenied, Message = message, UserId = userId };
}

public class ContactAccessGuard : IContactAccessGuard
{
    private const int PrivilegeDeniedErrorCode = unchecked((int)0x80048303);

    private readonly ILogger<ContactAccessGuard> _log;
    private readonly IDataverseClient _dataverse;

    public ContactAccessGuard(ILogger<ContactAccessGuard> log, IDataverseClient dataverse)
    {
        _log = log;
        _dataverse = dataverse;
    }

    private static string UserNameField =>
        Environment.GetEnvironmentVariable("DATAVERSE_USERNAME_FIELD") ?? "domainname";

    public ContactAccessResult CheckContactAccess(Guid userId, Guid contactId)
    {
        var resolvedUser = ResolveUserById(userId);
        if (resolvedUser is null)
        {
            _log.LogWarning("No enabled Dataverse user found for userId {UserId}.", userId);
            return ContactAccessResult.UserNotFound($"User '{userId}' was not found in Dataverse.");
        }

        var systemUserId = resolvedUser.Value;

        try
        {
            _log.LogInformation(
                "Impersonating Dataverse user {UserId} to verify contact {ContactId} access.",
                systemUserId,
                contactId);
            _dataverse.CallerId = systemUserId;

            _dataverse.Retrieve("contact", contactId, new ColumnSet("contactid"));
            return ContactAccessResult.Granted(systemUserId);
        }
        catch (FaultException<OrganizationServiceFault> ex) when (ex.Detail.ErrorCode == PrivilegeDeniedErrorCode)
        {
            _log.LogWarning(
                ex,
                "Dataverse denied contact read for user {UserId} on contact {ContactId}.",
                systemUserId,
                contactId);
            return ContactAccessResult.AccessDenied(
                systemUserId,
                $"User does not have access to contact '{contactId}'.");
        }
        catch (FaultException<OrganizationServiceFault> ex)
        {
            _log.LogWarning(
                ex,
                "Unable to retrieve contact {ContactId} for user {UserId}. ErrorCode={ErrorCode}",
                contactId,
                systemUserId,
                ex.Detail.ErrorCode);
            return ContactAccessResult.AccessDenied(
                systemUserId,
                $"User does not have access to contact '{contactId}'.");
        }
        finally
        {
            _dataverse.CallerId = Guid.Empty;
        }
    }

    public ContactAccessResult CheckContactAccessByEntraOid(Guid entraOid, Guid contactId)
    {
        var resolvedUser = ResolveUserByEntraOid(entraOid);
        if (resolvedUser is null)
        {
            _log.LogWarning("No enabled Dataverse user found for Entra oid {EntraOid}.", entraOid);
            return ContactAccessResult.UserNotFound($"User '{entraOid}' was not found in Dataverse.");
        }

        return CheckContactAccess(resolvedUser.Value, contactId);
    }

    private Guid? ResolveUserById(Guid userId)
    {
        var query = new QueryExpression("systemuser")
        {
            TopCount = 1,
            ColumnSet = new ColumnSet("systemuserid"),
            Criteria = new FilterExpression(LogicalOperator.And)
        };
        query.Criteria.AddCondition("systemuserid", ConditionOperator.Equal, userId);
        query.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, false);

        var result = _dataverse.RetrieveMultiple(query);
        return result.Entities is { Count: > 0 } ? result.Entities[0].Id : null;
    }

    private Guid? ResolveUserByEntraOid(Guid entraOid)
    {
        var query = new QueryExpression("systemuser")
        {
            TopCount = 1,
            ColumnSet = new ColumnSet("systemuserid", UserNameField),
            Criteria = new FilterExpression(LogicalOperator.And)
        };
        query.Criteria.AddCondition("azureactivedirectoryobjectid", ConditionOperator.Equal, entraOid);
        query.Criteria.AddCondition("isdisabled", ConditionOperator.Equal, false);

        var result = _dataverse.RetrieveMultiple(query);
        return result.Entities is { Count: > 0 } ? result.Entities[0].Id : null;
    }
}
