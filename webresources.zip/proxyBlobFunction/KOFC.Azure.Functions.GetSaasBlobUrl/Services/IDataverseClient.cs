using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Services;

public interface IDataverseClient
{
    Guid CallerId { get; set; }

    Entity Retrieve(string entityName, Guid id, ColumnSet columnSet);

    EntityCollection RetrieveMultiple(QueryBase query);
}
