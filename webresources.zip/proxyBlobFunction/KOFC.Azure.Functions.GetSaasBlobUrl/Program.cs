using Azure.Identity;
using Azure.Storage.Blobs;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.PowerPlatform.Dataverse.Client;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureServices((context, services) =>
    {
        services.AddApplicationInsightsTelemetryWorkerService();
        services.ConfigureFunctionsApplicationInsights();

        var configuration = context.Configuration;
        var accountName = configuration["BlobStorageAccountName"];
        if (!string.IsNullOrWhiteSpace(accountName))
        {
            services.AddSingleton(_ => new BlobServiceClient(
                new Uri($"https://{accountName}.blob.core.windows.net"),
                new DefaultAzureCredential()));
        }
        else
        {
            var storageConnectionString = configuration["BLOB_CONNECTION_STRING"]
                ?? configuration["AzureWebJobsStorage"];

            if (string.IsNullOrWhiteSpace(storageConnectionString))
            {
                throw new InvalidOperationException(
                    "Blob storage is not configured. Set BlobStorageAccountName (Managed Identity) " +
                    "or BLOB_CONNECTION_STRING / AzureWebJobsStorage.");
            }

            services.AddSingleton(_ => new BlobServiceClient(storageConnectionString));
        }

        services.AddScoped<ServiceClient>(sp =>
            DataverseClientFactory.Create(sp.GetRequiredService<ILogger<ServiceClient>>()));
        services.AddScoped<IDataverseClient, DataverseClientAdapter>();
        services.AddScoped<IContactAccessGuard, ContactAccessGuard>();

        services.AddSingleton<IPrincipalService, PrincipalService>();
        services.AddSingleton<IBlobService, BlobService>();
        services.AddHttpClient<IDataverseService, DataverseService>();
    })
    .Build();

host.Run();
