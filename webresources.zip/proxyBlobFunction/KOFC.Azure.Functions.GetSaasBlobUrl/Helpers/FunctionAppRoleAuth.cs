using System.Text;
using System.Text.Json;
using Microsoft.Azure.Functions.Worker.Http;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Helpers;

/// <summary>
/// Validates Easy Auth app-role tokens on inbound requests from Boomi.
/// </summary>
public static class FunctionAppRoleAuth
{
    public const string BlobReadRole = "Blob.Read";

    public static bool IsAuthenticated(HttpRequestData req)
    {
        if (!IsRunningInAzure())
        {
            return true;
        }

        return !string.IsNullOrWhiteSpace(GetHeader(req, "X-MS-CLIENT-PRINCIPAL"));
    }

    public static IReadOnlyCollection<string> GetCallerRoles(HttpRequestData req)
    {
        if (!IsRunningInAzure())
        {
            return new[] { BlobReadRole };
        }

        var principalHeader = GetHeader(req, "X-MS-CLIENT-PRINCIPAL");
        if (string.IsNullOrWhiteSpace(principalHeader))
        {
            return Array.Empty<string>();
        }

        try
        {
            var json = Encoding.UTF8.GetString(Convert.FromBase64String(principalHeader));
            using var document = JsonDocument.Parse(json);
            if (!document.RootElement.TryGetProperty("claims", out var claims))
            {
                return Array.Empty<string>();
            }

            var roles = new List<string>();
            foreach (var claim in claims.EnumerateArray())
            {
                if (!claim.TryGetProperty("typ", out var typ) || !claim.TryGetProperty("val", out var val))
                {
                    continue;
                }

                var type = typ.GetString();
                if (string.Equals(type, "roles", StringComparison.OrdinalIgnoreCase)
                    || string.Equals(type, "http://schemas.microsoft.com/ws/2008/06/identity/claims/role", StringComparison.OrdinalIgnoreCase))
                {
                    var role = val.GetString();
                    if (!string.IsNullOrWhiteSpace(role))
                    {
                        roles.Add(role);
                    }
                }
            }

            return roles;
        }
        catch
        {
            return Array.Empty<string>();
        }
    }

    public static bool HasAppRole(IReadOnlyCollection<string> callerRoles, string role) =>
        callerRoles.Contains(role, StringComparer.OrdinalIgnoreCase);

    public static bool IsRunningInAzure() =>
        !string.IsNullOrEmpty(Environment.GetEnvironmentVariable("WEBSITE_SITE_NAME"));

    private static string? GetHeader(HttpRequestData req, string headerName)
    {
        if (req.Headers.TryGetValues(headerName, out var values))
        {
            return values.FirstOrDefault();
        }

        return null;
    }
}
