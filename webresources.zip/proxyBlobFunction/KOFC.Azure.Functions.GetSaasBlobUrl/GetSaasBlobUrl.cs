using System.Net;
using System.Text.Json;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using KOFC.Azure.Functions.GetSaasBlobUrl.Helpers;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;

namespace KOFC.Azure.Functions.GetSaasBlobUrl;

public class GetSaasBlobUrl
{
    private readonly ILogger<GetSaasBlobUrl> _logger;
    private readonly IPrincipalService _principalService;
    private readonly IDataverseService _dataverseService;
    private readonly IContactAccessGuard _contactAccessGuard;
    private readonly IBlobService _blobService;
    private readonly IConfiguration _configuration;

    public GetSaasBlobUrl(
        ILogger<GetSaasBlobUrl> logger,
        IPrincipalService principalService,
        IDataverseService dataverseService,
        IContactAccessGuard contactAccessGuard,
        IBlobService blobService,
        IConfiguration configuration)
    {
        _logger = logger;
        _principalService = principalService;
        _dataverseService = dataverseService;
        _contactAccessGuard = contactAccessGuard;
        _blobService = blobService;
        _configuration = configuration;
    }

    [Function("GetSaasBlobUrl")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)] HttpRequestData req)
    {
        _logger.LogInformation("Processing request for GetSaasBlobUrl");

        try
        {
            var queryParams = ParseQuery(req);
            await MergePostBodyAsync(req, queryParams);
            var rawPath = GetParam(queryParams, "path");
            var contactId = GetParam(queryParams, "contactId");
            var responseFormat = (GetParam(queryParams, "format") ?? "redirect").ToLowerInvariant();

            if (string.IsNullOrWhiteSpace(rawPath))
            {
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest,
                    "Bad Request: Missing 'path' parameter");
            }

            if (string.IsNullOrWhiteSpace(contactId) || !Guid.TryParse(contactId, out var contactGuid))
            {
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest,
                    "Bad Request: Missing or invalid 'contactId' parameter");
            }

            var callerRoles = FunctionAppRoleAuth.GetCallerRoles(req);
            var accessToken = GetHeaderValue(req, "X-MS-TOKEN-AAD-ACCESS-TOKEN");
            var principalHeader = GetHeaderValue(req, "X-MS-CLIENT-PRINCIPAL");
            var isLegacyCaller = !string.IsNullOrWhiteSpace(accessToken)
                && !string.IsNullOrWhiteSpace(principalHeader);
            var isBoomiCaller = !isLegacyCaller
                && FunctionAppRoleAuth.HasAppRole(callerRoles, FunctionAppRoleAuth.BlobReadRole);

            if (isBoomiCaller)
            {
                if (!FunctionAppRoleAuth.IsAuthenticated(req))
                {
                    return await CreateErrorResponse(req, HttpStatusCode.Unauthorized,
                        "Unauthorized: Missing or invalid authentication token");
                }

                var accessResult = ValidateBoomiContactAccess(queryParams, contactGuid);
                if (!accessResult.IsGranted)
                {
                    var status = accessResult.Status == ContactAccessStatus.UserNotFound
                        ? HttpStatusCode.NotFound
                        : HttpStatusCode.Forbidden;
                    return await CreateErrorResponse(req, status, accessResult.Message);
                }

                _logger.LogInformation(
                    "Boomi request authorized for user {UserId}, contact {ContactId}",
                    accessResult.UserId,
                    contactGuid);
            }
            else if (!string.IsNullOrWhiteSpace(accessToken) && !string.IsNullOrWhiteSpace(principalHeader))
            {
                var userPrincipal = _principalService.DecodeUserPrincipal(principalHeader);
                if (userPrincipal == null)
                {
                    return await CreateErrorResponse(req, HttpStatusCode.Unauthorized,
                        "Unauthorized: Invalid user principal");
                }

                var dataverseUrl = _configuration["DataverseUrl"];
                if (string.IsNullOrWhiteSpace(dataverseUrl))
                {
                    return await CreateErrorResponse(req, HttpStatusCode.InternalServerError,
                        "Internal Server Error: Dataverse configuration missing");
                }

                var hasAccess = await _dataverseService.ValidateContactAccessAsync(
                    contactId,
                    accessToken,
                    dataverseUrl);
                if (!hasAccess)
                {
                    return await CreateErrorResponse(req, HttpStatusCode.Forbidden,
                        "Forbidden: You do not have access to this resource");
                }
            }
            else
            {
                return await CreateErrorResponse(req, HttpStatusCode.Unauthorized,
                    "Unauthorized: Missing or invalid authentication token");
            }

            var blobPath = _blobService.NormalizePathToBlob(rawPath);
            if (string.IsNullOrWhiteSpace(blobPath))
            {
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest,
                    "Bad Request: Invalid file path");
            }

            var containerName = _configuration["BlobContainerName"] ?? "kofcext-extractions";
            string sasUrl;
            try
            {
                sasUrl = await _blobService.GenerateSasUrlAsync(containerName, blobPath);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(ex, "Blob or container not found: {BlobPath}", blobPath);
                return await CreateErrorResponse(req, HttpStatusCode.NotFound,
                    "Not Found: The requested file does not exist");
            }

            _logger.LogInformation(
                "Generated SAS URL for contact {ContactId}, blob {BlobPath}, format {Format}",
                contactGuid,
                blobPath,
                responseFormat);

            if (responseFormat == "json")
            {
                var jsonResponse = req.CreateResponse(HttpStatusCode.OK);
                jsonResponse.Headers.Add("Content-Type", "application/json");
                await jsonResponse.WriteStringAsync(JsonSerializer.Serialize(new { sasUrl }));
                return jsonResponse;
            }

            var redirectResponse = req.CreateResponse(HttpStatusCode.Redirect);
            redirectResponse.Headers.Add("Location", sasUrl);
            return redirectResponse;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error processing request");
            return await CreateErrorResponse(req, HttpStatusCode.InternalServerError,
                "Internal Server Error: An unexpected error occurred");
        }
    }

    private ContactAccessResult ValidateBoomiContactAccess(
        Dictionary<string, string> queryParams,
        Guid contactGuid)
    {
        var userIdParam = GetParam(queryParams, "userId");
        if (!string.IsNullOrWhiteSpace(userIdParam) && Guid.TryParse(userIdParam, out var userId))
        {
            return _contactAccessGuard.CheckContactAccess(userId, contactGuid);
        }

        var oidParam = GetParam(queryParams, "oid");
        if (!string.IsNullOrWhiteSpace(oidParam) && Guid.TryParse(oidParam, out var entraOid))
        {
            return _contactAccessGuard.CheckContactAccessByEntraOid(entraOid, contactGuid);
        }

        return ContactAccessResult.UserNotFound(
            "A valid userId or oid parameter is required for Boomi requests.");
    }

    private static Dictionary<string, string> ParseQuery(HttpRequestData req)
    {
        var parsed = System.Web.HttpUtility.ParseQueryString(req.Url.Query);
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (string? key in parsed)
        {
            if (!string.IsNullOrWhiteSpace(key))
            {
                result[key] = parsed[key] ?? string.Empty;
            }
        }

        return result;
    }

    private static async Task MergePostBodyAsync(HttpRequestData req, Dictionary<string, string> queryParams)
    {
        if (!string.Equals(req.Method, "POST", StringComparison.OrdinalIgnoreCase))
        {
            return;
        }

        var body = await req.ReadAsStringAsync();
        if (string.IsNullOrWhiteSpace(body))
        {
            return;
        }

        try
        {
            using var document = JsonDocument.Parse(body);
            foreach (var property in document.RootElement.EnumerateObject())
            {
                if (!queryParams.ContainsKey(property.Name))
                {
                    queryParams[property.Name] = property.Value.ToString();
                }
            }
        }
        catch (JsonException)
        {
            // Ignore non-JSON POST bodies; query string may still be sufficient.
        }
    }

    private static string? GetParam(Dictionary<string, string> queryParams, string name)
    {
        return queryParams.TryGetValue(name, out var value) && !string.IsNullOrWhiteSpace(value)
            ? value
            : null;
    }

    private static string? GetHeaderValue(HttpRequestData req, string headerName)
    {
        if (req.Headers.TryGetValues(headerName, out var values))
        {
            return values.FirstOrDefault();
        }

        return null;
    }

    private static async Task<HttpResponseData> CreateErrorResponse(
        HttpRequestData req,
        HttpStatusCode statusCode,
        string message)
    {
        var response = req.CreateResponse(statusCode);
        await response.WriteStringAsync(message);
        return response;
    }
}
