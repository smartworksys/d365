using System.Net;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using KOFC.Azure.Functions.GetSaasBlobUrl.Services;

namespace KOFC.Azure.Functions.GetSaasBlobUrl;

/// <summary>
/// LOCAL TESTING VERSION - Bypasses Easy Auth for local development
/// DO NOT DEPLOY THIS TO PRODUCTION
/// </summary>
public class GetSaasBlobUrlLocal
{
    private readonly ILogger<GetSaasBlobUrlLocal> _logger;
    private readonly IBlobService _blobService;
    private readonly IConfiguration _configuration;

    public GetSaasBlobUrlLocal(
        ILogger<GetSaasBlobUrlLocal> logger,
        IBlobService blobService,
        IConfiguration configuration)
    {
        _logger = logger;
        _blobService = blobService;
        _configuration = configuration;
    }

    [Function("GetSaasBlobUrlLocal")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Anonymous, "get")] HttpRequestData req)
    {
        _logger.LogWarning("⚠️ USING LOCAL TESTING ENDPOINT - NO AUTH VALIDATION ⚠️");

        try
        {
            // Extract query parameters
            var queryParams = System.Web.HttpUtility.ParseQueryString(req.Url.Query);
            var rawPath = queryParams["path"];
            var contactId = queryParams["contactId"];

            if (string.IsNullOrWhiteSpace(rawPath))
            {
                _logger.LogWarning("Missing 'path' parameter");
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest, 
                    "Bad Request: Missing 'path' parameter");
            }

            if (string.IsNullOrWhiteSpace(contactId))
            {
                _logger.LogWarning("Missing 'contactId' parameter");
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest, 
                    "Bad Request: Missing 'contactId' parameter");
            }

            _logger.LogInformation("Request parameters - Path: {Path}, ContactId: {ContactId}", rawPath, contactId);

            // Normalize path to blob format
            var blobPath = _blobService.NormalizePathToBlob(rawPath);
            if (string.IsNullOrWhiteSpace(blobPath))
            {
                _logger.LogWarning("Failed to normalize path: {RawPath}", rawPath);
                return await CreateErrorResponse(req, HttpStatusCode.BadRequest, 
                    "Bad Request: Invalid file path");
            }

            // Generate SAS URL
            var containerName = _configuration["BlobContainerName"] ?? "kofcext-extractions";
            
            string sasUrl;
            try
            {
                sasUrl = await _blobService.GenerateSasUrlAsync(containerName, blobPath);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogWarning(ex, "Blob or container not found: {BlobPath}", blobPath);
                return await CreateErrorResponse(req, HttpStatusCode.NotFound, 
                    "Not Found: The requested file does not exist");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error generating SAS URL for blob: {BlobPath}", blobPath);
                return await CreateErrorResponse(req, HttpStatusCode.InternalServerError, 
                    "Internal Server Error: Failed to generate access URL");
            }

            _logger.LogInformation("Successfully generated SAS URL for blob {BlobPath}", blobPath);

            // Return 302 redirect to the SAS URL
            var response = req.CreateResponse(HttpStatusCode.Redirect);
            response.Headers.Add("Location", sasUrl);
            return response;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error processing request");
            return await CreateErrorResponse(req, HttpStatusCode.InternalServerError, 
                "Internal Server Error: An unexpected error occurred");
        }
    }

    private static async Task<HttpResponseData> CreateErrorResponse(
        HttpRequestData req, 
        HttpStatusCode statusCode, 
        string message)
    {
        var response = req.CreateResponse(statusCode);
        await response.WriteStringAsync(message);
        return response;
    }
}

