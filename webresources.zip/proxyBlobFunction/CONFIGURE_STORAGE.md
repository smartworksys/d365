# Configure Azure Storage Connection String

## 🔴 Error You're Seeing

```
System.FormatException: No valid combination of account information found.
```

This means your `AzureWebJobsStorage` connection string is invalid or missing.

---

## ✅ Solution: Configure Valid Connection String

### Option 1: Use Real Azure Storage Account (Recommended)

1. **Get your connection string from Azure Portal:**

   - Go to [Azure Portal](https://portal.azure.com)
   - Navigate to **Storage accounts** → Your storage account
   - Click **Access keys** (under Security + networking)
   - Click **Show** next to `key1`
   - Copy the **Connection string**

2. **Update `local.settings.json`:**

   ```json
   {
     "Values": {
       "AzureWebJobsStorage": "DefaultEndpointsProtocol=https;AccountName=YOUR_STORAGE_NAME;AccountKey=YOUR_ACCOUNT_KEY==;EndpointSuffix=core.windows.net",
       "FUNCTIONS_WORKER_RUNTIME": "dotnet-isolated",
       "DataverseUrl": "https://yourorg.crm.dynamics.com",
       "BlobContainerName": "kofcext-extractions"
     }
   }
   ```

   **Example:**
   ```json
   "AzureWebJobsStorage": "DefaultEndpointsProtocol=https;AccountName=mystorageaccount;AccountKey=abc123def456...==;EndpointSuffix=core.windows.net"
   ```

---

### Option 2: Use Local Storage Emulator (Azurite)

1. **Install Azurite:**
   ```bash
   npm install -g azurite
   ```

2. **Start Azurite:**
   ```bash
   azurite --silent --location c:\azurite --debug c:\azurite\debug.log
   ```

3. **Update `local.settings.json`:**
   ```json
   {
     "Values": {
       "AzureWebJobsStorage": "UseDevelopmentStorage=true",
       "FUNCTIONS_WORKER_RUNTIME": "dotnet-isolated",
       "DataverseUrl": "https://yourorg.crm.dynamics.com",
       "BlobContainerName": "kofcext-extractions"
     }
   }
   ```

4. **Create the container in Azurite:**
   ```bash
   # Using Azure Storage Explorer or Azure CLI
   az storage container create \
     --name kofcext-extractions \
     --connection-string "UseDevelopmentStorage=true"
   ```

---

### Option 3: Use Azure CLI to Get Connection String

```bash
# Get connection string
az storage account show-connection-string \
  --name YOUR_STORAGE_ACCOUNT_NAME \
  --resource-group YOUR_RESOURCE_GROUP \
  --query connectionString -o tsv
```

Then copy and paste into `local.settings.json`.

---

## 🔍 How to Verify Your Connection String is Valid

### Check Format

A valid connection string should:

1. **Azure Storage Account:**
   ```
   DefaultEndpointsProtocol=https;AccountName=STORAGE_NAME;AccountKey=KEY==;EndpointSuffix=core.windows.net
   ```

2. **Local Emulator:**
   ```
   UseDevelopmentStorage=true
   ```

### Test the Connection String

```powershell
# PowerShell
$connectionString = "YOUR_CONNECTION_STRING"
$blobClient = New-Object Azure.Storage.Blobs.BlobServiceClient($connectionString)
$containers = $blobClient.GetBlobContainers()
Write-Host "Connected successfully! Containers: $($containers.Count)"
```

Or use this C# snippet:

```csharp
using Azure.Storage.Blobs;

var connectionString = "YOUR_CONNECTION_STRING";
var client = new BlobServiceClient(connectionString);
var containers = client.GetBlobContainers();
Console.WriteLine($"Connected! Found {containers.Count()} containers");
```

---

## 📋 Complete Example `local.settings.json`

```json
{
  "IsEncrypted": false,
  "Values": {
    "AzureWebJobsStorage": "DefaultEndpointsProtocol=https;AccountName=mystorageaccount;AccountKey=abc123def456ghi789jkl012mno345pqr678stu901vwx234yz567ab890cd123ef456gh789ij012kl345mn678op==;EndpointSuffix=core.windows.net",
    "FUNCTIONS_WORKER_RUNTIME": "dotnet-isolated",
    "DataverseUrl": "https://yourorg.crm.dynamics.com",
    "BlobContainerName": "kofcext-extractions",
    "APPLICATIONINSIGHTS_CONNECTION_STRING": ""
  }
}
```

**Important:**
- ❌ **Never commit** `local.settings.json` with real connection strings to source control
- ✅ Use `.gitignore` to exclude it (already configured)
- ✅ For production, use Azure Key Vault or Application Settings

---

## 🔒 Security Best Practices

### For Local Development:
1. Use `local.settings.json` (already in `.gitignore`)
2. Or use Azurite (no secrets needed)

### For Production:
1. **Use Azure Application Settings:**
   ```bash
   az functionapp config appsettings set \
     --name YOUR-FUNCTION-APP \
     --resource-group YOUR-RESOURCE-GROUP \
     --settings "AzureWebJobsStorage=YOUR_CONNECTION_STRING"
   ```

2. **Or use Azure Key Vault** (recommended for production):
   ```bash
   # Store in Key Vault
   az keyvault secret set \
     --vault-name your-keyvault \
     --name "StorageConnectionString" \
     --value "YOUR_CONNECTION_STRING"
   
   # Reference in Function App
   az functionapp config appsettings set \
     --name YOUR-FUNCTION-APP \
     --resource-group YOUR-RESOURCE-GROUP \
     --settings "AzureWebJobsStorage=@Microsoft.KeyVault(SecretUri=https://your-keyvault.vault.azure.net/secrets/StorageConnectionString/)"
   ```

---

## 🐛 Troubleshooting

### Issue: "No valid combination of account information found"

**Causes:**
1. Connection string is empty or null
2. Connection string is malformed
3. Connection string is encrypted/incomplete (like what you have now)

**Solution:**
1. Get a fresh connection string from Azure Portal
2. Ensure it starts with `DefaultEndpointsProtocol=https;` or `UseDevelopmentStorage=true`
3. Verify no extra characters or encoding issues

---

### Issue: "The account credentials provided are not valid"

**Causes:**
1. Account key is incorrect or expired
2. Storage account is deleted or inaccessible
3. Wrong storage account name

**Solution:**
1. Regenerate access keys in Azure Portal
2. Verify storage account exists and is accessible
3. Check account name matches connection string

---

### Issue: "Container does not exist"

**Solution:**
```bash
# Create container using Azure CLI
az storage container create \
  --name kofcext-extractions \
  --account-name YOUR_STORAGE_ACCOUNT \
  --account-key YOUR_ACCOUNT_KEY
```

Or use Azure Portal:
- Storage Account → Containers → + Container → Name: `kofcext-extractions`

---

## ✅ Quick Fix Checklist

- [ ] Opened `MIS.Azure.Functions.GetSaasBlobUrl\local.settings.json`
- [ ] Replaced `AzureWebJobsStorage` with valid connection string
- [ ] Verified connection string format is correct
- [ ] Restarted the function (`func start`)
- [ ] Tested the endpoint again

---

## 📚 Related Documentation

- [Azure Storage connection strings](https://docs.microsoft.com/en-us/azure/storage/common/storage-configure-connection-string)
- [Azurite local storage emulator](https://docs.microsoft.com/en-us/azure/storage/common/storage-use-azurite)
- [Secure Azure Functions](https://docs.microsoft.com/en-us/azure/azure-functions/security-concepts)

---

## 🎯 After Fixing

Once you've updated the connection string, restart the function:

```powershell
# Stop the current function (Ctrl+C)
# Then restart:
cd MIS.Azure.Functions.GetSaasBlobUrl
func start
```

Test again:
```
http://localhost:7071/api/GetSaasBlobUrlLocal?path=D:\test\file.txt&contactId=12345678-1234-1234-1234-123456789012
```

You should now see success! ✅

