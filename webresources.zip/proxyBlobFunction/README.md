# MIS Azure Functions - GetSaasBlobUrl

A secure Azure Function App that provides authenticated access to Azure Blob Storage via SAS URLs, integrated with Dynamics 365 Dataverse for authorization.

## Overview

This Function App implements a secure HTTP-triggered Azure Function (`GetSaasBlobUrl`) that:

1. Authenticates users through **Azure AD Easy Auth**
2. Validates user access to Dynamics 365 `Contact` records via Dataverse API
3. Generates **15-minute read-only SAS URLs** for Azure Blob Storage
4. Handles Windows-style file paths and normalizes them to blob-safe paths

## Architecture

```
┌─────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   User      │────▶│  Azure AD    │────▶│   Function   │────▶│  Dataverse   │
│   Browser   │     │  Easy Auth   │     │     App      │     │     API      │
└─────────────┘     └──────────────┘     └──────────────┘     └──────────────┘
                                                 │
                                                 ▼
                                          ┌──────────────┐
                                          │    Azure     │
                                          │  Blob Store  │
                                          └──────────────┘
```

## Project Structure

```
MIS.Azure.Functions.GetSaasBlobUrl/
├── GetSaasBlobUrl.cs              # Main Azure Function
├── Program.cs                     # Dependency injection configuration
├── host.json                      # Function host configuration
├── local.settings.json            # Local development settings
├── Models/
│   └── UserPrincipal.cs          # User principal model
└── Services/
    ├── IPrincipalService.cs      # User principal decoder interface
    ├── PrincipalService.cs       # User principal decoder implementation
    ├── IDataverseService.cs      # Dataverse validation interface
    ├── DataverseService.cs       # Dataverse validation implementation
    ├── IBlobService.cs           # Blob SAS generation interface
    └── BlobService.cs            # Blob SAS generation implementation

MIS.Azure.Functions.GetSaasBlobUrl.Tests/
├── GetSaasBlobUrlTests.cs        # Main function tests
└── Services/
    ├── BlobServiceTests.cs       # Blob service unit tests
    ├── DataverseServiceTests.cs  # Dataverse service unit tests
    └── PrincipalServiceTests.cs  # Principal service unit tests
```

## Prerequisites

- .NET 8.0 SDK
- Azure Functions Core Tools v4
- Azure subscription
- Azure AD tenant
- Dynamics 365 environment with Dataverse
- Azure Storage Account

## Configuration

### Application Settings

Configure the following settings in `local.settings.json` (local) or Azure Portal (production):

| Setting                             | Description                                    | Example                               |
|-------------------------------------|------------------------------------------------|---------------------------------------|
| `AzureWebJobsStorage`               | Azure Storage connection string                | `DefaultEndpointsProtocol=https;...`  |
| `FUNCTIONS_WORKER_RUNTIME`          | Function runtime                               | `dotnet-isolated`                     |
| `DataverseUrl`                      | Dynamics 365 Dataverse organization URL        | `https://yourorg.crm.dynamics.com`    |
| `BlobContainerName`                 | Target blob container name                     | `kofcext-extractions`                 |
| `ClientId`                          | Azure AD application client ID (optional)      | `12345678-1234-1234-1234-123456789012`|
| `APPLICATIONINSIGHTS_CONNECTION_STRING` | Application Insights connection string     | `InstrumentationKey=...`              |

### Azure Portal Setup

#### 1. Create Function App

```bash
# Using Azure CLI
az functionapp create \
  --resource-group <resource-group> \
  --consumption-plan-location <location> \
  --runtime dotnet-isolated \
  --runtime-version 8 \
  --functions-version 4 \
  --name <function-app-name> \
  --storage-account <storage-account>
```

#### 2. Configure Azure AD Easy Auth

1. Navigate to your Function App in Azure Portal
2. Go to **Authentication** under **Settings**
3. Click **Add identity provider**
4. Select **Microsoft**
5. Configure the following:
   - **App registration type**: Create new app registration
   - **Name**: `<your-function-app-name>-auth`
   - **Supported account types**: Current tenant - Single tenant
   - **Restrict access**: Require authentication
   - **Unauthenticated requests**: HTTP 302 Found redirect: recommended for websites
6. Click **Add**

#### 3. Configure API Permissions

1. Go to **Azure AD** → **App registrations**
2. Find your Function App's registration
3. Go to **API permissions**
4. Add the following permissions:
   - **Dynamics CRM** → `user_impersonation` (Delegated)
5. Grant admin consent

#### 4. Configure Application Settings

Add the required configuration values in **Configuration** → **Application settings**

## Development

### Local Development

1. Clone the repository
2. Update `local.settings.json` with your configuration
3. Run the function locally:

```bash
cd MIS.Azure.Functions.GetSaasBlobUrl
func start
```

### Testing Easy Auth Locally

Easy Auth headers are not available in local development. To test locally:

1. Create a test endpoint that bypasses Easy Auth validation
2. Use tools like Postman to inject test headers
3. Or deploy to Azure and test with actual Easy Auth

### Running Tests

```bash
cd MIS.Azure.Functions.GetSaasBlobUrl.Tests
dotnet test
```

## API Usage

### Endpoint

```
GET /api/GetSaasBlobUrl?path={windowsPath}&contactId={contactGuid}
```

### Parameters

| Parameter   | Type   | Required | Description                                |
|-------------|--------|----------|--------------------------------------------|
| `path`      | string | Yes      | Windows file path (e.g., `D:\folder\file.txt`) |
| `contactId` | GUID   | Yes      | Dynamics 365 contact record GUID           |

### Example Request

```
GET https://your-function-app.azurewebsites.net/api/GetSaasBlobUrl?path=D:\KOFCExt%20Extractions\09272024\000554\document.xlsx&contactId=12345678-1234-1234-1234-123456789012
```

### Response Codes

| Status Code | Description                                    |
|-------------|------------------------------------------------|
| 302         | Success - Redirect to SAS URL                  |
| 400         | Bad Request - Missing or invalid parameters    |
| 401         | Unauthorized - Missing or invalid token        |
| 403         | Forbidden - No access to Dataverse contact     |
| 404         | Not Found - Blob does not exist                |
| 500         | Internal Server Error - API or blob failure    |

## Path Normalization

The function normalizes Windows file paths to blob-safe paths:

```
Input:  D:\KOFCExt Extractions\09272024\000554\document.xlsx
Output: 09272024/000554/document.xlsx
```

**Normalization Rules:**
1. Remove drive letter and colon (e.g., `D:\`)
2. Replace backslashes with forward slashes
3. Remove `KOFCExt Extractions/` prefix (case-insensitive)
4. Trim leading/trailing whitespace and slashes

## Security Features

### Authentication

- **Azure AD Easy Auth** ensures all requests are authenticated
- User identity extracted from `X-MS-CLIENT-PRINCIPAL` header
- Access tokens validated via `X-MS-TOKEN-AAD-ACCESS-TOKEN`

### Authorization

- Dataverse API validates user access to specific contact records
- Users can only access files associated with contacts they have permission to view

### Blob Access

- SAS URLs are **read-only**
- SAS URLs expire after **15 minutes**
- Each SAS URL is unique per request

### Logging

- All operations logged with Application Insights
- User actions tracked with user principal and OID
- Failed access attempts logged for security auditing

## Troubleshooting

### Common Issues

#### 1. Easy Auth Headers Missing

**Problem**: Function returns 401 Unauthorized

**Solution**: 
- Ensure Easy Auth is properly configured
- Verify app registration has correct API permissions
- Check that user has granted consent

#### 2. Dataverse Access Denied

**Problem**: Function returns 403 Forbidden

**Solution**:
- Verify user has access to the contact record in Dynamics 365
- Check Dataverse security roles
- Ensure API permissions include `user_impersonation`

#### 3. Blob Not Found

**Problem**: Function returns 404 Not Found

**Solution**:
- Verify blob exists in the storage account
- Check path normalization is working correctly
- Ensure container name is configured correctly

#### 4. SAS Generation Fails

**Problem**: Function returns 500 Internal Server Error

**Solution**:
- Verify storage account connection string
- Check storage account has blob service enabled
- Ensure Function App has permissions to generate SAS tokens

## Performance Considerations

- Uses dependency injection for efficient service lifecycle management
- HttpClient is properly registered for connection pooling
- Application Insights sampling configured to reduce telemetry costs
- BlobServiceClient uses singleton pattern for connection pooling

## Deployment

### Deploy via Azure CLI

```bash
# Build and publish
cd MIS.Azure.Functions.GetSaasBlobUrl
dotnet publish -c Release

# Deploy to Azure
func azure functionapp publish <function-app-name>
```

### Deploy via CI/CD

Use GitHub Actions or Azure DevOps pipelines for automated deployment.

Example GitHub Actions workflow:

```yaml
name: Deploy to Azure Functions

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup .NET
        uses: actions/setup-dotnet@v1
        with:
          dotnet-version: '8.0.x'
      
      - name: Build
        run: dotnet build --configuration Release
      
      - name: Test
        run: dotnet test --configuration Release
      
      - name: Publish
        run: dotnet publish -c Release -o ./output
      
      - name: Deploy to Azure Functions
        uses: Azure/functions-action@v1
        with:
          app-name: '<function-app-name>'
          package: './output'
          publish-profile: ${{ secrets.AZURE_FUNCTIONAPP_PUBLISH_PROFILE }}
```

## Monitoring

### Application Insights

The function integrates with Application Insights for:

- Request telemetry
- Dependency tracking (Dataverse API, Blob Storage)
- Exception tracking
- Custom metrics and events

### Key Metrics to Monitor

- Request duration
- Authentication failures (401 responses)
- Authorization failures (403 responses)
- Blob not found errors (404 responses)
- Dataverse API latency
- SAS generation failures

## License

Copyright © 2024. All rights reserved.

## Support

For issues or questions, please contact your system administrator or open an issue in the project repository.

