# Local Testing Guide

This guide explains how to test the Azure Function locally, since Easy Auth headers are only available in Azure App Service.

## Challenge

**Easy Auth headers** (`X-MS-TOKEN-AAD-ACCESS-TOKEN`, `X-MS-CLIENT-PRINCIPAL`) are **only injected by Azure App Service**, not by the local Azure Functions runtime. This means you cannot test the full authentication flow locally.

## Testing Options

### Option 1: Use the Local Testing Endpoint (Recommended for Development)

I've created `GetSaasBlobUrlLocal.cs` which bypasses authentication for local testing.

#### Setup

1. **Configure local settings** with a valid storage account:

```json
{
  "IsEncrypted": false,
  "Values": {
    "AzureWebJobsStorage": "DefaultEndpointsProtocol=https;AccountName=YOUR_STORAGE;AccountKey=YOUR_KEY;EndpointSuffix=core.windows.net",
    "FUNCTIONS_WORKER_RUNTIME": "dotnet-isolated",
    "DataverseUrl": "https://yourorg.crm.dynamics.com",
    "BlobContainerName": "kofcext-extractions"
  }
}
```

2. **Start the function**:

```bash
cd MIS.Azure.Functions.GetSaasBlobUrl
func start
```

3. **Test with the local endpoint**:

```bash
# Windows PowerShell
$path = "D:\KOFCExt Extractions\09272024\000554\test.xlsx"
$encodedPath = [System.Web.HttpUtility]::UrlEncode($path)
$url = "http://localhost:7071/api/GetSaasBlobUrlLocal?path=$encodedPath&contactId=12345678-1234-1234-1234-123456789012"
Start-Process $url

# Or just open in browser:
# http://localhost:7071/api/GetSaasBlobUrlLocal?path=D:\KOFCExt%20Extractions\test.xlsx&contactId=12345678-1234-1234-1234-123456789012
```

**⚠️ Important**: The local endpoint skips authentication and Dataverse validation. Only use for development!

---

### Option 2: Test with Postman/Thunder Client (Simulate Headers)

You can modify the main function to accept test headers in local mode.

#### Create a development mode flag:

Edit `local.settings.json`:

```json
{
  "Values": {
    "AzureWebJobsStorage": "...",
    "FUNCTIONS_WORKER_RUNTIME": "dotnet-isolated",
    "DataverseUrl": "https://yourorg.crm.dynamics.com",
    "BlobContainerName": "kofcext-extractions",
    "ENVIRONMENT": "Development"  // Add this
  }
}
```

#### Create test helper:

Create `MIS.Azure.Functions.GetSaasBlobUrl/Helpers/TestAuthHelper.cs`:

```csharp
using System.Text;
using System.Text.Json;
using MIS.Azure.Functions.GetSaasBlobUrl.Models;

namespace MIS.Azure.Functions.GetSaasBlobUrl.Helpers;

public static class TestAuthHelper
{
    public static string CreateTestPrincipal(string userName = "test@example.com", string oid = "12345678-1234-1234-1234-123456789012")
    {
        var principal = new UserPrincipal
        {
            AuthType = "aad",
            Claims = new List<Claim>
            {
                new Claim { Type = "name", Value = userName },
                new Claim { Type = "oid", Value = oid }
            }
        };

        var json = JsonSerializer.Serialize(principal);
        return Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
    }

    public static string CreateTestToken()
    {
        return "test-access-token-for-local-development";
    }
}
```

#### Use Postman:

**Request Configuration:**
- Method: `GET`
- URL: `http://localhost:7071/api/GetSaasBlobUrl?path=D:\test\file.txt&contactId=12345678-1234-1234-1234-123456789012`
- Headers:
  ```
  X-MS-TOKEN-AAD-ACCESS-TOKEN: test-token
  X-MS-CLIENT-PRINCIPAL: eyJhdXRoX3R5cCI6ImFhZCIsImNsYWltcyI6W3sidHlwIjoibmFtZSIsInZhbCI6InRlc3RAdGVzdC5jb20ifV19
  X-MS-CLIENT-PRINCIPAL-NAME: test@test.com
  X-MS-CLIENT-PRINCIPAL-ID: 12345678-1234-1234-1234-123456789012
  ```

**Note**: Dataverse validation will fail with a test token. You'd need a real access token or mock the service.

---

### Option 3: Unit Tests (Best for Development)

Run the comprehensive unit tests that mock all dependencies:

```bash
cd MIS.Azure.Functions.GetSaasBlobUrl.Tests
dotnet test --verbosity normal
```

#### Test specific scenarios:

```bash
# Test path normalization
dotnet test --filter "FullyQualifiedName~BlobServiceTests"

# Test Dataverse validation
dotnet test --filter "FullyQualifiedName~DataverseServiceTests"

# Test main function
dotnet test --filter "FullyQualifiedName~GetSaasBlobUrlTests"
```

#### Run with coverage:

```bash
dotnet test --collect:"XPlat Code Coverage"
```

---

### Option 4: Test Individual Services

Test services in isolation without running the full function:

#### Create a test console app:

Create `MIS.Azure.Functions.GetSaasBlobUrl.TestConsole/Program.cs`:

```csharp
using Azure.Storage.Blobs;
using MIS.Azure.Functions.GetSaasBlobUrl.Services;
using Microsoft.Extensions.Logging;

var loggerFactory = LoggerFactory.Create(builder => builder.AddConsole());
var logger = loggerFactory.CreateLogger<BlobService>();

var connectionString = "YOUR_STORAGE_CONNECTION_STRING";
var blobServiceClient = new BlobServiceClient(connectionString);

var blobService = new BlobService(logger, blobServiceClient);

// Test path normalization
var testPath = @"D:\KOFCExt Extractions\09272024\000554\test.xlsx";
var normalized = blobService.NormalizePathToBlob(testPath);
Console.WriteLine($"Original: {testPath}");
Console.WriteLine($"Normalized: {normalized}");

// Test SAS generation (if blob exists)
try
{
    var sasUrl = await blobService.GenerateSasUrlAsync("kofcext-extractions", normalized);
    Console.WriteLine($"SAS URL: {sasUrl}");
}
catch (Exception ex)
{
    Console.WriteLine($"Error: {ex.Message}");
}
```

---

### Option 5: Deploy to Azure Dev Environment

The most realistic testing approach:

#### 1. Create a dev Function App:

```bash
az functionapp create \
  --resource-group rg-dev-saasblob \
  --consumption-plan-location eastus \
  --runtime dotnet-isolated \
  --runtime-version 8 \
  --functions-version 4 \
  --name saasblob-dev \
  --storage-account devblobstorage
```

#### 2. Configure Easy Auth on dev:

Follow the same steps as production (see AZURE_SETUP_GUIDE.md)

#### 3. Deploy and test:

```bash
func azure functionapp publish saasblob-dev
```

#### 4. Test with real authentication:

```
https://saasblob-dev.azurewebsites.net/api/GetSaasBlobUrl?path=D:\test\file.txt&contactId=...
```

---

## Recommended Testing Workflow

### During Development:

1. **Unit Tests** - Test all business logic with mocks
   ```bash
   dotnet test --watch
   ```

2. **Local Endpoint** - Test blob access and path normalization
   ```bash
   func start
   # Use GetSaasBlobUrlLocal endpoint
   ```

3. **Service Integration** - Test individual services with real dependencies

### Before Deployment:

1. **Full Unit Test Suite**
   ```bash
   dotnet test --logger "console;verbosity=detailed"
   ```

2. **Azure Dev Environment** - Test with real Easy Auth and Dataverse

### After Deployment:

1. **Production Testing** - Test with real users and data
2. **Monitor Application Insights** - Watch for errors

---

## Quick Test Commands

### Test Path Normalization Only:

```bash
cd MIS.Azure.Functions.GetSaasBlobUrl.Tests
dotnet test --filter "FullyQualifiedName~BlobServiceTests.NormalizePathToBlob"
```

### Test Local Endpoint:

```powershell
# PowerShell
Invoke-WebRequest "http://localhost:7071/api/GetSaasBlobUrlLocal?path=D:\test\file.txt&contactId=12345678-1234-1234-1234-123456789012"
```

```bash
# Bash/Linux
curl "http://localhost:7071/api/GetSaasBlobUrlLocal?path=D%3A%5Ctest%5Cfile.txt&contactId=12345678-1234-1234-1234-123456789012"
```

### Test with Real Storage:

```bash
# Set environment variable
export AzureWebJobsStorage="DefaultEndpointsProtocol=https;..."

# Run function
func start
```

---

## Troubleshooting Local Testing

### Issue: "Cannot access blob storage"

**Solution**: 
- Use **Azure Storage Emulator** (Azurite) for local testing:
  ```bash
  # Install Azurite
  npm install -g azurite
  
  # Start Azurite
  azurite --silent --location c:\azurite --debug c:\azurite\debug.log
  
  # Update local.settings.json
  "AzureWebJobsStorage": "UseDevelopmentStorage=true"
  ```

### Issue: "Dataverse validation fails locally"

**Solution**: 
- Use the `GetSaasBlobUrlLocal` endpoint which skips Dataverse validation
- Or use unit tests with mocked Dataverse service

### Issue: "Path not found"

**Solution**:
- Create test blobs in your storage account:
  ```bash
  az storage blob upload \
    --account-name yourstorage \
    --container-name kofcext-extractions \
    --name "09272024/000554/test.xlsx" \
    --file "C:\local\test.xlsx"
  ```

### Issue: "Function won't start"

**Solution**:
```bash
# Clean and rebuild
dotnet clean
dotnet build
func start --verbose
```

---

## Security Reminder

⚠️ **NEVER deploy the local testing endpoint to production!**

Consider using compiler directives:

```csharp
#if DEBUG
[Function("GetSaasBlobUrlLocal")]
public async Task<HttpResponseData> RunLocal(...)
#endif
```

Or exclude from publish:

```xml
<!-- In .csproj -->
<ItemGroup>
  <Compile Remove="GetSaasBlobUrl.Local.cs" Condition="'$(Configuration)' == 'Release'" />
</ItemGroup>
```

---

## Next Steps

1. ✅ Run unit tests: `dotnet test`
2. ✅ Start local function: `func start`
3. ✅ Test local endpoint: `GetSaasBlobUrlLocal`
4. ✅ Deploy to dev environment for full testing
5. ✅ Test in production with real authentication

Happy testing! 🧪

