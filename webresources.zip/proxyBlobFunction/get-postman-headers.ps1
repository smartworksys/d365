# PowerShell script to get all headers needed for Postman testing
# Usage: .\get-postman-headers.ps1

param(
    [Parameter(Mandatory=$false)]
    [string]$DataverseUrl = "https://orgbf3a235c.crm.dynamics.com",
    
    [Parameter(Mandatory=$false)]
    [string]$UserEmail = ""
)

$ErrorActionPreference = "Stop"

Write-Host "🔑 Getting Authentication Headers for Postman" -ForegroundColor Cyan
Write-Host "===============================================" -ForegroundColor Cyan
Write-Host ""

# Check if logged in
Write-Host "🔐 Checking Azure login..." -ForegroundColor Yellow
$account = az account show 2>&1 | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Host "❌ Not logged in. Please run: az login" -ForegroundColor Red
    exit 1
}
Write-Host "✅ Logged in to Azure" -ForegroundColor Green
Write-Host ""

# Get access token
Write-Host "📥 Getting Azure AD token for Dataverse..." -ForegroundColor Yellow
$token = az account get-access-token --resource $DataverseUrl --query accessToken -o tsv

if ([string]::IsNullOrWhiteSpace($token)) {
    Write-Host "❌ Failed to get token" -ForegroundColor Red
    exit 1
}

Write-Host "✅ Token obtained" -ForegroundColor Green
Write-Host ""

# Get user info
Write-Host "👤 Getting user information..." -ForegroundColor Yellow
if ([string]::IsNullOrWhiteSpace($UserEmail)) {
    # Get signed-in user
    $userJson = az ad signed-in-user show | ConvertFrom-Json
    $UserEmail = $userJson.mail
    if ([string]::IsNullOrWhiteSpace($UserEmail)) {
        $UserEmail = $userJson.userPrincipalName
    }
    $userOid = $userJson.id
} else {
    # Get specific user
    $ErrorActionPreference = "SilentlyContinue"
    $userJson = az ad user show --id $UserEmail | ConvertFrom-Json
    $ErrorActionPreference = "Stop"
    
    if ($userJson -and $userJson.id) {
        $userOid = $userJson.id
    } else {
        Write-Host "⚠️  Could not find user '$UserEmail', using signed-in user" -ForegroundColor Yellow
        $userJson = az ad signed-in-user show | ConvertFrom-Json
        $UserEmail = $userJson.mail
        $userOid = $userJson.id
    }
}

Write-Host "  Email: $UserEmail" -ForegroundColor Gray
Write-Host "  OID: $userOid" -ForegroundColor Gray
Write-Host ""

# Generate principal
Write-Host "📝 Generating Base64 principal..." -ForegroundColor Yellow
$principal = @{
    auth_typ = "aad"
    claims = @(
        @{ typ = "name"; val = $UserEmail },
        @{ typ = "oid"; val = $userOid },
        @{ typ = "email"; val = $UserEmail },
        @{ typ = "preferred_username"; val = $UserEmail }
    )
} | ConvertTo-Json -Depth 10 -Compress

$bytes = [System.Text.Encoding]::UTF8.GetBytes($principal)
$base64Principal = [Convert]::ToBase64String($bytes)

Write-Host "✅ Principal generated" -ForegroundColor Green
Write-Host ""

# Display results
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
Write-Host "✅ Copy these headers to Postman:" -ForegroundColor Green
Write-Host ""
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
Write-Host ""
Write-Host "X-MS-TOKEN-AAD-ACCESS-TOKEN:" -ForegroundColor Yellow
Write-Host $token -ForegroundColor White
Write-Host ""
Write-Host "X-MS-CLIENT-PRINCIPAL:" -ForegroundColor Yellow
Write-Host $base64Principal -ForegroundColor White
Write-Host ""
Write-Host "X-MS-CLIENT-PRINCIPAL-NAME:" -ForegroundColor Yellow
Write-Host $UserEmail -ForegroundColor White
Write-Host ""
Write-Host "X-MS-CLIENT-PRINCIPAL-ID:" -ForegroundColor Yellow
Write-Host $userOid -ForegroundColor White
Write-Host ""
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
Write-Host ""
Write-Host "📋 Postman Request Setup:" -ForegroundColor Cyan
Write-Host "  1. Method: GET" -ForegroundColor White
Write-Host "  2. URL: http://localhost:7071/api/GetSaasBlobUrl?path=D:\test\file.txt&contactId=..." -ForegroundColor White
Write-Host "  3. Headers tab: Add all 4 headers above" -ForegroundColor White
Write-Host ""
Write-Host "💡 Tips:" -ForegroundColor Cyan
Write-Host "  - Token expires in ~1 hour - run script again for fresh token" -ForegroundColor Gray
Write-Host "  - Make sure function is running: func start" -ForegroundColor Gray
Write-Host "  - Verify Dataverse URL matches in local.settings.json" -ForegroundColor Gray
Write-Host ""

