# Azure Setup Guide for GetSaasBlobUrl Function

This guide walks you through setting up the Azure Function App with Easy Auth integration.

## Prerequisites

- Azure subscription with appropriate permissions
- Azure CLI installed (or use Azure Cloud Shell)
- Access to Dynamics 365 with Dataverse
- Azure Storage Account created

## Step-by-Step Setup

### 1. Create Resource Group (if needed)

```bash
az group create \
  --name rg-saasblob-function \
  --location eastus
```

### 2. Create Storage Account (if needed)

```bash
az storage account create \
  --name sassblobstorage \
  --resource-group rg-saasblob-function \
  --location eastus \
  --sku Standard_LRS
```

### 3. Create Application Insights

```bash
az monitor app-insights component create \
  --app saasblob-insights \
  --location eastus \
  --resource-group rg-saasblob-function \
  --application-type web
```

Get the connection string:

```bash
az monitor app-insights component show \
  --app saasblob-insights \
  --resource-group rg-saasblob-function \
  --query connectionString -o tsv
```

### 4. Create Function App

```bash
az functionapp create \
  --resource-group rg-saasblob-function \
  --consumption-plan-location eastus \
  --runtime dotnet-isolated \
  --runtime-version 8 \
  --functions-version 4 \
  --name saasblob-function-app \
  --storage-account sassblobstorage \
  --os-type Windows
```

### 5. Configure Application Settings

```bash
# Get the storage connection string
STORAGE_CONNECTION=$(az storage account show-connection-string \
  --name sassblobstorage \
  --resource-group rg-saasblob-function \
  --query connectionString -o tsv)

# Set application settings
az functionapp config appsettings set \
  --name saasblob-function-app \
  --resource-group rg-saasblob-function \
  --settings \
    "AzureWebJobsStorage=$STORAGE_CONNECTION" \
    "DataverseUrl=https://yourorg.crm.dynamics.com" \
    "BlobContainerName=kofcext-extractions" \
    "APPLICATIONINSIGHTS_CONNECTION_STRING=<from-step-3>"
```

### 6. Configure Azure AD Easy Auth

#### Option A: Azure Portal (Recommended for first-time setup)

1. Go to [Azure Portal](https://portal.azure.com)
2. Navigate to your Function App: `saasblob-function-app`
3. In the left menu, under **Settings**, click **Authentication**
4. Click **Add identity provider**
5. Select **Microsoft** as the identity provider
6. Configure the following settings:

   **App registration:**
   - App registration type: **Create new app registration**
   - Name: `saasblob-function-app-auth`
   - Supported account types: **Current tenant - Single tenant**

   **App Service authentication settings:**
   - Restrict access: **Require authentication**
   - Unauthenticated requests: **HTTP 302 Found redirect: recommended for websites**
   - Token store: **Enabled** (checked)

7. Click **Add**

8. After creation, click on the app registration name to open it
9. Go to **API permissions**
10. Click **Add a permission**
11. Select **Dynamics CRM**
12. Select **Delegated permissions**
13. Check **user_impersonation**
14. Click **Add permissions**
15. Click **Grant admin consent for [Your Tenant]**

#### Option B: Azure CLI

```bash
# Create the Function App with authentication
az functionapp auth update \
  --name saasblob-function-app \
  --resource-group rg-saasblob-function \
  --enabled true \
  --action LoginWithAzureActiveDirectory \
  --aad-allowed-token-audiences "api://saasblob-function-app-auth" \
  --aad-client-id <will-be-generated> \
  --aad-token-issuer-url "https://sts.windows.net/<tenant-id>/"
```

Note: You'll need to manually add the Dynamics CRM API permissions via the portal.

### 7. Configure CORS (if needed for web application)

```bash
az functionapp cors add \
  --name saasblob-function-app \
  --resource-group rg-saasblob-function \
  --allowed-origins "https://yourapp.dynamics.com"
```

### 8. Deploy the Function App

#### From Local Machine:

```bash
cd MIS.Azure.Functions.GetSaasBlobUrl
func azure functionapp publish saasblob-function-app
```

#### From CI/CD:

Set up GitHub Actions or Azure DevOps pipeline (see README.md for examples).

### 9. Verify Deployment

1. Get the Function URL:

```bash
az functionapp function show \
  --name saasblob-function-app \
  --resource-group rg-saasblob-function \
  --function-name GetSaasBlobUrl \
  --query invokeUrlTemplate -o tsv
```

2. Test the endpoint in a browser (should redirect to Microsoft login):

```
https://saasblob-function-app.azurewebsites.net/api/GetSaasBlobUrl?path=D:\test\file.txt&contactId=12345678-1234-1234-1234-123456789012
```

### 10. Configure Managed Identity (Optional but Recommended)

Enable Managed Identity for enhanced security:

```bash
# Enable system-assigned managed identity
az functionapp identity assign \
  --name saasblob-function-app \
  --resource-group rg-saasblob-function

# Grant Storage Blob Data Contributor role to the identity
FUNCTION_IDENTITY=$(az functionapp identity show \
  --name saasblob-function-app \
  --resource-group rg-saasblob-function \
  --query principalId -o tsv)

STORAGE_ID=$(az storage account show \
  --name sassblobstorage \
  --resource-group rg-saasblob-function \
  --query id -o tsv)

az role assignment create \
  --assignee $FUNCTION_IDENTITY \
  --role "Storage Blob Data Contributor" \
  --scope $STORAGE_ID
```

## Verification Checklist

- [ ] Function App is created and running
- [ ] Easy Auth is configured with Microsoft Identity Platform
- [ ] App registration has Dynamics CRM API permissions
- [ ] Admin consent granted for API permissions
- [ ] Application settings are configured correctly
- [ ] Storage account connection string is set
- [ ] Dataverse URL is correct
- [ ] Function is deployed successfully
- [ ] Authentication redirects to Microsoft login
- [ ] Authenticated requests receive Easy Auth headers

## Testing the Setup

### 1. Test Authentication

Open the function URL in a browser:

```
https://saasblob-function-app.azurewebsites.net/api/GetSaasBlobUrl?path=D:\test\file.txt&contactId=12345678-1234-1234-1234-123456789012
```

Expected: Redirect to Microsoft login page.

### 2. Test with Valid Credentials

After logging in with a valid Azure AD account that has access to the specified contact:

Expected: 
- If blob exists: 302 redirect to blob with SAS token
- If blob doesn't exist: 404 Not Found
- If no access to contact: 403 Forbidden

### 3. Check Logs

View real-time logs:

```bash
az webapp log tail \
  --name saasblob-function-app \
  --resource-group rg-saasblob-function
```

Or view in Application Insights:

```bash
az monitor app-insights query \
  --app saasblob-insights \
  --resource-group rg-saasblob-function \
  --analytics-query "requests | where timestamp > ago(1h) | order by timestamp desc"
```

## Troubleshooting

### Issue: "Authentication headers not found"

**Cause**: Easy Auth is not properly configured or disabled.

**Solution**: 
1. Verify Easy Auth is enabled in the portal
2. Check that authentication is set to "Require authentication"
3. Ensure you're accessing via HTTPS (not HTTP)

### Issue: "Access denied to Dataverse"

**Cause**: Missing API permissions or user doesn't have access.

**Solution**:
1. Verify API permissions include Dynamics CRM `user_impersonation`
2. Confirm admin consent was granted
3. Check user has appropriate security role in Dynamics 365

### Issue: "Blob not found"

**Cause**: Path normalization or blob doesn't exist.

**Solution**:
1. Check the path is correct
2. Verify blob exists in the storage account
3. Review Application Insights logs for the normalized path
4. Ensure container name is configured correctly

### Issue: "500 Internal Server Error"

**Cause**: Various configuration or runtime errors.

**Solution**:
1. Check Application Insights for detailed error logs
2. Verify all configuration settings are correct
3. Ensure storage account connection string is valid
4. Check Dataverse URL is accessible

## Security Best Practices

1. **Use Managed Identity** instead of connection strings where possible
2. **Enable Application Insights** for monitoring and security auditing
3. **Configure CORS** restrictively to only allowed domains
4. **Use Key Vault** for sensitive configuration values
5. **Enable HTTPS** only (disable HTTP)
6. **Regular review** of authentication logs in Application Insights
7. **Principle of least privilege** for Dynamics 365 security roles

## Monitoring and Alerts

### Create Alert for Failed Authentications

```bash
az monitor metrics alert create \
  --name "High-Authentication-Failures" \
  --resource-group rg-saasblob-function \
  --scopes "/subscriptions/<subscription-id>/resourceGroups/rg-saasblob-function/providers/Microsoft.Web/sites/saasblob-function-app" \
  --condition "count requests where resultCode == 401 > 10" \
  --window-size 5m \
  --evaluation-frequency 1m \
  --severity 2
```

### Create Alert for High Error Rate

```bash
az monitor metrics alert create \
  --name "High-Error-Rate" \
  --resource-group rg-saasblob-function \
  --scopes "/subscriptions/<subscription-id>/resourceGroups/rg-saasblob-function/providers/Microsoft.Web/sites/saasblob-function-app" \
  --condition "count requests where resultCode >= 500 > 5" \
  --window-size 5m \
  --evaluation-frequency 1m \
  --severity 1
```

## Additional Resources

- [Azure Functions Documentation](https://docs.microsoft.com/en-us/azure/azure-functions/)
- [Azure App Service Authentication](https://docs.microsoft.com/en-us/azure/app-service/overview-authentication-authorization)
- [Dynamics 365 Web API](https://docs.microsoft.com/en-us/power-apps/developer/data-platform/webapi/overview)
- [Azure Blob Storage SAS](https://docs.microsoft.com/en-us/azure/storage/common/storage-sas-overview)

## Support

For issues or questions:
1. Check Application Insights logs
2. Review this setup guide
3. Consult the main README.md
4. Contact your Azure administrator

