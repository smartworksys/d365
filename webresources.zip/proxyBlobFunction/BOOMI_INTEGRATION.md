# SaaS Blob Access — Boomi Integration Guide

This guide covers the end-to-end design for opening extraction files from **Dynamics 365 Timeline** (including links created by **ADF**) through **Boomi** to the **GetSaasBlobUrl** Azure Function.

---

## Architecture

```text
Timeline link (ADF / plugin / flow)
    → kofc_blob_open.html  (D365 web resource)
    → MSAL user token + x-api-key
    → Boomi REST (validates user token, extracts oid)
    → GetSaasBlobUrl Function (client-credentials + Blob.Read)
    → Managed Identity → user delegation SAS
    → Browser opens file
```

### Two-token model

| Hop | Token | Purpose |
|-----|-------|---------|
| Browser → Boomi | Delegated SPA token (`scp = access_as_user`) | Proves signed-in user |
| Boomi → Function | Client-credentials token (`roles = Blob.Read`) | Authorizes Boomi to call Function |

**User identity for Dataverse:** Boomi reads **`oid`** from the SPA JWT, resolves **`systemuserid`**, and forwards **`userId`** (or **`oid`**) to the Function. The browser does **not** send `userId`.

---

## 1. Azure Function App (`GetSaasBlobUrl`)

### App settings

| Setting | Required | Description |
|---------|----------|-------------|
| `DataverseUrl` | Yes | `https://yourorg.crm.dynamics.com` |
| `BlobContainerName` | Yes | e.g. `kofcext-extractions` |
| `BlobStorageAccountName` | Recommended | Storage account name for **Managed Identity** (no account key) |
| `BLOB_CONNECTION_STRING` | Fallback | Use only if MI is not configured |

### Managed Identity + blob (no storage key)

1. Enable **system-assigned Managed Identity** on the Function App.
2. On the storage account, assign the MI:
   - **Storage Blob Delegator** (generate user delegation SAS)
   - **Storage Blob Data Reader** (verify blob exists)
3. Set `BlobStorageAccountName` (not a connection string with `AccountKey`).

### Dataverse (Function → CRM)

1. Register the Function MI as an **Application User** in Power Platform.
2. Assign a role with **Act on Behalf of Another User** and contact read (via impersonation).

### Easy Auth + Entra app role

1. Enable **Easy Auth** on the Function App (Entra ID provider).
2. On the **Function API** app registration, expose app role **`Blob.Read`**.
3. Assign **`Blob.Read`** to the **Boomi service principal** (admin consent).

### Function endpoints

**Boomi → Function (production):**

```http
GET https://<function-app>.azurewebsites.net/api/GetSaasBlobUrl
    ?path=D%3A%5CKOFCExt%20Extractions%5Cfolder%5Cfile.xlsx
    &contactId=<contact-guid>
    &userId=<systemuserid-from-oid>
    &format=json
Authorization: Bearer <Boomi client-credentials token>
```

| Parameter | Required | Set by |
|-----------|----------|--------|
| `path` | Yes | Browser → Boomi (from timeline link) |
| `contactId` | Yes | Browser → Boomi (same as post regarding contact) |
| `userId` | Yes* | **Boomi** (from token `oid` → Dataverse lookup) |
| `oid` | Alt* | Boomi may send Entra oid; Function resolves user |
| `format` | No | `json` (for Boomi/browser client) or `redirect` (legacy direct) |

\* One of `userId` or `oid` is required on the Boomi path.

**JSON response (`format=json`):**

```json
{ "sasUrl": "https://<account>.blob.core.windows.net/..." }
```

**Legacy direct Easy Auth (optional, backward compatible):**

```http
GET /api/GetSaasBlobUrl?path=...&contactId=...
```

Requires Easy Auth user headers (`X-MS-TOKEN-AAD-ACCESS-TOKEN` + `X-MS-CLIENT-PRINCIPAL`). Returns **302 redirect** to SAS URL.

---

## 2. Boomi process

### REST endpoint (example)

`https://<boomi-host>/ws/rest/GetSaasBlobUrl`

### Gateway validation (browser → Boomi)

| Check | Purpose |
|-------|---------|
| `x-api-key` | Request from D365 integration |
| `Authorization: Bearer` | Valid SPA JWT (`access_as_user`) |

### Boomi steps

1. Validate SPA token at API gateway.
2. Extract **`oid`** from JWT (and optionally `preferred_username`).
3. Resolve **`systemuserid`**:
   - Query Dataverse: `systemusers?$filter=azureactivedirectoryobjectid eq '{oid}' and isdisabled eq false`
   - Or let Function resolve via `oid` parameter.
4. Obtain **client-credentials** token for Function API (`scope = api://<API_APP_ID>/.default`).
5. Call Function:

   ```http
   GET {functionUrl}/api/GetSaasBlobUrl?path={path}&contactId={contactId}&userId={systemuserid}&format=json
   Authorization: Bearer {boomi-app-token}
   ```

6. Return Function JSON `{ "sasUrl": "..." }` to the browser.

**Do not forward** the user's SPA token to the Function.

---

## 3. Dynamics 365 web resources

Upload and publish:

| Web resource | Type | Purpose |
|--------------|------|---------|
| `kofc_authclient.js` | Script | Shared MSAL client (`KOFC.Auth`) |
| `kofc_authcallback.html` | HTML | Shared redirect page (handles blob pending) |
| `kofc_msalbrowsermin` | Script | MSAL.js |
| `kofc_blobClient.js` | Script | `KOFC.Blob.openSaasBlob()` |
| `kofc_blob_open.html` | HTML | Timeline link landing page |
| `kofc_blobLinkBuilder.js` | Script | Optional link builder for forms/plugins |

### Environment variables (Text)

| Schema name | Purpose |
|-------------|---------|
| `kofc_BlobTenantId` | Entra tenant ID |
| `kofc_BlobClientId` | SPA client ID |
| `kofc_BlobApiAppId` | Function API app ID |
| `kofc_BlobApiKey` | Boomi `x-api-key` |
| `kofc_BlobBoomiUrl` | Boomi REST URL |
| `kofc_D365OrgUrl` | Optional — for ADF/link builders outside D365 session |
| `kofc_BlobOpenerWebResource` | Optional — default `kofc_blob_open.html` |

### Entra SPA redirect URI

Register (if not already):

```text
https://<org>.crm.dynamics.com/WebResources/kofc_authcallback.html
```

---

## 4. Timeline / ADF link contract (generic)

**Do not** put Boomi or Function URLs in timeline HTML.  
**Do** link to the D365 blob opener web resource with **business parameters only**.

### URL shape

```text
{OrgUrl}/main.aspx?pagetype=webresource
  &webresourceName=kofc_blob_open.html
  &data=path%3D{encodedPath}%26contactId%3D{contactGuid}
```

- **`contactId`** = same GUID as the timeline post **regarding** contact (required for authorization at click time).
- **`path`** = Windows-style file path from extraction metadata.

### ADF pipeline expression (example)

Set pipeline global parameters:

- `D365_OrgUrl` = `https://yourorg-dev.crm.dynamics.com`

Derived column for timeline `message`:

```text
@concat(
  '<a href="',
  pipeline().globalParameters.D365_OrgUrl,
  '/main.aspx?pagetype=webresource&webresourceName=kofc_blob_open.html&data=',
  uriComponent(
    concat(
      'path=', uriComponent(item().filePath),
      '&contactId=', item().contactId
    )
  ),
  '" target="_blank">View file</a>'
)
```

Replace `item().filePath` and `item().contactId` with your source column names.

### JavaScript link builder (forms / plugins)

```javascript
var url = KOFC.BlobLink.buildOpenerUrl({
    filePath: "D:\\KOFCExt Extractions\\09272024\\file.xlsx",
    contactId: "12345678-1234-1234-1234-123456789012"
});
```

Source: `webresources/blob-opener/kofc_blobLinkBuilder.js`

---

## 5. Deployment checklist

### Function App

- [ ] Deploy `KOFC.Azure.Functions.GetSaasBlobUrl`
- [ ] Enable Managed Identity + storage RBAC
- [ ] Configure `DataverseUrl`, `BlobContainerName`, `BlobStorageAccountName`
- [ ] Enable Easy Auth; expose and assign **`Blob.Read`**
- [ ] Register Dataverse application user for MI
- [ ] Restrict Function network access to Boomi (recommended)

### Boomi

- [ ] Create REST process + API gateway (`x-api-key` + SPA JWT validation)
- [ ] Map `oid` → `systemuserid` (or pass `oid` to Function)
- [ ] Client-credentials call to Function with `format=json`
- [ ] Return `{ sasUrl }` to browser

### Dynamics 365

- [ ] Publish web resources (§3)
- [ ] Create environment variables
- [ ] Register SPA redirect URI in Entra
- [ ] Update ADF / link generation to use opener URL (§4)

### ADF

- [ ] Set `D365_OrgUrl` per environment
- [ ] Update copy activity to build timeline links (not hardcoded Function URL)
- [ ] Ensure `contactId` and `filePath` are mapped from source

---

## 6. Testing

### Local Function (no auth)

```http
GET http://localhost:7071/api/GetSaasBlobUrlLocal?path=D:\test\file.txt&contactId=<guid>
```

### Boomi path (Postman)

1. Get Boomi client-credentials token (`Blob.Read`).
2. Call Function with `userId` or `oid`, `format=json`.
3. Expect `{ "sasUrl": "..." }`.

### End-to-end

1. Open Contact timeline entry with new link format.
2. Confirm sign-in (first time) via `kofc_authcallback.html`.
3. File opens from SAS URL.
4. Verify user without contact access receives 403.

---

## 7. Troubleshooting

| Symptom | Check |
|---------|-------|
| 401 from Function | Easy Auth / `Blob.Read` on Boomi SP |
| 403 from Function | User cannot read contact in Dataverse (impersonation) |
| 404 from Function | Blob path normalization / container name |
| Blank page on click | Web resources published; env vars set |
| MSAL redirect loop | `kofc_authcallback.html` registered in Entra SPA |
| ADF link wrong env | `D365_OrgUrl` pipeline parameter for that environment |

---

## 8. Repository layout

```text
proxyBlobFunction/
  KOFC.Azure.Functions.GetSaasBlobUrl/     # Function (Boomi + legacy Easy Auth)
  BOOMI_INTEGRATION.md                     # This guide

webresources/blob-opener/
  kofc_blob_open.html                      # Timeline landing page
  kofc_blobClient.js                       # KOFC.Blob client
  kofc_blobLinkBuilder.js                  # Generic link builder

webresources/eapp-boomi-button/
  kofc_authclient.js                       # Shared MSAL
  kofc_authcallback.html                   # Shared redirect (blob + eapp + policy)
```

---

## 9. Migration from hardcoded Function URL

**Before:**

```text
https://proxyblob.azurewebsites.net/api/GetSaasBlobUrl?path=...&contactId=...
```

**After:**

```text
https://<org>.crm.dynamics.com/main.aspx?pagetype=webresource&webresourceName=kofc_blob_open.html&data=path=...&contactId=...
```

1. Deploy web resources and configure env vars.
2. Update ADF link expression.
3. New timeline rows use Boomi path automatically.
4. Retire direct Function links when no longer needed (or keep legacy Easy Auth during transition).
