# Testing Authentication Locally

## Challenge

Azure AD Easy Auth headers are **only injected by Azure App Service**, not by the local Functions runtime. This means you cannot test the full authentication flow locally without some workarounds.

---

## Option 1: Use Local Testing Endpoint (Easiest)

The `GetSaasBlobUrlLocal` function bypasses authentication for local testing.

### Setup

1. **Start the function:**
   ```powershell
   cd KOFC.Azure.Functions.GetSaasBlobUrl
   func start
   ```

2. **Use the local endpoint:**
   ```
   http://localhost:7071/api/GetSaasBlobUrlLocal?path=D:\test\file.txt&contactId=12345678-1234-1234-1234-123456789012
   ```

**⚠️ Note:** This skips:
- ❌ Azure AD authentication
- ❌ Dataverse validation
- ✅ Only tests blob access and path normalization

---

## Option 2: Manually Inject Test Headers (Recommended for Auth Testing)

Create a test helper to simulate Easy Auth headers.

### Step 1: Create Test Helper

Create `KOFC.Azure.Functions.GetSaasBlobUrl/Helpers/TestAuthHelper.cs`:

```csharp
using System.Text;
using System.Text.Json;
using KOFC.Azure.Functions.GetSaasBlobUrl.Models;

namespace KOFC.Azure.Functions.GetSaasBlobUrl.Helpers;

public static class TestAuthHelper
{
    /// <summary>
    /// Creates a Base64-encoded user principal for testing
    /// </summary>
    public static string CreateTestPrincipal(
        string userName = "test@example.com",
        string oid = "12345678-1234-1234-1234-123456789012",
        string email = "test@example.com")
    {
        var principal = new UserPrincipal
        {
            AuthType = "aad",
            Claims = new List<Claim>
            {
                new Claim { Type = "name", Value = userName },
                new Claim { Type = "oid", Value = oid },
                new Claim { Type = "email", Value = email },
                new Claim { Type = "preferred_username", Value = email }
            }
        };

        var json = JsonSerializer.Serialize(principal);
        return Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
    }

    /// <summary>
    /// Creates a test access token (fake, won't work with real Dataverse)
    /// </summary>
    public static string CreateTestToken()
    {
        return "test-access-token-for-local-development";
    }
}
```

### Step 2: Modify Function for Local Testing

Add a development mode check in `GetSaasBlobUrl.cs`:

```csharp
// At the top of the Run method
#if DEBUG
// For local testing: check if we're in development mode
var isDevelopment = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT") == "Development";
if (isDevelopment)
{
    // Allow test headers or create default test headers
    var testPrincipal = TestAuthHelper.CreateTestPrincipal();
    var testToken = TestAuthHelper.CreateTestToken();
    
    // Use test values if headers are missing
    accessToken = accessToken ?? testToken;
    principalHeader = principalHeader ?? testPrincipal;
    
    _logger.LogWarning("⚠️ RUNNING IN DEVELOPMENT MODE - USING TEST AUTH ⚠️");
}
#endif
```

---

## Option 3: Use Postman/Thunder Client

Manually inject headers using an HTTP client.

### Setup Postman/Thunder Client

**Request:**
- Method: `GET`
- URL: `http://localhost:7071/api/GetSaasBlobUrl?path=D:\test\file.txt&contactId=12345678-1234-1234-1234-123456789012`

**Headers:**
```
X-MS-TOKEN-AAD-ACCESS-TOKEN: YOUR_REAL_TOKEN_HERE
X-MS-CLIENT-PRINCIPAL: eyJhdXRoX3R5cCI6ImFhZCIsImNsYWltcyI6W3sidHlwIjoibmFtZSIsInZhbCI6InRlc3RAdGVzdC5jb20ifV19
X-MS-CLIENT-PRINCIPAL-NAME: test@test.com
X-MS-CLIENT-PRINCIPAL-ID: 12345678-1234-1234-1234-123456789012
```

### Get Real Token (for Dataverse Testing)

1. **Get token via Azure CLI:**
   ```powershell
   az account get-access-token --resource https://yourorg.crm.dynamics.com
   ```

2. **Or use PowerShell to get token:**
   ```powershell
   # Install module if needed
   Install-Module -Name Az.Accounts -Force
   
   # Login and get token
   Connect-AzAccount
   $context = Get-AzContext
   $token = [Microsoft.Azure.Commands.Common.Authentication.AzureSession]::Instance.AuthenticationFactory.Authenticate(
       $context.Account, $context.Environment, $context.Tenant.Id,
       $null, "Never", $null, "https://yourorg.crm.dynamics.com")
   $token.AccessToken
   ```

---

## Option 4: Development Mode Flag

Create an environment variable-based bypass.

### Update GetSaasBlobUrl.cs

```csharp
[Function("GetSaasBlobUrl")]
public async Task<HttpResponseData> Run(
    [HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = null)] HttpRequestData req)
{
    _logger.LogInformation("Processing request for GetSaasBlobUrl");

    try
    {
        // Check for development mode
        var allowLocalTesting = Environment.GetEnvironmentVariable("ALLOW_LOCAL_AUTH_BYPASS") == "true";
        
        // Extract and validate Easy Auth headers
        var accessToken = GetHeaderValue(req, "X-MS-TOKEN-AAD-ACCESS-TOKEN");
        var principalHeader = GetHeaderValue(req, "X-MS-CLIENT-PRINCIPAL");
        
        // In development, allow test values
        if (allowLocalTesting && (string.IsNullOrWhiteSpace(accessToken) || string.IsNullOrWhiteSpace(principalHeader)))
        {
            _logger.LogWarning("⚠️ LOCAL TESTING MODE - Using test authentication");
            
            // Create test principal
            var testPrincipal = new UserPrincipal
            {
                AuthType = "aad",
                Claims = new List<Claim>
                {
                    new Claim { Type = "name", Value = "Test User" },
                    new Claim { Type = "oid", Value = "00000000-0000-0000-0000-000000000000" }
                }
            };
            
            var json = JsonSerializer.Serialize(testPrincipal);
            principalHeader = Convert.ToBase64String(Encoding.UTF8.GetBytes(json));
            accessToken = "test-token-for-local-development";
            
            // Skip Dataverse validation in local mode
            _logger.LogWarning("⚠️ SKIPPING DATAVERSE VALIDATION IN LOCAL MODE");
            // ... continue with blob access only
        }
        
        if (string.IsNullOrWhiteSpace(accessToken) || string.IsNullOrWhiteSpace(principalHeader))
        {
            _logger.LogWarning("Missing authentication headers. Request is not authenticated.");
            return await CreateErrorResponse(req, HttpStatusCode.Unauthorized, 
                "Unauthorized: Missing or invalid authentication token");
        }
        
        // ... rest of the code
    }
}
```

### Set Environment Variable

**In local.settings.json:**
```json
{
  "Values": {
    "ALLOW_LOCAL_AUTH_BYPASS": "true",
    "AzureWebJobsStorage": "...",
    ...
  }
}
```

**Or via PowerShell:**
```powershell
$env:ALLOW_LOCAL_AUTH_BYPASS = "true"
func start
```

---

## Option 5: Use ngrok or Similar (Test Real Auth)

Use a tunnel to Azure to get real Easy Auth headers.

### Setup ngrok

1. **Install ngrok:**
   ```powershell
   winget install ngrok
   ```

2. **Deploy function to Azure Dev environment**

3. **Create tunnel:**
   ```powershell
   ngrok http 7071
   ```

4. **Configure Azure Function to allow ngrok URL**

5. **Test with real authentication**

**Note:** This still requires Azure deployment, but allows local debugging.

---

## Recommended Approach

### For Development Workflow:

1. **Path Normalization & Blob Access:**
   - Use `GetSaasBlobUrlLocal` endpoint
   - Fast, no auth needed

2. **Authentication Logic:**
   - Use Postman/Thunder Client with real tokens
   - Test with actual Dataverse API

3. **Full Integration:**
   - Deploy to Azure Dev environment
   - Test with real Easy Auth

---

## Quick Test Commands

### Test Local Endpoint (No Auth):
```powershell
Invoke-WebRequest "http://localhost:7071/api/GetSaasBlobUrlLocal?path=D:\test\file.txt&contactId=12345678-1234-1234-1234-123456789012"
```

### Test with Headers (Postman):
```powershell
# PowerShell
$headers = @{
    "X-MS-TOKEN-AAD-ACCESS-TOKEN" = "test-token"
    "X-MS-CLIENT-PRINCIPAL" = "BASE64_ENCODED_PRINCIPAL"
    "X-MS-CLIENT-PRINCIPAL-NAME" = "test@test.com"
    "X-MS-CLIENT-PRINCIPAL-ID" = "12345678-1234-1234-1234-123456789012"
}

Invoke-WebRequest -Uri "http://localhost:7071/api/GetSaasBlobUrl?path=D:\test\file.txt&contactId=12345678-1234-1234-1234-123456789012" -Headers $headers
```

### Get Real Azure AD Token:
```powershell
# Azure CLI
az account get-access-token --resource https://yourorg.crm.dynamics.com --query accessToken -o tsv
```

---

## Troubleshooting

### Issue: "Headers not found" (401)

**Cause:** Headers aren't being injected locally

**Solution:** 
- Use `GetSaasBlobUrlLocal` for blob testing
- Or inject headers manually with Postman
- Or enable development mode flag

### Issue: "Dataverse validation fails"

**Cause:** Test token doesn't work with real Dataverse

**Solution:**
- Get real token from Azure AD
- Or skip Dataverse validation in local mode
- Or test in Azure Dev environment

### Issue: "Token expired"

**Cause:** Real tokens expire quickly

**Solution:**
- Get fresh token before testing
- Use development mode to bypass validation
- Deploy to Azure for real testing

---

## Best Practices

1. ✅ **Use local endpoint** for blob/path testing
2. ✅ **Use real tokens** for authentication testing
3. ✅ **Deploy to dev** for full integration testing
4. ✅ **Never deploy** local testing code to production

---

## Summary Table

| Method | Auth | Dataverse | Blob | Best For |
|--------|------|-----------|------|----------|
| **GetSaasBlobUrlLocal** | ❌ | ❌ | ✅ | Quick blob testing |
| **Manual Headers (Postman)** | ✅ | ✅* | ✅ | Auth flow testing |
| **Dev Mode Flag** | ⚠️ | ❌ | ✅ | Local development |
| **Azure Dev Environment** | ✅ | ✅ | ✅ | Full integration |

*Requires real token

---

See `LOCAL_TESTING_GUIDE.md` for more detailed testing scenarios.

