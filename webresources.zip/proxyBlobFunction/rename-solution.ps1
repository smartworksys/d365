# PowerShell script to rename solution and namespaces from MIS to KOFC
# Run this from the root directory: .\rename-solution.ps1

$ErrorActionPreference = "Stop"

Write-Host "🔄 Renaming Solution and Namespaces" -ForegroundColor Cyan
Write-Host "====================================" -ForegroundColor Cyan
Write-Host ""

# Old and new names
$oldNamespace = "MIS.Azure.Functions.GetSaasBlobUrl"
$newNamespace = "KOFC.Azure.Functions.GetSaasBlobUrl"
$oldFolder = "MIS.Azure.Functions.GetSaasBlobUrl"
$newFolder = "KOFC.Azure.Functions.GetSaasBlobUrl"
$oldTestFolder = "MIS.Azure.Functions.GetSaasBlobUrl.Tests"
$newTestFolder = "KOFC.Azure.Functions.GetSaasBlobUrl.Tests"
$oldSln = "MIS.Azure.Functions.GetSaasBlobUrl.sln"
$newSln = "KOFC.Azure.Functions.GetSaasBlobUrl.sln"

Write-Host "Old: $oldNamespace" -ForegroundColor Yellow
Write-Host "New: $newNamespace" -ForegroundColor Green
Write-Host ""

# Step 1: Rename folders
Write-Host "📁 Step 1: Renaming folders..." -ForegroundColor Yellow
if (Test-Path $oldFolder) {
    Rename-Item -Path $oldFolder -NewName $newFolder -Force
    Write-Host "✅ Renamed: $oldFolder -> $newFolder" -ForegroundColor Green
}
if (Test-Path $oldTestFolder) {
    Rename-Item -Path $oldTestFolder -NewName $newTestFolder -Force
    Write-Host "✅ Renamed: $oldTestFolder -> $newTestFolder" -ForegroundColor Green
}
Write-Host ""

# Step 2: Rename solution file
Write-Host "📄 Step 2: Renaming solution file..." -ForegroundColor Yellow
if (Test-Path $oldSln) {
    Rename-Item -Path $oldSln -NewName $newSln -Force
    Write-Host "✅ Renamed: $oldSln -> $newSln" -ForegroundColor Green
}
Write-Host ""

# Step 3: Update all .cs files
Write-Host "📝 Step 3: Updating C# source files..." -ForegroundColor Yellow
$csFiles = Get-ChildItem -Path $newFolder, $newTestFolder -Filter "*.cs" -Recurse -ErrorAction SilentlyContinue
foreach ($file in $csFiles) {
    $content = Get-Content $file.FullName -Raw
    $newContent = $content -replace [regex]::Escape($oldNamespace), $newNamespace
    if ($content -ne $newContent) {
        Set-Content -Path $file.FullName -Value $newContent -NoNewline
        Write-Host "  Updated: $($file.Name)" -ForegroundColor Gray
    }
}
Write-Host "✅ Updated C# files" -ForegroundColor Green
Write-Host ""

# Step 4: Update .csproj files
Write-Host "📦 Step 4: Updating project files..." -ForegroundColor Yellow
$csprojFiles = Get-ChildItem -Path $newFolder, $newTestFolder -Filter "*.csproj" -Recurse -ErrorAction SilentlyContinue
foreach ($file in $csprojFiles) {
    $content = Get-Content $file.FullName -Raw
    $newContent = $content -replace [regex]::Escape($oldNamespace), $newNamespace
    if ($content -ne $newContent) {
        Set-Content -Path $file.FullName -Value $newContent -NoNewline
        Write-Host "  Updated: $($file.Name)" -ForegroundColor Gray
    }
}
Write-Host "✅ Updated project files" -ForegroundColor Green
Write-Host ""

# Step 5: Update solution file
Write-Host "🔧 Step 5: Updating solution file..." -ForegroundColor Yellow
if (Test-Path $newSln) {
    $content = Get-Content $newSln -Raw
    $newContent = $content -replace [regex]::Escape($oldNamespace), $newNamespace
    $newContent = $newContent -replace [regex]::Escape($oldFolder), $newFolder
    $newContent = $newContent -replace [regex]::Escape($oldTestFolder), $newTestFolder
    Set-Content -Path $newSln -Value $newContent -NoNewline
    Write-Host "✅ Updated solution file" -ForegroundColor Green
}
Write-Host ""

# Step 6: Rename .csproj files
Write-Host "📝 Step 6: Renaming project files..." -ForegroundColor Yellow
$oldCsproj = Join-Path $newFolder "$oldNamespace.csproj"
$newCsproj = Join-Path $newFolder "$newNamespace.csproj"
if (Test-Path $oldCsproj) {
    Rename-Item -Path $oldCsproj -NewName "$newNamespace.csproj" -Force
    Write-Host "✅ Renamed project file" -ForegroundColor Green
}

$oldTestCsproj = Join-Path $newTestFolder "$oldNamespace.Tests.csproj"
$newTestCsproj = Join-Path $newTestFolder "$newNamespace.Tests.csproj"
if (Test-Path $oldTestCsproj) {
    Rename-Item -Path $oldTestCsproj -NewName "$newNamespace.Tests.csproj" -Force
    Write-Host "✅ Renamed test project file" -ForegroundColor Green
}
Write-Host ""

Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
Write-Host "✅ Rename Complete!" -ForegroundColor Green
Write-Host ""
Write-Host "Next steps:" -ForegroundColor Cyan
Write-Host "  1. Clean and rebuild: dotnet clean && dotnet build" -ForegroundColor White
Write-Host "  2. Update any deployment scripts with new paths" -ForegroundColor White
Write-Host ""


