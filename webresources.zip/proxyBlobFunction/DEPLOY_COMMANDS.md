# Deployment Commands Reference

## Correct Deployment Command

Always run from the function app project directory:

```powershell
# Navigate to function app directory
cd C:\proxyBlobFunction\MIS.Azure.Functions.GetSaasBlobUrl

# Deploy
func azure functionapp publish ProxyBlobAccess
```

## Alternative: One-liner

```powershell
cd C:\proxyBlobFunction\MIS.Azure.Functions.GetSaasBlobUrl; func azure functionapp publish ProxyBlobAccess
```

## Verify Deployment

```powershell
# Check function app status
az functionapp show --name ProxyBlobAccess --resource-group YOUR-RESOURCE-GROUP --query state

# List functions
az functionapp function list --name ProxyBlobAccess --resource-group YOUR-RESOURCE-GROUP

# Get function URL
az functionapp function show --name ProxyBlobAccess --resource-group YOUR-RESOURCE-GROUP --function-name GetSaasBlobUrl --query invokeUrlTemplate
```

## Check Application Settings

```powershell
az functionapp config appsettings list --name ProxyBlobAccess --resource-group YOUR-RESOURCE-GROUP
```

## Required Settings

Make sure these are configured in Azure:

- `BLOB_CONNECTION_STRING` (or `AzureWebJobsStorage`)
- `DataverseUrl`
- `BlobContainerName`
- `FUNCTIONS_WORKER_RUNTIME=dotnet-isolated`

## Set Application Settings

```powershell
az functionapp config appsettings set `
  --name ProxyBlobAccess `
  --resource-group YOUR-RESOURCE-GROUP `
  --settings `
    "BLOB_CONNECTION_STRING=YOUR_CONNECTION_STRING" `
    "DataverseUrl=https://orgbf3a235c.crm.dynamics.com" `
    "BlobContainerName=smart-office"
```


