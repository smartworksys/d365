# Deployment Scripts Guide

## Quick Start

### Option 1: Create and Deploy Everything (First Time)

```powershell
.\deploy-function.ps1
```

This script will:
- ✅ Create resource group (if needed)
- ✅ Create storage account (if needed)
- ✅ Create App Service Plan (Consumption)
- ✅ Create Function App
- ✅ Configure application settings
- ✅ Build the project
- ✅ Deploy the function

### Option 2: Deploy Only (After Initial Setup)

```powershell
.\deploy-only.ps1
```

This script will:
- ✅ Build the project
- ✅ Publish the project
- ✅ Deploy to existing Function App

---

## Custom Parameters

### Full Deployment Script

```powershell
.\deploy-function.ps1 `
    -FunctionAppName "MyFunctionApp" `
    -ResourceGroupName "MyResourceGroup" `
    -Location "westus2" `
    -DataverseUrl "https://myorg.crm.dynamics.com" `
    -BlobContainerName "my-container"
```

**Parameters:**
- `-FunctionAppName` - Name of the Function App (default: "ProxyBlobAccess")
- `-ResourceGroupName` - Resource group name (default: "ProxyBlobAccess_group")
- `-Location` - Azure region (default: "eastus")
- `-StorageAccountName` - Storage account name (auto-generated if not provided)
- `-AppServicePlanName` - App Service Plan name (auto-generated if not provided)
- `-SubscriptionId` - Azure subscription ID (optional)
- `-DataverseUrl` - Dynamics 365 Dataverse URL
- `-BlobContainerName` - Blob container name (default: "smart-office")
- `-BlobConnectionString` - Blob storage connection string (auto-retrieved if not provided)
- `-SkipBuild` - Skip build step
- `-SkipDeploy` - Skip deployment step

### Deploy Only Script

```powershell
.\deploy-only.ps1 `
    -FunctionAppName "MyFunctionApp" `
    -ResourceGroupName "MyResourceGroup"
```

---

## Prerequisites

1. **Azure CLI installed:**
   ```powershell
   winget install Microsoft.AzureCLI
   ```

2. **Azure Functions Core Tools:**
   ```powershell
   winget install Microsoft.AzureFunctionsCoreTools
   ```

3. **.NET 8 SDK:**
   ```powershell
   winget install Microsoft.DotNet.SDK.8
   ```

4. **Logged in to Azure:**
   ```powershell
   az login
   ```

---

## Step-by-Step Manual Deployment

If you prefer to deploy manually:

### 1. Create Resources

```powershell
# Login
az login

# Set subscription (optional)
az account set --subscription "YOUR-SUBSCRIPTION-ID"

# Create resource group
az group create --name ProxyBlobAccess_group --location eastus

# Create storage account
az storage account create `
    --name proxyblobaccessstorage `
    --resource-group ProxyBlobAccess_group `
    --location eastus `
    --sku Standard_LRS

# Create Function App
az functionapp create `
    --name ProxyBlobAccess `
    --resource-group ProxyBlobAccess_group `
    --consumption-plan-location eastus `
    --storage-account proxyblobaccessstorage `
    --runtime dotnet-isolated `
    --runtime-version 8 `
    --functions-version 4
```

### 2. Configure Settings

```powershell
# Get storage connection string
$storageConn = az storage account show-connection-string `
    --name proxyblobaccessstorage `
    --resource-group ProxyBlobAccess_group `
    --query connectionString -o tsv

# Set application settings
az functionapp config appsettings set `
    --name ProxyBlobAccess `
    --resource-group ProxyBlobAccess_group `
    --settings `
        "FUNCTIONS_WORKER_RUNTIME=dotnet-isolated" `
        "BLOB_CONNECTION_STRING=$storageConn" `
        "DataverseUrl=https://orgbf3a235c.crm.dynamics.com" `
        "BlobContainerName=smart-office"
```

### 3. Remove Incompatible Settings

```powershell
az functionapp config appsettings delete `
    --name ProxyBlobAccess `
    --resource-group ProxyBlobAccess_group `
    --setting-names WEBSITE_RUN_FROM_PACKAGE
```

### 4. Build and Deploy

```powershell
cd MIS.Azure.Functions.GetSaasBlobUrl
dotnet publish -c Release
func azure functionapp publish ProxyBlobAccess --dotnet-isolated
```

---

## Troubleshooting

### Error: "Unable to find project root"

**Solution:** Run from the correct directory:
```powershell
cd C:\proxyBlobFunction\MIS.Azure.Functions.GetSaasBlobUrl
func azure functionapp publish ProxyBlobAccess
```

### Error: "Can't determine Project to build"

**Solution:** Build first, then deploy from publish folder:
```powershell
dotnet publish -c Release -o ./publish
cd publish
func azure functionapp publish ProxyBlobAccess
```

### Error: "WEBSITE_RUN_FROM_PACKAGE not supported"

**Solution:** The script automatically removes this setting. If error persists:
```powershell
az functionapp config appsettings delete `
    --name ProxyBlobAccess `
    --resource-group ProxyBlobAccess_group `
    --setting-names WEBSITE_RUN_FROM_PACKAGE
```

### Error: "LinuxFxVersion error"

**Solution:** The script sets the correct runtime version. If error persists:
```powershell
az functionapp config set `
    --name ProxyBlobAccess `
    --resource-group ProxyBlobAccess_group `
    --net-framework-version v8.0
```

---

## Verify Deployment

### Check Functions

```powershell
az functionapp function list `
    --name ProxyBlobAccess `
    --resource-group ProxyBlobAccess_group
```

### Get Function URL

```powershell
az functionapp function show `
    --name ProxyBlobAccess `
    --resource-group ProxyBlobAccess_group `
    --function-name GetSaasBlobUrl `
    --query invokeUrlTemplate
```

### Test Function

```powershell
# Get URL
$url = az functionapp function show `
    --name ProxyBlobAccess `
    --resource-group ProxyBlobAccess_group `
    --function-name GetSaasBlobUrl `
    --query invokeUrlTemplate -o tsv

# Test
Invoke-WebRequest -Uri "$url?path=D:\test\file.txt&contactId=test-id"
```

---

## CI/CD Integration

### GitHub Actions Example

```yaml
name: Deploy Function App

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup .NET
        uses: actions/setup-dotnet@v1
        with:
          dotnet-version: '8.0.x'
      
      - name: Build
        run: dotnet build --configuration Release
      
      - name: Publish
        run: dotnet publish -c Release -o ./publish
      
      - name: Deploy to Azure
        uses: Azure/functions-action@v1
        with:
          app-name: 'ProxyBlobAccess'
          package: './publish'
          publish-profile: ${{ secrets.AZURE_FUNCTIONAPP_PUBLISH_PROFILE }}
```

### Azure DevOps Example

```yaml
trigger:
- main

pool:
  vmImage: 'windows-latest'

steps:
- task: UseDotNet@2
  inputs:
    version: '8.0.x'

- task: DotNetCoreCLI@2
  inputs:
    command: 'publish'
    publishWebProjects: false
    projects: '**/MIS.Azure.Functions.GetSaasBlobUrl.csproj'
    arguments: '-c Release -o $(build.artifactstagingdirectory)'

- task: AzureFunctionApp@1
  inputs:
    azureSubscription: 'Your-Service-Connection'
    appName: 'ProxyBlobAccess'
    package: '$(build.artifactstagingdirectory)'
```

---

## Best Practices

1. **Use parameter files** for different environments
2. **Store secrets in Key Vault** (not in scripts)
3. **Use managed identity** instead of connection strings where possible
4. **Tag resources** for better organization
5. **Enable Application Insights** for monitoring
6. **Use staging slots** for testing before production

---

## Script Output

The deployment script provides:
- ✅ Progress indicators for each step
- ✅ Error handling with clear messages
- ✅ Function URL after successful deployment
- ✅ Summary of created resources

---

## Support

For issues:
1. Check **DEPLOYMENT_TROUBLESHOOTING.md**
2. Review Azure Portal → Function App → Log stream
3. Check Application Insights for errors


