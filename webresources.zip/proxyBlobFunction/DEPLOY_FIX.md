# Fix Deployment Issues

## Problem 1: Multiple .csproj Files Found

**Solution:** Build the project first, then deploy from the publish folder.

```powershell
cd C:\proxyBlobFunction\MIS.Azure.Functions.GetSaasBlobUrl

# Build and publish
dotnet publish -c Release -o ./publish

# Deploy from publish folder
cd publish
func azure functionapp publish ProxyBlobAccess
```

OR specify the project explicitly:

```powershell
cd C:\proxyBlobFunction\MIS.Azure.Functions.GetSaasBlobUrl
func azure functionapp publish ProxyBlobAccess --dotnet-isolated
```

## Problem 2: LinuxFxVersion Error

**Cause:** Function app runtime version mismatch - trying to set .NET 6 when you need .NET 8.

**Solution:** Set the correct runtime version:

### Option A: Azure CLI (if using Windows/Linux Consumption)

```powershell
# For Windows
az functionapp config set --name ProxyBlobAccess --net-framework-version v8.0

# For Linux (if applicable)
az functionapp config set --name ProxyBlobAccess --linux-fx-version "DOTNET-ISOLATED|8.0"
```

### Option B: Azure Portal

1. Go to Function App → **Configuration** → **General settings**
2. Set **Stack**: `.NET`
3. Set **Version**: `8.0`
4. Save

### Option C: Remove LinuxFxVersion (for Flex Consumption)

If using Flex Consumption plan, remove the LinuxFxVersion setting:

```powershell
az functionapp config appsettings delete \
  --name ProxyBlobAccess \
  --resource-group YOUR-RESOURCE-GROUP \
  --setting-names WEBSITE_NODE_DEFAULT_VERSION
```

## Correct Deployment Process

### Step 1: Build the Project

```powershell
cd C:\proxyBlobFunction\MIS.Azure.Functions.GetSaasBlobUrl
dotnet clean
dotnet build -c Release
dotnet publish -c Release -o ./publish
```

### Step 2: Deploy

**Option A: Deploy from publish folder**
```powershell
cd publish
func azure functionapp publish ProxyBlobAccess
```

**Option B: Deploy specifying project**
```powershell
cd C:\proxyBlobFunction\MIS.Azure.Functions.GetSaasBlobUrl
func azure functionapp publish ProxyBlobAccess --dotnet-isolated --project MIS.Azure.Functions.GetSaasBlobUrl.csproj
```

**Option C: Using dotnet publish + zip deploy**
```powershell
cd C:\proxyBlobFunction\MIS.Azure.Functions.GetSaasBlobUrl
dotnet publish -c Release -o ./publish
cd publish
Compress-Archive -Path * -DestinationPath ../deploy.zip
az functionapp deployment source config-zip `
  --name ProxyBlobAccess `
  --resource-group YOUR-RESOURCE-GROUP `
  --src ../deploy.zip
```

## Verify Runtime Version

```powershell
az functionapp config show --name ProxyBlobAccess --resource-group YOUR-RESOURCE-GROUP --query "{netFrameworkVersion:netFrameworkVersion, linuxFxVersion:linuxFxVersion}"
```

Should show:
- Windows: `v8.0` for netFrameworkVersion
- Linux: `DOTNET-ISOLATED|8.0` for linuxFxVersion

## Quick Fix Commands

```powershell
# 1. Set runtime to .NET 8
az functionapp config set --name ProxyBlobAccess --net-framework-version v8.0

# 2. Build and publish
cd C:\proxyBlobFunction\MIS.Azure.Functions.GetSaasBlobUrl
dotnet publish -c Release -o ./publish

# 3. Deploy
cd publish
func azure functionapp publish ProxyBlobAccess
```


