# Testing with Postman - Real Authentication (No Code Changes)

## ✅ Yes, You Can Test Real Auth in Postman!

You can test **real authentication** locally using Postman by manually injecting the Easy Auth headers that Azure would normally provide. **No code changes needed!**

---

## Quick Setup

### Step 1: Start Your Function Locally

```powershell
cd KOFC.Azure.Functions.GetSaasBlobUrl
func start
```

Function will be available at: `http://localhost:7071/api/GetSaasBlobUrl`

---

### Step 2: Get Real Azure AD Token

#### Option A: Azure CLI (Easiest)

```powershell
# Get token for your Dataverse organization
az account get-access-token --resource https://yourorg.crm.dynamics.com --query accessToken -o tsv
```

**Copy the token** - you'll use it in Postman.

#### Option B: PowerShell (Alternative)

```powershell
# Login first if needed
Connect-AzAccount

# Get token
$context = Get-AzContext
$token = Get-AzAccessToken -ResourceUrl "https://yourorg.crm.dynamics.com"
$token.Token
```

---

### Step 3: Generate Base64 Principal

Create the Base64-encoded principal that matches your Azure AD user:

```powershell
# Generate principal for YOUR user
$userEmail = "your.email@yourdomain.com"  # Your actual email
$userOid = "YOUR-OID-HERE"  # Get from Azure AD or token claims

$principal = @{
    auth_typ = "aad"
    claims = @(
        @{ typ = "name"; val = $userEmail },
        @{ typ = "oid"; val = $userOid },
        @{ typ = "email"; val = $userEmail },
        @{ typ = "preferred_username"; val = $userEmail }
    )
} | ConvertTo-Json -Depth 10 -Compress

$bytes = [System.Text.Encoding]::UTF8.GetBytes($principal)
$base64Principal = [Convert]::ToBase64String($bytes)

Write-Host "X-MS-CLIENT-PRINCIPAL: $base64Principal"
```

**To get your OID (Object ID):**
```powershell
# Get your user's OID
az ad signed-in-user show --query id -o tsv
```

---

### Step 4: Configure Postman Request

**Method:** `GET`

**URL:**
```
http://localhost:7071/api/GetSaasBlobUrl?path=D:\KOFCExt%20Extractions\09272024\000554\file.xlsx&contactId=12345678-1234-1234-1234-123456789012
```

**Headers Tab:**
```
X-MS-TOKEN-AAD-ACCESS-TOKEN: [Paste the token from Step 2]
X-MS-CLIENT-PRINCIPAL: [Paste the base64 principal from Step 3]
X-MS-CLIENT-PRINCIPAL-NAME: your.email@yourdomain.com
X-MS-CLIENT-PRINCIPAL-ID: [Your OID from Step 3]
```

**Example Headers:**
```
X-MS-TOKEN-AAD-ACCESS-TOKEN: eyJ0eXAiOiJKV1QiLCJubGciOiJSUzI1NiIsIng1dCI6...
X-MS-CLIENT-PRINCIPAL: eyJhdXRoX3R5cCI6ImFhZCIsImNsYWltcyI6W3sidHlwIjoibmFtZSIsInZhbCI6InlvdXIuZW1haWxAZG9tYWluLmNvbSJ9XX0=
X-MS-CLIENT-PRINCIPAL-NAME: your.email@yourdomain.com
X-MS-CLIENT-PRINCIPAL-ID: 87654321-4321-4321-4321-210987654321
```

---

## Complete Example

### PowerShell Script to Get Everything

Save this as `get-postman-headers.ps1`:

```powershell
# Get Postman Headers for Testing
param(
    [Parameter(Mandatory=$false)]
    [string]$DataverseUrl = "https://yourorg.crm.dynamics.com",
    
    [Parameter(Mandatory=$false)]
    [string]$UserEmail = ""
)

Write-Host "🔑 Getting Authentication Headers for Postman" -ForegroundColor Cyan
Write-Host "===============================================" -ForegroundColor Cyan
Write-Host ""

# Get access token
Write-Host "📥 Getting Azure AD token..." -ForegroundColor Yellow
$token = az account get-access-token --resource $DataverseUrl --query accessToken -o tsv

if ([string]::IsNullOrWhiteSpace($token)) {
    Write-Host "❌ Failed to get token. Make sure you're logged in: az login" -ForegroundColor Red
    exit 1
}

Write-Host "✅ Token obtained" -ForegroundColor Green
Write-Host ""

# Get user info if email not provided
if ([string]::IsNullOrWhiteSpace($UserEmail)) {
    Write-Host "👤 Getting signed-in user info..." -ForegroundColor Yellow
    $user = az ad signed-in-user show
    $userJson = $user | ConvertFrom-Json
    $UserEmail = $userJson.mail
    $userOid = $userJson.id
} else {
    Write-Host "👤 Getting user OID..." -ForegroundColor Yellow
    $user = az ad user show --id $UserEmail 2>$null
    if ($LASTEXITCODE -eq 0) {
        $userJson = $user | ConvertFrom-Json
        $userOid = $userJson.id
    } else {
        Write-Host "⚠️  Could not find user, using default OID" -ForegroundColor Yellow
        $userOid = "00000000-0000-0000-0000-000000000000"
    }
}

# Generate principal
Write-Host "📝 Generating principal..." -ForegroundColor Yellow
$principal = @{
    auth_typ = "aad"
    claims = @(
        @{ typ = "name"; val = $UserEmail },
        @{ typ = "oid"; val = $userOid },
        @{ typ = "email"; val = $UserEmail },
        @{ typ = "preferred_username"; val = $UserEmail }
    )
} | ConvertTo-Json -Depth 10 -Compress

$bytes = [System.Text.Encoding]::UTF8.GetBytes($principal)
$base64Principal = [Convert]::ToBase64String($bytes)

Write-Host ""
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
Write-Host "✅ Copy these headers to Postman:" -ForegroundColor Green
Write-Host ""
Write-Host "X-MS-TOKEN-AAD-ACCESS-TOKEN:" -ForegroundColor Yellow
Write-Host $token -ForegroundColor White
Write-Host ""
Write-Host "X-MS-CLIENT-PRINCIPAL:" -ForegroundColor Yellow
Write-Host $base64Principal -ForegroundColor White
Write-Host ""
Write-Host "X-MS-CLIENT-PRINCIPAL-NAME:" -ForegroundColor Yellow
Write-Host $UserEmail -ForegroundColor White
Write-Host ""
Write-Host "X-MS-CLIENT-PRINCIPAL-ID:" -ForegroundColor Yellow
Write-Host $userOid -ForegroundColor White
Write-Host ""
Write-Host "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" -ForegroundColor Cyan
Write-Host ""
Write-Host "💡 Tip: Tokens expire in 1 hour. Run this script again for fresh token." -ForegroundColor Gray
Write-Host ""
```

**Usage:**
```powershell
.\get-postman-headers.ps1
```

---

## Postman Setup Screenshots Guide

### 1. Create New Request
- Method: **GET**
- URL: `http://localhost:7071/api/GetSaasBlobUrl?path=D:\test\file.txt&contactId=...`

### 2. Add Headers Tab
Click **Headers** tab and add:

| Key | Value |
|-----|-------|
| `X-MS-TOKEN-AAD-ACCESS-TOKEN` | `[Your token]` |
| `X-MS-CLIENT-PRINCIPAL` | `[Base64 principal]` |
| `X-MS-CLIENT-PRINCIPAL-NAME` | `your.email@domain.com` |
| `X-MS-CLIENT-PRINCIPAL-ID` | `[Your OID]` |

### 3. Send Request

Expected responses:
- **302 Redirect** → Success! Redirects to blob SAS URL
- **401 Unauthorized** → Headers missing/invalid
- **403 Forbidden** → No Dataverse access to contact
- **404 Not Found** → Blob doesn't exist

---

## Test Scenarios

### Scenario 1: Valid Request
```
✅ Headers: Valid token + Valid principal
✅ Contact: User has access
✅ Blob: Exists
Result: 302 Redirect to blob
```

### Scenario 2: Missing Headers
```
❌ Headers: Missing or empty
Result: 401 Unauthorized
```

### Scenario 3: Invalid Token
```
⚠️ Headers: Invalid/expired token
Result: 403 Forbidden (Dataverse rejects token)
```

### Scenario 4: No Contact Access
```
✅ Headers: Valid
❌ Contact: User doesn't have access
Result: 403 Forbidden
```

### Scenario 5: Blob Not Found
```
✅ Headers: Valid
✅ Contact: User has access
❌ Blob: Doesn't exist
Result: 404 Not Found
```

---

## Troubleshooting

### Issue: "401 Unauthorized"

**Check:**
- ✅ All 4 headers are present
- ✅ Headers are spelled correctly (case-sensitive)
- ✅ Principal is valid Base64

**Fix:**
```powershell
# Regenerate principal
.\get-postman-headers.ps1
```

---

### Issue: "403 Forbidden"

**Possible causes:**
1. Token expired (get new token)
2. User doesn't have access to the contact in Dataverse
3. Dataverse URL incorrect in local.settings.json

**Fix:**
```powershell
# Get fresh token
az account get-access-token --resource https://yourorg.crm.dynamics.com --query accessToken -o tsv

# Verify contact access in Dynamics 365
```

---

### Issue: "Token expired"

**Solution:**
- Tokens expire in **1 hour**
- Run `get-postman-headers.ps1` again for fresh token
- Or use Azure CLI: `az account get-access-token --resource ...`

---

### Issue: "Cannot decode principal"

**Solution:**
- Ensure principal is valid Base64
- Check JSON structure is correct
- Use the script to generate it properly

---

## Quick Reference

### Get Token:
```powershell
az account get-access-token --resource https://yourorg.crm.dynamics.com --query accessToken -o tsv
```

### Get Your OID:
```powershell
az ad signed-in-user show --query id -o tsv
```

### Generate Principal:
```powershell
.\get-postman-headers.ps1
```

---

## Advantages of Postman Testing

✅ **No code changes** - Test real auth flow  
✅ **Real tokens** - Test actual Dataverse API  
✅ **Debug headers** - See exactly what's sent  
✅ **Save requests** - Reuse for testing  
✅ **Environment variables** - Easy token management  

---

## Postman Environment Setup (Optional)

Create a Postman Environment with variables:

**Variables:**
- `base_url`: `http://localhost:7071`
- `access_token`: `[Your token]`
- `client_principal`: `[Base64 principal]`
- `principal_name`: `your.email@domain.com`
- `principal_id`: `[Your OID]`

**Then use in request:**
```
URL: {{base_url}}/api/GetSaasBlobUrl?path=...&contactId=...
Headers:
  X-MS-TOKEN-AAD-ACCESS-TOKEN: {{access_token}}
  X-MS-CLIENT-PRINCIPAL: {{client_principal}}
  X-MS-CLIENT-PRINCIPAL-NAME: {{principal_name}}
  X-MS-CLIENT-PRINCIPAL-ID: {{principal_id}}
```

This way you only update the token variable when it expires!

---

## Summary

**✅ YES - You can test real authentication in Postman!**

1. **No code changes needed** ✅
2. **Get real Azure AD token** ✅
3. **Generate Base64 principal** ✅
4. **Add headers in Postman** ✅
5. **Test the full flow** ✅

The function code doesn't need any modifications - it will accept the headers from Postman just like it would from Azure Easy Auth!

