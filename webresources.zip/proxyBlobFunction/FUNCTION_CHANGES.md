# GetSaasBlobUrl Function — Exact Code Changes (Boomi Integration)

This document lists **exact changes** made to the Azure Function App project for Boomi integration. For end-to-end setup steps, see [BOOMI_INTEGRATION.md](./BOOMI_INTEGRATION.md).

---

## Summary

| Area | Before | After |
|------|--------|-------|
| Callers | Direct browser → Easy Auth only | **Legacy Easy Auth** OR **Boomi** (`Blob.Read` app role) |
| User auth (Boomi path) | N/A | `userId` or `oid` from Boomi → impersonation in Dataverse |
| Response | 302 redirect only | **`format=json`** → `{ "sasUrl": "..." }` or default **302 redirect** |
| Blob SAS | Account key via connection string | **User delegation SAS** via Managed Identity when `BlobStorageAccountName` is set |
| HTTP methods | GET only | **GET and POST** (POST body JSON merged into query params) |
| Dataverse (Boomi path) | User token via HTTP | **Managed Identity** + impersonation via `ServiceClient` |

---

## New files

| File | Purpose |
|------|---------|
| `Helpers/FunctionAppRoleAuth.cs` | Reads `X-MS-CLIENT-PRINCIPAL`, extracts app roles, detects Azure vs local |
| `Services/IContactAccessGuard.cs` | Interface for Boomi-path contact authorization |
| `Services/ContactAccessGuard.cs` | Impersonates user in Dataverse; verifies contact read access |
| `Services/IDataverseClient.cs` | Thin wrapper over Dataverse SDK for testability |
| `Services/DataverseClientAdapter.cs` | Implements `IDataverseClient` using `ServiceClient` |
| `Services/DataverseClientFactory.cs` | Creates `ServiceClient` with `DefaultAzureCredential` |

---

## Modified files

### `GetSaasBlobUrl.cs`

**Constructor — new dependency:**

```csharp
IContactAccessGuard contactAccessGuard
```

**HTTP trigger — added POST:**

```csharp
[HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)]
```

**New request parameters:**

| Parameter | Required | Used by |
|-----------|----------|---------|
| `format` | No | `json` returns JSON; default is `redirect` |
| `userId` | Boomi path | Dataverse `systemuserid` (from Boomi) |
| `oid` | Boomi path (alt) | Entra object ID; Function resolves to `systemuserid` |

**Dual auth detection (lines 63–69):**

```csharp
var isLegacyCaller = !string.IsNullOrWhiteSpace(accessToken)
    && !string.IsNullOrWhiteSpace(principalHeader);
var isBoomiCaller = !isLegacyCaller
    && FunctionAppRoleAuth.HasAppRole(callerRoles, FunctionAppRoleAuth.BlobReadRole);
```

- **Legacy path:** Requires `X-MS-TOKEN-AAD-ACCESS-TOKEN` + `X-MS-CLIENT-PRINCIPAL`. Uses existing `IDataverseService.ValidateContactAccessAsync` with the user's token.
- **Boomi path:** No user access token. Requires `Blob.Read` role on caller principal. Uses `IContactAccessGuard` with `userId` or `oid`.

**Boomi authorization (`ValidateBoomiContactAccess`):**

1. If `userId` is present → `ContactAccessGuard.CheckContactAccess(userId, contactId)`
2. Else if `oid` is present → `ContactAccessGuard.CheckContactAccessByEntraOid(oid, contactId)`
3. Else → 404 with message requiring `userId` or `oid`

**HTTP status mapping (Boomi path):**

| Result | Status |
|--------|--------|
| User not found in Dataverse | **404** |
| User cannot read contact | **403** |

**Response format (lines 151–161):**

```csharp
if (responseFormat == "json")
{
    // 200 OK, Content-Type: application/json
    // { "sasUrl": "https://..." }
}
else
{
    // 302 Redirect, Location: sasUrl
}
```

**New helper methods:**

- `ParseQuery()` — case-insensitive query dictionary
- `MergePostBodyAsync()` — merges JSON POST body properties into query params (POST only)
- `GetParam()` — safe query param lookup
- `ValidateBoomiContactAccess()` — Boomi user/contact validation

**Unchanged on legacy path:**

- `path` and `contactId` validation
- `IDataverseService` contact check with user token
- Blob path normalization and SAS generation
- Error responses for missing blob (404)

---

### `Program.cs`

**Blob client registration — two modes:**

```csharp
// Managed Identity (preferred)
if (BlobStorageAccountName is set)
    BlobServiceClient(new Uri($"https://{accountName}.blob.core.windows.net"), DefaultAzureCredential)

// Fallback
else
    BlobServiceClient(BLOB_CONNECTION_STRING ?? AzureWebJobsStorage)
```

**New DI registrations:**

```csharp
services.AddScoped<ServiceClient>(DataverseClientFactory.Create);
services.AddScoped<IDataverseClient, DataverseClientAdapter>();
services.AddScoped<IContactAccessGuard, ContactAccessGuard>();
```

**Unchanged registrations:**

- `IPrincipalService` / `PrincipalService`
- `IBlobService` / `BlobService`
- `IDataverseService` / `DataverseService` (legacy path)

---

### `Services/BlobService.cs`

**Constructor — new behavior:**

```csharp
_useUserDelegationSas = !string.IsNullOrWhiteSpace(configuration["BlobStorageAccountName"]);
```

**`NormalizePathToBlob()` — prefix stripping restored:**

After drive-letter removal and slash normalization, strips the **`KOFCExt Extractions`** prefix (case-insensitive, with or without trailing slash):

```csharp
cleaned = Regex.Replace(cleaned, @"^(?i)kofcext extractions/?", string.Empty);
```

Example: `D:\KOFCExt Extractions\09272024\file.xlsx` → `09272024/file.xlsx`

**`GenerateSasUrlAsync()` — user delegation SAS:**

When `BlobStorageAccountName` is configured:

```csharp
var delegationKey = await _blobServiceClient.GetUserDelegationKeyAsync(...);
var sasQuery = sasBuilder.ToSasQueryParameters(delegationKey.Value, _blobServiceClient.AccountName);
```

When not configured, falls back to `blobClient.GenerateSasUri(sasBuilder)` (account key from connection string).

**SAS settings (unchanged):**

- Read-only permission
- Starts 5 minutes ago, expires in 15 minutes
- Verifies container and blob exist before generating SAS

---

### `KOFC.Azure.Functions.GetSaasBlobUrl.csproj`

**New NuGet packages:**

| Package | Version | Purpose |
|---------|---------|---------|
| `Azure.Identity` | 1.13.2 | `DefaultAzureCredential` for MI |
| `Microsoft.PowerPlatform.Dataverse.Client` | 1.2.10 | Dataverse SDK for impersonation |
| `Azure.Storage.Blobs` | 12.22.2 | Bumped for user delegation SAS APIs |

---

## Unchanged files (legacy behavior preserved)

| File | Notes |
|------|-------|
| `GetSaasBlobUrl.Local.cs` | Local dev endpoint without auth (excluded from Release build) |
| `Services/DataverseService.cs` | HTTP-based contact check for legacy Easy Auth path |
| `Services/PrincipalService.cs` | Decodes `X-MS-CLIENT-PRINCIPAL` for legacy path |
| `Models/UserPrincipal.cs` | Principal/claim model |
| `host.json` | No changes |

---

## New / updated app settings

| Setting | Required | Change |
|---------|----------|--------|
| `DataverseUrl` | Yes | Used by both legacy HTTP check and new MI Dataverse client |
| `BlobContainerName` | Yes | Unchanged |
| `BlobStorageAccountName` | **New (recommended)** | Enables MI + user delegation SAS (no storage account key) |
| `BLOB_CONNECTION_STRING` | Fallback | Used when `BlobStorageAccountName` is not set |
| `DATAVERSE_USERNAME_FIELD` | Optional | Defaults to `domainname`; used when resolving user by Entra oid |

**Entra / Easy Auth (Azure portal, not in code):**

- Expose app role **`Blob.Read`** on the Function API app registration
- Assign **`Blob.Read`** to the Boomi service principal

---

## Test project changes

**`GetSaasBlobUrlTests.cs`:**

- Added `IContactAccessGuard` mock to all tests
- Added `AzureEnvironmentScope` helper (sets/clears `WEBSITE_SITE_NAME` for auth-mode tests)
- New test: `Run_BoomiCaller_ReturnsJsonSasUrl`
- Auth tests updated to simulate Azure host where needed

**`BlobServiceTests.cs`:**

- `CreateBlobService()` passes mock `IConfiguration` with `BlobStorageAccountName = null`
- Uses `global::Azure.Storage.Blobs.BlobServiceClient` to avoid namespace conflict

**Test count:** 48 tests, all passing.

---

## Request/response contract (after changes)

### Boomi → Function

```http
GET /api/GetSaasBlobUrl?path={path}&contactId={guid}&userId={systemuserid}&format=json
Authorization: Bearer {client-credentials token with Blob.Read}
X-MS-CLIENT-PRINCIPAL: {Easy Auth principal with roles claim}
```

**Response (200):**

```json
{ "sasUrl": "https://<account>.blob.core.windows.net/<container>/<blob>?..." }
```

### Legacy direct (unchanged)

```http
GET /api/GetSaasBlobUrl?path={path}&contactId={guid}
X-MS-TOKEN-AAD-ACCESS-TOKEN: {user token}
X-MS-CLIENT-PRINCIPAL: {user principal}
```

**Response:** `302 Redirect` to SAS URL

---

## File tree (changed project)

```text
KOFC.Azure.Functions.GetSaasBlobUrl/
├── GetSaasBlobUrl.cs              # MODIFIED — dual auth, format=json, POST
├── Program.cs                     # MODIFIED — MI blob + Dataverse DI
├── KOFC.Azure.Functions.GetSaasBlobUrl.csproj  # MODIFIED — new packages
├── Helpers/
│   └── FunctionAppRoleAuth.cs     # NEW
└── Services/
    ├── BlobService.cs             # MODIFIED — user delegation SAS, prefix strip
    ├── ContactAccessGuard.cs      # NEW
    ├── IContactAccessGuard.cs     # NEW
    ├── DataverseClientAdapter.cs  # NEW
    ├── DataverseClientFactory.cs  # NEW
    ├── IDataverseClient.cs        # NEW
    ├── DataverseService.cs        # unchanged (legacy)
    └── PrincipalService.cs        # unchanged (legacy)
```
