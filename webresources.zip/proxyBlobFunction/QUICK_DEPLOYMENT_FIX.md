# Quick Fix: Functions Not Visible After Deployment

## Most Common Issue: Local Function Deployed

The `GetSaasBlobUrlLocal` function is for local testing only and shouldn't be in production.

**✅ FIXED:** Added to `.csproj` to exclude it from Release builds.

---

## Quick Diagnostic Steps

### 1. Check Function App Status

```bash
az functionapp show \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --query "{state:state, defaultHostName:defaultHostName}"
```

**Should show:** `"state": "Running"`

### 2. List Functions

```bash
az functionapp function list \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP
```

**Should see:** `GetSaasBlobUrl` function

### 3. Check Application Settings

```bash
az functionapp config appsettings list \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --query "[?name=='BLOB_CONNECTION_STRING' || name=='DataverseUrl']"
```

**Required:**
- `BLOB_CONNECTION_STRING` or `AzureWebJobsStorage`
- `DataverseUrl`
- `BlobContainerName`
- `FUNCTIONS_WORKER_RUNTIME=dotnet-isolated`

---

## Redeploy After Fix

```bash
cd MIS.Azure.Functions.GetSaasBlobUrl

# Clean and rebuild
dotnet clean
dotnet build -c Release

# Deploy
func azure functionapp publish YOUR-FUNCTION-APP
```

---

## Verify in Azure Portal

1. Go to **Function App** → **Functions**
2. Should see **GetSaasBlobUrl** (not GetSaasBlobUrlLocal)
3. Click on it → **Integration**
4. Should show: **HTTP (GET)** trigger

---

## If Still Not Visible

### Option 1: Restart Function App

```bash
az functionapp restart \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP
```

### Option 2: Check Logs

```bash
az webapp log tail \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP
```

Look for:
- Function registration messages
- Errors during startup
- Configuration issues

### Option 3: Test Endpoint Directly

Get function URL:
```bash
az functionapp function show \
  --name YOUR-FUNCTION-APP \
  --resource-group YOUR-RESOURCE-GROUP \
  --function-name GetSaasBlobUrl \
  --query invokeUrlTemplate -o tsv
```

Then test:
```bash
curl "https://YOUR-FUNCTION-APP.azurewebsites.net/api/GetSaasBlobUrl"
```

---

## Expected Results

**✅ Success:**
- Function listed in Azure Portal
- No errors in logs
- Endpoint accessible (returns 401 - expected without Easy Auth)

**❌ Failure:**
- Function not in list → Check deployment logs
- Errors in logs → Check configuration
- 500 errors → Check `BLOB_CONNECTION_STRING` is valid

---

## Common Errors

### "No functions found"

**Fix:**
1. Verify deployment succeeded
2. Check all DLLs are in deployment package
3. Restart function app
4. Check `FUNCTIONS_WORKER_RUNTIME=dotnet-isolated`

### "Function host is not running"

**Fix:**
```bash
az functionapp start --name YOUR-FUNCTION-APP --resource-group YOUR-RESOURCE-GROUP
```

### "The function runtime is unable to start"

**Fix:**
- Verify `BLOB_CONNECTION_STRING` is valid
- Check all required settings are configured
- Review function app logs for specific errors

---

See **DEPLOYMENT_TROUBLESHOOTING.md** for detailed troubleshooting.

