# Testing Authentication with Postman/Thunder Client

## Quick Setup Guide

### 1. Create Base64 Principal

Use this PowerShell script to generate the principal:

```powershell
# Generate test principal
$principal = @{
    auth_typ = "aad"
    claims = @(
        @{ typ = "name"; val = "Test User" },
        @{ typ = "oid"; val = "12345678-1234-1234-1234-123456789012" },
        @{ typ = "email"; val = "test@example.com" }
    )
} | ConvertTo-Json -Depth 10

$bytes = [System.Text.Encoding]::UTF8.GetBytes($principal)
$base64 = [Convert]::ToBase64String($bytes)
Write-Host "X-MS-CLIENT-PRINCIPAL: $base64"
```

### 2. Postman/Thunder Client Configuration

**Request:**
```
GET http://localhost:7071/api/GetSaasBlobUrl?path=D:\test\file.txt&contactId=12345678-1234-1234-1234-123456789012
```

**Headers:**
```
X-MS-TOKEN-AAD-ACCESS-TOKEN: YOUR_REAL_TOKEN_OR_TEST_TOKEN
X-MS-CLIENT-PRINCIPAL: eyJhdXRoX3R5cCI6ImFhZCIsImNsYWltcyI6W3sidHlwIjoibmFtZSIsInZhbCI6IlRlc3QgVXNlciJ9XX0=
X-MS-CLIENT-PRINCIPAL-NAME: Test User
X-MS-CLIENT-PRINCIPAL-ID: 12345678-1234-1234-1234-123456789012
```

### 3. Get Real Token for Dataverse

```powershell
# Azure CLI
az account get-access-token --resource https://yourorg.crm.dynamics.com --query accessToken -o tsv
```

Copy the token and use it in the `X-MS-TOKEN-AAD-ACCESS-TOKEN` header.

---

## Example Test Principal (Base64)

```
eyJhdXRoX3R5cCI6ImFhZCIsImNsYWltcyI6W3sidHlwIjoibmFtZSIsInZhbCI6IlRlc3QgVXNlciJ9LHsidHlwIjoib2lkIiwidmFsIjoiMTIzNDU2NzgtMTIzNC0xMjM0LTEyMzQtMTIzNDU2Nzg5MDEyIn1dfQ==
```

Decoded:
```json
{
  "auth_typ": "aad",
  "claims": [
    { "typ": "name", "val": "Test User" },
    { "typ": "oid", "val": "12345678-1234-1234-1234-123456789012" }
  ]
}
```

