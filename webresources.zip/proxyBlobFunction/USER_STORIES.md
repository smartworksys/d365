# User Stories - Azure Function App: GetSaasBlobUrl

## Overview

This document describes user stories for the GetSaasBlobUrl Azure Function App, which provides secure, authenticated access to Azure Blob Storage files via SAS URLs, integrated with Dynamics 365 for authorization.

---

## Epic 1: Secure File Access

### User Story 1.1: As a Dynamics 365 User
**As a** Dynamics 365 user  
**I want to** access files associated with contacts by clicking a link in the Timeline  
**So that** I can view documents without needing direct storage account access  

**Acceptance Criteria:**
- ✅ Click link in Dynamics 365 Timeline opens file in browser
- ✅ File opens automatically (no manual download step)
- ✅ Access is granted only if user has permission to view the contact
- ✅ File access expires after 15 minutes for security
- ✅ No access to storage account credentials required

**Technical Details:**
- Link format: `https://functionapp.azurewebsites.net/api/GetSaasBlobUrl?path=D:\...&contactId=GUID`
- Authentication via Azure AD Easy Auth
- Authorization validated via Dataverse API
- Returns 302 redirect to SAS URL

---

### User Story 1.2: As a Contact Owner
**As a** Dynamics 365 user who owns or has access to a contact record  
**I want to** access files related to that contact  
**So that** I can review client documents and attachments  

**Acceptance Criteria:**
- ✅ User can access files if they have read access to the contact in Dynamics 365
- ✅ Access is automatically denied if user doesn't have contact permissions
- ✅ Clear error message (403) if access is denied
- ✅ Files are accessible immediately without manual approval

**Business Rules:**
- Access control based on Dynamics 365 security roles
- Contact record ownership determines access
- Shared contacts allow access to all shared users

---

### User Story 1.3: As a Sales Manager
**As a** sales manager  
**I want to** share file links with my team members  
**So that** they can access client documents without security risks  

**Acceptance Criteria:**
- ✅ Links are automatically secured per user
- ✅ Each team member's access is validated individually
- ✅ No team member can access files they shouldn't have access to
- ✅ Links expire after 15 minutes for security

---

## Epic 2: Authentication & Authorization

### User Story 2.1: As an Authenticated User
**As a** user logged into Azure AD  
**I want to** be automatically authenticated when accessing files  
**So that** I don't need to enter credentials multiple times  

**Acceptance Criteria:**
- ✅ Single Sign-On (SSO) via Azure AD
- ✅ No manual login required if already logged in
- ✅ Seamless redirect to file after authentication
- ✅ Works across all Dynamics 365 sessions

**Technical Flow:**
1. User clicks link
2. Azure AD Easy Auth validates session
3. If not logged in, redirects to Azure AD login
4. After login, redirects back to function
5. Function processes request

---

### User Story 2.2: As a Security Administrator
**As a** security administrator  
**I want to** ensure only authorized users can access files  
**So that** sensitive client documents are protected  

**Acceptance Criteria:**
- ✅ All requests require Azure AD authentication
- ✅ Dataverse validates user access to contact records
- ✅ Unauthorized access attempts are logged and blocked
- ✅ Audit trail shows who accessed which files and when

**Security Requirements:**
- Multi-factor authentication (MFA) support via Azure AD
- Role-based access control (RBAC) in Dynamics 365
- Comprehensive logging in Application Insights

---

### User Story 2.3: As a Compliance Officer
**As a** compliance officer  
**I want to** track all file access attempts  
**So that** I can audit document access for regulatory compliance  

**Acceptance Criteria:**
- ✅ All access attempts are logged with user identity
- ✅ Successful and failed access attempts are recorded
- ✅ Logs include timestamp, user, contact, and file path
- ✅ Logs are stored in Application Insights for at least 90 days
- ✅ Logs can be exported for compliance reviews

---

## Epic 3: File Path Handling

### User Story 3.1: As a System Administrator
**As a** system administrator  
**I want** Windows file paths to be automatically converted to blob paths  
**So that** the system works with existing Dynamics 365 file references  

**Acceptance Criteria:**
- ✅ Windows paths like `D:\KOFCExt Extractions\folder\file.xlsx` are converted correctly
- ✅ Drive letters are removed automatically
- ✅ Backslashes are converted to forward slashes
- ✅ Path prefix "KOFCExt Extractions" is handled correctly
- ✅ Path normalization is logged for troubleshooting

**Examples:**
- Input: `D:\KOFCExt Extractions\09272024\000554\file.xlsx`
- Output: `KOFCExt Extractions/09272024/000554/file.xlsx`

---

### User Story 3.2: As a Developer
**As a** developer  
**I want** path normalization to handle various path formats  
**So that** the system is robust and handles edge cases  

**Acceptance Criteria:**
- ✅ Handles paths with spaces
- ✅ Handles special characters
- ✅ Handles paths with mixed case
- ✅ Trims leading/trailing whitespace
- ✅ Handles empty or invalid paths gracefully

---

## Epic 4: Error Handling

### User Story 4.1: As an End User
**As an** end user  
**I want** clear error messages when something goes wrong  
**So that** I understand what happened and can take appropriate action  

**Acceptance Criteria:**
- ✅ Clear error message for missing authentication (401)
- ✅ Clear error message for access denied (403)
- ✅ Clear error message for file not found (404)
- ✅ Clear error message for invalid parameters (400)
- ✅ Error messages are user-friendly, not technical jargon

**Error Messages:**
- 401: "Please log in to access this resource"
- 403: "You do not have permission to access this file"
- 404: "The requested file could not be found"
- 400: "Invalid request. Please check the link and try again"

---

### User Story 4.2: As a Support Technician
**As a** support technician  
**I want** detailed error logs  
**So that** I can quickly diagnose and resolve user issues  

**Acceptance Criteria:**
- ✅ Logs include full error details
- ✅ Logs include user identity and request parameters
- ✅ Logs include stack traces for exceptions
- ✅ Logs are searchable in Application Insights
- ✅ Correlation IDs link related log entries

---

## Epic 5: Performance & Reliability

### User Story 5.1: As an End User
**As an** end user  
**I want** files to load quickly  
**So that** I can access documents without delays  

**Acceptance Criteria:**
- ✅ File access completes in under 2 seconds
- ✅ No noticeable delay after clicking link
- ✅ System handles concurrent requests efficiently
- ✅ No timeout errors for valid requests

**Performance Targets:**
- Authentication: < 500ms
- Dataverse validation: < 500ms
- SAS generation: < 200ms
- Total: < 2 seconds

---

### User Story 5.2: As a System Administrator
**As a** system administrator  
**I want** the system to be highly available  
**So that** users can access files at any time  

**Acceptance Criteria:**
- ✅ System uptime > 99.9%
- ✅ Automatic scaling handles traffic spikes
- ✅ Failures are handled gracefully
- ✅ System recovers automatically from transient errors

---

## Epic 6: Integration

### User Story 6.1: As a Dynamics 365 Administrator
**As a** Dynamics 365 administrator  
**I want** the function to integrate seamlessly with Dynamics 365  
**So that** users have a unified experience  

**Acceptance Criteria:**
- ✅ Links work directly from Dynamics 365 Timeline
- ✅ No additional configuration required for users
- ✅ Integrates with existing Dynamics 365 security model
- ✅ Works with Dynamics 365 mobile app

---

### User Story 6.2: As a Developer
**As a** developer  
**I want** to easily add file links to Dynamics 365 records  
**So that** I can build customizations that leverage this functionality  

**Acceptance Criteria:**
- ✅ Simple URL format for links
- ✅ Clear documentation on how to construct links
- ✅ Works with JavaScript web resources
- ✅ Works with Power Automate flows

**Link Format:**
```
https://functionapp.azurewebsites.net/api/GetSaasBlobUrl?path={encoded_path}&contactId={contact_guid}
```

---

## Epic 7: Security

### User Story 7.1: As a Security Administrator
**As a** security administrator  
**I want** file access to expire automatically  
**So that** old links cannot be used indefinitely  

**Acceptance Criteria:**
- ✅ SAS URLs expire after 15 minutes
- ✅ Expired links return appropriate error
- ✅ Users must generate new links for expired files
- ✅ Expiration time is not configurable by users

---

### User Story 7.2: As a Security Administrator
**As a** security administrator  
**I want** read-only access to files  
**So that** users cannot modify or delete files through the link  

**Acceptance Criteria:**
- ✅ SAS URLs grant only read permissions
- ✅ Users cannot upload, modify, or delete via link
- ✅ Links cannot be used to enumerate storage account contents

---

## Personas

### Primary Personas

1. **Dynamics 365 User** (Primary)
   - Uses Dynamics 365 daily
   - Needs to access client documents
   - Not technical
   - Values: Ease of use, speed, reliability

2. **Sales Manager**
   - Manages team access to client documents
   - Needs audit trail
   - Values: Security, compliance, team efficiency

3. **System Administrator**
   - Manages Azure infrastructure
   - Troubleshoots issues
   - Values: Monitoring, logs, reliability

4. **Security Administrator**
   - Ensures data protection
   - Manages access controls
   - Values: Security, compliance, auditability

---

## Acceptance Criteria Summary

### Functional Requirements
- ✅ Users can access files via links from Dynamics 365
- ✅ Access is controlled by Dynamics 365 security roles
- ✅ Paths are automatically normalized
- ✅ Files open directly in browser
- ✅ Access expires after 15 minutes

### Non-Functional Requirements
- ✅ Response time < 2 seconds
- ✅ Uptime > 99.9%
- ✅ Comprehensive logging
- ✅ Security compliance
- ✅ Scalable architecture

### Technical Requirements
- ✅ Azure AD authentication
- ✅ Dataverse API integration
- ✅ Azure Blob Storage SAS URLs
- ✅ .NET 8 isolated process
- ✅ Application Insights monitoring

---

## User Journey

### Happy Path

1. User clicks link in Dynamics 365 Timeline
2. Browser navigates to Function App URL
3. Azure AD Easy Auth authenticates user (if not already)
4. Function extracts user identity and token
5. Function validates user access to contact via Dataverse
6. Function normalizes file path
7. Function generates SAS URL (15-min expiration)
8. Function returns 302 redirect to SAS URL
9. Browser opens file directly
10. User views file

**Total Time: < 2 seconds**

---

## Edge Cases

### EC1: User Not Logged In
- User clicks link
- Redirected to Azure AD login
- After login, redirected back to function
- Process continues normally

### EC2: User Lacks Contact Access
- User clicks link
- Function validates access
- Dataverse returns 403
- Function returns 403 to user
- Clear error message displayed

### EC3: File Not Found
- User clicks link
- All validations pass
- Blob doesn't exist in storage
- Function returns 404
- Clear error message displayed

### EC4: Expired Link
- User tries to use old link
- SAS token expired
- Blob storage returns error
- User needs to generate new link

### EC5: Invalid Path Format
- User clicks link with malformed path
- Path normalization fails
- Function returns 400
- Clear error message displayed

---

## Success Metrics

### User Satisfaction
- ✅ > 95% successful file access
- ✅ < 2% user-reported issues
- ✅ Average access time < 2 seconds

### Security
- ✅ 100% requests authenticated
- ✅ 0 unauthorized access incidents
- ✅ All access attempts logged

### Reliability
- ✅ > 99.9% uptime
- ✅ < 0.1% error rate
- ✅ Automatic failover working

---

## Future Enhancements

### Potential User Stories (Backlog)

1. **Bulk File Access**
   - As a user, I want to access multiple files at once
   
2. **File Preview**
   - As a user, I want to preview files without downloading
   
3. **Download Tracking**
   - As a manager, I want to see who downloaded which files
   
4. **Custom Expiration**
   - As an admin, I want to configure link expiration times
   
5. **File Sharing**
   - As a user, I want to share files with external users securely

